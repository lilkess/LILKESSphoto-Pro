// LILKESSphoto Pro - Windows desktop shell (Electron).
// The app is served from local files through a private "lkp://" address, so
// images, fonts and AI models load (fetch works) with no browser or web server.
const { app, BrowserWindow, Menu, shell, dialog, session, protocol, net } = require('electron');
const path = require('path'), fs = require('fs');
const { pathToFileURL } = require('url');

protocol.registerSchemesAsPrivileged([{
  scheme: 'lkp',
  privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true }
}]);

const WWW = app.isPackaged ? path.join(process.resourcesPath, 'www') : path.join(__dirname, '_www');
const ICON = path.join(__dirname, 'build', 'icon.ico');
let win = null, splash = null;

function fileArg(argv) {
  return argv.slice(1).find(a => /\.(psd|lkphoto|png|jpe?g|webp)$/i.test(a) && fs.existsSync(a));
}

async function openPath(f) {
  if (!win || !f) return;
  try {
    const b64 = fs.readFileSync(f).toString('base64');
    await win.webContents.executeJavaScript(
      `(()=>{const b=atob("${b64}"),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);` +
      `const file=new File([u],${JSON.stringify(path.basename(f))});` +
      `const w=document.getElementById('welcome');if(w)w.hidden=true;window.__openFile&&window.__openFile(file);})()`);
  } catch (e) { dialog.showErrorBox('Could not open file', String(e && e.message || e)); }
}

async function openDialog() {
  const r = await dialog.showOpenDialog(win, {
    title: 'Open', properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Images and projects', extensions: ['lkphoto', 'psd', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'] },
              { name: 'All files', extensions: ['*'] }]
  });
  if (!r.canceled) for (const f of r.filePaths) await openPath(f);
}

// Send a keyboard shortcut to the app (the app already handles all its shortcuts).
function key(k, mods) {
  return () => { if (!win) return; const wc = win.webContents;
    wc.sendInputEvent({ type: 'keyDown', keyCode: k, modifiers: mods });
    wc.sendInputEvent({ type: 'char', keyCode: k, modifiers: mods });
    wc.sendInputEvent({ type: 'keyUp', keyCode: k, modifiers: mods }); };
}

function buildMenu() {
  const t = [
    { label: '&File', submenu: [
      { label: 'Open…', accelerator: 'CmdOrCtrl+O', click: openDialog },
      { label: 'Save', click: key('S', ['control']) },
      { type: 'separator' },
      { label: 'Exit', accelerator: 'Alt+F4', click: () => app.quit() } ] },
    { label: '&Edit', submenu: [
      { label: 'Undo', click: key('Z', ['control']) },
      { label: 'Redo', click: key('Z', ['control', 'shift']) },
      { type: 'separator' },
      { label: 'Cut', click: key('X', ['control']) },
      { label: 'Copy', click: key('C', ['control']) },
      { label: 'Paste', click: key('V', ['control']) },
      { label: 'Select All', click: key('A', ['control']) } ] },
    { label: '&View', submenu: [
      { label: 'Toggle Full Screen', accelerator: 'F11', click: () => win && win.setFullScreen(!win.isFullScreen()) },
      { label: 'Zoom In (app UI)', accelerator: 'CmdOrCtrl+Plus', click: () => win && win.webContents.setZoomLevel(win.webContents.getZoomLevel() + 0.5) },
      { label: 'Zoom Out (app UI)', accelerator: 'CmdOrCtrl+Shift+-', click: () => win && win.webContents.setZoomLevel(win.webContents.getZoomLevel() - 0.5) },
      { label: 'Reset UI Zoom', click: () => win && win.webContents.setZoomLevel(0) },
      { type: 'separator' },
      { label: 'Reload', accelerator: 'CmdOrCtrl+R', click: () => win && win.reload() },
      { label: 'Developer Tools', accelerator: 'F12', click: () => win && win.webContents.toggleDevTools() } ] },
    { label: '&Window', submenu: [{ role: 'minimize' }, { role: 'togglefullscreen' }] },
    { label: '&Help', submenu: [
      { label: 'About LILKESSphoto Pro', click: () => dialog.showMessageBox(win, { type: 'info', title: 'About',
          message: 'LILKESSphoto Pro', detail: 'Version ' + app.getVersion() + '\nDesktop edition for Windows 10 / 11' }) } ] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

function createWindows() {
  splash = new BrowserWindow({ width: 360, height: 280, frame: false, resizable: false, movable: true,
    alwaysOnTop: true, center: true, backgroundColor: '#1e1e1e', icon: ICON, show: true });
  splash.loadFile(path.join(__dirname, 'splash.html'));

  win = new BrowserWindow({ width: 1400, height: 900, minWidth: 900, minHeight: 600, backgroundColor: '#1e1e1e',
    title: 'LILKESSphoto Pro', icon: ICON, show: false,
    webPreferences: { contextIsolation: true, sandbox: true, preload: path.join(__dirname, 'preload.js') } });
  buildMenu();
  win.loadURL('lkp://app/index.html');
  win.once('ready-to-show', () => { win.maximize(); win.show(); if (splash) { splash.destroy(); splash = null; } });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('lkp://')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); } });
  win.webContents.on('did-finish-load', () => { const f = fileArg(process.argv); if (f && !win.__opened) { win.__opened = true; openPath(f); } });
  win.webContents.on('did-fail-load', (e, code, desc, url) => {
    if (code !== -3) dialog.showErrorBox('LILKESSphoto Pro could not load', desc + '\n' + url + '\n\nApp folder: ' + WWW); });
  win.on('closed', () => { win = null; });
}

// Saving: show the normal Windows "Save as" box for downloads/exports.
function wireDownloads() {
  session.defaultSession.on('will-download', (e, item) => {
    const def = path.join(app.getPath('documents'), item.getFilename());
    item.setSaveDialogOptions({ defaultPath: def, title: 'Save' });
  });
}

const lock = app.requestSingleInstanceLock();
if (!lock) app.quit(); else {
  app.on('second-instance', (e, argv) => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); const f = fileArg(argv); if (f) openPath(f); } });
  app.whenReady().then(() => {
    // Serve ./www safely (no path escape) for lkp://app/...
    protocol.handle('lkp', req => {
      let rel = decodeURIComponent(new URL(req.url).pathname).replace(/^\/+/, '') || 'index.html';
      const full = path.normalize(path.join(WWW, rel));
      if (!full.startsWith(path.normalize(WWW + path.sep))) return new Response('Forbidden', { status: 403 });
      if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) return new Response('Not found: ' + rel, { status: 404 });
      return net.fetch(pathToFileURL(full).toString());
    });
    try {
      const allow = ['local-fonts', 'fileSystem', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen'];
      session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(allow.includes(perm)));
      session.defaultSession.setPermissionCheckHandler((wc, perm) => allow.includes(perm));
    } catch (e) {}
    wireDownloads();
    createWindows();
  });
  app.on('window-all-closed', () => app.quit());
}
