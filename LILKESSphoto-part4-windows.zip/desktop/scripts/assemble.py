"""Puts the 3 project parts in place at the repository root.
Works if you uploaded the ZIP files or already extracted them (also in sub-folders)."""
import glob, os, shutil, sys, zipfile

root = os.getcwd()
for z in sorted(glob.glob('LILKESSphoto-part*.zip')):
    print('Opening', z)
    zipfile.ZipFile(z).extractall('.')

def find_dirs(name, must_contain=None):
    out = []
    for dp, dn, _ in os.walk('.'):
        dn[:] = [d for d in dn if d not in ('node_modules', '.git', 'release', '_www', 'android')]
        if name in dn:
            p = os.path.join(dp, name)
            if must_contain is None or must_contain in p.replace('\\', '/'):
                out.append(p)
    return out

if not os.path.isfile('www/index.html'):
    hits = [p for p in glob.glob('**/www/index.html', recursive=True) if 'node_modules' not in p]
    if hits:
        base = os.path.dirname(os.path.dirname(hits[0]))
        print('Project found inside', base, '- copying it to the top')
        shutil.copytree(base, '.', dirs_exist_ok=True)
for d in ('store', 'models'):
    if not os.path.isdir(os.path.join('www', d)):
        for p in find_dirs(d, 'www'):
            print('Placing', d, 'from', p)
            shutil.copytree(p, os.path.join('www', d), dirs_exist_ok=True)
            break
cnt = lambda d: len(os.listdir(d)) if os.path.isdir(d) else 0
print('www/index.html :', os.path.isfile('www/index.html'))
print('www/store files:', cnt('www/store'))
print('www/models files:', cnt('www/models'))
if not os.path.isfile('www/index.html'):
    print('ERROR: www/index.html not found. Upload Part 1 (the app).'); sys.exit(1)
