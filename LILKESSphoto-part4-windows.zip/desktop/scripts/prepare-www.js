// Copies the app (../www) into desktop/_www so Electron Builder can pack it.
// Stops with a clear message if anything essential is missing.
const fs = require('fs'), path = require('path');
const src = path.resolve(__dirname, '..', '..', 'www');
const dst = path.resolve(__dirname, '..', '_www');
const must = ['index.html', 'js/app.js', 'js/packs.js', 'css/app.css', 'css/fonts.css',
  'models/u2netp.onnx', 'models/pphumanseg.onnx', 'img/logo96.png'];
const miss = must.filter(f => !fs.existsSync(path.join(src, f)));
if (!fs.existsSync(src) || miss.length) {
  console.error('ERROR: the app files are missing in: ' + src);
  miss.forEach(f => console.error('  missing: www/' + f));
  console.error('Upload Part 1, 2 and 3 of the project to the repository first.');
  process.exit(1);
}
const store = path.join(src, 'store');
const n = fs.existsSync(store) ? fs.readdirSync(store).length : 0;
if (n < 100) { console.error('ERROR: www/store has only ' + n + ' files (expected 156). Part 2 missing?'); process.exit(1); }
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
console.log('App copied: ' + dst + '  (store files: ' + n + ')');
