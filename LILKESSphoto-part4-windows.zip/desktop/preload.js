// Minimal, safe bridge. The app itself needs no Node access.
const { contextBridge } = require('electron');
contextBridge.exposeInMainWorld('LKP_DESKTOP', { platform: process.platform, isDesktop: true });
