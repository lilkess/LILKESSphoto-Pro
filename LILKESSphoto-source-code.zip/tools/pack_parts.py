#!/usr/bin/env python3
"""Zips the Capacitor project into parts that are each far below GitHub's 25 MB browser-upload limit."""
import os,zipfile,shutil,re
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));C=R+'/capacitor';D=R+'/dist_cap'
if os.path.exists(D):shutil.rmtree(D)
os.makedirs(D)
shutil.copy(R+'/tools/cap_static/README-PHONE-STEPS.txt',C+'/README-PHONE-STEPS.txt')
def zipit(name,items,base=C,pre=''):
    with zipfile.ZipFile(D+'/'+name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for it in items:
            p=base+'/'+it
            if os.path.isdir(p):
                for r,_,fs in os.walk(p):
                    for f in sorted(fs):full=os.path.join(r,f);z.write(full,pre+os.path.relpath(full,base))
            else:z.write(p,pre+it)
    print(name,'%.1f MB'%(os.path.getsize(D+'/'+name)/1048576))
zipit('LILKESSphoto-part1-app.zip',['package.json','capacitor.config.json','.gitignore','README-PHONE-STEPS.txt','scripts','tools','android-res','www/index.html','www/manifest.webmanifest','www/css','www/js','www/img','www/fonts'])
zipit('LILKESSphoto-part2-store.zip',['www/store'])
zipit('LILKESSphoto-part3-models.zip',['www/models'])
shutil.copy(C+'/.github/workflows/build-apk.yml',D+'/build-apk.yml')
shutil.copy(R+'/tools/cap_static/README-PHONE-STEPS.txt',D+'/README-PHONE-STEPS.txt')
# readable source code (data modules are left out: they are the store pictures and AI models already in parts 2 and 3)
S=D+'/_src';os.makedirs(S+'/src');os.makedirs(S+'/lib_adv')
for f in sorted(os.listdir(R+'/src')):
    if f.startswith(('m05zl','m05zv0','m05zv1')):continue
    shutil.copy(R+'/src/'+f,S+'/src/'+f)
for f in os.listdir(R+'/lib_adv'):
    if f.endswith('.js'):shutil.copy(R+'/lib_adv/'+f,S+'/lib_adv/'+f)
shutil.copytree(R+'/assets',S+'/assets');shutil.copytree(R+'/web',S+'/web',ignore=shutil.ignore_patterns('app.js','index.html','artifact.html','packs.js','model.js','model2.js'))
shutil.copytree(R+'/tools',S+'/tools',ignore=shutil.ignore_patterns('__pycache__','mkstore*.py','cap_static'));shutil.copytree(R+'/tools/cap_static',S+'/tools/cap_static')
shutil.copy(R+'/build.py',S+'/build.py')
open(S+'/README-SOURCE.txt','w').write('Readable source code of LILKESSphoto Pro (the program text only).\nsrc/ holds the program in numbered modules, lib_adv/ the image libraries, web/ the page and style templates.\nThe store pictures and AI models are not in this zip: they are in parts 2 and 3 (www/store and www/models).\ntools/build_capacitor.py rebuilds the Android project folder from these sources plus the store and model data.\nbuild.py builds the single-file web/PWA version.\n')
zipit('LILKESSphoto-source-code.zip',['src','lib_adv','assets','web','tools','build.py','README-SOURCE.txt'],base=S)
shutil.rmtree(S)
print('largest file in any part:',max(os.path.getsize(D+'/'+f) for f in os.listdir(D))//1024,'KB')
