// minimal ONNX reader (also the basis of the in-app runtime)
const fs=require('fs');
function rd(buf){let p=0;const u8=buf;
 const varint=()=>{let r=0,s=0,b;do{b=u8[p++];r+=(b&127)*Math.pow(2,s);s+=7;}while(b&128);return r;};
 return {more:()=>p<u8.length,tag:()=>{const t=varint();return [t>>>3,t&7];},varint,
  bytes:()=>{const n=varint();const s=u8.subarray(p,p+n);p+=n;return s;},
  f32:()=>{const v=new DataView(u8.buffer,u8.byteOffset+p,4).getFloat32(0,true);p+=4;return v;},
  skip:(w)=>{if(w===0)varint();else if(w===1)p+=8;else if(w===2){const n=varint();p+=n;}else if(w===5)p+=4;}};}
function parseTensor(b){const r=rd(b),t={dims:[],dt:1,name:'',raw:null,f:null,i64:[]};
 while(r.more()){const [f,w]=r.tag();
  if(f===1){if(w===2){const s=rd(r.bytes());while(s.more())t.dims.push(s.varint());}else t.dims.push(r.varint());}
  else if(f===2)t.dt=r.varint();else if(f===8)t.name=Buffer.from(r.bytes()).toString();else if(f===9)t.raw=r.bytes();
  else if(f===4&&w===2){const s=r.bytes();t.f=new Float32Array(s.buffer.slice(s.byteOffset,s.byteOffset+s.length));}
  else if(f===7){if(w===2){const s=rd(r.bytes());while(s.more())t.i64.push(s.varint());}else t.i64.push(r.varint());}
  else r.skip(w);}
 return t;}
function parseAttr(b){const r=rd(b),a={name:'',type:0};
 while(r.more()){const [f,w]=r.tag();
  if(f===1)a.name=Buffer.from(r.bytes()).toString();else if(f===2)a.f=r.f32();else if(f===3)a.i=r.varint();
  else if(f===4)a.s=Buffer.from(r.bytes()).toString();else if(f===5)a.t=parseTensor(r.bytes());
  else if(f===7){if(w===2){const s=r.bytes();a.floats=Array.from(new Float32Array(s.buffer.slice(s.byteOffset,s.byteOffset+s.length)));}else(a.floats=a.floats||[]).push(r.f32());}
  else if(f===8){a.ints=a.ints||[];if(w===2){const s=rd(r.bytes());while(s.more())a.ints.push(s.varint());}else a.ints.push(r.varint());}
  else if(f===20)a.type=r.varint();else r.skip(w);}
 return a;}
function parseNode(b){const r=rd(b),n={in:[],out:[],op:'',name:'',attr:{}};
 while(r.more()){const [f,w]=r.tag();
  if(f===1)n.in.push(Buffer.from(r.bytes()).toString());else if(f===2)n.out.push(Buffer.from(r.bytes()).toString());
  else if(f===3)n.name=Buffer.from(r.bytes()).toString();else if(f===4)n.op=Buffer.from(r.bytes()).toString();
  else if(f===5){const a=parseAttr(r.bytes());n.attr[a.name]=a;}else r.skip(w);}
 return n;}
function parseModel(buf){const r=rd(buf);let g=null;
 while(r.more()){const [f,w]=r.tag();if(f===7)g=r.bytes();else r.skip(w);}
 const gr=rd(g),G={nodes:[],init:{},inputs:[],outputs:[]};
 while(gr.more()){const [f,w]=gr.tag();
  if(f===1)G.nodes.push(parseNode(gr.bytes()));else if(f===5){const t=parseTensor(gr.bytes());G.init[t.name]=t;}
  else if(f===11||f===12){const vr=rd(gr.bytes());let nm='';while(vr.more()){const [ff,ww]=vr.tag();if(ff===1)nm=Buffer.from(vr.bytes()).toString();else vr.skip(ww);}(f===11?G.inputs:G.outputs).push(nm);}
  else gr.skip(w);}
 return G;}
module.exports={parseModel};
if(require.main===module){const G=parseModel(new Uint8Array(fs.readFileSync(process.argv[2])));
 const c={};G.nodes.forEach(n=>c[n.op]=(c[n.op]||0)+1);console.log(G.nodes.length,'nodes',c,'inputs',G.inputs.filter(i=>!G.init[i]),'outputs',G.outputs,'inits',Object.keys(G.init).length);
 const seen={};G.nodes.forEach(n=>{const k=n.op+':'+Object.values(n.attr).map(a=>a.name+'='+(a.ints?a.ints.join(','):a.s!==undefined?a.s:a.i!==undefined?a.i:a.f)).join(';');seen[k]=(seen[k]||0)+1;});
 console.log(Object.entries(seen).filter(([k])=>!k.startsWith('Conv')).map(e=>e.join(' x')).join('\n'));
 const cv={};G.nodes.filter(n=>n.op==='Conv').forEach(n=>{const w=G.init[n.in[1]];const k=(w?w.dims.join('x'):'?')+' '+(n.attr.dilations?n.attr.dilations.ints:'')+' '+(n.attr.pads?n.attr.pads.ints:'');cv[k]=(cv[k]||0)+1;});console.log(cv);}
