import base64,os,io,sys,logging
logging.disable(logging.CRITICAL)
from fontTools import subset
from fontTools.ttLib import TTFont
CF='/mnt/skills/examples/canvas-design/canvas-fonts/'
GF='/usr/share/fonts/truetype/google-fonts/'
INT='/usr/share/fonts/opentype/inter/'
LIB='/usr/share/fonts/truetype/liberation/'
CRO='/usr/share/fonts/truetype/crosextra/'
DJ='/usr/share/fonts/truetype/dejavu/'
def find(name):
    import subprocess
    r=subprocess.run(['fc-list',':family=%s'%name,'file'],capture_output=True,text=True).stdout
    return r
# (css family, weight, style, file, local aliases)
F=[]
def add(fam,w,st,f,loc=()):F.append((fam,w,st,f,loc))
for w,st,n in [(400,'normal','Regular'),(700,'normal','Bold'),(400,'italic','Italic'),(700,'italic','BoldItalic')]:
    add('Inter',w,st,INT+'Inter-%s.otf'%n)
    add('Poppins',w,st,GF+'Poppins-%s.ttf'%n)
    add('Work Sans',w,st,CF+'WorkSans-%s.ttf'%n)
    add('Instrument Sans',w,st,CF+'InstrumentSans-%s.ttf'%n)
    add('Lora',w,st,CF+'Lora-%s.ttf'%n)
    add('IBM Plex Serif',w,st,CF+'IBMPlexSerif-%s.ttf'%n)
    add('Arial',w,st,LIB+'LiberationSans-%s.ttf'%n,('Arial',))
    add('Helvetica',w,st,LIB+'LiberationSans-%s.ttf'%n,('Helvetica',))
    add('Times New Roman',w,st,LIB+'LiberationSerif-%s.ttf'%n,('Times New Roman',))
    add('Calibri',w,st,CRO+'Carlito-%s.ttf'%n,('Calibri',))
    add('Cambria',w,st,CRO+'Caladea-%s.ttf'%n,('Cambria',))
for w,st,n in [(400,'normal','Regular'),(700,'normal','Bold'),(400,'italic','Italic')]:
    add('Crimson Pro',w,st,CF+'CrimsonPro-%s.ttf'%n)
for w,n in [(400,'Regular'),(700,'Bold')]:
    add('Outfit',w,'normal',CF+'Outfit-%s.ttf'%n)
    add('Bricolage Grotesque',w,'normal',CF+'BricolageGrotesque-%s.ttf'%n)
    add('Big Shoulders Display',w,'normal',CF+'BigShoulders-%s.ttf'%n)
    add('National Park',w,'normal',CF+'NationalPark-%s.ttf'%n)
    add('JetBrains Mono',w,'normal',CF+'JetBrainsMono-%s.ttf'%n)
    add('IBM Plex Mono',w,'normal',CF+'IBMPlexMono-%s.ttf'%n)
    add('Red Hat Mono',w,'normal',CF+'RedHatMono-%s.ttf'%n)
    add('Geist Mono',w,'normal',CF+'GeistMono-%s.ttf'%n)
    add('Courier New',w,'normal',LIB+'LiberationMono-%s.ttf'%('Regular' if w==400 else 'Bold'),('Courier New',))
    add('Verdana',w,'normal',DJ+'DejaVuSans%s.ttf'%('' if w==400 else '-Bold'),('Verdana',))
    add('Tahoma',w,'normal',DJ+'DejaVuSans%s.ttf'%('' if w==400 else '-Bold'),('Tahoma',))
add('Smooch Sans',400,'normal',CF+'SmoochSans-Medium.ttf');add('Smooch Sans',700,'normal',CF+'SmoochSans-Medium.ttf')
add('Jura',400,'normal',CF+'Jura-Medium.ttf');add('Jura',700,'normal',CF+'Jura-Medium.ttf')
add('Tektur',400,'normal',CF+'Tektur-Regular.ttf');add('Tektur',700,'normal',CF+'Tektur-Medium.ttf')
add('Libre Baskerville',400,'normal',CF+'LibreBaskerville-Regular.ttf')
add('Gloock',400,'normal',CF+'Gloock-Regular.ttf')
add('Young Serif',400,'normal',CF+'YoungSerif-Regular.ttf')
add('Instrument Serif',400,'normal',CF+'InstrumentSerif-Regular.ttf');add('Instrument Serif',400,'italic',CF+'InstrumentSerif-Italic.ttf')
add('Italiana',400,'normal',CF+'Italiana-Regular.ttf')
add('Arsenal SC',400,'normal',CF+'ArsenalSC-Regular.ttf')
add('Erica One',400,'normal',CF+'EricaOne-Regular.ttf')
add('Boldonse',400,'normal',CF+'Boldonse-Regular.ttf')
add('Poiret One',400,'normal',CF+'PoiretOne-Regular.ttf')
add('Pixelify Sans',400,'normal',CF+'PixelifySans-Medium.ttf')
add('Silkscreen',400,'normal',CF+'Silkscreen-Regular.ttf')
add('Nothing You Could Do',400,'normal',CF+'NothingYouCouldDo-Regular.ttf')
add('DM Mono',400,'normal',CF+'DMMono-Regular.ttf')
# TeX Gyre / Charter / Utopia clones, found through fontconfig
import subprocess
def fcfile(pat):
    r=subprocess.run(['fc-match','-f','%{file}',pat],capture_output=True,text=True).stdout
    return r
for fam,pat,loc in [('Century Gothic','TeX Gyre Adventor','Century Gothic'),('Bookman Old Style','TeX Gyre Bonum','Bookman Old Style'),('Palatino Linotype','TeX Gyre Pagella','Palatino Linotype'),('Palatino','TeX Gyre Pagella','Palatino'),('Georgia','Bitstream Charter','Georgia'),('Monotype Corsiva','TeX Gyre Chorus','Monotype Corsiva')]:
    f=fcfile(pat)
    if os.path.exists(f):add(fam,400,'normal',f,(loc,))
    fb=fcfile(pat+':bold')
    if os.path.exists(fb) and fb!=f:add(fam,700,'normal',fb,(loc+' Bold',))
cache={}
uni=list(range(0x20,0x7f))+list(range(0xa0,0x180))+[0x2013,0x2014,0x2018,0x2019,0x201c,0x201d,0x2022,0x2026,0x20ac,0x2122,0x2190,0x2191,0x2192,0x2193,0x2605,0x2606,0x2665,0x2764,0x2713,0x00b7]
out=[];total=0
for fam,w,st,f,loc in F:
    if not os.path.exists(f):print('MISSING',f);continue
    if (f,loc) in cache:b64=cache[(f,loc)]
    else:
        opt=subset.Options();opt.flavor='woff';opt.layout_features=['kern','liga','calt','ccmp','locl','mark','mkmk'];opt.name_IDs=[1,2];opt.notdef_outline=True;opt.hinting=False
        try:font=TTFont(f,fontNumber=0)
        except Exception as e:
            print('SKIP',fam,f);continue
        s=subset.Subsetter(opt);s.populate(unicodes=uni);s.subset(font)
        font.flavor='woff';bio=io.BytesIO();font.save(bio);d=bio.getvalue();total+=len(d)
        b64=base64.b64encode(d).decode();cache[(f,loc)]=b64
    src=''.join("local('%s'),"%l for l in loc)+"url(data:font/woff;base64,%s) format('woff')"%b64
    out.append("@font-face{font-family:'%s';font-weight:%d;font-style:%s;font-display:swap;src:%s}"%(fam,w,st,src))
open('/home/claude/lkphoto/web/fonts_embed.css','w').write('\n'.join(out))
print(len(out),'faces',total//1024,'KB woff', os.path.getsize('/home/claude/lkphoto/web/fonts_embed.css')//1024,'KB css')
