#!/usr/bin/env python3
"""Builds the Capacitor / Android project folder (capacitor/) from the app sources.
Splits the 34 MB single-file app into small separate files:
  index.html, css/, fonts/, img/, js/app.js, js/packs.js, store/*.webp|jpg, models/*.onnx"""
import os,re,json,base64,glob,shutil,sys
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
O=R+'/capacitor'
if os.path.exists(O):shutil.rmtree(O)
for d in ('www/css','www/fonts','www/img','www/js','www/store','www/models','scripts','tools','android-res'):os.makedirs(O+'/'+d)
w=lambda p,s,m='w':open(O+'/'+p,m).write(s)
# ---- 1. code, split into: main app, store pack data, model data
fl=sorted(glob.glob(R+'/src/m0*.js'))
pre=[f for f in fl if os.path.basename(f)<'m05b'];post=[f for f in fl if os.path.basename(f)>='m05b']
libs=[R+'/lib_adv/'+n for n in ('cut_select.js','fxr_layerstyle.js','vec_paths.js','raw_camera.js','onnx_rt.js','onnx_gl.js') if os.path.exists(R+'/lib_adv/'+n)]
isdata=lambda f:os.path.basename(f).startswith('m05zl');ismodel=lambda f:os.path.basename(f).startswith(('m05zv0','m05zv1'))
rd=lambda f:open(f).read()
app_js='\n'.join(rd(f) for f in pre+libs+post if not isdata(f) and not ismodel(f))
w('www/js/app.js',app_js)
# ---- 2. store pictures: base64 text -> real image files
store=[];other=[];seen=set();nimg=0
for f in [f for f in post if isdata(f)]:
    t=rd(f);m=re.search(r'const (KESS_PACK\d*)=(\[.*\]);\s*$',t,re.S)
    if not m:other.append(t);continue
    for e in json.loads(m.group(2)):
        ext={'image/webp':'webp','image/jpeg':'jpg','image/png':'png'}[e['mime']]
        base=re.sub(r'[^A-Za-z0-9_-]','_',e['id']);name=base;k=2
        while name in seen:name=base+'_'+str(k);k+=1
        seen.add(name);fn='store/%s.%s'%(name,ext)
        w('www/'+fn,base64.b64decode(e['data']),'wb');nimg+=1
        e2={k2:v for k2,v in e.items() if k2!='data'};e2['file']=fn;store.append(e2)
w('www/js/packs.js','/* store pictures are separate files in store/ */\nconst KESS_PACK='+json.dumps(store,separators=(',',':'))+';\n'+'\n'.join(other)+'\n')
# ---- 3. AI models: base64 text -> real .onnx files
for fn,var,out in (('m05zv0','U2NETP_B64','u2netp.onnx'),('m05zv1','PPHS_B64','pphumanseg.onnx')):
    f=[x for x in post if fn in os.path.basename(x)][0];m=re.search(var+r'="([A-Za-z0-9+/=]+)"',rd(f))
    w('www/models/'+out,base64.b64decode(m.group(1)),'wb')
# ---- 4. fonts: 98 base64 @font-face rules -> font files
fc=rd(R+'/web/fonts_embed.css');seenf={}
def fontrep(m):
    fam,wt,st,loc,ext,b=m.groups()
    base=re.sub(r'[^a-z0-9]+','-',fam.lower())+'-'+wt+('-i' if st=='italic' else '');n=seenf.get(base,0);seenf[base]=n+1
    fn='fonts/%s%s.%s'%(base,'' if not n else '-'+str(n),ext);w('www/'+fn,base64.b64decode(b),'wb')
    return "@font-face{font-family:'%s';font-weight:%s;font-style:%s;font-display:swap;src:%surl(../%s) format('%s')"%(fam,wt,st,loc or '',fn,'woff2' if ext=='woff2' else 'woff')
fc2=re.sub(r"@font-face\{font-family:'([^']+)';font-weight:(\d+);font-style:(\w+);font-display:swap;src:(local\('[^']*'\),)?url\(data:font/(woff2?);base64,([A-Za-z0-9+/=]+)\)(?: format\('[^']*'\))?",fontrep,fc)
assert 'base64' not in fc2,'a font was left embedded'
w('www/css/fonts.css',fc2)
# ---- 5. images in css / splash
for n in ('logo96.png','splash.jpg'):shutil.copy(R+'/assets/'+n,O+'/www/img/'+n)
css=rd(R+'/web/head.css').replace('url(data:image/png;base64,{{LOGO}})','url(../img/logo96.png)');assert '{{' not in css
w('www/css/app.css',css)
body=rd(R+'/web/splash.html').replace('data:image/jpeg;base64,{{SPLASH}}','img/splash.jpg')+rd(R+'/web/body.html');assert '{{' not in body
gf=re.search(r'fonts=\'(<link[^\n]*?>)\'',rd(R+'/build.py')).group(1)
for n in ('icon-192.png','icon-512.png','icon-180.png'):shutil.copy(R+'/assets/'+n,O+'/www/img/'+n)
w('www/manifest.webmanifest',json.dumps({"name":"LILKESSphoto Pro","short_name":"LILKESSphoto","start_url":"index.html","display":"standalone","background_color":"#252525","theme_color":"#252525","icons":[{"src":"img/icon-192.png","sizes":"192x192","type":"image/png"},{"src":"img/icon-512.png","sizes":"512x512","type":"image/png"}]}))
html=('<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1,user-scalable=no">\n'
 '<title>LILKESSphoto Pro</title><meta name="theme-color" content="#252525"><link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="img/icon-192.png">\n'
 +gf+'\n<link rel="stylesheet" href="css/fonts.css"><link rel="stylesheet" href="css/app.css">\n</head><body>\n'+body+'\n'
 '<script>window.U2NETP_URL="models/u2netp.onnx";window.PPHS_URL="models/pphumanseg.onnx";</script>\n<script src="js/packs.js"></script>\n<script src="js/app.js"></script>\n</body></html>\n')
w('www/index.html',html)
# ---- 6. android resources (launcher icons for every density)
from PIL import Image
src=Image.open(R+'/assets/icon-512.png').convert('RGBA')
for d,s in (('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)):
    os.makedirs(O+'/android-res/mipmap-'+d,exist_ok=True)
    a=src.resize((s,s),Image.LANCZOS);a.save(O+'/android-res/mipmap-%s/ic_launcher.png'%d);a.save(O+'/android-res/mipmap-%s/ic_launcher_round.png'%d)
    fs=round(s*108/48);fg=Image.new('RGBA',(fs,fs),(0,0,0,0));k=round(fs*0.62);b=src.resize((k,k),Image.LANCZOS);fg.paste(b,((fs-k)//2,(fs-k)//2),b);fg.save(O+'/android-res/mipmap-%s/ic_launcher_foreground.png'%d)
print('store pictures:',nimg,' fonts:',sum(seenf.values()),' app.js KB:',len(app_js)//1024)

# ---- 7. static project files (config, workflow, scripts)
S=R+'/tools/cap_static'
for p in ('package.json','capacitor.config.json','.gitignore'):shutil.copy(S+'/'+p,O+'/'+p)
for p in ('scripts/apply_android_resources.py','tools/check_project.py'):shutil.copy(S+'/'+p,O+'/'+p)
os.makedirs(O+'/.github/workflows',exist_ok=True);shutil.copy(S+'/workflow/build-apk.yml',O+'/.github/workflows/build-apk.yml')
print('project built in',O)
