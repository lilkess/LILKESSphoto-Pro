#!/usr/bin/env python3
"""Checks that every file the app needs is present, before the build starts. Prints a plain list of problems."""
import os,re,json,sys
bad=[];ok=0
def need(p,why):
    global ok
    if os.path.isfile(p) and os.path.getsize(p)>0:ok+=1
    else:bad.append('MISSING  '+p+'   ('+why+')')
for p in ('package.json','capacitor.config.json','scripts/apply_android_resources.py'):need(p,'project file')
for p in ('package.json','capacitor.config.json'):
    try:json.load(open(p))
    except Exception as e:bad.append('BROKEN   '+p+': '+str(e))
if not os.path.isfile('www/index.html'):bad.append('MISSING  www/index.html   (part 1 of the project did not open)')
else:
    h=open('www/index.html').read()
    for m in re.findall(r'(?:src|href)="([^"#?]+)"',h):
        if m.startswith(('http','data:')):continue
        need('www/'+m,'used by index.html')
    for m in re.findall(r'"(models/[^"]+)"',h):need('www/'+m,'AI model (part 3)')
    for css in re.findall(r'href="(css/[^"]+)"',h):
        for u in re.findall(r'url\(([^)]+)\)',open('www/'+css).read() if os.path.isfile('www/'+css) else ''):
            u=u.strip('\'"')
            if not u.startswith(('data:','http')):need(os.path.normpath('www/css/'+u),'used by '+css)
    if os.path.isfile('www/js/packs.js'):
        for f in set(re.findall(r'"file":"([^"]+)"',open('www/js/packs.js').read())):need('www/'+f,'store picture (part 2)')
for m in ('www/js/app.js','www/js/packs.js'):
    if os.path.isfile(m) and os.path.getsize(m)<1000:bad.append('TOO SMALL '+m)
total=sum(os.path.getsize(os.path.join(r,f)) for r,_,fs in os.walk('www') for f in fs) if os.path.isdir('www') else 0
print('files checked:',ok,' www size: %.1f MB'%(total/1048576))
if bad:
    print('\nPROBLEMS FOUND:');print('\n'.join(bad[:60]))
    print('\nUpload the missing project part(s) listed above (see the README), then run the build again.')
    sys.exit(1)
print('Everything is present.')
