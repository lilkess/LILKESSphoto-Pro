LILKESSphoto Pro - build the Android APK from your phone (free, no Android Studio)
==================================================================================
What you have (download all of them from the chat, do NOT open/extract the zips):
  LILKESSphoto-part1-app.zip      the app, fonts, icons and build settings
  LILKESSphoto-part2-store.zip    the 156 store pictures
  LILKESSphoto-part3-models.zip   the 2 AI model files (Select Subject / Remove Background)
  build-apk.yml                   the build recipe for GitHub (a text file)
  (optional) LILKESSphoto-source-code.zip   readable source code for future work; not needed for the build

Every zip is under 25 MB, so the GitHub website accepts it. The build opens the zips by itself.

STEP 1 - Upload the three parts
  1. Open https://github.com/lilkess/LILKESSphoto-Pro in Chrome on your phone and sign in.
  2. Tap "Add file" > "Upload files".
  3. Choose part1, part2 and part3 zips (select all three at once).
  4. Wait until all three show a full bar, then tap "Commit changes".

STEP 2 - Add the build recipe
  1. Tap "Add file" > "Create new file".
  2. In the name box type exactly:   .github/workflows/build-apk.yml
     (typing the / makes the folders for you)
  3. Open the build-apk.yml file on your phone, select all the text, copy it,
     and paste it into the big box on GitHub.
  4. Tap "Commit changes" > "Commit changes".

STEP 3 - Run the build
  1. Tap the "Actions" tab. If GitHub asks, tap "I understand my workflows, go ahead and enable them".
  2. Tap "Build Android APK" in the left list (on a phone: the list at the top).
  3. Tap "Run workflow" > the green "Run workflow" button.
  4. Wait about 8 to 15 minutes. A yellow dot means it is working, a green tick means done.

STEP 4 - Get the APK
  1. Tap the finished run (green tick). Scroll to the bottom to "Artifacts".
  2. Tap "LILKESSphoto-Pro-APK" to download a zip. Open it with Files and extract it.
  3. Tap app-debug.apk. Android asks you to allow "Install unknown apps" for your browser/Files: allow it, then install.

If the run shows a red cross
  - Tap the run, then tap the step with the red cross, and take a screenshot of the red lines.
  - The step "Check that no file is missing" lists any missing file by name. Upload that part again.
  - Send me the screenshot and I will fix it.

Notes
  - This builds a "debug" APK. It installs and runs fine for yourself and for friends. Google Play needs a
    signed "release" build; that is a separate step I can add later.
  - Saving a picture in the Android app opens the Android share sheet ("Pick where to save it") - choose Files / Drive / Gallery.
  - This build recipe has not been run on GitHub yet. If something fails, the red lines will tell us what to fix.
