#!/usr/bin/env python3
"""Runs in the build after `npx cap add android`: launcher icons, large-image memory, build memory."""
import os,re,shutil,sys
A='android/app/src/main'
if not os.path.isdir(A):sys.exit('The android folder was not created. Look at the "Create the Android project" step.')
# 1. icons
n=0
for d in os.listdir('android-res'):
    src='android-res/'+d;dst=A+'/res/'+d
    if os.path.isdir(src):
        os.makedirs(dst,exist_ok=True)
        for f in os.listdir(src):shutil.copy(src+'/'+f,dst+'/'+f);n+=1
print('icons copied:',n)
bg=A+'/res/values/ic_launcher_background.xml'
if os.path.exists(bg):
    t=open(bg).read();t=re.sub(r'(<color name="ic_launcher_background">)[^<]*(</color>)',r'\1#252525\2',t);open(bg,'w').write(t)
# 2. photo editing needs a big memory heap
mf=A+'/AndroidManifest.xml';t=open(mf).read()
if 'android:largeHeap' not in t:
    t=t.replace('<application','<application android:largeHeap="true"',1);open(mf,'w').write(t);print('largeHeap on')
# 3. more memory for the Gradle build itself
gp='android/gradle.properties';t=open(gp).read() if os.path.exists(gp) else ''
t=re.sub(r'^org\.gradle\.jvmargs=.*\n?','',t,flags=re.M)+'\norg.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8\n';open(gp,'w').write(t)
print('done')
