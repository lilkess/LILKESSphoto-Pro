import os,sys,re,glob
R='/home/claude/lkphoto'
fl=sorted(glob.glob(R+'/src/m0*.js'))
pre=[f for f in fl if os.path.basename(f)<'m05b']
post=[f for f in fl if os.path.basename(f)>='m05b']
libs=[R+'/lib_adv/'+n for n in ('cut_select.js','fxr_layerstyle.js','vec_paths.js','raw_camera.js','onnx_rt.js','onnx_gl.js') if os.path.exists(R+'/lib_adv/'+n)]
isdata=lambda f:os.path.basename(f).startswith('m05zl')
ismodel=lambda f:os.path.basename(f).startswith(('m05zv0','m05zv1'))
js='\n'.join(open(f).read() for f in pre+libs+post)
js_main='\n'.join(open(f).read() for f in pre+libs+post if not isdata(f) and not ismodel(f))
open(R+'/web/model.js','w').write(open([f for f in post if 'm05zv0' in f][0]).read())
open(R+'/web/model2.js','w').write(open([f for f in post if 'm05zv1' in f][0]).read())
packs_js='\n'.join(open(f).read() for f in post if isdata(f))
open(R+'/web/packs.js','w').write(packs_js)
open(R+'/web/app.js','w').write(js)
import base64
b64=lambda f:base64.b64encode(open(R+'/assets/'+f,'rb').read()).decode()
css=open(R+'/web/head.css').read().replace('{{LOGO}}',b64('logo96.png'))
if os.path.exists(R+'/web/fonts_embed.css'):css+='\n'+open(R+'/web/fonts_embed.css').read()
body=open(R+'/web/splash.html').read().replace('{{SPLASH}}',b64('splash.jpg'))+open(R+'/web/body.html').read()
fonts='<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Anton&family=Bebas+Neue&family=Dancing+Script:wght@700&family=Lobster&family=Montserrat:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Oswald:wght@400;700&family=Pacifico&family=Permanent+Marker&family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&family=Roboto+Slab:wght@400;700&display=swap">'
frag0='<title>LILKESSphoto Pro</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'+fonts+'\n<style>\n'+css+'</style>\n'+body+'\n<script>\n'+js+'\n</script>\n'
frag=frag0
art=frag0.replace('\n<script>\n'+js+'\n</script>\n','\n<script src="packs.js"></script>\n<script src="model.js"></script>\n<script src="model2.js"></script>\n<script>\n'+js_main+'\n</script>\n')
open(R+'/web/artifact.html','w').write(art)
pwa='<link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#252525"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><link rel="apple-touch-icon" href="icon-180.png"><link rel="icon" href="icon-192.png">'
sa='<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1,user-scalable=no">\n'+pwa+'\n'+frag.replace('<meta name="claude:viewport-fit-sides" content="cover">\n','')+'</body></html>\n'
sa=sa.replace('</head>','')  # title/style/body follow head tags
sa=sa.replace('<title>','<title>',1)
# put style in head properly
sa=sa.replace('<style>','<style>',1)
sa=re.sub(r'(</style>)',r'\1\n</head><body>',sa,count=1)
sa+=''
open(R+'/web/index.html','w').write(sa)
print(len(js),len(frag))
