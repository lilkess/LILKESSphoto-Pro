/* vec_ : small vector path toolkit.  path={subs:[{closed,pts:[{x,y,ix,iy,ox,oy}]}]}  (handles are absolute points; equal to the anchor = corner) */
function vec_pt(x,y){return {x,y,ix:x,iy:y,ox:x,oy:y};}
function vec_clone(p){return JSON.parse(JSON.stringify(p));}
function vec_hasH(q){return q.ix!==q.x||q.iy!==q.y||q.ox!==q.x||q.oy!==q.y;}
function vec_tpt(q,m){
  const f=(x,y)=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]],a=f(q.x,q.y),i=f(q.ix,q.iy),o=f(q.ox,q.oy);
  return {x:a[0],y:a[1],ix:i[0],iy:i[1],ox:o[0],oy:o[1]};
}
function vec_transform(path,m){return {subs:path.subs.map(s=>({closed:s.closed,pts:s.pts.map(q=>vec_tpt(q,m))}))};}
function vec_translate(path,dx,dy){return vec_transform(path,[1,0,0,1,dx,dy]);}
function vec_trace(ctx,path,m){
  const P=path.subs;
  for(const s of P){
    const pts=m?s.pts.map(q=>vec_tpt(q,m)):s.pts;if(!pts.length)continue;
    ctx.moveTo(pts[0].x,pts[0].y);
    const n=pts.length,end=s.closed?n:n-1;
    for(let j=0;j<end;j++){
      const a=pts[j],b=pts[(j+1)%n];
      if(!vec_hasH(a)&&!vec_hasH(b))ctx.lineTo(b.x,b.y);else ctx.bezierCurveTo(a.ox,a.oy,b.ix,b.iy,b.x,b.y);
    }
    if(s.closed)ctx.closePath();
  }
}
function vec_toPath2D(path,m){const p=new Path2D();vec_trace(p,path,m);return p;}
function vec_bez(a,b,t){
  const u=1-t,c1x=a.ox,c1y=a.oy,c2x=b.ix,c2y=b.iy;
  return {x:u*u*u*a.x+3*u*u*t*c1x+3*u*t*t*c2x+t*t*t*b.x,y:u*u*u*a.y+3*u*u*t*c1y+3*u*t*t*c2y+t*t*t*b.y};
}
function vec_segs(s){const n=s.pts.length,out=[],end=s.closed?n:n-1;for(let j=0;j<end;j++)out.push([s.pts[j],s.pts[(j+1)%n]]);return out;}
function vec_flatten(path,tol){
  tol=tol||0.5;const out=[];
  for(const s of path.subs){
    const pts=[];if(!s.pts.length)continue;pts.push({x:s.pts[0].x,y:s.pts[0].y});
    for(const [a,b] of vec_segs(s)){
      if(!vec_hasH(a)&&!vec_hasH(b)){pts.push({x:b.x,y:b.y});continue;}
      const L=Math.hypot(a.ox-a.x,a.oy-a.y)+Math.hypot(b.ix-a.ox,b.iy-a.oy)+Math.hypot(b.x-b.ix,b.y-b.iy);
      const n=Math.max(4,Math.min(80,Math.ceil(Math.sqrt(L/tol)*1.6)));
      for(let k=1;k<=n;k++)pts.push(vec_bez(a,b,k/n));
    }
    out.push({closed:s.closed,pts});
  }
  return out;
}
function vec_bounds(path){
  let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  for(const f of vec_flatten(path,0.3))for(const p of f.pts){if(p.x<x0)x0=p.x;if(p.x>x1)x1=p.x;if(p.y<y0)y0=p.y;if(p.y>y1)y1=p.y;}
  return {x0,y0,x1,y1};
}
function vec_pointInPath(path,x,y,rule){
  let w=0,c=0;
  for(const f of vec_flatten(path,0.5)){
    const p=f.pts;
    for(let i=0;i<p.length;i++){
      const a=p[i],b=p[(i+1)%p.length];
      if((a.y<=y)!==(b.y<=y)){const t=(y-a.y)/(b.y-a.y),xi=a.x+t*(b.x-a.x);if(xi>x){c++;w+=b.y>a.y?1:-1;}}
    }
  }
  return rule==='evenodd'?(c&1)===1:w!==0;
}
function vec_distSeg(px,py,ax,ay,bx,by){
  const dx=bx-ax,dy=by-ay,l=dx*dx+dy*dy;let t=l?((px-ax)*dx+(py-ay)*dy)/l:0;t=Math.max(0,Math.min(1,t));
  return Math.hypot(px-(ax+dx*t),py-(ay+dy*t));
}
function vec_hitTest(path,x,y,tolA,tolH,tolS){
  const subs=path.subs;
  for(let i=0;i<subs.length;i++)for(let j=0;j<subs[i].pts.length;j++){const q=subs[i].pts[j];if(Math.hypot(x-q.x,y-q.y)<=tolA)return {type:'anchor',sub:i,pt:j};}
  for(let i=0;i<subs.length;i++)for(let j=0;j<subs[i].pts.length;j++){
    const q=subs[i].pts[j];
    if((q.ix!==q.x||q.iy!==q.y)&&Math.hypot(x-q.ix,y-q.iy)<=tolH)return {type:'in',sub:i,pt:j};
    if((q.ox!==q.x||q.oy!==q.y)&&Math.hypot(x-q.ox,y-q.oy)<=tolH)return {type:'out',sub:i,pt:j};
  }
  let best=null,bd=tolS;
  for(let i=0;i<subs.length;i++){
    const segs=vec_segs(subs[i]);
    for(let j=0;j<segs.length;j++){
      const [a,b]=segs[j];let prev={x:a.x,y:a.y};const n=a.ox===a.x&&a.oy===a.y&&b.ix===b.x&&b.iy===b.y?1:24;
      for(let k=1;k<=n;k++){
        const t=k/n,cur=n===1?{x:b.x,y:b.y}:vec_bez(a,b,t),d=vec_distSeg(x,y,prev.x,prev.y,cur.x,cur.y);
        if(d<bd){bd=d;best={type:'segment',sub:i,pt:j,t:(k-0.5)/n};}prev=cur;
      }
    }
  }
  if(best)return best;
  return vec_pointInPath(path,x,y,'evenodd')?{type:'fill'}:null;
}
function vec_addPoint(sub,x,y,dx,dy){
  const q=vec_pt(x,y);
  if(dx!=null&&(Math.abs(dx-x)>1||Math.abs(dy-y)>1)){q.ox=dx;q.oy=dy;q.ix=2*x-dx;q.iy=2*y-dy;}
  sub.pts.push(q);return q;
}
function vec_closeSub(sub){sub.closed=true;}
function vec_moveAnchor(sub,j,dx,dy){const q=sub.pts[j];q.x+=dx;q.y+=dy;q.ix+=dx;q.iy+=dy;q.ox+=dx;q.oy+=dy;}
function vec_moveHandle(sub,j,which,x,y,brk){
  const q=sub.pts[j];
  if(which==='out'){
    const li=Math.hypot(q.ix-q.x,q.iy-q.y);q.ox=x;q.oy=y;
    if(!brk&&li>0.01){const d=Math.hypot(x-q.x,y-q.y)||1;q.ix=q.x-(x-q.x)/d*li;q.iy=q.y-(y-q.y)/d*li;}
    else if(!brk&&li<=0.01){q.ix=2*q.x-x;q.iy=2*q.y-y;}
  }else{
    const lo=Math.hypot(q.ox-q.x,q.oy-q.y);q.ix=x;q.iy=y;
    if(!brk&&lo>0.01){const d=Math.hypot(x-q.x,y-q.y)||1;q.ox=q.x-(x-q.x)/d*lo;q.oy=q.y-(y-q.y)/d*lo;}
    else if(!brk&&lo<=0.01){q.ox=2*q.x-x;q.oy=2*q.y-y;}
  }
}
function vec_insertPointAt(sub,j,t){
  const n=sub.pts.length,a=sub.pts[j],b=sub.pts[(j+1)%n];
  const L=(p,q,u)=>({x:p.x+(q.x-p.x)*u,y:p.y+(q.y-p.y)*u});
  const p0={x:a.x,y:a.y},p1={x:a.ox,y:a.oy},p2={x:b.ix,y:b.iy},p3={x:b.x,y:b.y};
  const q0=L(p0,p1,t),q1=L(p1,p2,t),q2=L(p2,p3,t),r0=L(q0,q1,t),r1=L(q1,q2,t),m=L(r0,r1,t);
  const straight=!vec_hasH(a)&&!vec_hasH(b);
  const np={x:m.x,y:m.y,ix:straight?m.x:r0.x,iy:straight?m.y:r0.y,ox:straight?m.x:r1.x,oy:straight?m.y:r1.y};
  if(!straight){a.ox=q0.x;a.oy=q0.y;b.ix=q2.x;b.iy=q2.y;}
  sub.pts.splice(j+1,0,np);return np;
}
function vec_deletePoint(sub,j){sub.pts.splice(j,1);return sub.pts.length<2;}
function vec_convertPoint(sub,j){
  const q=sub.pts[j],n=sub.pts.length;
  if(vec_hasH(q)){q.ix=q.x;q.iy=q.y;q.ox=q.x;q.oy=q.y;return;}
  const a=sub.pts[(j-1+n)%n],b=sub.pts[(j+1)%n];
  let dx=b.x-a.x,dy=b.y-a.y;const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
  const la=Math.hypot(q.x-a.x,q.y-a.y)/3,lb=Math.hypot(b.x-q.x,b.y-q.y)/3;
  q.ix=q.x-dx*la;q.iy=q.y-dy*la;q.ox=q.x+dx*lb;q.oy=q.y+dy*lb;
}
function vec_autoSmooth(sub,tension){
  const t=tension==null?0.5:tension,n=sub.pts.length,P=sub.pts;
  for(let j=0;j<n;j++){
    const q=P[j],closed=sub.closed;
    const a=(j>0||closed)?P[(j-1+n)%n]:null,b=(j<n-1||closed)?P[(j+1)%n]:null;
    if(!a||!b){
      const o=a||b;if(!o){continue;}
      q.ix=q.x;q.iy=q.y;q.ox=q.x;q.oy=q.y;
      const dx=(o.x-q.x)*t*0.6,dy=(o.y-q.y)*t*0.6;
      if(b){q.ox=q.x+dx;q.oy=q.y+dy;}else{q.ix=q.x+dx;q.iy=q.y+dy;}
      continue;
    }
    let tx=b.x-a.x,ty=b.y-a.y;const tl=Math.hypot(tx,ty)||1;tx/=tl;ty/=tl;
    const la=Math.hypot(q.x-a.x,q.y-a.y)*t*0.66,lb=Math.hypot(b.x-q.x,b.y-q.y)*t*0.66;
    q.ix=q.x-tx*la;q.iy=q.y-ty*la;q.ox=q.x+tx*lb;q.oy=q.y+ty*lb;
  }
}
function vec_dp(pts,tol,closed){
  if(pts.length<3)return pts.slice();
  const keep=new Uint8Array(pts.length);keep[0]=1;keep[pts.length-1]=1;
  const st=[[0,pts.length-1]];
  while(st.length){
    const [i,j]=st.pop();let md=0,mi=-1;
    for(let k=i+1;k<j;k++){const d=vec_distSeg(pts[k].x,pts[k].y,pts[i].x,pts[i].y,pts[j].x,pts[j].y);if(d>md){md=d;mi=k;}}
    if(md>tol&&mi>0){keep[mi]=1;st.push([i,mi],[mi,j]);}
  }
  return pts.filter((p,i)=>keep[i]);
}
function vec_fromPolyline(pts,closed,tol){
  tol=tol==null?2:tol;let s=vec_dp(pts,tol,closed);
  if(closed&&s.length>1&&Math.hypot(s[0].x-s[s.length-1].x,s[0].y-s[s.length-1].y)<1)s.pop();
  const sub={closed:!!closed,pts:s.map(p=>vec_pt(p.x,p.y))};vec_autoSmooth(sub,0.9);return sub;
}
/* SVG path data parser */
function vec_fromSVG(d){
  const tk=d.match(/[a-zA-Z]|-?\d*\.?\d+(?:e[-+]?\d+)?/g)||[],path={subs:[]};let i=0,cx=0,cy=0,sx=0,sy=0,cmd='',sub=null,lc=null,lq=null;
  const num=()=>parseFloat(tk[i++]);
  const start=(x,y)=>{sub={closed:false,pts:[vec_pt(x,y)]};path.subs.push(sub);cx=sx=x;cy=sy=y;};
  const cubic=(x1,y1,x2,y2,x,y)=>{const a=sub.pts[sub.pts.length-1];a.ox=x1;a.oy=y1;const q=vec_pt(x,y);q.ix=x2;q.iy=y2;sub.pts.push(q);cx=x;cy=y;lc=[x2,y2];};
  const arc=(rx,ry,rot,fa,fs,x,y)=>{
    if(!rx||!ry){sub.pts.push(vec_pt(x,y));cx=x;cy=y;return;}
    rx=Math.abs(rx);ry=Math.abs(ry);const ph=rot*Math.PI/180,c=Math.cos(ph),s=Math.sin(ph);
    const dx=(cx-x)/2,dy=(cy-y)/2,x1=c*dx+s*dy,y1=-s*dx+c*dy;
    let l=x1*x1/(rx*rx)+y1*y1/(ry*ry);if(l>1){const k=Math.sqrt(l);rx*=k;ry*=k;}
    const sg=fa===fs?-1:1,num2=rx*rx*ry*ry-rx*rx*y1*y1-ry*ry*x1*x1,den=rx*rx*y1*y1+ry*ry*x1*x1;
    const co=sg*Math.sqrt(Math.max(0,num2/den)),cxp=co*rx*y1/ry,cyp=-co*ry*x1/rx;
    const ccx=c*cxp-s*cyp+(cx+x)/2,ccy=s*cxp+c*cyp+(cy+y)/2;
    const ang=(ux,uy,vx,vy)=>{const a=Math.atan2(ux*vy-uy*vx,ux*vx+uy*vy);return a;};
    let t1=ang(1,0,(x1-cxp)/rx,(y1-cyp)/ry),dt=ang((x1-cxp)/rx,(y1-cyp)/ry,(-x1-cxp)/rx,(-y1-cyp)/ry);
    if(!fs&&dt>0)dt-=2*Math.PI;else if(fs&&dt<0)dt+=2*Math.PI;
    const n=Math.max(1,Math.ceil(Math.abs(dt)/(Math.PI/2))),da=dt/n,kk=4/3*Math.tan(da/4);
    for(let k=0;k<n;k++){
      const a1=t1+k*da,a2=a1+da,e1=[Math.cos(a1),Math.sin(a1)],e2=[Math.cos(a2),Math.sin(a2)];
      const P=(u,v)=>[ccx+rx*u*c-ry*v*s,ccy+rx*u*s+ry*v*c];
      const p1=P(e1[0]-kk*e1[1],e1[1]+kk*e1[0]),p2=P(e2[0]+kk*e2[1],e2[1]-kk*e2[0]),p3=P(e2[0],e2[1]);
      cubic(p1[0],p1[1],p2[0],p2[1],k===n-1?x:p3[0],k===n-1?y:p3[1]);
    }
  };
  while(i<tk.length){
    if(/[a-zA-Z]/.test(tk[i]))cmd=tk[i++];
    const rel=cmd===cmd.toLowerCase(),C=cmd.toUpperCase(),ox=rel?cx:0,oy=rel?cy:0;
    if(C==='Z'){if(sub){sub.closed=true;cx=sx;cy=sy;sub=null;}lc=lq=null;continue;}
    if(C==='M'){const x=num()+ox,y=num()+oy;start(x,y);cmd=rel?'l':'L';lc=lq=null;continue;}
    if(!sub)start(cx,cy);
    if(C==='L'){const x=num()+ox,y=num()+oy;sub.pts.push(vec_pt(x,y));cx=x;cy=y;lc=lq=null;}
    else if(C==='H'){const x=num()+ox;sub.pts.push(vec_pt(x,cy));cx=x;lc=lq=null;}
    else if(C==='V'){const y=num()+oy;sub.pts.push(vec_pt(cx,y));cy=y;lc=lq=null;}
    else if(C==='C'){const a=num()+ox,b=num()+oy,c2=num()+ox,d2=num()+oy,x=num()+ox,y=num()+oy;cubic(a,b,c2,d2,x,y);lq=null;}
    else if(C==='S'){const c2=num()+ox,d2=num()+oy,x=num()+ox,y=num()+oy;const r=lc?[2*cx-lc[0],2*cy-lc[1]]:[cx,cy];cubic(r[0],r[1],c2,d2,x,y);lq=null;}
    else if(C==='Q'){const qx=num()+ox,qy=num()+oy,x=num()+ox,y=num()+oy;cubic(cx+2/3*(qx-cx),cy+2/3*(qy-cy),x+2/3*(qx-x),y+2/3*(qy-y),x,y);lq=[qx,qy];lc=null;}
    else if(C==='T'){const x=num()+ox,y=num()+oy;const q=lq?[2*cx-lq[0],2*cy-lq[1]]:[cx,cy];cubic(cx+2/3*(q[0]-cx),cy+2/3*(q[1]-cy),x+2/3*(q[0]-x),y+2/3*(q[1]-y),x,y);lq=q;lc=null;}
    else if(C==='A'){const rx=num(),ry=num(),rot=num(),fa=num(),fs=num(),x=num()+ox,y=num()+oy;arc(rx,ry,rot,fa,fs,x,y);lc=lq=null;}
    else{i++;}
  }
  for(const s of path.subs){
    if(s.closed&&s.pts.length>1){const a=s.pts[0],b=s.pts[s.pts.length-1];if(Math.hypot(a.x-b.x,a.y-b.y)<1e-6){a.ix=b.ix;a.iy=b.iy;s.pts.pop();}}
  }
  path.subs=path.subs.filter(s=>s.pts.length>1);
  return path;
}
function vec_fit(path,x,y,w,h,keepAspect){
  const b=vec_bounds(path),bw=b.x1-b.x0||1,bh=b.y1-b.y0||1;let sx=w/bw,sy=h/bh,ox=x,oy=y;
  if(keepAspect){const k=Math.min(sx,sy);ox=x+(w-bw*k)/2;oy=y+(h-bh*k)/2;sx=sy=k;}
  return vec_transform(path,[sx,0,0,sy,ox-b.x0*sx,oy-b.y0*sy]);
}
/* custom shapes, 0..100 box, filled with even-odd */
const VEC_SHAPES=[
  ['heart','Heart','M50 90C20 66 6 48 6 32A22 22 0 0 1 50 24A22 22 0 0 1 94 32C94 48 80 66 50 90Z'],
  ['star5','Star','M50 6L61.8 38.2L96 39.4L69 60.6L78.5 93.6L50 74.2L21.5 93.6L31 60.6L4 39.4L38.2 38.2Z'],
  ['star6','Six point star','M50 4L62 28L90 27L76 50L90 73L62 72L50 96L38 72L10 73L24 50L10 27L38 28Z'],
  ['burst','Burst','M50 2L58 22L76 8L76 30L98 30L84 48L98 66L76 68L76 90L58 78L50 98L42 78L24 90L24 68L2 66L16 48L2 30L24 30L24 8L42 22Z'],
  ['bubble','Speech bubble','M50 10C26 10 6 25 6 44C6 56 14 66 26 72L20 92L44 77C46 77 48 78 50 78C74 78 94 63 94 44C94 25 74 10 50 10Z'],
  ['bubbleR','Speech box','M10 12H90V68H46L24 90V68H10Z'],
  ['cloud','Cloud','M26 78A20 20 0 0 1 24 40A26 26 0 0 1 72 28A22 22 0 0 1 80 78Z'],
  ['bolt','Lightning','M58 4L18 56H44L36 96L82 38H54Z'],
  ['arrowR','Arrow right','M6 38H58V14L96 50L58 86V62H6Z'],
  ['arrowL','Arrow left','M94 38H42V14L4 50L42 86V62H94Z'],
  ['arrowU','Arrow up','M38 94V42H14L50 4L86 42H62V94Z'],
  ['arrowD','Arrow down','M38 6V58H14L50 96L86 58H62V6Z'],
  ['arrow2','Double arrow','M4 50L28 24V40H72V24L96 50L72 76V60H28V76Z'],
  ['chevron','Chevron','M14 8L58 8L90 50L58 92L14 92L46 50Z'],
  ['check','Check mark','M6 54L22 38L38 54L78 12L94 28L38 86Z'],
  ['plus','Plus','M38 6H62V38H94V62H62V94H38V62H6V38H38Z'],
  ['minus','Minus','M6 38H94V62H6Z'],
  ['cross','Cross','M24 6L50 32L76 6L94 24L68 50L94 76L76 94L50 68L24 94L6 76L32 50L6 24Z'],
  ['crown','Crown','M6 78L12 28L34 52L50 16L66 52L88 28L94 78Z'],
  ['sun','Sun','M50 28A22 22 0 1 0 50 72A22 22 0 1 0 50 28ZM46 2H54V18H46ZM46 82H54V98H46ZM2 46H18V54H2ZM82 46H98V54H82ZM14 14L20 8L31 19L25 25ZM69 75L75 69L86 80L80 86ZM14 86L8 80L19 69L25 75ZM69 25L80 14L86 20L75 31Z'],
  ['moon','Crescent moon','M64 6A44 44 0 1 0 94 70A36 36 0 0 1 64 6Z'],
  ['leaf','Leaf','M10 90C10 40 40 10 92 8C94 60 64 90 10 90ZM10 90L58 42'],
  ['drop','Drop','M50 4C50 4 18 42 18 64A32 32 0 0 0 82 64C82 42 50 4 50 4Z'],
  ['flower','Flower','M50 38A12 12 0 1 0 50 62A12 12 0 1 0 50 38ZM50 4A18 18 0 0 1 50 38A18 18 0 0 1 50 4ZM96 40A18 18 0 0 1 62 50A18 18 0 0 1 96 40ZM80 92A18 18 0 0 1 56 62A18 18 0 0 1 80 92ZM20 92A18 18 0 0 1 44 62A18 18 0 0 1 20 92ZM4 40A18 18 0 0 1 38 50A18 18 0 0 1 4 40Z'],
  ['shield','Shield','M50 4L88 16V46C88 70 72 86 50 96C28 86 12 70 12 46V16Z'],
  ['banner','Ribbon banner','M2 24H98L86 50L98 76H2L14 50Z'],
  ['ticket','Ticket','M4 20H96V40A10 10 0 0 0 96 60V80H4V60A10 10 0 0 0 4 40Z'],
  ['diamond','Diamond','M50 4L96 50L50 96L4 50Z'],
  ['hexagon','Hexagon','M26 8H74L98 50L74 92H26L2 50Z'],
  ['octagon','Octagon','M30 4H70L96 30V70L70 96H30L4 70V30Z'],
  ['pentagon','Pentagon','M50 4L96 38L78 94H22L4 38Z'],
  ['trapezoid','Trapezoid','M24 18H76L98 82H2Z'],
  ['parallelogram','Parallelogram','M26 18H98L74 82H2Z'],
  ['gear','Gear','M42 4H58L60 16L70 20L80 12L90 22L82 32L86 42L98 44V60L86 62L82 72L90 82L80 92L70 84L60 88L58 98H42L40 88L30 84L20 92L10 82L18 72L14 62L2 60V44L14 42L18 32L10 22L20 12L30 20L40 16ZM50 34A16 16 0 1 0 50 66A16 16 0 1 0 50 34Z'],
  ['home','House','M50 6L96 46H82V92H58V62H42V92H18V46H4Z'],
  ['pin','Location pin','M50 4C30 4 16 19 16 38C16 62 50 96 50 96C50 96 84 62 84 38C84 19 70 4 50 4ZM50 26A12 12 0 1 1 50 50A12 12 0 1 1 50 26Z'],
  ['note','Music note','M36 8L88 2V68A16 14 0 1 1 74 56V24L48 28V78A16 14 0 1 1 36 66Z'],
  ['envelope','Envelope','M4 18H96V82H4ZM12 26L50 54L88 26ZM12 74H88V38L50 66L12 38Z'],
  ['bookmark','Bookmark','M22 4H78V96L50 72L22 96Z'],
  ['tag','Tag','M4 8H54L96 50L50 96L4 50ZM24 22A8 8 0 1 0 24 38A8 8 0 1 0 24 22Z'],
  ['flag','Flag','M14 4H24V96H14ZM28 8C48 -2 62 18 90 8V52C62 62 48 42 28 52Z'],
  ['ring','Ring','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM50 24A26 26 0 1 1 50 76A26 26 0 1 1 50 24Z'],
  ['frame','Frame','M4 4H96V96H4ZM18 18V82H82V18Z'],
  ['seal','Seal badge','M50 2L60 12L74 8L80 22L94 26L90 40L98 50L90 60L94 74L80 78L74 92L60 88L50 98L40 88L26 92L20 78L6 74L10 60L2 50L10 40L6 26L20 22L26 8L40 12Z'],
  ['wave','Wave','M2 40C16 20 30 20 44 40S72 60 98 36V74C72 98 58 98 44 78S16 58 2 78Z'],
  ['smiley','Smiley','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM34 30A7 9 0 1 1 34 48A7 9 0 1 1 34 30ZM66 30A7 9 0 1 1 66 48A7 9 0 1 1 66 30ZM24 60C32 82 68 82 76 60C60 70 40 70 24 60Z']
].map(s=>({id:s[0],name:s[1],d:s[2]}));
const VEC_SHAPE_CACHE={};
function vec_shape(id){
  if(!VEC_SHAPE_CACHE[id]){const s=VEC_SHAPES.find(q=>q.id===id)||VEC_SHAPES[0];VEC_SHAPE_CACHE[id]=vec_fit(vec_fromSVG(s.d),0,0,100,100,false);}
  return VEC_SHAPE_CACHE[id];
}
/* trace the alpha of a canvas into bezier outlines (marching squares with sub-pixel interpolation) */
function vec_contours(alpha,W,H,level){
  const w=W+2,h=H+2,f=new Float32Array(w*h);
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)f[(y+1)*w+x+1]=alpha[y*W+x];
  const segs=new Map(),key=(a,b,c)=>a+','+b+','+c;
  const interp=(x0,y0,v0,x1,y1,v1)=>{const t=(level-v0)/((v1-v0)||1);return [x0+(x1-x0)*t,y0+(y1-y0)*t];};
  const add=(ka,pa,kb,pb)=>{
    let A=segs.get(ka);if(!A){A={p:pa,n:[]};segs.set(ka,A);}
    let B=segs.get(kb);if(!B){B={p:pb,n:[]};segs.set(kb,B);}
    A.n.push(kb);B.n.push(ka);
  };
  for(let y=0;y<h-1;y++)for(let x=0;x<w-1;x++){
    const v00=f[y*w+x],v10=f[y*w+x+1],v11=f[(y+1)*w+x+1],v01=f[(y+1)*w+x];
    const c=(v00>level?1:0)|(v10>level?2:0)|(v11>level?4:0)|(v01>level?8:0);
    if(c===0||c===15)continue;
    const T=()=>[key('h',x,y),interp(x,y,v00,x+1,y,v10)],R=()=>[key('v',x+1,y),interp(x+1,y,v10,x+1,y+1,v11)],B=()=>[key('h',x,y+1),interp(x,y+1,v01,x+1,y+1,v11)],L=()=>[key('v',x,y),interp(x,y,v00,x,y+1,v01)];
    const pr=(a,b)=>{const p=a(),q=b();add(p[0],p[1],q[0],q[1]);};
    switch(c){
      case 1:case 14:pr(L,T);break;case 2:case 13:pr(T,R);break;case 3:case 12:pr(L,R);break;
      case 4:case 11:pr(R,B);break;case 6:case 9:pr(T,B);break;case 7:case 8:pr(L,B);break;
      case 5:pr(L,T);pr(R,B);break;case 10:pr(T,R);pr(L,B);break;
    }
  }
  const used=new Set(),out=[];
  for(const [k,v] of segs){
    if(used.has(k))continue;
    const poly=[];let cur=k,prev=null;
    while(cur&&!used.has(cur)){
      used.add(cur);const n=segs.get(cur);poly.push({x:n.p[0]-1+0.5,y:n.p[1]-1+0.5});
      let nx=null;for(const c of n.n){if(c!==prev&&!used.has(c)){nx=c;break;}}
      prev=cur;cur=nx;
    }
    if(poly.length>3)out.push(poly);
  }
  return out;
}
function vec_polyArea(p){let a=0;for(let i=0;i<p.length;i++){const q=p[(i+1)%p.length];a+=p[i].x*q.y-q.x*p[i].y;}return a/2;}
function vec_polyToSub(dense,tol,cornerAng){
  /* smooth sub with corner detection on the dense contour */
  const n=dense.length;
  const simp=vec_dp(dense.concat([dense[0]]),tol,true);simp.pop();
  if(simp.length<3)return null;
  const idx=simp.map(p=>dense.findIndex(d=>d===p));
  const sub={closed:true,pts:simp.map(p=>vec_pt(p.x,p.y))};
  const k=Math.max(2,Math.round(n/60)),corner=[];
  for(let j=0;j<simp.length;j++){
    const i=idx[j],a=dense[(i-k+n)%n],b=dense[(i+k)%n],c=dense[i];
    const v1=[c.x-a.x,c.y-a.y],v2=[b.x-c.x,b.y-c.y],l1=Math.hypot(...v1)||1,l2=Math.hypot(...v2)||1;
    const ang=Math.acos(Math.max(-1,Math.min(1,(v1[0]*v2[0]+v1[1]*v2[1])/(l1*l2))))*180/Math.PI;
    corner.push(ang>cornerAng);
  }
  const P=sub.pts,m=P.length;
  for(let j=0;j<m;j++){
    const q=P[j];if(corner[j])continue;
    const a=P[(j-1+m)%m],b=P[(j+1)%m];
    let tx=b.x-a.x,ty=b.y-a.y;const tl=Math.hypot(tx,ty)||1;tx/=tl;ty/=tl;
    const la=Math.hypot(q.x-a.x,q.y-a.y)/3,lb=Math.hypot(b.x-q.x,b.y-q.y)/3;
    q.ix=q.x-tx*la;q.iy=q.y-ty*la;q.ox=q.x+tx*lb;q.oy=q.y+ty*lb;
  }
  /* segments between two corners stay straight; a corner next to a smooth point keeps its handle toward the smooth point flat */
  return sub;
}
function vec_traceAlpha(canvas,opts){
  opts=opts||{};const W=canvas.width,H=canvas.height,d=cctx(canvas).getImageData(0,0,W,H).data,a=new Float32Array(W*H);
  for(let i=0;i<W*H;i++)a[i]=d[i*4+3];
  const path={subs:[]};
  for(const poly of vec_contours(a,W,H,127.5)){
    if(Math.abs(vec_polyArea(poly))<(opts.minArea||6))continue;
    const s=vec_polyToSub(poly,opts.tol||0.7,opts.cornerAngle||38);if(s)path.subs.push(s);
  }
  return path;
}
function vec_traceAlphaGroups(canvas,opts){
  opts=opts||{};const W=canvas.width,H=canvas.height,d=cctx(canvas).getImageData(0,0,W,H).data,a=new Float32Array(W*H),lab=new Int32Array(W*H);
  for(let i=0;i<W*H;i++)a[i]=d[i*4+3];
  let L=0;const bb=[null];
  for(let i=0;i<W*H;i++){
    if(a[i]<=127||lab[i])continue;
    L++;const st=[i];lab[i]=L;let x0=W,y0=H,x1=0,y1=0;
    while(st.length){
      const p=st.pop(),x=p%W,y=(p/W)|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;
      for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=W||ny>=H)continue;const q=ny*W+nx;if(a[q]>127&&!lab[q]){lab[q]=L;st.push(q);}}
    }
    bb.push({x0,y0,x1,y1});
  }
  const groups=bb.slice(1).map((b,i)=>({id:i+1,bbox:{x:b.x0,y:b.y0,w:b.x1-b.x0+1,h:b.y1-b.y0+1},path:{subs:[]}}));
  for(const poly of vec_contours(a,W,H,127.5)){
    if(Math.abs(vec_polyArea(poly))<(opts.minArea||6))continue;
    let g=0;const p0=poly[0],cx=Math.round(p0.x-0.5),cy=Math.round(p0.y-0.5);
    for(let r=0;r<=3&&!g;r++)for(let dy=-r;dy<=r&&!g;dy++)for(let dx=-r;dx<=r&&!g;dx++){const x=cx+dx,y=cy+dy;if(x>=0&&y>=0&&x<W&&y<H&&lab[y*W+x])g=lab[y*W+x];}
    const s=vec_polyToSub(poly,opts.tol||0.7,opts.cornerAngle||38);if(s&&g)groups[g-1].path.subs.push(s);
  }
  return groups.filter(g=>g.path.subs.length).sort((p,q)=>(Math.abs(p.bbox.y-q.bbox.y)>Math.min(p.bbox.h,q.bbox.h)*0.6?p.bbox.y-q.bbox.y:p.bbox.x-q.bbox.x));
}
