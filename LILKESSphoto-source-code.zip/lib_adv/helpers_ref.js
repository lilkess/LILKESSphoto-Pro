(()=>{
'use strict';
/* ===== helpers ===== */
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const hexRgb=h=>{h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return [n>>16&255,n>>8&255,n&255];};
const rgbHex=(r,g,b)=>'#'+[r,g,b].map(v=>clamp(Math.round(v),0,255).toString(16).padStart(2,'0')).join('');
const rgbaStr=(h,a)=>{const c=hexRgb(h);return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';};
const lumHex=h=>{const c=hexRgb(h);return 0.299*c[0]+0.587*c[1]+0.114*c[2];};
const FONTS=['Montserrat','Anton','Bebas Neue','Oswald','Playfair Display','Pacifico','Lobster','Dancing Script','Permanent Marker','Roboto Slab','Arial','Georgia','Impact','Verdana','Courier New'];

function mkCanvas(w,h){const c=document.createElement('canvas');c.width=Math.max(1,Math.round(w));c.height=Math.max(1,Math.round(h));return c;}
function cctx(c){return c.getContext('2d',{willReadFrequently:true});}
function cloneCanvas(c){const n=mkCanvas(c.width,c.height);cctx(n).drawImage(c,0,0);return n;}

function blurH(s,t,w,h,r){
  const n=2*r+1;
  for(let y=0;y<h;y++){const o=y*w*4;
    for(let c=0;c<4;c++){let acc=0;
      for(let i=-r;i<=r;i++)acc+=s[o+Math.min(w-1,Math.max(0,i))*4+c];
      for(let x=0;x<w;x++){t[o+x*4+c]=acc/n;acc+=s[o+Math.min(w-1,x+r+1)*4+c]-s[o+Math.max(0,x-r)*4+c];}
    }}
}
function blurV(s,t,w,h,r){
  const n=2*r+1,st=w*4;
  for(let x=0;x<w;x++){
    for(let c=0;c<4;c++){const o=x*4+c;let acc=0;
      for(let i=-r;i<=r;i++)acc+=s[o+Math.min(h-1,Math.max(0,i))*st];
      for(let y=0;y<h;y++){t[o+y*st]=acc/n;acc+=s[o+Math.min(h-1,y+r+1)*st]-s[o+Math.max(0,y-r)*st];}
    }}
}
function boxBlur(d,w,h,r,it){
  if(r<1)return d;const t=new Uint8ClampedArray(d.length);
  for(let k=0;k<(it||1);k++){blurH(d,t,w,h,r);blurV(t,d,w,h,r);}
  return d;
}
