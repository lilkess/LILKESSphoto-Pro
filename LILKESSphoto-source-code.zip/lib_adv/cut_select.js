/* hdr placeholder */
/* ---------- internal utils ---------- */
function cut__rng(seed){let s=seed>>>0;return function(){s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
function cut__getData(canvas){return cctx(canvas).getImageData(0,0,canvas.width,canvas.height);}
function cut__resize(canvas,w,h){const n=mkCanvas(w,h),c=cctx(n);c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';c.drawImage(canvas,0,0,n.width,n.height);return n;}
let cut__gam=null;
function cut__toLab(d,n){ // RGBA bytes -> Float32Array(n*3) L(0..100) a b
  if(!cut__gam){cut__gam=new Float32Array(256);for(let i=0;i<256;i++){const c=i/255;cut__gam[i]=c<=0.04045?c/12.92:Math.pow((c+0.055)/1.055,2.4);}}
  const g=cut__gam,o=new Float32Array(n*3),e=216/24389,k=24389/27;
  for(let i=0,j=0;i<n;i++,j+=3){
    const r=g[d[i*4]],gg=g[d[i*4+1]],b=g[d[i*4+2]];
    let x=(0.4124564*r+0.3575761*gg+0.1804375*b)/0.95047,y=0.2126729*r+0.7151522*gg+0.0721750*b,z=(0.0193339*r+0.1191920*gg+0.9503041*b)/1.08883;
    x=x>e?Math.cbrt(x):(k*x+16)/116;y=y>e?Math.cbrt(y):(k*y+16)/116;z=z>e?Math.cbrt(z):(k*z+16)/116;
    o[j]=116*y-16;o[j+1]=500*(x-y);o[j+2]=200*(y-z);
  }
  return o;
}

/* ---------- Boykov-Kolmogorov max-flow on an 8-connected pixel grid ----------
 nodes: Int32Array of active pixel ids; tr[p]=source cap - sink cap (Float32Array N);
 cap[p*8+d]=residual capacity p->p+offs[d] (arcs to non-nodes must be 0). Returns Uint8Array tree (1=source side). */
function cut__maxflow(w,h,nodes,tr,cap){
  const N=w*h,offs=[1,-1,w,-w,w+1,-w-1,1-w,w-1],OPP=[1,0,3,2,5,4,7,6],INF=1e9;
  const tree=new Uint8Array(N),par=new Int32Array(N).fill(-1),TS=new Int32Array(N),DIST=new Int32Array(N),inQ=new Uint8Array(N);
  const M=nodes.length+2,q=new Int32Array(M);let qh=0,qt=0,qn=0,time=0;
  const orph=[];
  const setActive=i=>{if(!inQ[i]){inQ[i]=1;q[qt]=i;qt=qt+1===M?0:qt+1;qn++;}};
  for(let k=0;k<nodes.length;k++){const i=nodes[k],t=tr[i];
    if(t>0){tree[i]=1;par[i]=-2;DIST[i]=1;setActive(i);}else if(t<0){tree[i]=2;par[i]=-2;DIST[i]=1;setActive(i);}}
  const rootDist=j=>{
    let d=0,k=j;
    for(;;){
      if(TS[k]===time){d+=DIST[k];break;}
      const pa=par[k];
      if(pa===-2){TS[k]=time;DIST[k]=1;d+=1;break;}
      if(pa<0)return INF;
      d++;k=(pa>>3)+offs[pa&7];
    }
    k=j;let dd=d;
    while(TS[k]!==time){TS[k]=time;DIST[k]=dd;dd--;k=(par[k]>>3)+offs[par[k]&7];}
    return d;
  };
  const adopt=i=>{
    const isS=tree[i]===1;let best=-1,dmin=INF;
    for(let d=0;d<8;d++){
      const a=i*8+d,j=i+offs[d];
      if(tree[j]!==tree[i])continue;
      if(isS?!(cap[j*8+OPP[d]]>0):!(cap[a]>0))continue;
      const dd=rootDist(j);
      if(dd<dmin){dmin=dd;best=a;}
    }
    if(best>=0){par[i]=best;TS[i]=time;DIST[i]=dmin+1;return;}
    for(let d=0;d<8;d++){
      const a=i*8+d,j=i+offs[d];
      if(tree[j]!==tree[i])continue;
      if(isS?cap[j*8+OPP[d]]>0:cap[a]>0)setActive(j);
      const pj=par[j];
      if(pj>=0&&(pj>>3)+offs[pj&7]===i){par[j]=-3;orph.push(j);}
    }
    tree[i]=0;par[i]=-1;
  };
  const augment=mid=>{
    const s0=mid>>3,t0=s0+offs[mid&7];
    let b=cap[mid],i=s0,pa;
    for(;;){pa=par[i];if(pa===-2)break;const sa=((pa>>3)+offs[pa&7])*8+OPP[pa&7];if(cap[sa]<b)b=cap[sa];i=(pa>>3)+offs[pa&7];}
    if(tr[i]<b)b=tr[i];
    const rs=i;i=t0;
    for(;;){pa=par[i];if(pa===-2)break;if(cap[pa]<b)b=cap[pa];i=(pa>>3)+offs[pa&7];}
    if(-tr[i]<b)b=-tr[i];
    const rt=i;
    cap[mid]-=b;cap[(t0)*8+OPP[mid&7]]+=b;
    i=s0;
    for(;;){pa=par[i];if(pa===-2)break;const hd=(pa>>3)+offs[pa&7],sa=hd*8+OPP[pa&7];cap[sa]-=b;cap[pa]+=b;if(cap[sa]<=0){par[i]=-3;orph.push(i);}i=hd;}
    tr[rs]-=b;if(tr[rs]<=0){par[rs]=-3;orph.push(rs);}
    i=t0;
    for(;;){pa=par[i];if(pa===-2)break;const hd=(pa>>3)+offs[pa&7];cap[pa]-=b;cap[hd*8+OPP[pa&7]]+=b;if(cap[pa]<=0){par[i]=-3;orph.push(i);}i=hd;}
    tr[rt]+=b;if(tr[rt]>=0){par[rt]=-3;orph.push(rt);}
  };
  let cur=-1;
  for(;;){
    let i=cur;
    if(i>=0&&tree[i]===0)i=-1;
    if(i<0){for(;;){if(qn===0){i=-1;break;}i=q[qh];qh=qh+1===M?0:qh+1;qn--;inQ[i]=0;if(tree[i]!==0&&par[i]!==-3)break;}if(i<0)break;}
    let mid=-1;
    const ti=tree[i];
    if(ti===1){
      for(let d=0;d<8;d++){const a=i*8+d;if(cap[a]>0){const j=i+offs[d];
        if(tree[j]===0){tree[j]=1;par[j]=j*8+OPP[d];TS[j]=TS[i];DIST[j]=DIST[i]+1;setActive(j);}
        else if(tree[j]===2){mid=a;break;}
        else if(TS[j]<=TS[i]&&DIST[j]>DIST[i]){par[j]=j*8+OPP[d];TS[j]=TS[i];DIST[j]=DIST[i]+1;}}}
    }else{
      for(let d=0;d<8;d++){const j=i+offs[d],sa=j*8+OPP[d];if(cap[sa]>0){
        if(tree[j]===0){tree[j]=2;par[j]=sa;TS[j]=TS[i];DIST[j]=DIST[i]+1;setActive(j);}
        else if(tree[j]===1){mid=sa;break;}
        else if(TS[j]<=TS[i]&&DIST[j]>DIST[i]){par[j]=sa;TS[j]=TS[i];DIST[j]=DIST[i]+1;}}}
    }
    time++;
    if(mid>=0){cur=i;augment(mid);while(orph.length)adopt(orph.pop());}
    else cur=-1;
  }
  return tree;
}

/* ---------- GMM colour models (Lab) ---------- */
function cut__kmeans(lab,idx,K,rnd,iters){
  const n=idx.length,sub=Math.min(n,12000),step=n/sub,P=new Float32Array(sub*3);
  for(let s=0;s<sub;s++){const p=idx[Math.floor(s*step)]*3;P[s*3]=lab[p];P[s*3+1]=lab[p+1];P[s*3+2]=lab[p+2];}
  const C=new Float32Array(K*3),dm=new Float32Array(sub).fill(1e30);
  let f=Math.floor(rnd()*sub);
  for(let k=0;k<K;k++){
    C[k*3]=P[f*3];C[k*3+1]=P[f*3+1];C[k*3+2]=P[f*3+2];
    let bi=0,bv=-1;
    for(let s=0;s<sub;s++){const a=P[s*3]-C[k*3],b=P[s*3+1]-C[k*3+1],c=P[s*3+2]-C[k*3+2],d=a*a+b*b+c*c;if(d<dm[s])dm[s]=d;if(dm[s]>bv){bv=dm[s];bi=s;}}
    f=bi;
  }
  const as=new Uint8Array(sub),sm=new Float64Array(K*3),ct=new Float64Array(K);
  for(let it=0;it<iters;it++){
    sm.fill(0);ct.fill(0);
    for(let s=0;s<sub;s++){let bk=0,bv=1e30;for(let k=0;k<K;k++){const a=P[s*3]-C[k*3],b=P[s*3+1]-C[k*3+1],c=P[s*3+2]-C[k*3+2],d=a*a+b*b+c*c;if(d<bv){bv=d;bk=k;}}
      as[s]=bk;sm[bk*3]+=P[s*3];sm[bk*3+1]+=P[s*3+1];sm[bk*3+2]+=P[s*3+2];ct[bk]++;}
    for(let k=0;k<K;k++)if(ct[k]>0){C[k*3]=sm[k*3]/ct[k];C[k*3+1]=sm[k*3+1]/ct[k];C[k*3+2]=sm[k*3+2]/ct[k];}
  }
  const comp=new Uint8Array(n);
  for(let s=0;s<n;s++){const p=idx[s]*3;let bk=0,bv=1e30;for(let k=0;k<K;k++){const a=lab[p]-C[k*3],b=lab[p+1]-C[k*3+1],c=lab[p+2]-C[k*3+2],d=a*a+b*b+c*c;if(d<bv){bv=d;bk=k;}}comp[s]=bk;}
  return comp;
}
// learn a GMM from hard component assignment; returns {K,c:Float32Array(K),mu,icv}
function cut__gmmLearn(lab,idx,comp,K,varFloor){
  const n=idx.length,cnt=new Float64Array(K),m=new Float64Array(K*3),s=new Float64Array(K*6);
  for(let i=0;i<n;i++){const p=idx[i]*3,k=comp[i],x=lab[p],y=lab[p+1],z=lab[p+2];
    cnt[k]++;m[k*3]+=x;m[k*3+1]+=y;m[k*3+2]+=z;
    s[k*6]+=x*x;s[k*6+1]+=x*y;s[k*6+2]+=x*z;s[k*6+3]+=y*y;s[k*6+4]+=y*z;s[k*6+5]+=z*z;}
  const g={K,c:new Float32Array(K).fill(-1e30),mu:new Float32Array(K*3),icv:new Float32Array(K*6),W:new Float32Array(K)};
  for(let k=0;k<K;k++){
    if(cnt[k]<4)continue;
    const c=cnt[k],mx=m[k*3]/c,my=m[k*3+1]/c,mz=m[k*3+2]/c;
    const a=s[k*6]/c-mx*mx+varFloor,b=s[k*6+1]/c-mx*my,cc=s[k*6+2]/c-mx*mz,d=s[k*6+3]/c-my*my+varFloor,e=s[k*6+4]/c-my*mz,f=s[k*6+5]/c-mz*mz+varFloor;
    const det=a*(d*f-e*e)-b*(b*f-e*cc)+cc*(b*e-d*cc);
    if(!(det>1e-6))continue;
    const id=1/det;
    g.mu[k*3]=mx;g.mu[k*3+1]=my;g.mu[k*3+2]=mz;
    g.icv[k*6]=(d*f-e*e)*id;g.icv[k*6+1]=(cc*e-b*f)*id;g.icv[k*6+2]=(b*e-cc*d)*id;g.icv[k*6+3]=(a*f-cc*cc)*id;g.icv[k*6+4]=(b*cc-a*e)*id;g.icv[k*6+5]=(a*d-b*b)*id;
    g.W[k]=c/n;
    g.c[k]=Math.log(c/n)-0.5*Math.log(det);
  }
  return g;
}
// negative log likelihood of pixel offset p (into lab) ; also best component
function cut__gmmCost(g,lab,p){
  const x=lab[p],y=lab[p+1],z=lab[p+2];let mx=-1e30;const K=g.K;
  let t0=0,t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,t7=0;
  // K<=8 unrolled storage
  for(let k=0;k<K;k++){
    const dx=x-g.mu[k*3],dy=y-g.mu[k*3+1],dz=z-g.mu[k*3+2],i=k*6;
    const mh=g.icv[i]*dx*dx+g.icv[i+3]*dy*dy+g.icv[i+5]*dz*dz+2*(g.icv[i+1]*dx*dy+g.icv[i+2]*dx*dz+g.icv[i+4]*dy*dz);
    const t=g.c[k]-0.5*mh;
    switch(k){case 0:t0=t;break;case 1:t1=t;break;case 2:t2=t;break;case 3:t3=t;break;case 4:t4=t;break;case 5:t5=t;break;case 6:t6=t;break;default:t7=t;}
    if(t>mx)mx=t;
  }
  let s=0;
  if(K>0)s+=Math.exp(t0-mx);if(K>1)s+=Math.exp(t1-mx);if(K>2)s+=Math.exp(t2-mx);if(K>3)s+=Math.exp(t3-mx);
  if(K>4)s+=Math.exp(t4-mx);if(K>5)s+=Math.exp(t5-mx);if(K>6)s+=Math.exp(t6-mx);if(K>7)s+=Math.exp(t7-mx);
  return -(mx+Math.log(s));
}
function cut__gmmAssign(g,lab,idx,comp){
  const K=g.K;
  for(let i=0;i<idx.length;i++){const p=idx[i]*3,x=lab[p],y=lab[p+1],z=lab[p+2];let bk=0,bv=-1e31;
    for(let k=0;k<K;k++){const dx=x-g.mu[k*3],dy=y-g.mu[k*3+1],dz=z-g.mu[k*3+2],j=k*6;
      const t=g.c[k]-0.5*(g.icv[j]*dx*dx+g.icv[j+3]*dy*dy+g.icv[j+5]*dz*dz+2*(g.icv[j+1]*dx*dy+g.icv[j+2]*dx*dz+g.icv[j+4]*dy*dz));
      if(t>bv){bv=t;bk=k;}}
    comp[i]=bk;}
}

/* ---------- GrabCut ----------
 lab: Float32Array(n*3); lbl0: Uint8Array(n) 0=bg,1=fg,2=prob bg,3=prob fg. Returns Uint8Array(n) 1=fg.
 o:{iters:4,K:5,gamma:50,band:12,varFloor:4} */
function cut__nweights(lab,w,h,gamma){
  const N=w*h,wt=new Float32Array(N*4);let sum=0,cnt=0;
  const D=(a,b)=>(lab[a]-lab[b])*(lab[a]-lab[b])+(lab[a+1]-lab[b+1])*(lab[a+1]-lab[b+1])+(lab[a+2]-lab[b+2])*(lab[a+2]-lab[b+2]);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=y*w+x,a=p*3;
    if(x+1<w){const d=D(a,a+3);wt[p*4]=d;sum+=d;cnt++;}
    if(y+1<h){let d=D(a,a+w*3);wt[p*4+1]=d;sum+=d;cnt++;
      if(x+1<w){d=D(a,a+w*3+3);wt[p*4+2]=d;sum+=d;cnt++;}
      if(x>0){d=D(a,a+w*3-3);wt[p*4+3]=d;sum+=d;cnt++;}}}
  const beta=1/(2*sum/Math.max(1,cnt)+1e-6),r2=0.70710678;
  for(let p=0;p<N;p++){const x=p%w,y=(p/w)|0,i=p*4;
    wt[i]=x+1<w?gamma*Math.exp(-beta*wt[i]):0;
    if(y+1<h){wt[i+1]=gamma*Math.exp(-beta*wt[i+1]);wt[i+2]=x+1<w?r2*gamma*Math.exp(-beta*wt[i+2]):0;wt[i+3]=x>0?r2*gamma*Math.exp(-beta*wt[i+3]):0;}
    else{wt[i+1]=wt[i+2]=wt[i+3]=0;}}
  return wt;
}
const CUT_DX=[1,-1,0,0,1,-1,1,-1],CUT_DY=[0,0,1,-1,1,-1,-1,1];
function cut__grabcut(lab,w,h,lbl0,o){
  o=o||{};const N=w*h,K=o.K||5,gamma=o.gamma||50,iters=o.iters||4,band=o.band||12,vf=o.varFloor||4;
  const T0=performance.now(),TL=o.log?(m=>console.log(m,Math.round(performance.now()-T0))):(()=>{});const rnd=cut__rng(1234),lbl=Uint8Array.from(lbl0),wt=o.wt||cut__nweights(lab,w,h,gamma);
  const split=()=>{let nf=0,nb=0;for(let p=0;p<N;p++){if(lbl[p]&1)nf++;else nb++;}
    const fi=new Int32Array(nf),bi=new Int32Array(nb);nf=nb=0;for(let p=0;p<N;p++){if(lbl[p]&1)fi[nf++]=p;else bi[nb++]=p;}return [fi,bi];};
  let [fi,bi]=split();
  let cf=cut__kmeans(lab,fi,K,rnd,8),cb=cut__kmeans(lab,bi,K,rnd,8);
  TL('init');
  const offs=[1,-1,w,-w,w+1,-w-1,1-w,w-1];
  const tr=new Float32Array(N),cap=new Float32Array(N*8),state=new Int8Array(N);
  const res=new Uint8Array(N);
  for(let it=0;it<iters;it++){
    const gf=cut__gmmLearn(lab,fi,cf,K,vf),gb=cut__gmmLearn(lab,bi,cb,K,vf);
    const nodes=[];
    for(let p=0;p<N;p++){
      const l=lbl[p];tr[p]=0;
      if(l===0)state[p]=-1;else if(l===1)state[p]=1;
      else{const a=p*3,t=cut__gmmCost(gb,lab,a)-cut__gmmCost(gf,lab,a)+(o.tb?o.tb[p]:0);
        if(t>band)state[p]=1;else if(t<-band)state[p]=-1;else{state[p]=0;nodes.push(p);tr[p]=t;}}
    }
    TL('unary');
    cap.fill(0);
    const nl=Int32Array.from(nodes);
    for(let k=0;k<nl.length;k++){const p=nl[k],x=p%w,y=(p/w)|0;
      for(let d=0;d<8;d++){
        const nx=x+CUT_DX[d],ny=y+CUT_DY[d];if(nx<0||ny<0||nx>=w||ny>=h)continue;
        const q=p+offs[d];let wv;
        switch(d){case 0:wv=wt[p*4];break;case 1:wv=wt[q*4];break;case 2:wv=wt[p*4+1];break;case 3:wv=wt[q*4+1];break;case 4:wv=wt[p*4+2];break;case 5:wv=wt[q*4+2];break;case 6:wv=wt[q*4+3];break;default:wv=wt[p*4+3];}
        const s=state[q];
        if(s===0)cap[p*8+d]=wv;else tr[p]+=s>0?wv:-wv;
      }}
    TL('graph '+nl.length);
    const tree=cut__maxflow(w,h,nl,tr,cap);
    TL('flow');
    for(let p=0;p<N;p++){const s=state[p];res[p]=s===0?(tree[p]===1?1:0):(s>0?1:0);}
    if(it<iters-1){
      for(let p=0;p<N;p++)if(lbl0[p]>=2)lbl[p]=res[p]?3:2;
      [fi,bi]=split();
      cf=new Uint8Array(fi.length);cb=new Uint8Array(bi.length);
      cut__gmmAssign(gf,lab,fi,cf);cut__gmmAssign(gb,lab,bi,cb);
    }
  }
  return res;
}

/* ---------- small image-processing helpers ---------- */
// box mean of a w*h Float32 plane (edge clamped); returns new array
function cut__box(s,w,h,r){
  const t=new Float32Array(w*h),o=new Float32Array(w*h),n=2*r+1;
  for(let y=0;y<h;y++){const b=y*w;let a=0;for(let i=-r;i<=r;i++)a+=s[b+Math.min(w-1,Math.max(0,i))];
    for(let x=0;x<w;x++){t[b+x]=a/n;a+=s[b+Math.min(w-1,x+r+1)]-s[b+Math.max(0,x-r)];}}
  for(let x=0;x<w;x++){let a=0;for(let i=-r;i<=r;i++)a+=t[Math.min(h-1,Math.max(0,i))*w+x];
    for(let y=0;y<h;y++){o[y*w+x]=a/n;a+=t[Math.min(h-1,y+r+1)*w+x]-t[Math.max(0,y-r)*w+x];}}
  return o;
}
// chamfer (3-4) distance in pixels to nearest nonzero pixel of m
function cut__dist(m,w,h){
  const d=new Float32Array(w*h),INF=1e9;
  for(let i=0;i<w*h;i++)d[i]=m[i]?0:INF;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=y*w+x;let v=d[p];if(v===0)continue;
    if(x>0&&d[p-1]+1<v)v=d[p-1]+1;if(y>0){if(d[p-w]+1<v)v=d[p-w]+1;if(x>0&&d[p-w-1]+1.4142<v)v=d[p-w-1]+1.4142;if(x<w-1&&d[p-w+1]+1.4142<v)v=d[p-w+1]+1.4142;}d[p]=v;}
  for(let y=h-1;y>=0;y--)for(let x=w-1;x>=0;x--){const p=y*w+x;let v=d[p];if(v===0)continue;
    if(x<w-1&&d[p+1]+1<v)v=d[p+1]+1;if(y<h-1){if(d[p+w]+1<v)v=d[p+w]+1;if(x<w-1&&d[p+w+1]+1.4142<v)v=d[p+w+1]+1.4142;if(x>0&&d[p+w-1]+1.4142<v)v=d[p+w-1]+1.4142;}d[p]=v;}
  return d;
}
// connected components of nonzero pixels (4-conn). returns {id:Int32Array (0=none, 1..n), n, area:Int32Array, touch:Int32Array(border pixel count), cx,cy sums}
function cut__components(m,w,h,conn8){
  const N=w*h,id=new Int32Array(N),st=new Int32Array(N);let n=0;const area=[0],touch=[0],sx=[0],sy=[0];
  for(let s=0;s<N;s++){
    if(!m[s]||id[s])continue;n++;let sp=0,a=0,tc=0,mx=0,my=0;st[sp++]=s;id[s]=n;
    while(sp){const p=st[--sp],x=p%w,y=(p/w)|0;a++;mx+=x;my+=y;if(x===0||y===0||x===w-1||y===h-1)tc++;
      if(x>0&&m[p-1]&&!id[p-1]){id[p-1]=n;st[sp++]=p-1;}
      if(x<w-1&&m[p+1]&&!id[p+1]){id[p+1]=n;st[sp++]=p+1;}
      if(y>0&&m[p-w]&&!id[p-w]){id[p-w]=n;st[sp++]=p-w;}
      if(y<h-1&&m[p+w]&&!id[p+w]){id[p+w]=n;st[sp++]=p+w;}
      if(conn8){
        if(x>0&&y>0&&m[p-w-1]&&!id[p-w-1]){id[p-w-1]=n;st[sp++]=p-w-1;}
        if(x<w-1&&y>0&&m[p-w+1]&&!id[p-w+1]){id[p-w+1]=n;st[sp++]=p-w+1;}
        if(x>0&&y<h-1&&m[p+w-1]&&!id[p+w-1]){id[p+w-1]=n;st[sp++]=p+w-1;}
        if(x<w-1&&y<h-1&&m[p+w+1]&&!id[p+w+1]){id[p+w+1]=n;st[sp++]=p+w+1;}}}
    area.push(a);touch.push(tc);sx.push(mx/a);sy.push(my/a);}
  return {id,n,area,touch,cx:sx,cy:sy};
}
// gradient magnitude of Lab (central differences), light 3x3 pre-blur is expected from caller
function cut__gradMag(lab,w,h){
  const g=new Float32Array(w*h);
  for(let y=0;y<h;y++){const y0=Math.max(0,y-1),y1=Math.min(h-1,y+1);
    for(let x=0;x<w;x++){const x0=Math.max(0,x-1),x1=Math.min(w-1,x+1),p=y*w+x;
      let s=0;for(let c=0;c<3;c++){const dx=lab[(y*w+x1)*3+c]-lab[(y*w+x0)*3+c],dy=lab[(y1*w+x)*3+c]-lab[(y0*w+x)*3+c];s+=dx*dx+dy*dy;}
      g[p]=Math.sqrt(s)*0.5;}}
  return g;
}
function cut__blurLab(lab,w,h,r){
  const o=new Float32Array(lab.length),pl=new Float32Array(w*h);
  for(let c=0;c<3;c++){for(let i=0;i<w*h;i++)pl[i]=lab[i*3+c];const b=cut__box(pl,w,h,r);for(let i=0;i<w*h;i++)o[i*3+c]=b[i];}
  return o;
}
function cut__dilate(m,w,h,r){const d=cut__dist(m,w,h),o=new Uint8Array(w*h);for(let i=0;i<w*h;i++)o[i]=d[i]<=r?1:0;return o;}
function cut__erode(m,w,h,r){const inv=new Uint8Array(w*h);for(let i=0;i<w*h;i++)inv[i]=m[i]?0:1;
  // pixels outside image count as foreground for erosion (do not erode at image border)
  const d=cut__dist(inv,w,h),o=new Uint8Array(w*h);for(let i=0;i<w*h;i++)o[i]=d[i]>r?1:0;return o;}

/* ---------- automatic background seed detection ----------
 Smooth (low-texture) connected regions touching the border and not covering the image centre = background.
 Returns {lbl (0 bg seed,1 fg core,3 prob fg,2 prob bg), bg:Uint8Array flat bg, flat:bool, T:texture} */
function cut__autoInit(lab0,w,h,mode,dbg){
  const N=w*h,lab=cut__blurLab(lab0,w,h,1),G=cut__gradMag(lab,w,h),T=cut__box(G,w,h,2);
  const bw=Math.max(2,Math.round(Math.min(w,h)*0.012));
  const ring=new Uint8Array(N);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(Math.min(x,y,w-1-x,h-1-y)<bw)ring[y*w+x]=1;
  const tfl=2.2,S=new Uint8Array(N);
  for(let p=0;p<N;p++)S[p]=T[p]<tfl?1:0;
  const cc=cut__components(S,w,h,false),bgm=new Uint8Array(N);
  const keep=new Uint8Array(cc.n+1),ctr=new Float64Array(cc.n+1),touchR=new Float64Array(cc.n+1);
  const x0=Math.round(w*0.35),x1=Math.round(w*0.65),y0=Math.round(h*0.3),y1=Math.round(h*0.7);
  for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const id=cc.id[y*w+x];if(id)ctr[id]++;}
  const ca=(x1-x0)*(y1-y0);
  for(let p=0;p<N;p++)if(ring[p]&&S[p])touchR[cc.id[p]]++;
  for(let k=1;k<=cc.n;k++)keep[k]=(touchR[k]>=Math.max(6,bw*4)&&cc.area[k]>=0.004*N)?1:0;
  // mean colour per component, reference = largest border-touching one; reject colour outliers (e.g. dark bag strap)
  const mc=new Float64Array((cc.n+1)*3);
  for(let p=0;p<N;p++){const k=cc.id[p];if(k){mc[k*3]+=lab[p*3];mc[k*3+1]+=lab[p*3+1];mc[k*3+2]+=lab[p*3+2];}}
  for(let k=1;k<=cc.n;k++){mc[k*3]/=cc.area[k];mc[k*3+1]/=cc.area[k];mc[k*3+2]/=cc.area[k];}
  let ref=0;for(let k=1;k<=cc.n;k++)if(keep[k]&&(!ref||touchR[k]>touchR[ref]))ref=k;
  const cd=k=>Math.hypot(mc[k*3]-mc[ref*3],mc[k*3+1]-mc[ref*3+1],mc[k*3+2]-mc[ref*3+2]);
  if(ref)for(let k=1;k<=cc.n;k++)if(keep[k]&&k!==ref&&(cd(k)>40||ctr[k]>0.3*Math.min(ca,cc.area[k])))keep[k]=0;
  for(let p=0;p<N;p++)if(S[p]&&keep[cc.id[p]])bgm[p]=1;
  if(ref){ // hop across thin edge lines: big smooth regions next to bg with similar colour
    const dd=cut__dist(bgm,w,h),near=new Uint8Array(cc.n+1);
    for(let p=0;p<N;p++){const k=cc.id[p];if(k&&!keep[k]&&dd[p]<=6)near[k]=1;}
    for(let k=1;k<=cc.n;k++)if(near[k]&&cc.area[k]>=0.015*N&&cd(k)<40)keep[k]=2;
    for(let p=0;p<N;p++)if(S[p]&&keep[cc.id[p]]===2)bgm[p]=1;
  }
  let nb=0;for(let i=0;i<N;i++)nb+=bgm[i];
  const flat=nb>0.08*N&&mode!=='center';
  const lbl=new Uint8Array(N);
  if(flat){
    const hard=cut__erode(bgm,w,h,2);
    for(let i=0;i<N;i++)lbl[i]=hard[i]?0:3;
    // fg core: erosion of the largest non-bg components
    const nbg=new Uint8Array(N);for(let i=0;i<N;i++)nbg[i]=bgm[i]?0:1;
    const c2=cut__components(nbg,w,h,false),big=new Uint8Array(N);
    let mxA=0;for(let k=1;k<=c2.n;k++)if(c2.area[k]>mxA)mxA=c2.area[k];
    for(let i=0;i<N;i++)if(nbg[i]&&c2.area[c2.id[i]]>=0.2*mxA)big[i]=1;
    const core=cut__erode(big,w,h,Math.max(3,Math.round(Math.min(w,h)*0.025)));
    for(let i=0;i<N;i++)if(core[i]&&lbl[i]===3)lbl[i]=1;
  }else{
    // centre prior: ring = bg, central ellipse = prob fg, rest prob bg
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=y*w+x;
      if(ring[p])lbl[p]=0;else{const e=Math.hypot((x-w/2)/(w*0.38),(y-h/2)/(h*0.38));lbl[p]=e<1?3:2;}}
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const e=Math.hypot((x-w/2)/(w*0.18),(y-h/2)/(h*0.18));if(e<1)lbl[y*w+x]=1;}
  }
  if(dbg){dbg.T=T;dbg.bgm=bgm;dbg.nb=nb;dbg.flat=flat;}
  return {lbl,bg:bgm,flat,T};
}

/* ---------- mask post-processing / upsampling / guided-filter edge refinement ---------- */
// keep significant components, drop specks, fill enclosed holes (m: Uint8Array 0/1, modified)
function cut__postMask(m,w,h,bgm,minFrac){
  const N=w*h,cc=cut__components(m,w,h,true);let mx=0;
  for(let k=1;k<=cc.n;k++)if(cc.area[k]>mx)mx=cc.area[k];
  const keep=new Uint8Array(cc.n+1);
  for(let k=1;k<=cc.n;k++){
    const cxn=cc.cx[k]/w,cyn=cc.cy[k]/h,central=Math.abs(cxn-0.5)<0.3&&Math.abs(cyn-0.5)<0.35;
    keep[k]=(cc.area[k]>=Math.max(minFrac*mx,0.0015*N)||(central&&cc.area[k]>=0.003*N))?1:0;}
  for(let i=0;i<N;i++)if(m[i]&&!keep[cc.id[i]])m[i]=0;
  const inv=new Uint8Array(N);for(let i=0;i<N;i++)inv[i]=m[i]?0:1;
  const hc=cut__components(inv,w,h,false),nb=new Int32Array(hc.n+1);
  if(bgm)for(let i=0;i<N;i++)if(inv[i]&&bgm[i])nb[hc.id[i]]++;
  for(let i=0;i<N;i++)if(inv[i]){const k=hc.id[i];if(hc.touch[k]===0&&nb[k]<0.5*hc.area[k])m[i]=1;}
  return m;
}
// bilinear upsample Uint8 plane (sw*sh) -> Uint8ClampedArray(W*H)
function cut__upsample(s,sw,sh,W,H){
  const o=new Uint8ClampedArray(W*H),fx=sw/W,fy=sh/H;
  const xi=new Int32Array(W),xw=new Float32Array(W);
  for(let x=0;x<W;x++){const u=Math.min(sw-1,Math.max(0,(x+0.5)*fx-0.5)),i=Math.min(sw-2<0?0:sw-2,Math.floor(u));xi[x]=i;xw[x]=sw>1?u-i:0;}
  for(let y=0;y<H;y++){const v=Math.min(sh-1,Math.max(0,(y+0.5)*fy-0.5)),j=Math.min(sh-2<0?0:sh-2,Math.floor(v)),wy=sh>1?v-j:0,r0=j*sw,r1=(sh>1?j+1:j)*sw;
    for(let x=0;x<W;x++){const i=xi[x],i1=sw>1?i+1:i,wx=xw[x];
      o[y*W+x]=(s[r0+i]*(1-wx)+s[r0+i1]*wx)*(1-wy)+(s[r1+i]*(1-wx)+s[r1+i1]*wx)*wy;}}
  return o;
}
// guided filter (gray guide) applied in place to alpha `a` (W*H) on tiles that touch the uncertain band `unc` (Uint8 W*H)
function cut__guidedTiles(img,W,H,a,unc,r,eps){
  const TS=192,P=r+1;
  const gt=(x0,y0,x1,y1)=>{ // filter tile [x0,x1)x[y0,y1) using padded window
    const px0=Math.max(0,x0-P),py0=Math.max(0,y0-P),px1=Math.min(W,x1+P),py1=Math.min(H,y1+P),tw=px1-px0,th=py1-py0,n=tw*th;
    const I=new Float32Array(n),Pp=new Float32Array(n),II=new Float32Array(n),IP=new Float32Array(n);
    for(let y=0;y<th;y++)for(let x=0;x<tw;x++){const s=(py0+y)*W+px0+x,k=y*tw+x,i=(0.299*img[s*4]+0.587*img[s*4+1]+0.114*img[s*4+2])/255,p=a[s]/255;I[k]=i;Pp[k]=p;II[k]=i*i;IP[k]=i*p;}
    const mI=cut__box(I,tw,th,r),mP=cut__box(Pp,tw,th,r),mII=cut__box(II,tw,th,r),mIP=cut__box(IP,tw,th,r);
    const A=II,B=IP;
    for(let k=0;k<n;k++){const v=mII[k]-mI[k]*mI[k],c=mIP[k]-mI[k]*mP[k],aa=c/(v+eps);A[k]=aa;B[k]=mP[k]-aa*mI[k];}
    const mA=cut__box(A,tw,th,r),mB=cut__box(B,tw,th,r);
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const s=y*W+x;if(!unc[s])continue;const k=(y-py0)*tw+(x-px0);
      let q=mA[k]*I[k]+mB[k];q=(q-0.22)/0.62;a[s]=q<0?0:q>1?255:q*255+0.5;}
  };
  for(let ty=0;ty<H;ty+=TS)for(let tx=0;tx<W;tx+=TS){
    const x1=Math.min(W,tx+TS),y1=Math.min(H,ty+TS);let any=false;
    for(let y=ty;y<y1&&!any;y++){const b=y*W;for(let x=tx;x<x1;x++)if(unc[b+x]){any=true;break;}}
    if(any)gt(tx,ty,x1,y1);}
}
// low-res binary mask (sw*sh, 1=fg) -> refined full-res alpha for a window of image data `img` (W*H RGBA)
function cut__finalize(m,sw,sh,img,W,H,opts){
  opts=opts||{};const N=sw*sh,sc=W/sw;
  const f=new Float32Array(N);for(let i=0;i<N;i++)f[i]=m[i]*255;
  let b=cut__box(f,sw,sh,1);
  const s8=new Uint8ClampedArray(N);for(let i=0;i<N;i++)s8[i]=b[i];
  const dl=cut__dilate(m,sw,sh,2),er=cut__erode(m,sw,sh,2),unc8=new Uint8Array(N);
  for(let i=0;i<N;i++)unc8[i]=dl[i]&&!er[i]?1:0;
  const a=cut__upsample(s8,sw,sh,W,H),uu=cut__upsample(unc8.map(v=>v*255),sw,sh,W,H),unc=new Uint8Array(W*H);
  for(let i=0;i<W*H;i++)unc[i]=uu[i]>20?1:0;
  const r=Math.max(2,Math.round(opts.gr||Math.min(8,Math.max(4,sc*2.2))));
  cut__guidedTiles(img,W,H,a,unc,r,opts.eps||2e-3);
  const fe=opts.feather==null?1:opts.feather;
  if(fe>0.01)cut__featherAlpha(a,W,H,fe);
  return a;
}
// small gaussian-like softening of the alpha (radius px)
function cut__featherAlpha(a,W,H,rad){
  const r=Math.max(1,Math.round(rad)),d=new Uint8ClampedArray(a);
  const t=new Float32Array(a.length);for(let i=0;i<a.length;i++)t[i]=a[i];
  // only soften near edges: cheap full-plane box blur applied where alpha not saturated in neighbourhood is overkill; do plain 2-pass box on whole plane via cut__box
  const b=cut__box(t,W,H,r);for(let i=0;i<a.length;i++)a[i]=b[i];
  void d;return a;
}

/* ---------- shared GrabCut driver on a low-res window ---------- */
function cut__runGC(lab,w,h,lbl,tb,o){
  o=o||{};
  const m=cut__grabcut(lab,w,h,lbl,{iters:o.iters||4,K:o.K||5,gamma:o.gamma||50,band:o.band||12,tb:tb});
  return m;
}
function cut__prepare(canvas,x0,y0,ww,hh,maxSide){
  const sc=Math.min(1,maxSide/Math.max(ww,hh)),w=Math.max(2,Math.round(ww*sc)),h=Math.max(2,Math.round(hh*sc));
  const win=mkCanvas(ww,hh);cctx(win).drawImage(canvas,x0,y0,ww,hh,0,0,ww,hh);
  const small=sc<1?cut__resize(win,w,h):win,d=cut__getData(small);
  return {win,w,h,lab:cut__toLab(d.data,w*h),full:sc<1?cut__getData(win).data:d.data,W:ww,H:hh};
}
function cut_removeBackground(canvas,opts){
  opts=opts||{};const maxSide=opts.maxSide||640,subject=opts.subject||'auto';
  const W=canvas.width,H=canvas.height,pr=cut__prepare(canvas,0,0,W,H,maxSide),w=pr.w,h=pr.h,N=w*h;
  const init=cut__autoInit(pr.lab,w,h,subject);
  let tb=null;
  if(init.flat){tb=new Float32Array(N);for(let i=0;i<N;i++)tb[i]=init.T[i]>3?Math.min(8,(init.T[i]-3)*3):0;}
  const m=cut__runGC(pr.lab,w,h,init.lbl,tb,opts);
  cut__postMask(m,w,h,init.flat?init.bg:null,0.35);
  const alpha=cut__finalize(m,w,h,pr.full,W,H,opts);
  return {alpha,w:W,h:H};
}

/* ---------- objectSelect: GrabCut inside a rect / polygon ---------- */
function cut__regionBox(region,W,H){
  let x0,y0,x1,y1;
  if(region.rect){const r=region.rect;x0=r.x;y0=r.y;x1=r.x+r.w;y1=r.y+r.h;}
  else{const p=region.poly;x0=y0=1e9;x1=y1=-1e9;for(const q of p){if(q.x<x0)x0=q.x;if(q.x>x1)x1=q.x;if(q.y<y0)y0=q.y;if(q.y>y1)y1=q.y;}}
  if(x1<x0){const t=x0;x0=x1;x1=t;}if(y1<y0){const t=y0;y0=y1;y1=t;}
  return {x0:clamp(Math.floor(x0),0,W-1),y0:clamp(Math.floor(y0),0,H-1),x1:clamp(Math.ceil(x1),1,W),y1:clamp(Math.ceil(y1),1,H)};
}
function cut_objectSelect(canvas,region,opts){
  opts=opts||{};const W=canvas.width,H=canvas.height,maxSide=opts.maxSide||640;
  const bb=cut__regionBox(region,W,H),bw=Math.max(2,bb.x1-bb.x0),bh=Math.max(2,bb.y1-bb.y0);
  const mg=Math.max(10,Math.round(Math.max(bw,bh)*0.12));
  const wx0=Math.max(0,bb.x0-mg),wy0=Math.max(0,bb.y0-mg),wx1=Math.min(W,bb.x1+mg),wy1=Math.min(H,bb.y1+mg),ww=wx1-wx0,wh=wy1-wy0;
  const pr=cut__prepare(canvas,wx0,wy0,ww,wh,maxSide),w=pr.w,h=pr.h,N=w*h,sx=w/ww,sy=h/wh;
  // region mask at low res
  const rc=mkCanvas(w,h),rx=cctx(rc);rx.fillStyle='#fff';rx.beginPath();
  if(region.rect){const r=region.rect;rx.rect((r.x-wx0)*sx,(r.y-wy0)*sy,r.w*sx,r.h*sy);}
  else region.poly.forEach((q,i)=>{const X=(q.x-wx0)*sx,Y=(q.y-wy0)*sy;i?rx.lineTo(X,Y):rx.moveTo(X,Y);});
  rx.closePath();rx.fill();
  const rd=rx.getImageData(0,0,w,h).data,inR=new Uint8Array(N);
  for(let i=0;i<N;i++)inR[i]=rd[i*4+3]>127?1:0;
  const dist=cut__dist(inR.map(v=>v?0:1),w,h);let mxd=0;for(let i=0;i<N;i++)if(inR[i]&&dist[i]>mxd)mxd=dist[i];
  const lbl=new Uint8Array(N);
  for(let i=0;i<N;i++)lbl[i]=!inR[i]?0:(dist[i]>=0.5*mxd?3:2);
  // flat background connected to the outside margin -> hard bg inside the region too
  let tb=null,bgm=null;
  const init=cut__autoInit(pr.lab,w,h,'auto');
  if(init.flat){bgm=init.bg;const er=cut__erode(bgm,w,h,1);tb=new Float32Array(N);
    for(let i=0;i<N;i++){if(inR[i]&&er[i]&&lbl[i]!==3)lbl[i]=0;else if(inR[i]&&er[i]&&dist[i]<0.5*mxd*0.8&&init.T[i]<1.2)lbl[i]=2;
      tb[i]=init.T[i]>3?Math.min(6,(init.T[i]-3)*3):0;}
    // keep central probable-fg from being forced to bg
  }
  if(!inR.some(v=>v))return {alpha:new Uint8ClampedArray(W*H),w:W,h:H};
  const m=cut__runGC(pr.lab,w,h,lbl,tb,opts);
  for(let i=0;i<N;i++)if(!inR[i])m[i]=0;
  cut__postMask(m,w,h,bgm,0.1);
  const a=cut__finalize(m,w,h,pr.full,ww,wh,opts),alpha=new Uint8ClampedArray(W*H);
  for(let y=0;y<wh;y++){const o=(y+wy0)*W+wx0,s=y*ww;for(let x=0;x<ww;x++)alpha[o+x]=a[s+x];}
  // clip to the user region at full res (soft) for rect
  if(region.rect){const r=region.rect;for(let y=0;y<H;y++)for(let x=0;x<W;x++){if(x<r.x||x>=r.x+r.w||y<r.y||y>=r.y+r.h)alpha[y*W+x]=0;}}
  return {alpha,w:W,h:H};
}

/* ---------- quickSelect: colour-similarity growth from a brush stroke ---------- */
function cut_quickSelect(canvas,pts,radius,opts){
  opts=opts||{};const W=canvas.width,H=canvas.height,tol=opts.tol==null?30:opts.tol,r=Math.max(1,radius||10);
  let out=opts.prev?new Uint8ClampedArray(opts.prev):new Uint8ClampedArray(W*H);
  if(!pts||!pts.length)return {alpha:out,w:W,h:H};
  let bx0=1e9,by0=1e9,bx1=-1e9,by1=-1e9;for(const p of pts){bx0=Math.min(bx0,p.x);by0=Math.min(by0,p.y);bx1=Math.max(bx1,p.x);by1=Math.max(by1,p.y);}
  const pad=Math.ceil(3*r)+2,x0=clamp(Math.floor(bx0-pad),0,W-1),y0=clamp(Math.floor(by0-pad),0,H-1),x1=clamp(Math.ceil(bx1+pad),x0+1,W),y1=clamp(Math.ceil(by1+pad),y0+1,H),ww=x1-x0,wh=y1-y0;
  const id=cctx(canvas).getImageData(x0,y0,ww,wh).data;
  const s=Math.max(1,Math.ceil(Math.max(ww,wh)/380)),w=Math.ceil(ww/s),h=Math.ceil(wh/s),N=w*h;
  let px;
  if(s===1)px=id;else{px=new Uint8ClampedArray(N*4);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){let a=0,b=0,c=0,n=0;for(let j=y*s;j<Math.min(wh,y*s+s);j++)for(let i=x*s;i<Math.min(ww,x*s+s);i++){const q=(j*ww+i)*4;a+=id[q];b+=id[q+1];c+=id[q+2];n++;}
      const o=(y*w+x)*4;px[o]=a/n;px[o+1]=b/n;px[o+2]=c/n;px[o+3]=255;}}
  const lab=cut__blurLab(cut__toLab(px,N),w,h,1),G=cut__gradMag(lab,w,h);
  // seed discs along the stroke
  const seed=new Uint8Array(N),rr=Math.max(1.2,r/s);
  const stamp=(cx,cy)=>{const ix=Math.round(cx),iy=Math.round(cy),R=Math.ceil(rr);
    for(let y=Math.max(0,iy-R);y<=Math.min(h-1,iy+R);y++)for(let x=Math.max(0,ix-R);x<=Math.min(w-1,ix+R);x++)if((x-cx)*(x-cx)+(y-cy)*(y-cy)<=rr*rr)seed[y*w+x]=1;};
  for(let i=0;i<pts.length;i++){
    const ax=(pts[i].x-x0)/s,ay=(pts[i].y-y0)/s;
    if(i===0)stamp(ax,ay);else{const bx=(pts[i-1].x-x0)/s,by=(pts[i-1].y-y0)/s,d=Math.hypot(ax-bx,ay-by),n=Math.max(1,Math.ceil(d/(rr*0.5)));
      for(let k=1;k<=n;k++)stamp(bx+(ax-bx)*k/n,by+(ay-by)*k/n);}}
  const sd=cut__dist(seed,w,h);
  // colour model of the seed: <=3 clusters
  const si=[];for(let i=0;i<N;i++)if(seed[i])si.push(i);
  const sa=Int32Array.from(si),K=Math.min(3,Math.max(1,Math.floor(sa.length/30))),comp=K>1?cut__kmeans(lab,sa,K,cut__rng(3),6):new Uint8Array(sa.length);
  const cm=new Float64Array(K*3),cn=new Float64Array(K),cv=new Float64Array(K);
  for(let i=0;i<sa.length;i++){const k=comp[i],p=sa[i]*3;cn[k]++;cm[k*3]+=lab[p];cm[k*3+1]+=lab[p+1];cm[k*3+2]+=lab[p+2];}
  for(let k=0;k<K;k++)if(cn[k]){cm[k*3]/=cn[k];cm[k*3+1]/=cn[k];cm[k*3+2]/=cn[k];}
  for(let i=0;i<sa.length;i++){const k=comp[i],p=sa[i]*3;cv[k]+=(lab[p]-cm[k*3])**2+(lab[p+1]-cm[k*3+1])**2+(lab[p+2]-cm[k*3+2])**2;}
  const gs=[];for(let i=0;i<sa.length;i++)gs.push(G[sa[i]]);gs.sort((a,b)=>a-b);
  const gthr=Math.max(3+tol*0.12,(gs.length?gs[Math.floor(gs.length*0.9)]:0)*1.6+tol*0.05);
  const eff=new Float64Array(K);for(let k=0;k<K;k++)eff[k]=(tol*0.75+1.2*Math.sqrt(cv[k]/Math.max(1,cn[k])/3*3))**2;
  const lim=2*rr+1,m=new Uint8Array(N),q=new Int32Array(N);let qh=0,qt=0;
  const ok=p=>{if(sd[p]>lim)return false;const a=p*3;for(let k=0;k<K;k++){if(!cn[k])continue;const d=(lab[a]-cm[k*3])**2+(lab[a+1]-cm[k*3+1])**2+(lab[a+2]-cm[k*3+2])**2;if(d<=eff[k])return true;}return false;};
  for(let i=0;i<sa.length;i++){const p=sa[i];m[p]=1;q[qt++]=p;}
  while(qh<qt){const p=q[qh++];if(G[p]>gthr&&!seed[p])continue;const x=p%w,y=(p/w)|0;
    if(x>0&&!m[p-1]&&ok(p-1)){m[p-1]=1;q[qt++]=p-1;}
    if(x<w-1&&!m[p+1]&&ok(p+1)){m[p+1]=1;q[qt++]=p+1;}
    if(y>0&&!m[p-w]&&ok(p-w)){m[p-w]=1;q[qt++]=p-w;}
    if(y<h-1&&!m[p+w]&&ok(p+w)){m[p+w]=1;q[qt++]=p+w;}}
  // smooth: fill small holes, 3x3 majority
  const inv=new Uint8Array(N);for(let i=0;i<N;i++)inv[i]=m[i]?0:1;
  const hc=cut__components(inv,w,h,false);for(let i=0;i<N;i++)if(inv[i]&&hc.touch[hc.id[i]]===0&&hc.area[hc.id[i]]<Math.max(30,0.05*qt))m[i]=1;
  const mm=new Uint8Array(N);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){let c=0;for(let j=Math.max(0,y-1);j<=Math.min(h-1,y+1);j++)for(let i=Math.max(0,x-1);i<=Math.min(w-1,x+1);i++)c+=m[j*w+i];mm[y*w+x]=c>=5?1:0;}
  const f=new Float32Array(N);for(let i=0;i<N;i++)f[i]=mm[i]*255;
  const b=cut__box(f,w,h,1),b8=new Uint8ClampedArray(N);for(let i=0;i<N;i++)b8[i]=b[i];
  const a=s===1?b8:cut__upsample(b8,w,h,ww,wh);
  const sub=opts.mode==='sub';
  for(let y=0;y<wh;y++){const o=(y+y0)*W+x0,so=y*ww;
    for(let x=0;x<ww;x++){const v=a[so+x];if(!v)continue;const t=o+x;out[t]=sub?out[t]*(255-v)/255:Math.max(out[t],v);}}
  return {alpha:out,w:W,h:H};
}

/* ---------- live-wire ---------- */
// edge field: Uint8 edge strength (0..255, high = strong edge) from a Sobel on luma; {w,h,e,x0,y0}
function cut__edgeRegion(canvas,x0,y0,ww,hh){
  const d=cctx(canvas).getImageData(x0,y0,ww,hh).data,n=ww*hh,L=new Float32Array(n);
  for(let i=0;i<n;i++)L[i]=0.299*d[i*4]+0.587*d[i*4+1]+0.114*d[i*4+2];
  const e=new Uint8Array(n);
  for(let y=0;y<hh;y++){const ya=Math.max(0,y-1)*ww,yb=y*ww,yc=Math.min(hh-1,y+1)*ww;
    for(let x=0;x<ww;x++){const xa=Math.max(0,x-1),xc=Math.min(ww-1,x+1);
      const gx=(L[ya+xc]+2*L[yb+xc]+L[yc+xc])-(L[ya+xa]+2*L[yb+xa]+L[yc+xa]),gy=(L[yc+xa]+2*L[yc+x]+L[yc+xc])-(L[ya+xa]+2*L[ya+x]+L[ya+xc]);
      const g=Math.sqrt(gx*gx+gy*gy)*0.25;e[yb+x]=g>255?255:g;}}
  return e;
}
function cut_edgeCostField(canvas){
  const W=canvas.width,H=canvas.height;return {w:W,h:H,e:cut__edgeRegion(canvas,0,0,W,H)};
}
function cut_magneticPath(canvas,from,to,opts){
  opts=opts||{};const W=canvas.width,H=canvas.height,pad=opts.pad==null?40:opts.pad;
  const fx=clamp(Math.round(from.x),0,W-1),fy=clamp(Math.round(from.y),0,H-1),tx=clamp(Math.round(to.x),0,W-1),ty=clamp(Math.round(to.y),0,H-1);
  const x0=Math.max(0,Math.min(fx,tx)-pad),y0=Math.max(0,Math.min(fy,ty)-pad),x1=Math.min(W,Math.max(fx,tx)+pad+1),y1=Math.min(H,Math.max(fy,ty)+pad+1),w=x1-x0,h=y1-y0,N=w*h;
  let e;const fld=opts.field;
  if(fld&&fld.w===W&&fld.h===H){e=new Uint8Array(N);for(let y=0;y<h;y++)e.set(fld.e.subarray((y+y0)*W+x0,(y+y0)*W+x0+w),y*w);}
  else e=cut__edgeRegion(canvas,x0,y0,w,h);
  // cost LUT: strong edge -> cheap
  const lut=new Float32Array(256);for(let i=0;i<256;i++){const t=Math.min(1,i/(opts.edgeScale||60));lut[i]=0.04+(1-t)*(1-t)*1.0;}
  const dist=new Float32Array(N).fill(1e30),par=new Int32Array(N).fill(-1),pos=new Int32Array(N).fill(-1),heap=new Int32Array(N+1);let hn=0;
  const up=i=>{const v=heap[i],dv=dist[v];while(i>1){const p=i>>1,pv=heap[p];if(dist[pv]<=dv)break;heap[i]=pv;pos[pv]=i;i=p;}heap[i]=v;pos[v]=i;};
  const down=i=>{const v=heap[i],dv=dist[v];for(;;){let c=i*2;if(c>hn)break;if(c<hn&&dist[heap[c+1]]<dist[heap[c]])c++;if(dist[heap[c]]>=dv)break;heap[i]=heap[c];pos[heap[i]]=i;i=c;}heap[i]=v;pos[v]=i;};
  const src=(fy-y0)*w+fx-x0,dst=(ty-y0)*w+tx-x0;
  dist[src]=0;heap[++hn]=src;pos[src]=1;
  const done=new Uint8Array(N),DX=[1,-1,0,0,1,-1,1,-1],DY=[0,0,1,-1,1,-1,-1,1],DW=[1,1,1,1,1.4142,1.4142,1.4142,1.4142];
  while(hn){
    const v=heap[1];hn--;if(hn){heap[1]=heap[hn+1];pos[heap[1]]=1;down(1);}pos[v]=-2;done[v]=1;
    if(v===dst)break;
    const x=v%w,y=(v/w)|0;
    for(let k=0;k<8;k++){const nx=x+DX[k],ny=y+DY[k];if(nx<0||ny<0||nx>=w||ny>=h)continue;const u=ny*w+nx;if(done[u])continue;
      const nd=dist[v]+lut[e[u]]*DW[k];
      if(nd<dist[u]){dist[u]=nd;par[u]=v;if(pos[u]>0){up(pos[u]);}else{heap[++hn]=u;pos[u]=hn;up(hn);}}}
  }
  const path=[];let c=dst;
  if(par[dst]<0&&dst!==src){return [{x:fx,y:fy},{x:tx,y:ty}];}
  while(c!==-1&&c!==undefined){path.push({x:x0+c%w,y:y0+((c/w)|0)});if(c===src)break;c=par[c];}
  return path.reverse();
}

/* ---------- scattered-data fill (push-pull) of a C-channel float image; known: Uint8 ---------- */
function cut__pushPull(v,known,w,h,C){
  const lv=[{v:Float32Array.from(v),k:Uint8Array.from(known),w,h}];
  for(let i=0;i<lv.length;i++){const a=lv[i];if(a.w<=1&&a.h<=1)break;if(i>14)break;
    const w2=Math.max(1,(a.w+1)>>1),h2=Math.max(1,(a.h+1)>>1),nv=new Float32Array(w2*h2*C),nk=new Uint8Array(w2*h2);
    for(let y=0;y<h2;y++)for(let x=0;x<w2;x++){let n=0;const s=new Float64Array(C);
      for(let j=y*2;j<Math.min(a.h,y*2+2);j++)for(let i2=x*2;i2<Math.min(a.w,x*2+2);i2++){const p=j*a.w+i2;if(a.k[p]){n++;for(let c=0;c<C;c++)s[c]+=a.v[p*C+c];}}
      if(n){nk[y*w2+x]=1;for(let c=0;c<C;c++)nv[(y*w2+x)*C+c]=s[c]/n;}}
    lv.push({v:nv,k:nk,w:w2,h:h2});}
  for(let i=lv.length-2;i>=0;i--){const f=lv[i],c=lv[i+1];
    for(let y=0;y<f.h;y++)for(let x=0;x<f.w;x++){const p=y*f.w+x;if(f.k[p])continue;
      const u=Math.min(c.w-1,Math.max(0,(x+0.5)/2-0.5)),vv=Math.min(c.h-1,Math.max(0,(y+0.5)/2-0.5)),x0=Math.floor(u),y0=Math.floor(vv),x1=Math.min(c.w-1,x0+1),y1=Math.min(c.h-1,y0+1),fx=u-x0,fy=vv-y0;
      for(let ch=0;ch<C;ch++)f.v[p*C+ch]=(c.v[(y0*c.w+x0)*C+ch]*(1-fx)+c.v[(y0*c.w+x1)*C+ch]*fx)*(1-fy)+(c.v[(y1*c.w+x0)*C+ch]*(1-fx)+c.v[(y1*c.w+x1)*C+ch]*fx)*fy;}
    // after filling, level i becomes fully "known" for the next finer level
    f.k.fill(1);}
  return lv[0].v;
}

/* ---------- PatchMatch inpainting on one level ---------- */
function cut__pmLevel(rgb,hole,w,h,nnf,iters,rnd,hw){
  const R=3,N=w*h,PS=2*R+1;
  if(w<PS+2||h<PS+2)return;
  const po=new Int32Array(PS*PS);{let k=0;for(let dy=-R;dy<=R;dy++)for(let dx=-R;dx<=R;dx++)po[k++]=dy*w+dx;}
  // valid source centres: whole patch known and inside
  const hi=new Int32Array((w+1)*(h+1));
  for(let y=0;y<h;y++){let r=0;for(let x=0;x<w;x++){r+=hole[y*w+x];hi[(y+1)*(w+1)+x+1]=hi[y*(w+1)+x+1]+r;}}
  const V=new Uint8Array(N),vl=[];
  for(let y=R;y<h-R;y++)for(let x=R;x<w-R;x++){const s=hi[(y+R+1)*(w+1)+x+R+1]-hi[(y-R)*(w+1)+x+R+1]-hi[(y+R+1)*(w+1)+x-R]+hi[(y-R)*(w+1)+x-R];if(s===0){V[y*w+x]=1;vl.push(y*w+x);}}
  if(!vl.length)return;
  // domain: in-bounds centres whose patch touches the hole
  const dom=[];
  for(let y=R;y<h-R;y++)for(let x=R;x<w-R;x++){const s=hi[(y+R+1)*(w+1)+x+R+1]-hi[(y-R)*(w+1)+x+R+1]-hi[(y+R+1)*(w+1)+x-R]+hi[(y-R)*(w+1)+x-R];if(s>0)dom.push(y*w+x);}
  const nd=dom.length;if(!nd)return;
  const D=Int32Array.from(dom),cost=new Float32Array(N),acc=new Float32Array(N*3),ws=new Float32Array(N);
  const nv=vl.length;
  const dcost=(p,c,best)=>{let s=0;
    for(let k=0;k<po.length;k++){const a=(p+po[k])*3,b=(c+po[k])*3,wt=hole[p+po[k]]?hw:1;
      const d0=rgb[a]-rgb[b],d1=rgb[a+1]-rgb[b+1],d2=rgb[a+2]-rgb[b+2];s+=wt*(d0*d0+d1*d1+d2*d2);if(s>=best)return s;}
    return s;};
  for(let i=0;i<nd;i++){const p=D[i];let c=nnf[p];if(c<0||!V[c])nnf[p]=vl[Math.floor(rnd()*nv)];}
  const maxR=Math.max(w,h);
  for(let it=0;it<iters;it++){
    for(let i=0;i<nd;i++){const p=D[i];cost[p]=dcost(p,nnf[p],1e30);}
    const fw=(it&1)===0;
    for(let ii=0;ii<nd;ii++){
      const p=D[fw?ii:nd-1-ii];let best=cost[p],bc=nnf[p];
      // propagation
      const n1=fw?p-1:p+1,n2=fw?p-w:p+w,sh1=fw?1:-1,sh2=fw?w:-w;
      let q=n1>=0&&n1<N?nnf[n1]:-1;
      if(q>=0){const c=q+sh1;if(c!==bc&&c>=0&&c<N&&V[c]){const d=dcost(p,c,best);if(d<best){best=d;bc=c;}}}
      q=n2>=0&&n2<N?nnf[n2]:-1;
      if(q>=0){const c=q+sh2;if(c!==bc&&c>=0&&c<N&&V[c]){const d=dcost(p,c,best);if(d<best){best=d;bc=c;}}}
      // random search
      const cx=bc%w,cy=(bc/w)|0;
      for(let r=maxR;r>=1;r>>=1){
        const x=cx+Math.floor((rnd()*2-1)*r),y=cy+Math.floor((rnd()*2-1)*r);
        if(x<R||y<R||x>=w-R||y>=h-R)continue;const c=y*w+x;if(!V[c]||c===bc)continue;
        const d=dcost(p,c,best);if(d<best){best=d;bc=c;}}
      nnf[p]=bc;cost[p]=best;
    }
    // vote
    acc.fill(0);ws.fill(0);
    for(let i=0;i<nd;i++){const p=D[i],c=nnf[p],wt=1/(1+cost[p]/(PS*PS*25));
      for(let k=0;k<po.length;k++){const q=p+po[k];if(!hole[q])continue;const a=(c+po[k])*3;acc[q*3]+=wt*rgb[a];acc[q*3+1]+=wt*rgb[a+1];acc[q*3+2]+=wt*rgb[a+2];ws[q]+=wt;}}
    for(let q=0;q<N;q++)if(hole[q]&&ws[q]>0){rgb[q*3]=acc[q*3]/ws[q];rgb[q*3+1]=acc[q*3+1]/ws[q];rgb[q*3+2]=acc[q*3+2]/ws[q];}
  }
}
// full multi-scale inpaint of RGBA window data; hole: Uint8 (1 = fill). returns Float32 RGB (n*3)
function cut__pmInpaint(px,hole0,w0,h0,o){
  const iters=o.iters||4,rnd=cut__rng(98765);
  // bbox of hole
  let bx0=w0,by0=h0,bx1=-1,by1=-1;for(let y=0;y<h0;y++)for(let x=0;x<w0;x++)if(hole0[y*w0+x]){if(x<bx0)bx0=x;if(x>bx1)bx1=x;if(y<by0)by0=y;if(y>by1)by1=y;}
  const md=Math.max(1,Math.min(bx1-bx0+1,by1-by0+1));
  let nl=1;while(nl<7&&md/Math.pow(2,nl)>=7&&Math.min(w0,h0)/Math.pow(2,nl)>=24)nl++;
  const L=[];{const rgb=new Float32Array(w0*h0*3);for(let i=0;i<w0*h0;i++){rgb[i*3]=px[i*4];rgb[i*3+1]=px[i*4+1];rgb[i*3+2]=px[i*4+2];}L.push({rgb,hole:hole0,w:w0,h:h0});}
  for(let l=1;l<nl;l++){const a=L[l-1],w=a.w>>1,h=a.h>>1,rgb=new Float32Array(w*h*3),hole=new Uint8Array(w*h);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){let n=0,s0=0,s1=0,s2=0,hh=0,t0=0,t1=0,t2=0;
      for(let j=0;j<2;j++)for(let i=0;i<2;i++){const p=(2*y+j)*a.w+2*x+i;t0+=a.rgb[p*3];t1+=a.rgb[p*3+1];t2+=a.rgb[p*3+2];if(a.hole[p])hh=1;else{n++;s0+=a.rgb[p*3];s1+=a.rgb[p*3+1];s2+=a.rgb[p*3+2];}}
      const o2=y*w+x;hole[o2]=hh;
      if(n){rgb[o2*3]=s0/n;rgb[o2*3+1]=s1/n;rgb[o2*3+2]=s2/n;}else{rgb[o2*3]=t0/4;rgb[o2*3+1]=t1/4;rgb[o2*3+2]=t2/4;}}
    L.push({rgb,hole,w,h});}
  // coarsest: diffusion init
  {const c=L[nl-1],kn=new Uint8Array(c.w*c.h);for(let i=0;i<kn.length;i++)kn[i]=c.hole[i]?0:1;
    const f=cut__pushPull(c.rgb,kn,c.w,c.h,3);for(let i=0;i<kn.length;i++)if(c.hole[i]){c.rgb[i*3]=f[i*3];c.rgb[i*3+1]=f[i*3+1];c.rgb[i*3+2]=f[i*3+2];}}
  let nnf=null;
  for(let l=nl-1;l>=0;l--){const c=L[l],N=c.w*c.h;
    const cur=new Int32Array(N).fill(-1);
    if(nnf){const p=L[l+1];
      for(let y=0;y<c.h;y++)for(let x=0;x<c.w;x++){const xs=Math.min(p.w-1,x>>1),ys=Math.min(p.h-1,y>>1),q=nnf[ys*p.w+xs];if(q>=0){const qx=(q%p.w)*2+(x&1),qy=((q/p.w)|0)*2+(y&1);if(qx<c.w&&qy<c.h)cur[y*c.w+x]=qy*c.w+qx;}}
      // upsample fill colours
      for(let y=0;y<c.h;y++)for(let x=0;x<c.w;x++){const pp=y*c.w+x;if(!c.hole[pp])continue;
        const u=Math.min(p.w-1,Math.max(0,(x+0.5)/2-0.5)),v=Math.min(p.h-1,Math.max(0,(y+0.5)/2-0.5)),x0=Math.floor(u),y0=Math.floor(v),x1=Math.min(p.w-1,x0+1),y1=Math.min(p.h-1,y0+1),fx=u-x0,fy=v-y0;
        for(let ch=0;ch<3;ch++)c.rgb[pp*3+ch]=(p.rgb[(y0*p.w+x0)*3+ch]*(1-fx)+p.rgb[(y0*p.w+x1)*3+ch]*fx)*(1-fy)+(p.rgb[(y1*p.w+x0)*3+ch]*(1-fx)+p.rgb[(y1*p.w+x1)*3+ch]*fx)*fy;}
    }
    cut__pmLevel(c.rgb,c.hole,c.w,c.h,cur,l===nl-1?iters+2:(l===0?Math.max(2,iters-1):iters),rnd,l===nl-1?0.15:0.5);
    nnf=cur;}
  return L[0].rgb;
}
function cut__maskArr(m,w,h){ // Uint8ClampedArray | canvas -> Uint8Array alpha plane
  if(m&&m.getContext){const d=cctx(m).getImageData(0,0,m.width,m.height).data,o=new Uint8Array(m.width*m.height);for(let i=0;i<o.length;i++)o[i]=d[i*4+3];return o;}
  return m;
}
function cut_inpaint(canvas,maskAlpha,opts){
  opts=opts||{};const W=canvas.width,H=canvas.height,out=cloneCanvas(canvas),m=cut__maskArr(maskAlpha,W,H);
  const margin=opts.margin==null?2:opts.margin,fe=opts.feather==null?2:opts.feather,cap=opts.maxWin||1200;
  let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(m[y*W+x]>127){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
  if(x1<0)return out;
  const bw=x1-x0+1,bh=y1-y0+1,mg=Math.max(24,Math.round(margin*Math.max(bw,bh)));
  const wx0=Math.max(0,x0-mg),wy0=Math.max(0,y0-mg),wx1=Math.min(W,x1+1+mg),wy1=Math.min(H,y1+1+mg),ww=wx1-wx0,wh=wy1-wy0;
  const id=cctx(canvas).getImageData(wx0,wy0,ww,wh);
  // synthesis region = mask dilated by feather (+1)
  const hm=new Uint8Array(ww*wh);for(let y=0;y<wh;y++)for(let x=0;x<ww;x++)hm[y*ww+x]=m[(y+wy0)*W+x+wx0]>127?1:0;
  const dr=Math.max(1,Math.round(fe));const D=cut__dilate(hm,ww,wh,dr);
  const sc=Math.min(1,cap/Math.max(ww,wh)),lw=Math.max(8,Math.round(ww*sc)),lh=Math.max(8,Math.round(wh*sc));
  let px,hole;
  if(sc<1){const tc=mkCanvas(ww,wh);cctx(tc).putImageData(id,0,0);px=cut__getData(cut__resize(tc,lw,lh)).data;
    hole=new Uint8Array(lw*lh);for(let y=0;y<lh;y++)for(let x=0;x<lw;x++){const sx=Math.min(ww-1,Math.floor(x/sc)),sy=Math.min(wh-1,Math.floor(y/sc));let v=0;
      for(let j=0;j<=1&&!v;j++)for(let i=0;i<=1;i++){const xx=Math.min(ww-1,sx+i*Math.ceil(1/sc)-0),yy=Math.min(wh-1,sy+j*Math.ceil(1/sc)-0);if(D[yy*ww+xx]){v=1;break;}}
      hole[y*lw+x]=v;}
    const hd=cut__dilate(hole,lw,lh,1);hole=hd;}
  else{px=id.data;hole=D;}
  const rgb=cut__pmInpaint(px,hole,lw,lh,opts);
  // to full-res fill image
  let fill;
  if(sc<1){const lc=mkCanvas(lw,lh),lx=cctx(lc),li=lx.createImageData(lw,lh);for(let i=0;i<lw*lh;i++){li.data[i*4]=rgb[i*3];li.data[i*4+1]=rgb[i*3+1];li.data[i*4+2]=rgb[i*3+2];li.data[i*4+3]=255;}
    lx.putImageData(li,0,0);fill=cut__getData(cut__resize(lc,ww,wh)).data;}
  else{fill=new Uint8ClampedArray(ww*wh*4);for(let i=0;i<ww*wh;i++){fill[i*4]=rgb[i*3];fill[i*4+1]=rgb[i*3+1];fill[i*4+2]=rgb[i*3+2];fill[i*4+3]=255;}}
  const f=new Float32Array(ww*wh);for(let i=0;i<f.length;i++)f[i]=D[i]*255;
  const al=fe>=1?cut__box(f,ww,wh,Math.max(1,Math.round(fe))):f,o=id.data;
  for(let i=0;i<ww*wh;i++){const a=hm[i]?1:Math.min(1,al[i]/255*1.0);if(a<=0)continue;
    for(let c=0;c<3;c++)o[i*4+c]=o[i*4+c]*(1-a)+fill[i*4+c]*a;}
  cctx(out).putImageData(id,wx0,wy0);
  return out;
}

/* ---------- healPatch: clone with low-frequency colour matching (Laplace-interpolated boundary difference) ---------- */
// src: {x,y,w,h} rect of `canvas` itself, or a canvas/ImageData-like canvas. Modifies `canvas` in place and returns it.
function cut_healPatch(canvas,src,dstX,dstY,maskAlpha){
  const W=canvas.width,H=canvas.height,cx=cctx(canvas);
  let sc,sw,sh;
  if(src&&src.getContext){sc=src;sw=src.width;sh=src.height;}
  else{sw=Math.round(src.w);sh=Math.round(src.h);sc=mkCanvas(sw,sh);cctx(sc).drawImage(canvas,Math.round(src.x),Math.round(src.y),sw,sh,0,0,sw,sh);}
  const dx=Math.round(dstX),dy=Math.round(dstY);
  const rx0=Math.max(0,dx),ry0=Math.max(0,dy),rx1=Math.min(W,dx+sw),ry1=Math.min(H,dy+sh),rw=rx1-rx0,rh=ry1-ry0;
  if(rw<1||rh<1)return canvas;
  const S=cctx(sc).getImageData(rx0-dx,ry0-dy,rw,rh).data;
  // dest incl. 1px frame
  const fx0=Math.max(0,rx0-1),fy0=Math.max(0,ry0-1),fx1=Math.min(W,rx1+1),fy1=Math.min(H,ry1+1),fw=fx1-fx0,fh=fy1-fy0;
  const dimg=cx.getImageData(fx0,fy0,fw,fh),Dd=dimg.data;
  // mask (default: full rect with soft edge)
  const mk=new Float32Array(rw*rh);
  let mA=null;if(maskAlpha){mA=cut__maskArr(maskAlpha,sw,sh);}
  for(let y=0;y<rh;y++)for(let x=0;x<rw;x++){
    if(mA)mk[y*rw+x]=mA[(y+ry0-dy)*sw+x+rx0-dx]/255;
    else{const e=Math.min(x+(rx0-dx),y+(ry0-dy),sw-1-(x+rx0-dx),sh-1-(y+ry0-dy)),r=Math.max(2,Math.min(sw,sh)*0.08);mk[y*rw+x]=Math.min(1,(e+0.5)/r);}}
  // boundary diff: known where mask<0.5 (inside rect) or frame cells outside rect; unknown = mask>=0.5
  const gw=rw+2,gh=rh+2,gv=new Float32Array(gw*gh*3),gk=new Uint8Array(gw*gh);
  for(let y=0;y<gh;y++)for(let x=0;x<gw;x++){
    const ix=x-1,iy=y-1,g=y*gw+x;
    const X=clamp(ix,0,rw-1),Y=clamp(iy,0,rh-1),si=(Y*rw+X)*4;
    const inside=ix>=0&&iy>=0&&ix<rw&&iy<rh;
    if(inside&&mk[iy*rw+ix]>=0.5)continue;
    const px=rx0+ix,py=ry0+iy;if(px<0||py<0||px>=W||py>=H)continue;
    const di=((py-fy0)*fw+(px-fx0))*4;
    gk[g]=1;gv[g*3]=Dd[di]-S[si];gv[g*3+1]=Dd[di+1]-S[si+1];gv[g*3+2]=Dd[di+2]-S[si+2];}
  let any=false;for(let i=0;i<gk.length;i++)if(gk[i]){any=true;break;}
  const diff=any?cut__pushPull(gv,gk,gw,gh,3):new Float32Array(gw*gh*3);
  // smooth the interpolated difference a little to avoid push-pull blockiness
  const sm=new Float32Array(gw*gh);const dsm=new Float32Array(gw*gh*3);
  for(let c=0;c<3;c++){for(let i=0;i<gw*gh;i++)sm[i]=diff[i*3+c];const b=cut__box(sm,gw,gh,Math.max(1,Math.round(Math.min(gw,gh)/16)));for(let i=0;i<gw*gh;i++)dsm[i*3+c]=b[i];}
  const od=cx.getImageData(rx0,ry0,rw,rh),O=od.data;
  for(let y=0;y<rh;y++)for(let x=0;x<rw;x++){const m=mk[y*rw+x];if(m<=0)continue;const i=(y*rw+x)*4,g=(y+1)*gw+x+1;
    for(let c=0;c<3;c++){const v=S[i+c]+(m>=0.5?dsm[g*3+c]:dsm[g*3+c]*m*2);O[i+c]=O[i+c]*(1-m)+v*m;}}
  cx.putImageData(od,rx0,ry0);
  return canvas;
}

/* ---------- red-eye ---------- */
function cut_redEye(canvas,cx,cy,radius,amount){
  const W=canvas.width,H=canvas.height,am=amount==null?1:amount,r=Math.max(1,radius),x0=Math.max(0,Math.floor(cx-r)),y0=Math.max(0,Math.floor(cy-r)),x1=Math.min(W,Math.ceil(cx+r)+1),y1=Math.min(H,Math.ceil(cy+r)+1);
  if(x1<=x0||y1<=y0)return canvas;
  const c=cctx(canvas),id=c.getImageData(x0,y0,x1-x0,y1-y0),d=id.data,w=x1-x0;
  for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
    const dd=Math.hypot(x-cx,y-cy)/r;if(dd>1)continue;
    const i=((y-y0)*w+x-x0)*4,R=d[i],G=d[i+1],B=d[i+2],gb=Math.max(G,B);
    const red=(R-gb)/(R+1);if(R<60||red<0.25)continue;
    const fall=dd<0.7?1:(1-dd)/0.3,k=Math.min(1,(red-0.25)/0.3)*fall*am;
    const nl=Math.min(R,(G+B)*0.5*0.9+4);
    d[i]=R+(nl-R)*k;d[i+1]=G+(Math.min(G,nl)-G)*k*0.5;d[i+2]=B+(Math.min(B,nl)-B)*k*0.5;}
  c.putImageData(id,x0,y0);return canvas;
}

/* ---------- alpha utilities ---------- */
function cut_alphaToCanvas(alpha,w,h){
  const c=mkCanvas(w,h),x=cctx(c),id=x.createImageData(w,h),d=id.data;
  for(let i=0;i<w*h;i++){d[i*4]=d[i*4+1]=d[i*4+2]=255;d[i*4+3]=alpha[i];}
  x.putImageData(id,0,0);return c;
}
// opts {thresh:127 (binarise before cleaning; 0 = keep soft values),minArea:0.001 (fraction of w*h; or px if >=1),keepLargest:false,
//       fillHoles:true,holeArea:0.01,shrink:0 (px, negative grows),smooth:1 (px),feather:0}
function cut_cleanAlpha(alpha,w,h,opts){
  opts=opts||{};const N=w*h,thr=opts.thresh==null?127:opts.thresh,m=new Uint8Array(N);
  for(let i=0;i<N;i++)m[i]=alpha[i]>thr?1:0;
  const ma=opts.minArea==null?0.001:opts.minArea,minA=ma>=1?ma:ma*N;
  const cc=cut__components(m,w,h,true);let mx=0;for(let k=1;k<=cc.n;k++)if(cc.area[k]>mx)mx=cc.area[k];
  for(let i=0;i<N;i++)if(m[i]){const a=cc.area[cc.id[i]];if(a<minA||(opts.keepLargest&&a<mx))m[i]=0;}
  if(opts.fillHoles!==false){const ha=opts.holeArea==null?0.01:opts.holeArea,lim=ha>=1?ha:ha*N,inv=new Uint8Array(N);
    for(let i=0;i<N;i++)inv[i]=m[i]?0:1;const hc=cut__components(inv,w,h,false);
    for(let i=0;i<N;i++)if(inv[i]&&hc.touch[hc.id[i]]===0&&hc.area[hc.id[i]]<=lim)m[i]=1;}
  let mm=m;
  const sh=opts.shrink||0;if(sh>0)mm=cut__erode(mm,w,h,sh);else if(sh<0)mm=cut__dilate(mm,w,h,-sh);
  const out=new Uint8ClampedArray(N),sm=opts.smooth==null?1:opts.smooth;
  if(sm>0||opts.feather>0){const f=new Float32Array(N);
    if(thr===0&&!opts.hard){for(let i=0;i<N;i++)f[i]=mm[i]?alpha[i]:0;}else for(let i=0;i<N;i++)f[i]=mm[i]*255;
    let b=f;const r1=Math.max(sm,0);if(r1>=1)b=cut__box(b,w,h,Math.round(r1));
    // re-sharpen so smoothing rounds the contour but does not leave a wide ramp
    const fe=opts.feather||0;if(fe>=1)b=cut__box(b,w,h,Math.round(fe));
    const lo=fe>=1?0:0.2,hi=fe>=1?255:0.8*255;
    for(let i=0;i<N;i++){const v=(b[i]-lo*255*(fe>=1?0:1))/(fe>=1?255:(hi-lo*255))*(fe>=1?255:255);out[i]=fe>=1?b[i]:(b[i]-lo*255)/(hi-lo*255)*255;}
  }else for(let i=0;i<N;i++)out[i]=mm[i]*255;
  return out;
}
