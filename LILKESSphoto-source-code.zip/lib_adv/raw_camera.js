/* ===== raw_camera.js : Camera-Raw-style develop pipeline (prefix raw_) =====
 Public API
  RAW_DEFAULTS                      neutral params object (see keys below)
  raw_process(imageData, params, {scale}) -> new ImageData (alpha kept; neutral params => pixel-identical copy)
       scale = preview downscale factor (<=1); radius based effects use fullres radii * scale. params may be partial.
  raw_histogram(imageData) -> {r,g,b,l:Uint32Array(256), max}
  raw_drawHistogram(ctx2d, hist, w, h)   stacked/additive colour histogram
  RAW_PRESETS  [{id,name,p}]  (p = full params)      raw_autoSettings(imageData) -> params
  RAW_SECTIONS UI schema (basic,curve,hsl,grade,detail,effects,optics)
  raw_getParam(p,'hsl.red.h') / raw_setParam(p,key,val) (returns p) / raw_clone(p) / raw_merge(base,over) / raw_params(partial)
 Params: temp,tint,exposure,contrast,highlights,shadows,whites,blacks,texture,clarity,dehaze,vibrance,saturation,
  curve,curveR,curveG,curveB (null|[[x,y]..0..255]), hsl{red,orange,yellow,green,aqua,blue,purple,magenta:{h,s,l}},
  grade{shadows,mids,highs:{h 0..360,s 0..100,l -100..100},blend,balance}, sharpen,sharpenRadius,masking,nrLum,nrColor,
  vignette,vigMid,vigFeather,grain,grainSize, caFix(bool), lensCorr, bw(bool)
*/
const RAW_BANDS=['red','orange','yellow','green','aqua','blue','purple','magenta'];
const RAW_BAND_HUE=[0,30,60,120,180,240,275,320];

function raw_mkDefaults(){
  const hsl={};for(const b of RAW_BANDS)hsl[b]={h:0,s:0,l:0};
  return {temp:0,tint:0,exposure:0,contrast:0,highlights:0,shadows:0,whites:0,blacks:0,texture:0,clarity:0,dehaze:0,vibrance:0,saturation:0,
    curve:null,curveR:null,curveG:null,curveB:null,hsl,
    grade:{shadows:{h:0,s:0,l:0},mids:{h:0,s:0,l:0},highs:{h:0,s:0,l:0},blend:50,balance:0},
    sharpen:0,sharpenRadius:1,masking:0,nrLum:0,nrColor:0,
    vignette:0,vigMid:50,vigFeather:50,grain:0,grainSize:25,caFix:false,lensCorr:0,bw:false};
}
const RAW_DEFAULTS=raw_mkDefaults();
function raw_clone(o){return o==null||typeof o!=='object'?o:Array.isArray(o)?o.map(raw_clone):Object.keys(o).reduce((a,k)=>(a[k]=raw_clone(o[k]),a),{});}
function raw_merge(b,o){
  if(o==null)return b;
  for(const k in o){const v=o[k];
    if(v&&typeof v==='object'&&!Array.isArray(v)&&b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k]))raw_merge(b[k],v);else b[k]=raw_clone(v);}
  return b;
}
function raw_params(p){return raw_merge(raw_mkDefaults(),p);}
function raw_getParam(p,key){let o=p;for(const k of key.split('.')){if(o==null)return undefined;o=o[k];}return o;}
function raw_setParam(p,key,val){
  const ks=key.split('.');let o=p;
  for(let i=0;i<ks.length-1;i++){if(o[ks[i]]==null||typeof o[ks[i]]!=='object')o[ks[i]]={};o=o[ks[i]];}
  o[ks[ks.length-1]]=val;return p;
}

/* ---------- small math / filters ---------- */
function raw_ss(a,b,x){const t=x<=a?0:x>=b?1:(x-a)/(b-a);return t*t*(3-2*t);}
function raw_luma(F,n){const Y=new Float32Array(n);for(let i=0,j=0;i<n;i++,j+=3)Y[i]=0.2126*F[j]+0.7152*F[j+1]+0.0722*F[j+2];return Y;}
/* running-sum box filter (edge shrinking window), s->d (may alias), t = scratch */
function raw_box(s,d,w,h,r,t){
  for(let y=0;y<h;y++){const o=y*w;let acc=0;const e0=Math.min(r,w-1);
    for(let i=0;i<=e0;i++)acc+=s[o+i];
    for(let x=0;x<w;x++){const hi=Math.min(w-1,x+r),lo=Math.max(0,x-r);t[o+x]=acc/(hi-lo+1);
      if(x+r+1<w)acc+=s[o+x+r+1];if(x-r>=0)acc-=s[o+x-r];}}
  const acc=new Float64Array(w),e1=Math.min(r,h-1);
  for(let y=0;y<=e1;y++){const o=y*w;for(let x=0;x<w;x++)acc[x]+=t[o+x];}
  for(let y=0;y<h;y++){const o=y*w,inv=1/(Math.min(h-1,y+r)-Math.max(0,y-r)+1);
    for(let x=0;x<w;x++)d[o+x]=acc[x]*inv;
    if(y+r+1<h){const o2=(y+r+1)*w;for(let x=0;x<w;x++)acc[x]+=t[o2+x];}
    if(y-r>=0){const o3=(y-r)*w;for(let x=0;x<w;x++)acc[x]-=t[o3+x];}}
}
function raw_blurF(a,w,h,r,it){const t=new Float32Array(a.length);for(let k=0;k<it;k++)raw_box(a,a,w,h,r,t);return a;}
function raw_down(s,w,h,f,st,off){
  st=st||1;off=off||0;const w2=Math.ceil(w/f),h2=Math.ceil(h/f),d=new Float32Array(w2*h2);
  for(let y=0;y<h2;y++){const y0=y*f,y1=Math.min(h,y0+f);
    for(let x=0;x<w2;x++){const x0=x*f,x1=Math.min(w,x0+f);let a=0;
      for(let yy=y0;yy<y1;yy++){const o=yy*w;for(let xx=x0;xx<x1;xx++)a+=s[(o+xx)*st+off];}
      d[y*w2+x]=a/((y1-y0)*(x1-x0));}}
  return {d,w:w2,h:h2};
}
function raw_up(s,w2,h2,w,h,f){
  const d=new Float32Array(w*h),x0=new Int32Array(w),x1=new Int32Array(w),xf=new Float32Array(w);
  for(let x=0;x<w;x++){let u=(x+0.5)/f-0.5;if(u<0)u=0;let i=Math.min(w2-1,Math.floor(u));x0[x]=i;x1[x]=Math.min(w2-1,i+1);xf[x]=Math.min(1,u-i);}
  for(let y=0;y<h;y++){let v=(y+0.5)/f-0.5;if(v<0)v=0;const j=Math.min(h2-1,Math.floor(v)),j1=Math.min(h2-1,j+1),fy=Math.min(1,v-j),oa=j*w2,ob=j1*w2,o=y*w;
    for(let x=0;x<w;x++){const a=x0[x],b=x1[x],fx=xf[x];
      const t=s[oa+a]+(s[oa+b]-s[oa+a])*fx,u2=s[ob+a]+(s[ob+b]-s[ob+a])*fx;d[o+x]=t+(u2-t)*fy;}}
  return d;
}
/* fast guided filter: guide I, sources Ps (arrays), radius r (px), eps -> array of filtered Ps (full res) */
function raw_guided(I,Ps,w,h,r,eps){
  const f=r>6?Math.ceil(r/4):1;
  let Is=I,ws=w,hs=h,Pss=Ps,rs=r;
  if(f>1){const a=raw_down(I,w,h,f);Is=a.d;ws=a.w;hs=a.h;Pss=Ps.map(p=>p===I?Is:raw_down(p,w,h,f).d);rs=Math.max(1,Math.round(r/f));}
  const n=ws*hs,t=new Float32Array(n),mI=new Float32Array(n),vr=new Float32Array(n),tmp=new Float32Array(n);
  raw_box(Is,mI,ws,hs,rs,t);
  for(let i=0;i<n;i++)tmp[i]=Is[i]*Is[i];
  raw_box(tmp,vr,ws,hs,rs,t);
  for(let i=0;i<n;i++)vr[i]=Math.max(0,vr[i]-mI[i]*mI[i]);
  const out=[];
  for(let k=0;k<Pss.length;k++){
    const P=Pss[k],self=(P===Is),a=new Float32Array(n),b=new Float32Array(n);
    if(self){for(let i=0;i<n;i++){const aa=vr[i]/(vr[i]+eps);a[i]=aa;b[i]=mI[i]*(1-aa);}}
    else{const mP=new Float32Array(n),mIP=new Float32Array(n);
      raw_box(P,mP,ws,hs,rs,t);for(let i=0;i<n;i++)tmp[i]=Is[i]*P[i];raw_box(tmp,mIP,ws,hs,rs,t);
      for(let i=0;i<n;i++){const aa=(mIP[i]-mI[i]*mP[i])/(vr[i]+eps);a[i]=aa;b[i]=mP[i]-aa*mI[i];}}
    raw_box(a,a,ws,hs,rs,t);raw_box(b,b,ws,hs,rs,t);
    let A=a,B=b;if(f>1){A=raw_up(a,ws,hs,w,h,f);B=raw_up(b,ws,hs,w,h,f);}
    const q=new Float32Array(w*h);for(let i=0;i<q.length;i++)q[i]=A[i]*I[i]+B[i];
    out.push(q);
  }
  return out;
}

/* ---------- sRGB tables ---------- */
let raw_decT=null,raw_encT=null;
function raw_tables(){
  if(raw_decT)return;
  raw_decT=new Float32Array(4098);raw_encT=new Float32Array(4098);
  for(let i=0;i<4098;i++){const v=i/4096;raw_decT[i]=v<=0.04045?v/12.92:Math.pow((v+0.055)/1.055,2.4);
    const l=8*v*v;raw_encT[i]=l<=0.0031308?l*12.92:1.055*Math.pow(l,1/2.4)-0.055;}
}
function raw_dec(v){v=v<0?0:v>1?1:v;const x=v*4096,i=x|0,f=x-i;return raw_decT[i]+(raw_decT[i+1]-raw_decT[i])*f;}
function raw_enc(l){l=l<0?0:l>8?8:l;const x=Math.sqrt(l*0.125)*4096,i=x|0,f=x-i;return raw_encT[i]+(raw_encT[i+1]-raw_encT[i])*f;}
function raw_knee(v,tm,inv){if(v<=0.92)return v;return 0.92+0.08*(1-Math.exp(-(v-0.92)*12.5))*inv;}

/* ---------- stages ---------- */
function raw_lens(F,w,h,lc){
  const k=lc/100*0.12,z=k>0?1/(1+k):1,vg=lc/100*0.25,cx=(w-1)/2,cy=(h-1)/2,R2=(cx*cx+cy*cy)||1,O=new Float32Array(F.length);
  for(let y=0;y<h;y++){const dy=y-cy;
    for(let x=0;x<w;x++){const dx=x-cx,r2=(dx*dx+dy*dy)/R2,fs=z*(1+k*r2);
      let sx=cx+dx*fs,sy=cy+dy*fs;sx=sx<0?0:sx>w-1?w-1:sx;sy=sy<0?0:sy>h-1?h-1:sy;
      const x0=sx|0,y0=sy|0,x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1),fx=sx-x0,fy=sy-y0;
      const a=(y0*w+x0)*3,b=(y0*w+x1)*3,c=(y1*w+x0)*3,d=(y1*w+x1)*3,g=1+vg*r2,o=(y*w+x)*3;
      for(let ch=0;ch<3;ch++){const t=F[a+ch]+(F[b+ch]-F[a+ch])*fx,u=F[c+ch]+(F[d+ch]-F[c+ch])*fx;O[o+ch]=(t+(u-t)*fy)*g;}}}
  return O;
}
function raw_wbExp(F,n,P){
  raw_tables();
  const t=P.temp/100,ti=P.tint/100;
  let gr=Math.pow(2,0.45*t),gb=Math.pow(2,-0.45*t),gg=Math.pow(2,-0.3*ti);
  const kn=1/(0.2126*gr+0.7152*gg+0.0722*gb),ex=Math.pow(2,P.exposure);
  gr*=kn*ex;gg*=kn*ex;gb*=kn*ex;
  const vmax=raw_enc(Math.max(gr,gg,gb)),tm=(vmax-0.92)*12.5,inv=vmax>1?1/(1-Math.exp(-tm)):1,useK=vmax>1;
  // knee maps [0.92,vmax]->[0.92,1]
  for(let i=0;i<n*3;i+=3){
    let r=raw_enc(raw_dec(F[i])*gr),g=raw_enc(raw_dec(F[i+1])*gg),b=raw_enc(raw_dec(F[i+2])*gb);
    if(useK){r=raw_knee(r,tm,inv);g=raw_knee(g,tm,inv);b=raw_knee(b,tm,inv);}
    F[i]=r>1?1:r;F[i+1]=g>1?1:g;F[i+2]=b>1?1:b;
  }
}
function raw_shadHigh(F,w,h,P,s){
  const n=w*h,Y=raw_luma(F,n),B=raw_guided(Y,[Y],w,h,Math.max(2,Math.round(60*s)),0.02)[0];
  const sh=P.shadows/100,hl=P.highlights/100;
  for(let i=0,j=0;i<n;i++,j+=3){
    const b=B[i]<0?0:B[i]>1?1:B[i],y=Y[i]>1?1:Y[i],m=0.7*b+0.3*y;
    const st=(sh>=0?sh:sh*0.9)*(1-raw_ss(0.05,0.65,m))+(hl<0?hl:hl*0.6)*raw_ss(0.3,0.95,m);
    const g=Math.exp(st*0.6931);let r=F[j]*g,gg=F[j+1]*g,bb=F[j+2]*g;
    F[j]=r>1?1:r;F[j+1]=gg>1?1:gg;F[j+2]=bb>1?1:bb;
  }
}
function raw_toneLUT(P){
  const L=new Float32Array(1025),bp=-0.1*P.blacks/100,wp=1-0.25*P.whites/100,a=P.contrast/100*0.8,ymax=1/wp,tm=(ymax-0.95)*20,inv=ymax>1?1/(1-Math.exp(-tm)):1;
  for(let i=0;i<=1024;i++){
    let y=i/1024;y=(y-bp)/(1-bp);
    if(y<0.02){const q=0.02;y=y<=-q*0?(y<-0.1?0:0.02*Math.exp(y/0.02-1)*0+Math.max(0,y)):y;} // hard floor handled below
    if(y<0)y=0;
    y=y/wp;
    if(ymax>1&&y>0.95)y=0.95+0.05*(1-Math.exp(-(y-0.95)*20))*inv;
    y=y>1?1:y;
    y=y+a*y*(1-y)*(2*y-1);
    L[i]=y<0?0:y>1?1:y;
  }
  return L;
}
function raw_applyLUT(F,n,L){
  for(let i=0;i<n*3;i++){let v=F[i];v=v<0?0:v>1?1:v;const x=v*1024,k=x|0,f=x-k;F[i]=L[k]+(L[k+1>1024?1024:k+1]-L[k])*f;}
}
function raw_localContrast(F,w,h,P,s){
  const n=w*h,Y=raw_luma(F,n),cl=P.clarity/100,tx=P.texture/100;
  let B1=null,B2=null;
  if(cl)B1=raw_guided(Y,[Y],w,h,Math.max(3,Math.round(30*s)),0.02)[0];
  if(tx)B2=raw_guided(Y,[Y],w,h,Math.max(1,Math.round(2.5*s)),0.0006)[0];
  for(let i=0,j=0;i<n;i++,j+=3){
    const y=Y[i];let d=0;const wm=0.3+0.7*4*Math.min(1,Math.max(0,y))*(1-Math.min(1,Math.max(0,y)));
    if(B1)d+=cl*1.3*(y-B1[i])*(cl>0?wm:1);
    if(B2)d+=tx*1.2*(y-B2[i])*wm;
    let ra=(y+d+0.02)/(y+0.02);ra=ra<0.2?0.2:ra>4?4:ra;
    let r=F[j]*ra,g=F[j+1]*ra,b=F[j+2]*ra;
    F[j]=r<0?0:r>1?1:r;F[j+1]=g<0?0:g>1?1:g;F[j+2]=b<0?0:b>1?1:b;
  }
}
function raw_minF(s,w,h,r){
  const t=new Float32Array(s.length),d=new Float32Array(s.length);
  for(let y=0;y<h;y++){const o=y*w;for(let x=0;x<w;x++){let m=1e9;const a=Math.max(0,x-r),b=Math.min(w-1,x+r);for(let i=a;i<=b;i++){const v=s[o+i];if(v<m)m=v;}t[o+x]=m;}}
  for(let y=0;y<h;y++){const a=Math.max(0,y-r),b=Math.min(h-1,y+r);for(let x=0;x<w;x++){let m=1e9;for(let i=a;i<=b;i++){const v=t[i*w+x];if(v<m)m=v;}d[y*w+x]=m;}}
  return d;
}
function raw_dehaze(F,w,h,P,s){
  const dz=P.dehaze/100,n=w*h,f=Math.max(1,Math.ceil(Math.max(w,h)/320));
  const R=raw_down(F,w,h,f,3,0),G=raw_down(F,w,h,f,3,1),Bc=raw_down(F,w,h,f,3,2),ws=R.w,hs=R.h,ns=ws*hs;
  const mn=new Float32Array(ns);
  for(let i=0;i<ns;i++)mn[i]=Math.min(R.d[i],G.d[i],Bc.d[i]);
  let dark=raw_minF(mn,ws,hs,2);
  // atmospheric light: mean colour of the brightest 0.1% dark-channel pixels
  const hist=new Uint32Array(256);for(let i=0;i<ns;i++)hist[Math.min(255,dark[i]*255|0)]++;
  let need=Math.max(1,Math.round(ns*0.001)),th=255,acc=0;for(;th>0;th--){acc+=hist[th];if(acc>=need)break;}
  let ar=0,ag=0,ab=0,c=0;for(let i=0;i<ns;i++)if(Math.min(255,dark[i]*255|0)>=th){ar+=R.d[i];ag+=G.d[i];ab+=Bc.d[i];c++;}
  ar=Math.min(1,Math.max(0.6,ar/c));ag=Math.min(1,Math.max(0.6,ag/c));ab=Math.min(1,Math.max(0.6,ab/c));
  if(dz<0){const k=-dz*0.6;
    for(let i=0;i<n*3;i+=3){F[i]=F[i]*(1-k)+ar*k;F[i+1]=F[i+1]*(1-k)+ag*k;F[i+2]=F[i+2]*(1-k)+ab*k;}return;}
  for(let i=0;i<ns;i++)mn[i]=Math.min(R.d[i]/ar,G.d[i]/ag,Bc.d[i]/ab);
  dark=raw_minF(mn,ws,hs,2);
  const om=0.85*dz,tS=new Float32Array(ns),gy=new Float32Array(ns);
  for(let i=0;i<ns;i++){tS[i]=1-om*dark[i];gy[i]=0.2126*R.d[i]+0.7152*G.d[i]+0.0722*Bc.d[i];}
  const tr=raw_guided(gy,[tS],ws,hs,Math.max(2,Math.round(40*s/f)),0.002)[0];
  const T=raw_up(tr,ws,hs,w,h,f);
  for(let i=0,j=0;i<n;i++,j+=3){
    let t=T[i];t=t<0.25?0.25:t>1?1:t;const it=1/t;
    let r=(F[j]-ar)*it+ar,g=(F[j+1]-ag)*it+ag,b=(F[j+2]-ab)*it+ab;
    F[j]=r<0?0:r>1?1:r;F[j+1]=g<0?0:g>1?1:g;F[j+2]=b<0?0:b>1?1:b;
  }
}
function raw_vibSat(F,n,P){
  const vib=P.vibrance/100,sat=P.saturation/100,fs=1+sat;
  for(let i=0;i<n*3;i+=3){
    let r=F[i],g=F[i+1],b=F[i+2];
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),dl=mx-mn;if(dl<1e-5)continue;
    const sv=dl/mx;let f=fs;
    if(vib>0){let p=0;if(mx===r){const hd=(g-b)/dl*60;p=Math.max(0,1-Math.abs(hd-25)/30);}
      const q=1-sv;f*=1+vib*q*q*(1-0.75*p)*1.2;}
    else if(vib<0)f*=1+vib*(0.5+0.5*sv);
    if(f<0)f=0;
    const y=0.2126*r+0.7152*g+0.0722*b;
    if(f>1){ // avoid hue-shifting clip
      let fm=f;const dr=r-y,dg=g-y,db=b-y;
      if(dr>1e-6)fm=Math.min(fm,(1-y)/dr);else if(dr<-1e-6)fm=Math.min(fm,y/-dr);
      if(dg>1e-6)fm=Math.min(fm,(1-y)/dg);else if(dg<-1e-6)fm=Math.min(fm,y/-dg);
      if(db>1e-6)fm=Math.min(fm,(1-y)/db);else if(db<-1e-6)fm=Math.min(fm,y/-db);
      f=Math.max(1,fm);
    }
    F[i]=y+(r-y)*f;F[i+1]=y+(g-y)*f;F[i+2]=y+(b-y)*f;
  }
}
/* monotone cubic (Fritsch-Carlson) curve -> LUT 1025 (values 0..1) */
function raw_curveLUT(pts){
  let p=pts.map(a=>[+a[0],+a[1]]).sort((a,b)=>a[0]-b[0]);
  const q=[];for(const a of p){if(q.length&&a[0]-q[q.length-1][0]<1e-6)q[q.length-1]=a;else q.push(a);}
  p=q;if(p.length<2)p=[[0,p.length?p[0][1]:0],[255,p.length?p[0][1]:255]];
  if(p[0][0]>0)p.unshift([0,p[0][1]]);if(p[p.length-1][0]<255)p.push([255,p[p.length-1][1]]);
  const n=p.length,dx=[],m=[],t=new Array(n);
  for(let i=0;i<n-1;i++){dx[i]=p[i+1][0]-p[i][0];m[i]=(p[i+1][1]-p[i][1])/dx[i];}
  t[0]=m[0];t[n-1]=m[n-2];for(let i=1;i<n-1;i++)t[i]=m[i-1]*m[i]<=0?0:(m[i-1]+m[i])/2;
  for(let i=0;i<n-1;i++){if(m[i]===0){t[i]=0;t[i+1]=0;continue;}const a=t[i]/m[i],b=t[i+1]/m[i],s=a*a+b*b;if(s>9){const k=3/Math.sqrt(s);t[i]=k*a*m[i];t[i+1]=k*b*m[i];}}
  const L=new Float32Array(1025);let seg=0;
  for(let i=0;i<=1024;i++){const x=i/1024*255;while(seg<n-2&&x>p[seg+1][0])seg++;
    const h=dx[seg],u=(x-p[seg][0])/h,u2=u*u,u3=u2*u;
    const y=(2*u3-3*u2+1)*p[seg][1]+(u3-2*u2+u)*h*t[seg]+(-2*u3+3*u2)*p[seg+1][1]+(u3-u2)*h*t[seg+1];
    L[i]=Math.min(1,Math.max(0,y/255));}
  return L;
}
function raw_lutAt(L,v){v=v<0?0:v>1?1:v;const x=v*1024,k=x|0;return L[k]+(L[k<1024?k+1:1024]-L[k])*(x-k);}
function raw_curves(F,n,P){
  const M=P.curve?raw_curveLUT(P.curve):null,ch=[P.curveR,P.curveG,P.curveB].map(c=>c?raw_curveLUT(c):null),Ls=[];
  for(let c=0;c<3;c++){
    if(!M&&!ch[c]){Ls.push(null);continue;}
    const L=new Float32Array(1025);
    for(let i=0;i<=1024;i++){let v=i/1024;if(M)v=raw_lutAt(M,v);if(ch[c])v=raw_lutAt(ch[c],v);L[i]=v;}
    Ls.push(L);
  }
  for(let c=0;c<3;c++){const L=Ls[c];if(!L)continue;
    for(let i=c;i<n*3;i+=3){let v=F[i];v=v<0?0:v>1?1:v;const x=v*1024,k=x|0;F[i]=L[k]+(L[k<1024?k+1:1024]-L[k])*(x-k);}}
}
function raw_hslTables(P){
  const dh=new Float32Array(362),ds=new Float32Array(362),dl=new Float32Array(362),c=RAW_BAND_HUE;
  for(let d=0;d<=361;d++){
    const h=d%360;let i=7;for(let k=0;k<8;k++){if(h>=c[k]&&(k===7||h<c[k+1])){i=k;break;}}
    const j=(i+1)%8,c0=c[i],c1=i===7?360:c[j],t=(h-c0)/(c1-c0),s=t*t*(3-2*t),A=P.hsl[RAW_BANDS[i]],B=P.hsl[RAW_BANDS[j]];
    dh[d]=((A.h||0)*(1-s)+(B.h||0)*s)*0.3;ds[d]=((A.s||0)*(1-s)+(B.s||0)*s)/100;dl[d]=((A.l||0)*(1-s)+(B.l||0)*s)/100;
  }
  return {dh,ds,dl};
}
function raw_hsvCh(nn,h6,v,s){let k=(nn+h6)%6;const m=Math.max(0,Math.min(k,4-k,1));return v-v*s*m;}
function raw_hslMix(F,n,P){
  const T=raw_hslTables(P),dh=T.dh,ds=T.ds,dl=T.dl,bw=P.bw;
  for(let i=0;i<n*3;i+=3){
    const r=F[i],g=F[i+1],b=F[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),dlt=mx-mn;
    if(dlt<1e-5)continue;
    const sv=dlt/mx,gate=raw_ss(0.03,0.2,sv)*raw_ss(0.02,0.1,mx);
    let hh=mx===r?(g-b)/dlt:mx===g?2+(b-r)/dlt:4+(r-g)/dlt;if(hh<0)hh+=6;
    const deg=hh*60,k=deg|0,fr=deg-k;
    if(bw){ // handled elsewhere
      continue;}
    const sh=(dh[k]+(dh[k+1]-dh[k])*fr)*gate,ss=(ds[k]+(ds[k+1]-ds[k])*fr)*gate,ll=(dl[k]+(dl[k+1]-dl[k])*fr)*gate;
    let nd=deg+sh;nd=nd<0?nd+360:nd>=360?nd-360:nd;
    const s2=Math.min(1,Math.max(0,sv*(1+ss))),v2=mx*(1+ll*0.5),h6=nd/60;
    const R=raw_hsvCh(5,h6,v2,s2),G=raw_hsvCh(3,h6,v2,s2),B=raw_hsvCh(1,h6,v2,s2);
    F[i]=R>1?1:R<0?0:R;F[i+1]=G>1?1:G<0?0:G;F[i+2]=B>1?1:B<0?0:B;
  }
}
function raw_bw(F,n,P){
  const T=raw_hslTables(P),dl=T.dl;
  for(let i=0;i<n*3;i+=3){
    const r=F[i],g=F[i+1],b=F[i+2],y=0.2126*r+0.7152*g+0.0722*b,mx=Math.max(r,g,b),dlt=mx-Math.min(r,g,b);
    let o=y;
    if(dlt>1e-5){let hh=mx===r?(g-b)/dlt:mx===g?2+(b-r)/dlt:4+(r-g)/dlt;if(hh<0)hh+=6;
      const deg=hh*60,k=deg|0,fr=deg-k,gate=raw_ss(0.0,0.25,dlt/mx);
      o=y*(1+(dl[k]+(dl[k+1]-dl[k])*fr)*gate*1.1);}
    o=o<0?0:o>1?1:o;F[i]=o;F[i+1]=o;F[i+2]=o;
  }
}
function raw_grade(F,n,P){
  const G=P.grade,zs=[G.shadows,G.mids,G.highs],off=[];
  for(const z of zs){
    const c=raw_hsv2(z.h||0,1,1),y=0.2126*c[0]+0.7152*c[1]+0.0722*c[2],a=(z.s||0)/100*0.35;
    off.push([(c[0]-y)*a,(c[1]-y)*a,(c[2]-y)*a,(z.l||0)/100*0.3]);
  }
  const bal=(G.balance||0)/100*0.25,wd=0.1+0.35*(G.blend==null?50:G.blend)/100,lo=0.33+bal,hi=0.66+bal;
  const e0=off[0],e1=off[1],e2=off[2];
  for(let i=0;i<n*3;i+=3){
    const r=F[i],g=F[i+1],b=F[i+2],y=0.2126*r+0.7152*g+0.0722*b;
    const ws=1-raw_ss(lo-wd,lo+wd,y),wh=raw_ss(hi-wd,hi+wd,y);let wm=1-ws-wh;if(wm<0)wm=0;
    const nr=r+e0[0]*ws+e1[0]*wm+e2[0]*wh+e0[3]*ws+e1[3]*wm+e2[3]*wh,
          ng=g+e0[1]*ws+e1[1]*wm+e2[1]*wh+e0[3]*ws+e1[3]*wm+e2[3]*wh,
          nb=b+e0[2]*ws+e1[2]*wm+e2[2]*wh+e0[3]*ws+e1[3]*wm+e2[3]*wh;
    F[i]=nr<0?0:nr>1?1:nr;F[i+1]=ng<0?0:ng>1?1:ng;F[i+2]=nb<0?0:nb>1?1:nb;
  }
}
function raw_hsv2(h,s,v){const h6=(((h%360)+360)%360)/60;return [raw_hsvCh(5,h6,v,s),raw_hsvCh(3,h6,v,s),raw_hsvCh(1,h6,v,s)];}
function raw_caFix(F,w,h,s){
  const n=w*h,Y=raw_luma(F,n),E=new Float32Array(n);
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x;E[i]=Math.max(Math.abs(Y[i+1]-Y[i-1]),Math.abs(Y[i+w]-Y[i-w]));}
  const r=Math.max(1,Math.round(2*s+0.5));
  // dilate edge map (max filter via blur of the squared edge + blur)
  raw_blurF(E,w,h,r,2);
  for(let i=0,j=0;i<n;i++,j+=3){
    const e=E[i];if(e<0.012)continue;
    const R=F[j],G=F[j+1],B=F[j+2],mx=Math.max(R,G,B),dlt=mx-Math.min(R,G,B);if(dlt<1e-4)continue;
    const sv=dlt/mx;let hh=mx===R?(G-B)/dlt:mx===G?2+(B-R)/dlt:4+(R-G)/dlt;if(hh<0)hh+=6;const deg=hh*60;
    let hw=0;
    if(deg>=250&&deg<=340)hw=Math.min(1,Math.min(deg-250,340-deg)/15);   // purple/magenta
    else if(deg>=70&&deg<=170)hw=0.7*Math.min(1,Math.min(deg-70,170-deg)/15);// green
    if(hw===0)continue;
    const fac=raw_ss(0.012,0.05,e)*hw*raw_ss(0.12,0.35,sv)*0.95;
    const y=0.2126*R+0.7152*G+0.0722*B;
    F[j]=R+(y-R)*fac;F[j+1]=G+(y-G)*fac;F[j+2]=B+(y-B)*fac;
  }
}
function raw_nr(F,w,h,P,s){
  const n=w*h,Y=raw_luma(F,n),Cb=new Float32Array(n),Cr=new Float32Array(n);
  for(let i=0,j=0;i<n;i++,j+=3){Cb[i]=F[j+2]-Y[i];Cr[i]=F[j]-Y[i];}
  let Y2=Y;
  if(P.nrLum>0){const a=P.nrLum/100,q=raw_guided(Y,[Y],w,h,Math.max(1,Math.round(2.5*s)),0.0003+a*a*0.012)[0],m=Math.min(1,a*1.3);
    Y2=new Float32Array(n);for(let i=0;i<n;i++)Y2[i]=Y[i]+(q[i]-Y[i])*m;}
  let Cb2=Cb,Cr2=Cr;
  if(P.nrColor>0){const a=P.nrColor/100,q=raw_guided(Y,[Cb,Cr],w,h,Math.max(2,Math.round(7*s)),0.0005+a*a*0.03),m=Math.min(1,a*1.5);
    Cb2=new Float32Array(n);Cr2=new Float32Array(n);for(let i=0;i<n;i++){Cb2[i]=Cb[i]+(q[0][i]-Cb[i])*m;Cr2[i]=Cr[i]+(q[1][i]-Cr[i])*m;}}
  for(let i=0,j=0;i<n;i++,j+=3){
    const y=Y2[i],r=y+Cr2[i],b=y+Cb2[i],g=(y-0.2126*r-0.0722*b)/0.7152;
    F[j]=r<0?0:r>1?1:r;F[j+1]=g<0?0:g>1?1:g;F[j+2]=b<0?0:b>1?1:b;
  }
}
function raw_sharpen(F,w,h,P,s){
  const n=w*h,Y=raw_luma(F,n),r=Math.max(1,Math.round(P.sharpenRadius*s*1.2)),Yb=raw_blurF(Float32Array.from(Y),w,h,r,3);
  const amt=P.sharpen/100*1.1,mk=P.masking/100,lo=mk*0.012,hi=lo+0.015+mk*0.03,M=mk>0?new Float32Array(n):null;
  if(M){for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x,gx=Yb[i+1]-Yb[i-1],gy=Yb[i+w]-Yb[i-w];M[i]=raw_ss(lo,hi,Math.sqrt(gx*gx+gy*gy));}}
  for(let i=0,j=0;i<n;i++,j+=3){
    let d=Y[i]-Yb[i];d=d/(1+Math.abs(d)*4);
    const a=amt*d*(M?M[i]:1);
    const R=F[j]+a,G=F[j+1]+a,B=F[j+2]+a;
    F[j]=R<0?0:R>1?1:R;F[j+1]=G<0?0:G>1?1:G;F[j+2]=B<0?0:B>1?1:B;
  }
}
function raw_vig(F,w,h,P){
  const a=P.vignette/100,e0=P.vigMid/100*0.85,e1=e0+0.05+(1.1-e0)*P.vigFeather/100,cx=(w-1)/2||1,cy=(h-1)/2||1,dx2=new Float32Array(w);
  for(let x=0;x<w;x++){const d=(x-cx)/cx;dx2[x]=d*d;}
  for(let y=0;y<h;y++){const dy=(y-cy)/cy,dy2=dy*dy;
    for(let x=0;x<w;x++){const d=Math.sqrt((dx2[x]+dy2)*0.5),m=raw_ss(e0,e1,d);if(m<=0)continue;const j=(y*w+x)*3;
      if(a<0){const g=1+a*m*0.95;F[j]*=g;F[j+1]*=g;F[j+2]*=g;}
      else{const k=a*m*0.85;F[j]+=(1-F[j])*k;F[j+1]+=(1-F[j+1])*k;F[j+2]+=(1-F[j+2])*k;}}}
}
function raw_hash(x,y,seed){let h=(Math.imul(x,374761393)+Math.imul(y,668265263)+seed)|0;h=Math.imul(h^(h>>>13),1274126177);h^=h>>>16;return (h>>>0)/2147483648-1;}
function raw_grain(F,w,h,P,s){
  const amp=P.grain/100*0.16,c=Math.max(1,(0.8+P.grainSize/100*3.5)*Math.max(s,0.35));
  const gw=Math.ceil(w/c)+2,gh=Math.ceil(h/c)+2,N=new Float32Array(gw*gh);
  for(let y=0;y<gh;y++)for(let x=0;x<gw;x++)N[y*gw+x]=(raw_hash(x,y,1234567)+raw_hash(x,y,7654321))*0.6;
  for(let y=0;y<h;y++){const v=y/c,j0=v|0,fy=v-j0,wy=fy*fy*(3-2*fy);
    for(let x=0;x<w;x++){const u=x/c,i0=u|0,fx=u-i0,wx=fx*fx*(3-2*fx),o=j0*gw+i0;
      const a=N[o]+(N[o+1]-N[o])*wx,b=N[o+gw]+(N[o+gw+1]-N[o+gw])*wx,nz=a+(b-a)*wy;
      const j=(y*w+x)*3,yy=0.2126*F[j]+0.7152*F[j+1]+0.0722*F[j+2],k=amp*nz*(0.35+0.65*4*yy*(1-yy));
      let R=F[j]+k,G=F[j+1]+k,B=F[j+2]+k;
      F[j]=R<0?0:R>1?1:R;F[j+1]=G<0?0:G>1?1:G;F[j+2]=B<0?0:B>1?1:B;}}
}
function raw_hslActive(P){for(const b of RAW_BANDS){const o=P.hsl[b];if(o&&(o.h||o.s||o.l))return true;}return false;}
function raw_gradeActive(P){const g=P.grade;for(const z of [g.shadows,g.mids,g.highs])if(z&&(z.s||z.l))return true;return false;}

function raw_process(img,params,ctx){
  const P=raw_params(params),w=img.width,h=img.height,n=w*h,s=ctx&&ctx.scale>0?ctx.scale:1,src=img.data;
  const fl={
    lens:!!P.lensCorr,wb:!!(P.temp||P.tint||P.exposure),sh:!!(P.shadows||P.highlights),tone:!!(P.whites||P.blacks||P.contrast),
    lc:!!(P.clarity||P.texture),dz:!!P.dehaze,vs:!P.bw&&!!(P.vibrance||P.saturation),
    cv:!!(P.curve||P.curveR||P.curveG||P.curveB),hsl:!P.bw&&raw_hslActive(P),bw:!!P.bw,gr:raw_gradeActive(P),ca:!!P.caFix,
    nr:!!(P.nrLum||P.nrColor),sp:P.sharpen>0,vg:!!P.vignette,gn:P.grain>0};
  let any=false;for(const k in fl)if(fl[k])any=true;
  const out=new Uint8ClampedArray(src.length);
  if(!any){out.set(src);return new ImageData(out,w,h);}
  const L8=new Float32Array(256);for(let i=0;i<256;i++)L8[i]=i/255;
  let F=new Float32Array(n*3);
  for(let i=0,j=0,k=0;i<n;i++,j+=4,k+=3){F[k]=L8[src[j]];F[k+1]=L8[src[j+1]];F[k+2]=L8[src[j+2]];}
  if(fl.lens)F=raw_lens(F,w,h,P.lensCorr);
  if(fl.wb)raw_wbExp(F,n,P);
  if(fl.sh)raw_shadHigh(F,w,h,P,s);
  if(fl.tone)raw_applyLUT(F,n,raw_toneLUT(P));
  if(fl.lc)raw_localContrast(F,w,h,P,s);
  if(fl.dz)raw_dehaze(F,w,h,P,s);
  if(fl.vs)raw_vibSat(F,n,P);
  if(fl.cv)raw_curves(F,n,P);
  if(fl.hsl)raw_hslMix(F,n,P);
  if(fl.bw)raw_bw(F,n,P);
  if(fl.gr)raw_grade(F,n,P);
  if(fl.ca)raw_caFix(F,w,h,s);
  if(fl.nr)raw_nr(F,w,h,P,s);
  if(fl.sp)raw_sharpen(F,w,h,P,s);
  if(fl.vg)raw_vig(F,w,h,P);
  if(fl.gn)raw_grain(F,w,h,P,s);
  // output with deterministic interleaved-gradient dither (avoids banding)
  for(let y=0,k=0,j=0;y<h;y++)for(let x=0;x<w;x++,k+=3,j+=4){
    let d=0.06711056*x+0.00583715*y;d-=Math.floor(d);d=52.9829189*d;d-=Math.floor(d);d-=0.5;
    let r=F[k]*255+d,g=F[k+1]*255+d,b=F[k+2]*255+d;
    out[j]=r!==r?0:r;out[j+1]=g!==g?0:g;out[j+2]=b!==b?0:b;out[j+3]=src[j+3];}
  return new ImageData(out,w,h);
}

/* ---------- histogram ---------- */
function raw_histogram(img){
  const d=img.data,n=img.width*img.height,st=Math.max(1,Math.floor(n/1500000)),r=new Uint32Array(256),g=new Uint32Array(256),b=new Uint32Array(256),l=new Uint32Array(256);
  for(let i=0;i<n;i+=st){const j=i*4;if(d[j+3]===0)continue;r[d[j]]++;g[d[j+1]]++;b[d[j+2]]++;l[Math.round(0.2126*d[j]+0.7152*d[j+1]+0.0722*d[j+2])]++;}
  let mx=0;for(let i=1;i<255;i++)mx=Math.max(mx,r[i],g[i],b[i],l[i]);
  if(!mx)for(let i=0;i<256;i++)mx=Math.max(mx,r[i],g[i],b[i],l[i]);
  return {r,g,b,l,max:mx||1};
}
function raw_drawHistogram(c,hist,w,h){
  c.save();c.fillStyle='#151515';c.fillRect(0,0,w,h);c.globalCompositeOperation='lighter';
  const cols=[['r','rgba(255,50,50,0.9)'],['g','rgba(50,255,50,0.9)'],['b','rgba(60,90,255,0.9)']],sm=a=>{const o=new Float32Array(256);for(let i=0;i<256;i++)o[i]=(a[Math.max(0,i-1)]+2*a[i]+a[Math.min(255,i+1)])/4;return o;};
  for(const [k,col] of cols){const a=sm(hist[k]);c.fillStyle=col;c.beginPath();c.moveTo(0,h);
    for(let i=0;i<256;i++)c.lineTo(i/255*w,h-Math.min(1,a[i]/hist.max)*(h-2));
    c.lineTo(w,h);c.closePath();c.globalAlpha=0.55;c.fill();}
  c.globalAlpha=1;c.globalCompositeOperation='source-over';
  const a=sm(hist.l);c.strokeStyle='rgba(220,220,220,0.8)';c.lineWidth=1;c.beginPath();
  for(let i=0;i<256;i++){const x=i/255*w,y=h-Math.min(1,a[i]/hist.max)*(h-2);i?c.lineTo(x,y):c.moveTo(x,y);}
  c.stroke();c.restore();
}

/* ---------- auto ---------- */
function raw_autoSettings(img){
  const p=raw_mkDefaults(),d=img.data,n=img.width*img.height,st=Math.max(1,Math.floor(n/200000)),hist=new Uint32Array(256);
  let cnt=0,sr=0,sg=0,sb=0;
  for(let i=0;i<n;i+=st){const j=i*4;if(d[j+3]<8)continue;const y=Math.round(0.2126*d[j]+0.7152*d[j+1]+0.0722*d[j+2]);hist[y]++;cnt++;sr+=d[j];sg+=d[j+1];sb+=d[j+2];}
  if(!cnt)return p;
  const pc=q=>{let a=0;for(let i=0;i<256;i++){a+=hist[i];if(a>=q*cnt)return i/255;}return 1;};
  const p005=pc(0.005),p05=pc(0.05),med=pc(0.5),p95=pc(0.95),p995=pc(0.995);
  let dark=0,bright=0;for(let i=0;i<256;i++){if(i<38)dark+=hist[i];if(i>230)bright+=hist[i];}dark/=cnt;bright/=cnt;
  const dl=v=>v<=0.04045?v/12.92:Math.pow((v+0.055)/1.055,2.4),tgt=dl(0.46),ml=Math.max(dl(med),0.002);
  p.exposure=Math.round(clampR(Math.log2(tgt/ml)*0.7,-1.5,1.5)*20)/20;
  const ex=Math.pow(2,p.exposure*0.6);let hi=Math.min(1,p995*ex);
  if(bright>0.04)p.highlights=-Math.round(clampR(bright*250,10,60));
  if(dark>0.2)p.shadows=Math.round(clampR(dark*70,10,55));
  if(hi<0.97)p.whites=Math.round(clampR((0.98-hi)*160,0,40));
  p.blacks=-Math.round(clampR((p005-0.01)*400,0,40));
  const spread=p95-p05;if(spread<0.55)p.contrast=Math.round(clampR((0.55-spread)*80,0,28));
  p.vibrance=15;p.clarity=8;
  const mr=sr/cnt,mb=sb/cnt,mean=(sr+sg+sb)/(3*cnt)+1;p.temp=Math.round(clampR(-(mr-mb)/mean*30,-12,12));
  return p;
}
function clampR(v,a,b){return Math.min(b,Math.max(a,v));}

/* ---------- presets ---------- */
function raw_pr(id,name,o){return {id,name,p:raw_params(o)};}
function raw_H(o){const r={};for(const k in o)r[k]={h:o[k][0]||0,s:o[k][1]||0,l:o[k][2]||0};return r;}
const RAW_PRESETS=[
  raw_pr('vivid','Vivid',{contrast:14,vibrance:35,saturation:10,clarity:14,highlights:-15,shadows:14,whites:6,sharpen:40}),
  raw_pr('portrait_soft','Portrait soft',{exposure:0.15,contrast:-10,highlights:-20,shadows:20,texture:-28,clarity:-10,vibrance:8,saturation:-4,temp:5,nrColor:20,
    hsl:raw_H({orange:[0,-4,8],red:[0,-6,4]})}),
  raw_pr('matte_film','Matte film',{contrast:-8,highlights:-15,whites:-10,saturation:-12,vibrance:6,
    curve:[[0,26],[70,76],[180,184],[255,238]],grade:{shadows:{h:200,s:22,l:0},mids:{h:0,s:0,l:0},highs:{h:42,s:14,l:0},blend:60,balance:0},grain:12}),
  raw_pr('teal_orange','Moody teal-orange',{contrast:16,highlights:-24,shadows:-6,blacks:-14,vibrance:12,saturation:-10,
    hsl:raw_H({orange:[0,14,4],yellow:[-6,-10,0],green:[-12,-20,-6],aqua:[-8,10,-8],blue:[-6,12,-12]}),
    grade:{shadows:{h:195,s:40,l:-4},mids:{h:0,s:0,l:0},highs:{h:35,s:30,l:0},blend:60,balance:0},vignette:-24}),
  raw_pr('bw_contrast','B&W high contrast',{bw:true,contrast:40,blacks:-22,whites:18,clarity:25,
    hsl:raw_H({red:[0,0,14],orange:[0,0,12],yellow:[0,0,18],green:[0,0,-4],aqua:[0,0,-12],blue:[0,0,-28],purple:[0,0,-14],magenta:[0,0,-6]}),grain:18,vignette:-14}),
  raw_pr('bw_soft','B&W soft',{bw:true,contrast:-8,shadows:20,highlights:-14,texture:-12,
    hsl:raw_H({red:[0,0,10],orange:[0,0,16],yellow:[0,0,10],blue:[0,0,-10]}),grain:10}),
  raw_pr('warm_sunset','Warm sunset',{temp:32,tint:8,exposure:0.1,contrast:10,vibrance:25,highlights:-20,
    hsl:raw_H({orange:[0,16,0],yellow:[-8,10,0],red:[0,8,0]}),
    grade:{shadows:{h:345,s:22,l:0},mids:{h:0,s:0,l:0},highs:{h:32,s:35,l:0},blend:55,balance:10}}),
  raw_pr('cool_blue','Cool blue',{temp:-28,tint:-4,contrast:8,saturation:-4,vibrance:14,
    hsl:raw_H({blue:[0,14,0],aqua:[0,10,0]}),grade:{shadows:{h:225,s:30,l:0},mids:{h:0,s:0,l:0},highs:{h:200,s:10,l:0},blend:50,balance:0}}),
  raw_pr('faded_vintage','Faded vintage',{temp:12,contrast:-14,saturation:-18,
    curve:[[0,32],[64,72],[192,198],[255,236]],grade:{shadows:{h:190,s:16,l:0},mids:{h:0,s:0,l:0},highs:{h:45,s:26,l:0},blend:50,balance:0},grain:26,grainSize:40,vignette:-20}),
  raw_pr('hdr','HDR look',{shadows:55,highlights:-55,clarity:38,texture:28,dehaze:14,vibrance:24,contrast:10,sharpen:50,masking:20}),
  raw_pr('clean_bright','Clean bright',{exposure:0.3,contrast:8,shadows:24,highlights:-12,whites:16,vibrance:12,temp:-3,clarity:6}),
  raw_pr('golden_hour','Golden hour',{temp:26,tint:6,exposure:0.1,contrast:8,highlights:-20,shadows:16,vibrance:20,saturation:6,
    hsl:raw_H({orange:[0,12,4],yellow:[-6,14,2]}),grade:{shadows:{h:25,s:16,l:0},mids:{h:0,s:0,l:0},highs:{h:40,s:36,l:0},blend:50,balance:0}}),
  raw_pr('cinematic','Cinematic',{contrast:16,highlights:-18,blacks:4,saturation:-10,
    hsl:raw_H({orange:[0,6,0],blue:[-8,0,-6],green:[-10,-14,0]}),
    grade:{shadows:{h:210,s:35,l:-4},mids:{h:30,s:8,l:0},highs:{h:40,s:20,l:0},blend:55,balance:0},vignette:-22,grain:10}),
  raw_pr('skin_glow','Skin glow',{exposure:0.2,contrast:-6,highlights:-14,shadows:18,texture:-20,clarity:-10,vibrance:8,temp:4,nrColor:20,
    hsl:raw_H({orange:[0,-6,12],red:[0,-8,6]})}),
  raw_pr('dramatic','Dramatic',{contrast:32,highlights:-34,shadows:26,clarity:34,dehaze:16,texture:20,blacks:-24,whites:14,saturation:-10,vibrance:14,vignette:-28,sharpen:50,masking:20}),
  raw_pr('low_key','Low-key',{exposure:-0.55,contrast:22,highlights:-10,shadows:-18,blacks:-28,whites:12,saturation:-6,clarity:14,vignette:-35,vigMid:35})
];

/* ---------- UI schema ---------- */
function raw_ctl(k,label,min,max,step,def){return {k,label,min,max,step:step||1,def:def==null?0:def};}
const RAW_SECTIONS=[
  {id:'basic',title:'Basic',controls:[{type:'check',k:'bw',label:'Black & White',def:false},
    raw_ctl('temp','Temperature',-100,100),raw_ctl('tint','Tint',-100,100),raw_ctl('exposure','Exposure',-5,5,0.05),
    raw_ctl('contrast','Contrast',-100,100),raw_ctl('highlights','Highlights',-100,100),raw_ctl('shadows','Shadows',-100,100),
    raw_ctl('whites','Whites',-100,100),raw_ctl('blacks','Blacks',-100,100),raw_ctl('texture','Texture',-100,100),
    raw_ctl('clarity','Clarity',-100,100),raw_ctl('dehaze','Dehaze',-100,100),raw_ctl('vibrance','Vibrance',-100,100),raw_ctl('saturation','Saturation',-100,100)]},
  {id:'curve',title:'Tone Curve',type:'curve'},
  {id:'hsl',title:'Color Mixer',type:'hsl'},
  {id:'grade',title:'Color Grading',type:'grade'},
  {id:'detail',title:'Detail',controls:[raw_ctl('sharpen','Sharpening',0,150),raw_ctl('sharpenRadius','Radius',0.5,3,0.1,1),raw_ctl('masking','Masking',0,100),
    raw_ctl('nrLum','Noise reduction',0,100),raw_ctl('nrColor','Color noise reduction',0,100)]},
  {id:'effects',title:'Effects',controls:[raw_ctl('vignette','Vignette',-100,100),raw_ctl('vigMid','Midpoint',0,100,1,50),raw_ctl('vigFeather','Feather',0,100,1,50),
    raw_ctl('grain','Grain',0,100),raw_ctl('grainSize','Grain size',0,100,1,25)]},
  {id:'optics',title:'Optics',controls:[{type:'check',k:'caFix',label:'Remove chromatic aberration',def:false},raw_ctl('lensCorr','Lens correction',-100,100)]}
];
