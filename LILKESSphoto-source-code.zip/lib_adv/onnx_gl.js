/* ===== WebGL2 executor for the U2-Net graph (same ops as onnx_rt.js, runs on the GPU) =====
   Self-contained (it is stringified into a Web Worker). Tensors are RGBA32F atlas textures:
   4 channels per texel, one "slice" of 4 channels per tile, tiles laid out in a grid. */
function ortgl_make(){
  let gl=null,fbo=null,LIM=4096,progs={},vao=null;
  const VS='#version 300 es\nvoid main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));gl_Position=vec4(p*2.0-1.0,0.0,1.0);}';
  const HEAD='#version 300 es\nprecision highp float;precision highp int;precision highp sampler2D;\nout vec4 o;\n'
   +'uniform int uOW,uOH,uOGX,uONS;\n'
   +'bool outPix(out int so,out int x,out int y){ivec2 p=ivec2(gl_FragCoord.xy);int sx=p.x/uOW,sy=p.y/uOH;so=sy*uOGX+sx;x=p.x-sx*uOW;y=p.y-sy*uOH;return so<uONS&&sx<uOGX;}\n';
  const FS={
   conv:HEAD+'uniform sampler2D uIn,uW;uniform int uIW,uIH,uIGX,uINS,uKH,uKW,uSY,uSX,uDY,uDX,uPT,uPL,uWW;\n'
    +'vec4 fw(int t){return texelFetch(uW,ivec2(t%uWW,t/uWW),0);}\n'
    +'void main(){int so,ox,oy;if(!outPix(so,ox,oy)){o=vec4(0.0);return;}\n'
    +'int per=uINS*uKH*uKW*4+1;int base=so*per;vec4 a=fw(base);\n'
    +'for(int si=0;si<uINS;si++){int sxi=si%uIGX,syi=si/uIGX;\n'
    +'for(int ky=0;ky<uKH;ky++){int iy=oy*uSY-uPT+ky*uDY;if(iy<0||iy>=uIH)continue;\n'
    +'for(int kx=0;kx<uKW;kx++){int ix=ox*uSX-uPL+kx*uDX;if(ix<0||ix>=uIW)continue;\n'
    +'vec4 v=texelFetch(uIn,ivec2(sxi*uIW+ix,syi*uIH+iy),0);int t=base+1+((si*uKH+ky)*uKW+kx)*4;\n'
    +'a.x+=dot(v,fw(t));a.y+=dot(v,fw(t+1));a.z+=dot(v,fw(t+2));a.w+=dot(v,fw(t+3));}}}\n'
    +'o=a;}',
   ew:HEAD+'uniform sampler2D uA,uB;uniform int uOp;\n'
    +'void main(){ivec2 p=ivec2(gl_FragCoord.xy);vec4 a=texelFetch(uA,p,0);\n'
    +'if(uOp==0)o=max(a,0.0);else if(uOp==1)o=1.0/(1.0+exp(-a));else o=a+texelFetch(uB,p,0);}',
   pool:HEAD+'uniform sampler2D uIn;uniform int uIW,uIH,uIGX;\n'
    +'void main(){int so,ox,oy;if(!outPix(so,ox,oy)){o=vec4(0.0);return;}\n'
    +'int sx=so%uIGX,sy=so/uIGX;vec4 m=vec4(-1e30);\n'
    +'for(int ky=0;ky<2;ky++){int iy=oy*2+ky;if(iy>=uIH)break;for(int kx=0;kx<2;kx++){int ix=ox*2+kx;if(ix>=uIW)break;m=max(m,texelFetch(uIn,ivec2(sx*uIW+ix,sy*uIH+iy),0));}}\n'
    +'o=m;}',
   resize:HEAD+'uniform sampler2D uIn;uniform int uIW,uIH,uIGX;\n'
    +'void main(){int so,ox,oy;if(!outPix(so,ox,oy)){o=vec4(0.0);return;}\n'
    +'int sx=so%uIGX,sy=so/uIGX;\n'
    +'float fy=uOH>1?(float(oy)+0.5)*float(uIH)/float(uOH)-0.5:0.0;float fx=uOW>1?(float(ox)+0.5)*float(uIW)/float(uOW)-0.5:0.0;\n'
    +'fy=max(fy,0.0);fx=max(fx,0.0);int y0=min(uIH-1,int(floor(fy))),x0=min(uIW-1,int(floor(fx)));int y1=min(uIH-1,y0+1),x1=min(uIW-1,x0+1);float wy=fy-float(y0),wx=fx-float(x0);\n'
    +'ivec2 b=ivec2(sx*uIW,sy*uIH);\n'
    +'vec4 t=mix(texelFetch(uIn,b+ivec2(x0,y0),0),texelFetch(uIn,b+ivec2(x1,y0),0),wx);vec4 u=mix(texelFetch(uIn,b+ivec2(x0,y1),0),texelFetch(uIn,b+ivec2(x1,y1),0),wx);o=mix(t,u,wy);}',
   cat:HEAD+'uniform sampler2D uT0,uT1,uT2,uT3,uT4,uT5;uniform int uN,uGX[6],uOff[6],uCh[6],uTot;\n'
    +'float get(int j,int ch,int x,int y){int l=ch-uOff[j];int sl=l/4,cp=l-sl*4;ivec2 q=ivec2((sl%uGX[j])*uOW+x,(sl/uGX[j])*uOH+y);vec4 v;\n'
    +'if(j==0)v=texelFetch(uT0,q,0);else if(j==1)v=texelFetch(uT1,q,0);else if(j==2)v=texelFetch(uT2,q,0);else if(j==3)v=texelFetch(uT3,q,0);else if(j==4)v=texelFetch(uT4,q,0);else v=texelFetch(uT5,q,0);\n'
    +'return cp==0?v.x:cp==1?v.y:cp==2?v.z:v.w;}\n'
    +'void main(){int so,x,y;if(!outPix(so,x,y)){o=vec4(0.0);return;}\n'
    +'float r[4];for(int k=0;k<4;k++){int ch=so*4+k;r[k]=0.0;if(ch<uTot){for(int j=0;j<6;j++){if(j>=uN)break;if(ch>=uOff[j]&&ch<uOff[j]+uCh[j]){r[k]=get(j,ch,x,y);}}}}\n'
    +'o=vec4(r[0],r[1],r[2],r[3]);}'
  };
  function prog(name){
    if(progs[name])return progs[name];
    const mk=(t,s)=>{const sh=gl.createShader(t);gl.shaderSource(sh,s);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw new Error('shader '+name+': '+gl.getShaderInfoLog(sh));return sh;};
    const p=gl.createProgram();gl.attachShader(p,mk(gl.VERTEX_SHADER,VS));gl.attachShader(p,mk(gl.FRAGMENT_SHADER,FS[name]));gl.linkProgram(p);
    if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error('link '+name+': '+gl.getProgramInfoLog(p));
    return progs[name]={p,loc:{}};
  }
  const U=(P,n,v)=>{let l=P.loc[n];if(l===undefined)l=P.loc[n]=gl.getUniformLocation(P.p,n);if(l===null)return;if(Array.isArray(v))gl.uniform1iv(l,v);else gl.uniform1i(l,v);};
  function init(cv){
    gl=cv.getContext('webgl2',{antialias:false,depth:false,stencil:false,alpha:false,preserveDrawingBuffer:false,powerPreference:'high-performance'});
    if(!gl)throw new Error('no webgl2');
    if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('float render targets unavailable');
    LIM=Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE),8192);
    fbo=gl.createFramebuffer();vao=gl.createVertexArray();gl.bindVertexArray(vao);
    gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);
    for(const k in FS)prog(k);
  }
  function tex(w,h,data){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,w,h,0,gl.RGBA,gl.FLOAT,data||null);return t;}
  function lay(C,H,W){const ns=Math.ceil(C/4),gx=Math.min(ns,Math.max(1,Math.floor(LIM/W))),gy=Math.ceil(ns/gx);
    if(gx*W>LIM||gy*H>LIM)throw new Error('tensor too large for this GPU');return {ns,gx,gy,tw:gx*W,th:gy*H};}
  function alloc(C,H,W){const L=lay(C,H,W);return Object.assign({d:[1,C,H,W],gpu:true,tex:tex(L.tw,L.th,null)},L);}
  function target(T){gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,T.tex,0);
    if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('framebuffer incomplete');gl.viewport(0,0,T.tw,T.th);}
  function bind(unit,t,P,name){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,t);U(P,name,unit);}
  function outU(P,T){U(P,'uOW',T.d[3]);U(P,'uOH',T.d[2]);U(P,'uOGX',T.gx);U(P,'uONS',T.ns);}
  function draw(){gl.drawArrays(gl.TRIANGLES,0,3);}
  /* weights packed once per conv node */
  function packConv(w,b){
    const [Co,Ci,KH,KW]=w.d,nso=Math.ceil(Co/4),nsi=Math.ceil(Ci/4),per=nsi*KH*KW*4+1,total=nso*per,WW=2048,HH=Math.ceil(total/WW),buf=new Float32Array(WW*HH*4);
    for(let so=0;so<nso;so++){
      const base=so*per;
      for(let k=0;k<4;k++){const co=so*4+k;if(co<Co&&b)buf[base*4+k]=b.v[co];}
      for(let si=0;si<nsi;si++)for(let ky=0;ky<KH;ky++)for(let kx=0;kx<KW;kx++)for(let r=0;r<4;r++){
        const co=so*4+r;if(co>=Co)continue;const t=base+1+((si*KH+ky)*KW+kx)*4+r;
        for(let c=0;c<4;c++){const ci=si*4+c;if(ci<Ci)buf[t*4+c]=w.v[((co*Ci+ci)*KH+ky)*KW+kx];}
      }
    }
    return {tex:tex(WW,HH,buf),WW};
  }
  function conv(x,node,Wt){
    const w=Wt.w,[Co,Ci,KH,KW]=w.d,at=node.a,st=at.strides?at.strides.ints:[1,1],dl=at.dilations?at.dilations.ints:[1,1];let pd=at.pads?at.pads.ints:[0,0,0,0];
    const H=x.d[2],W=x.d[3];
    if(at.auto_pad&&at.auto_pad.s&&at.auto_pad.s!=='NOTSET'&&at.auto_pad.s!=='VALID'){
      const th=Math.max(0,(Math.ceil(H/st[0])-1)*st[0]+(KH-1)*dl[0]+1-H),tw=Math.max(0,(Math.ceil(W/st[1])-1)*st[1]+(KW-1)*dl[1]+1-W),up=at.auto_pad.s==='SAME_UPPER';
      pd=[up?th>>1:th-(th>>1),up?tw>>1:tw-(tw>>1),up?th-(th>>1):th>>1,up?tw-(tw>>1):tw>>1];}
    const OH=Math.floor((H+pd[0]+pd[2]-dl[0]*(KH-1)-1)/st[0])+1,OW=Math.floor((W+pd[1]+pd[3]-dl[1]*(KW-1)-1)/st[1])+1;
    const out=alloc(Co,OH,OW),P=progs.conv;gl.useProgram(P.p);target(out);outU(P,out);
    bind(0,x.tex,P,'uIn');bind(1,Wt.tex,P,'uW');
    U(P,'uIW',W);U(P,'uIH',H);U(P,'uIGX',x.gx);U(P,'uINS',Math.ceil(Ci/4));U(P,'uKH',KH);U(P,'uKW',KW);
    U(P,'uSY',st[0]);U(P,'uSX',st[1]);U(P,'uDY',dl[0]);U(P,'uDX',dl[1]);U(P,'uPT',pd[0]);U(P,'uPL',pd[1]);U(P,'uWW',Wt.WW);
    draw();return out;
  }
  function ew(x,y,op){const out=alloc(x.d[1],x.d[2],x.d[3]),P=progs.ew;gl.useProgram(P.p);target(out);outU(P,out);bind(0,x.tex,P,'uA');bind(1,(y||x).tex,P,'uB');U(P,'uOp',op);draw();return out;}
  function pool(x){const H=x.d[2],W=x.d[3],out=alloc(x.d[1],Math.ceil(H/2),Math.ceil(W/2)),P=progs.pool;gl.useProgram(P.p);target(out);outU(P,out);bind(0,x.tex,P,'uIn');U(P,'uIW',W);U(P,'uIH',H);U(P,'uIGX',x.gx);draw();return out;}
  function resize(x,sz){const out=alloc(x.d[1],sz[2],sz[3]),P=progs.resize;gl.useProgram(P.p);target(out);outU(P,out);bind(0,x.tex,P,'uIn');U(P,'uIW',x.d[3]);U(P,'uIH',x.d[2]);U(P,'uIGX',x.gx);draw();return out;}
  function cat(list){
    if(list.length>6)throw new Error('concat of more than 6 inputs');
    let C=0;const off=[],ch=[],gxs=[];list.forEach(t=>{off.push(C);ch.push(t.d[1]);gxs.push(t.gx);C+=t.d[1];});
    while(off.length<6){off.push(0);ch.push(0);gxs.push(1);}
    const out=alloc(C,list[0].d[2],list[0].d[3]),P=progs.cat;gl.useProgram(P.p);target(out);outU(P,out);
    for(let j=0;j<6;j++)bind(j,(list[j]||list[0]).tex,P,'uT'+j);
    U(P,'uN',list.length);U(P,'uTot',C);U(P,'uGX',gxs);U(P,'uOff',off);U(P,'uCh',ch);draw();return out;
  }
  function upload(data,C,H,W){const T=alloc(C,H,W),buf=new Float32Array(T.tw*T.th*4);
    for(let c=0;c<C;c++){const s=c>>2,k=c&3,ox=(s%T.gx)*W,oy=Math.floor(s/T.gx)*H;for(let y=0;y<H;y++)for(let x=0;x<W;x++)buf[((oy+y)*T.tw+ox+x)*4+k]=data[(c*H+y)*W+x];}
    gl.bindTexture(gl.TEXTURE_2D,T.tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,T.tw,T.th,0,gl.RGBA,gl.FLOAT,buf);return T;}
  function download(T,c){const buf=new Float32Array(T.tw*T.th*4);target(T);gl.readPixels(0,0,T.tw,T.th,gl.RGBA,gl.FLOAT,buf);
    const H=T.d[2],W=T.d[3],s=c>>2,k=c&3,ox=(s%T.gx)*W,oy=Math.floor(s/T.gx)*H,o=new Float32Array(W*H);
    for(let y=0;y<H;y++)for(let x=0;x<W;x++)o[y*W+x]=buf[((oy+y)*T.tw+ox+x)*4+k];return o;}
  /* prepare: one weight texture per Conv */
  function prepare(G){const cache={};G.nodes.forEach((n,ix)=>{if(n.op!=='Conv')return;const w=G.init[n.i[1]],b=n.i[2]?G.init[n.i[2]]:null;const P=packConv(w,b);cache[ix]={w,tex:P.tex,WW:P.WW};});return cache;}
  function run(G,cache,inputName,input,onProgress,cancelled){
    const vals={};vals[inputName]=input;
    const last={};G.nodes.forEach((n,ix)=>n.i.forEach(nm=>{if(nm)last[nm]=ix;}));G.outputs.forEach(o=>last[o]=1e9);
    const N=G.nodes.length;
    const free=t=>{if(t&&t.gpu&&t.tex){gl.deleteTexture(t.tex);t.tex=null;}};
    for(let ix=0;ix<N;ix++){
      if(cancelled&&cancelled())throw new Error('cancelled');
      const n=G.nodes[ix],I=n.i.map(nm=>nm?(vals[nm]!==undefined?vals[nm]:G.init[nm]):null);let out;
      switch(n.op){
        case 'Constant':out=n.a.value.t;break;
        case 'Conv':out=conv(I[0],n,cache[ix]);break;
        case 'Relu':out=ew(I[0],null,0);break;
        case 'Sigmoid':out=ew(I[0],null,1);break;
        case 'Add':out=ew(I[0],I[1],2);break;
        case 'MaxPool':out=pool(I[0]);break;
        case 'Resize':out=resize(I[0],I[3].v);break;
        case 'Concat':{
          const ax=n.a.axis.i;
          if(I[0].gpu)out=cat(I);else{let a=[];I.forEach(t=>{a=a.concat(Array.from(t.v));});out={d:[a.length],v:a};}
          break;}
        case 'Shape':out={d:[I[0].d.length],v:I[0].d.slice()};break;
        case 'Gather':{const idx=I[1];if(idx.d.length===0)out={d:[],v:[I[0].v[idx.v[0]]]};else out={d:[idx.v.length],v:Array.from(idx.v,i=>I[0].v[i])};break;}
        case 'Unsqueeze':out={d:[I[0].v.length],v:Array.from(I[0].v)};break;
        case 'Slice':{const st=I[1].v[0],en=I[2].v[0],L=I[0].v.length,s=st<0?L+st:st,e=Math.min(L,en<0?L+en:en);out={d:[Math.max(0,e-s)],v:Array.from(I[0].v).slice(s,e)};break;}
        case 'Cast':out=I[0];break;
        default:throw new Error('unsupported op '+n.op);
      }
      vals[n.o[0]]=out;
      for(const nm of n.i){if(nm&&last[nm]===ix&&vals[nm]!==undefined&&!G.init[nm]){free(vals[nm]);delete vals[nm];}}
      if(ix%24===23){gl.finish();if(onProgress)onProgress((ix+1)/N);}
    }
    const o=G.outputs[0],T=vals[o],C=Math.min(4,T.d[1]),H=T.d[2],W=T.d[3],res=new Float32Array(C*H*W);
    for(let c=0;c<C;c++)res.set(download(T,c),c*H*W);
    for(const k in vals)free(vals[k]);
    return {d:[1,C,H,W],v:res};
  }
  return {init,prepare,run,upload};
}
