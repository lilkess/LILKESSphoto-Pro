/* ===== small ONNX runtime for convolutional segmentation nets (U2-Net family) =====
   Self-contained: ort_make() returns {parse, run}. It is stringified into a Web Worker, so it must not touch outer variables.
   Supported ops: Conv (group 1), Relu, Sigmoid, Add, MaxPool, Concat, Resize (bilinear), and the tiny shape ops
   that U2-Net exports around Resize (Shape, Gather, Unsqueeze, Slice, Cast, Constant). */
function ort_make(){
  const dec=new TextDecoder();
  function rd(u8){let p=0;
    const varint=()=>{let r=0,s=0,b;do{b=u8[p++];r+=(b&127)*Math.pow(2,s);s+=7;}while(b&128);return r;};
    return {more:()=>p<u8.length,tag:()=>{const t=varint();return [Math.floor(t/8),t&7];},varint,
      bytes:()=>{const n=varint();const s=u8.subarray(p,p+n);p+=n;return s;},
      f32:()=>{const v=new DataView(u8.buffer,u8.byteOffset+p,4).getFloat32(0,true);p+=4;return v;},
      skip:w=>{if(w===0)varint();else if(w===1)p+=8;else if(w===2){const n=varint();p+=n;}else if(w===5)p+=4;}};}
  const str=b=>dec.decode(b);
  const copy=s=>s.buffer.slice(s.byteOffset,s.byteOffset+s.length);
  function tensor(b){const r=rd(b),t={d:[],dt:1,name:'',raw:null,f:null,i:[]};
    while(r.more()){const [f,w]=r.tag();
      if(f===1){if(w===2){const s=rd(r.bytes());while(s.more())t.d.push(s.varint());}else t.d.push(r.varint());}
      else if(f===2)t.dt=r.varint();else if(f===8)t.name=str(r.bytes());else if(f===9)t.raw=r.bytes();
      else if(f===4&&w===2){t.f=new Float32Array(copy(r.bytes()));}
      else if(f===7){if(w===2){const s=rd(r.bytes());while(s.more())t.i.push(s.varint());}else t.i.push(r.varint());}
      else r.skip(w);}
    const n=t.d.reduce((a,b)=>a*b,1);
    if(t.dt===1){t.v=t.f||(t.raw?new Float32Array(copy(t.raw)):new Float32Array(n));}
    else if(t.dt===7){if(t.raw){const bi=new BigInt64Array(copy(t.raw));t.v=Array.from(bi,x=>Number(x));}else t.v=t.i;}
    else if(t.dt===6){t.v=t.raw?Array.from(new Int32Array(copy(t.raw))):t.i;}
    else t.v=t.raw?Array.from(new Uint8Array(copy(t.raw))):t.i;
    delete t.raw;delete t.f;delete t.i;return t;}
  function attr(b){const r=rd(b),a={name:''};
    while(r.more()){const [f,w]=r.tag();
      if(f===1)a.name=str(r.bytes());else if(f===2)a.f=r.f32();else if(f===3)a.i=r.varint();else if(f===4)a.s=str(r.bytes());
      else if(f===5)a.t=tensor(r.bytes());
      else if(f===8){a.ints=a.ints||[];if(w===2){const s=rd(r.bytes());while(s.more())a.ints.push(s.varint());}else a.ints.push(r.varint());}
      else r.skip(w);}
    return a;}
  function node(b){const r=rd(b),n={i:[],o:[],op:'',a:{}};
    while(r.more()){const [f,w]=r.tag();
      if(f===1)n.i.push(str(r.bytes()));else if(f===2)n.o.push(str(r.bytes()));else if(f===4)n.op=str(r.bytes());
      else if(f===5){const a=attr(r.bytes());n.a[a.name]=a;}else r.skip(w);}
    return n;}
  function parse(u8){
    const r=rd(u8);let g=null;
    while(r.more()){const [f,w]=r.tag();if(f===7)g=r.bytes();else r.skip(w);}
    const gr=rd(g),G={nodes:[],init:{},inputs:[],outputs:[]};
    while(gr.more()){const [f,w]=gr.tag();
      if(f===1)G.nodes.push(node(gr.bytes()));
      else if(f===5){const t=tensor(gr.bytes());G.init[t.name]=t;}
      else if(f===11||f===12){const vr=rd(gr.bytes());let nm='';while(vr.more()){const [ff,ww]=vr.tag();if(ff===1)nm=str(vr.bytes());else vr.skip(ww);}(f===11?G.inputs:G.outputs).push(nm);}
      else gr.skip(w);}
    G.inputs=G.inputs.filter(n=>!G.init[n]);
    return G;}
  /* ---- operators ---- */
  function conv(x,w,b,at){
    const [,Ci,H,W]=x.d,[Co,Cw,KH,KW]=w.d;
    const st=at.strides?at.strides.ints:[1,1],dl=at.dilations?at.dilations.ints:[1,1];let pd=at.pads?at.pads.ints:[0,0,0,0];
    if(at.auto_pad&&at.auto_pad.s&&at.auto_pad.s!=='NOTSET'&&at.auto_pad.s!=='VALID'){
      const th=Math.max(0,(Math.ceil(H/st[0])-1)*st[0]+(KH-1)*dl[0]+1-H),tw=Math.max(0,(Math.ceil(W/st[1])-1)*st[1]+(KW-1)*dl[1]+1-W),up=at.auto_pad.s==='SAME_UPPER';
      pd=[up?th>>1:th-(th>>1),up?tw>>1:tw-(tw>>1),up?th-(th>>1):th>>1,up?tw-(tw>>1):tw>>1];}
    if(Cw!==Ci)throw new Error('grouped conv not supported');
    const sy=st[0],sx=st[1],dy=dl[0],dx=dl[1],pt=pd[0],pl=pd[1];
    const OH=Math.floor((H+pd[0]+pd[2]-dy*(KH-1)-1)/sy)+1,OW=Math.floor((W+pd[1]+pd[3]-dx*(KW-1)-1)/sx)+1;
    const out=new Float32Array(Co*OH*OW),xv=x.v,wv=w.v;
    for(let co=0;co<Co;co++){
      const ob=co*OH*OW,bias=b?b.v[co]:0;
      if(bias!==0)out.fill(bias,ob,ob+OH*OW);
      for(let ci=0;ci<Ci;ci++){
        const ib=ci*H*W;
        for(let ky=0;ky<KH;ky++)for(let kx=0;kx<KW;kx++){
          const wt=wv[((co*Ci+ci)*KH+ky)*KW+kx];if(wt===0)continue;
          const oy0=Math.max(0,Math.ceil((pt-ky*dy)/sy)),oy1=Math.min(OH-1,Math.floor((H-1+pt-ky*dy)/sy));
          const ox0=Math.max(0,Math.ceil((pl-kx*dx)/sx)),ox1=Math.min(OW-1,Math.floor((W-1+pl-kx*dx)/sx));
          for(let oy=oy0;oy<=oy1;oy++){
            const iy=oy*sy-pt+ky*dy,ir=ib+iy*W,or=ob+oy*OW;
            if(sx===1){const off=ir-pl+kx*dx;for(let ox=ox0;ox<=ox1;ox++)out[or+ox]+=wt*xv[off+ox];}
            else for(let ox=ox0;ox<=ox1;ox++)out[or+ox]+=wt*xv[ir+ox*sx-pl+kx*dx];
          }
        }
      }
    }
    return {d:[1,Co,OH,OW],v:out};
  }
  function maxpool(x,at){
    const [,C,H,W]=x.d,k=at.kernel_shape.ints,s=at.strides?at.strides.ints:k,ceil=at.ceil_mode&&at.ceil_mode.i;
    const OH=ceil?Math.ceil((H-k[0])/s[0])+1:Math.floor((H-k[0])/s[0])+1,OW=ceil?Math.ceil((W-k[1])/s[1])+1:Math.floor((W-k[1])/s[1])+1;
    const out=new Float32Array(C*OH*OW),xv=x.v;
    for(let c=0;c<C;c++)for(let oy=0;oy<OH;oy++)for(let ox=0;ox<OW;ox++){
      let m=-1e30;
      for(let ky=0;ky<k[0];ky++){const y=oy*s[0]+ky;if(y>=H)break;for(let kx=0;kx<k[1];kx++){const xx=ox*s[1]+kx;if(xx>=W)break;const v=xv[(c*H+y)*W+xx];if(v>m)m=v;}}
      out[(c*OH+oy)*OW+ox]=m;}
    return {d:[1,C,OH,OW],v:out};
  }
  function resize(x,sizes){
    const [,C,H,W]=x.d,OH=sizes[2],OW=sizes[3],out=new Float32Array(C*OH*OW),xv=x.v;
    const ys=new Int32Array(OH),y1=new Int32Array(OH),fy=new Float32Array(OH),xs=new Int32Array(OW),x1=new Int32Array(OW),fx=new Float32Array(OW);
    for(let i=0;i<OH;i++){let s=OH>1?(i+0.5)*H/OH-0.5:0;if(s<0)s=0;const a=Math.min(H-1,Math.floor(s));ys[i]=a;y1[i]=Math.min(H-1,a+1);fy[i]=s-a;}
    for(let i=0;i<OW;i++){let s=OW>1?(i+0.5)*W/OW-0.5:0;if(s<0)s=0;const a=Math.min(W-1,Math.floor(s));xs[i]=a;x1[i]=Math.min(W-1,a+1);fx[i]=s-a;}
    for(let c=0;c<C;c++){const ib=c*H*W,ob=c*OH*OW;
      for(let oy=0;oy<OH;oy++){const r0=ib+ys[oy]*W,r1=ib+y1[oy]*W,wy=fy[oy];
        for(let ox=0;ox<OW;ox++){const a=xs[ox],b=x1[ox],wx=fx[ox];
          const t=xv[r0+a]*(1-wx)+xv[r0+b]*wx,u=xv[r1+a]*(1-wx)+xv[r1+b]*wx;
          out[ob+oy*OW+ox]=t*(1-wy)+u*wy;}}}
    return {d:[1,C,OH,OW],v:out};
  }
  function run(G,inputName,input,onProgress,cancelled){
    const vals={};vals[inputName]=input;
    for(const k in G.init)vals[k]=G.init[k];
    const last={};G.nodes.forEach((n,ix)=>n.i.forEach(nm=>{if(nm)last[nm]=ix;}));
    G.outputs.forEach(o=>last[o]=1e9);
    const N=G.nodes.length;
    for(let ix=0;ix<N;ix++){
      if(cancelled&&cancelled())throw new Error('cancelled');
      const n=G.nodes[ix],I=n.i.map(nm=>nm?vals[nm]:null);let out;
      switch(n.op){
        case 'Constant':out=n.a.value.t;break;
        case 'Conv':out=conv(I[0],I[1],I[2],n.a);break;
        case 'Relu':{const x=I[0],o=new Float32Array(x.v.length);for(let i=0;i<o.length;i++){const v=x.v[i];o[i]=v>0?v:0;}out={d:x.d,v:o};break;}
        case 'Sigmoid':{const x=I[0],o=new Float32Array(x.v.length);for(let i=0;i<o.length;i++)o[i]=1/(1+Math.exp(-x.v[i]));out={d:x.d,v:o};break;}
        case 'Add':{const a=I[0],b=I[1];if(a.v.length!==b.v.length)throw new Error('broadcast Add not supported');const o=new Float32Array(a.v.length);for(let i=0;i<o.length;i++)o[i]=a.v[i]+b.v[i];out={d:a.d,v:o};break;}
        case 'MaxPool':out=maxpool(I[0],n.a);break;
        case 'Concat':{
          const ax=n.a.axis.i;
          if(I[0].v instanceof Float32Array&&I[0].d.length===4&&ax===1){
            const [,,H,W]=I[0].d;let C=0;I.forEach(t=>C+=t.d[1]);const o=new Float32Array(C*H*W);let off=0;I.forEach(t=>{o.set(t.v,off);off+=t.v.length;});out={d:[1,C,H,W],v:o};
          }else{let a=[];I.forEach(t=>{a=a.concat(Array.from(t.v));});out={d:[a.length],v:a};}
          break;}
        case 'Resize':{const sz=I[3];if(!sz||!sz.v.length)throw new Error('Resize needs explicit sizes');out=resize(I[0],sz.v);break;}
        case 'Shape':out={d:[I[0].d.length],v:I[0].d.slice()};break;
        case 'Gather':{const idx=I[1];if(idx.d.length===0)out={d:[],v:[I[0].v[idx.v[0]]]};else out={d:[idx.v.length],v:Array.from(idx.v,i=>I[0].v[i])};break;}
        case 'Unsqueeze':out={d:[I[0].v.length],v:Array.from(I[0].v)};break;
        case 'Slice':{const st=I[1].v[0],en=I[2].v[0];const L=I[0].v.length;const s=st<0?L+st:st,e=Math.min(L,en<0?L+en:en);out={d:[Math.max(0,e-s)],v:Array.from(I[0].v).slice(s,e)};break;}
        case 'Cast':out=I[0];break;
        default:throw new Error('unsupported op '+n.op);
      }
      vals[n.o[0]]=out;
      for(const nm of n.i){if(nm&&last[nm]===ix&&!G.init[nm])delete vals[nm];}
      if(onProgress&&(ix%16===0||ix===N-1))onProgress((ix+1)/N);
    }
    return G.outputs.map(o=>vals[o]);
  }
  return {parse,run};
}
