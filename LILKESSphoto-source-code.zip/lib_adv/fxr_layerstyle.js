/* fxr_layerstyle.js - Photoshop-style "Layer Style" renderer (prefix fxr_). Needs host helpers: clamp, hexRgb, mkCanvas, cctx.
 PUBLIC API
  fxr_pad(fx)                -> int px that effects may extend beyond the layer alpha bounds (unscaled).
  fxr_render(lay,fx,opts)    -> NEW canvas, same size as `lay`. opts={fillOpacity:1, patternFn:(id)=>tile canvas|null, scale:1}
                                fillOpacity multiplies only the layer's own pixels; scale multiplies every size/distance.
  fxr_hasAny(fx)             -> true if any effect has on:true.
  fxr_defaults(kind)         -> fresh param object (on:true) for 'shadow','ishadow','glow','iglow','bevel','satin','overlay','grad','pat','stroke';
                                fxr_defaults() -> object with all kinds (on:false).
 fx = { shadow, ishadow, glow, iglow, bevel, satin, overlay, grad, pat, stroke } (see SPEC; colors '#rrggbb', blend = globalCompositeOperation,
  op 0..1, angle deg: 0 = light from right, 90 = from top; offset = (-cos a, +sin a)*dist). Legacy shadow {blur,dx,dy} and glow {blur} accepted.
 RENDER ORDER (bottom -> top):
  1 drop shadow (knocked out by shape unless knock===false)  2 outer glow (knocked out)  3 outer part of bevel (style outer/emboss/pillow)
  4 outer part of stroke (outside/center)  5 layer pixels (x fillOpacity)  then, clipped to the shape alpha:
  6 color overlay  7 gradient overlay  8 pattern overlay  9 satin  10 inner glow  11 inner shadow  12 bevel&emboss (inner part)  13 stroke (inner part)
 Parts 3/4 are drawn *beneath* the shape pixels (seam-free antialiasing); everything inside the shape is composed on a private "stack" canvas
 and finally clipped with the exact layer alpha, so edge pixels never get double coverage.
 Notes: size -> gaussian sigma=size/2 (3 box passes, same as canvas shadowBlur); spread/choke grow the matte by size*pct before blurring;
  stroke/spread/bevel use an exact euclidean distance transform; satin: |A(+off)-A(-off)| blurred (invert:true -> 1-that); noise = dissolve grain. */

function fxr_num(v,d){return typeof v==='number'&&isFinite(v)?v:d;}
function fxr_col(c,d){return hexRgb(typeof c==='string'&&/^#?([0-9a-f]{3}|[0-9a-f]{6})/i.test(c)?(c.length>7?c.slice(0,7):c):d);}
function fxr_pct(v,d){return clamp(fxr_num(v,d),0,100)/100;}
function fxr_frac(v){v=fxr_num(v,0);return clamp(v>1?v/100:v,0,1);}
function fxr_defaults(kind){
  const D={
    shadow:()=>({on:true,color:'#000000',op:.6,blend:'multiply',angle:120,dist:8,spread:0,size:12,noise:0,knock:true}),
    ishadow:()=>({on:true,color:'#000000',op:.7,blend:'multiply',angle:120,dist:6,choke:0,size:10,noise:0}),
    glow:()=>({on:true,color:'#ffd54f',op:.8,blend:'screen',size:18,spread:0,noise:0}),
    iglow:()=>({on:true,color:'#ffffbe',op:.75,blend:'screen',size:12,choke:0,source:'edge',noise:0}),
    bevel:()=>({on:true,style:'inner',technique:'smooth',depth:100,dir:'up',size:8,soften:0,angle:120,altitude:30,hiColor:'#ffffff',hiOp:.75,hiBlend:'screen',shColor:'#000000',shOp:.75,shBlend:'multiply'}),
    satin:()=>({on:true,color:'#000000',op:.5,blend:'multiply',angle:19,dist:11,size:14,invert:true}),
    overlay:()=>({on:true,color:'#f2b134',op:1,blend:'source-over'}),
    grad:()=>({on:true,stops:[{p:0,c:'#ffffff'},{p:1,c:'#000000'}],style:'linear',angle:90,scale:100,reverse:false,op:1,blend:'source-over'}),
    pat:()=>({on:true,id:'dots',scale:100,op:1,blend:'source-over'}),
    stroke:()=>({on:true,color:'#000000',w:6,pos:'outside',op:1,blend:'source-over',fillType:'color'})
  };
  if(kind==null){const o={};for(const k in D){o[k]=D[k]();o[k].on=false;}return o;}
  return D[kind]?D[kind]():null;
}
const FXR_KEYS=['shadow','ishadow','glow','iglow','bevel','satin','overlay','grad','pat','stroke'];
function fxr_hasAny(fx){if(!fx)return false;for(const k of FXR_KEYS)if(fx[k]&&fx[k].on)return true;return false;}

/* resolve + scale parameters */
function fxr_norm(fx,sc){
  const N={sh:null,ish:null,gl:null,ig:null,bv:null,sa:null,ov:null,gr:null,pt:null,sk:null};if(!fx)return N;
  let o=fx.shadow;
  if(o&&o.on){
    const size=fxr_num(o.size,fxr_num(o.blur,12));let ox,oy;
    if(o.dist===undefined&&o.angle===undefined&&(o.dx!==undefined||o.dy!==undefined)){ox=fxr_num(o.dx,0);oy=fxr_num(o.dy,0);}
    else{const a=fxr_num(o.angle,120)*Math.PI/180,d=fxr_num(o.dist,8);ox=-Math.cos(a)*d;oy=Math.sin(a)*d;}
    N.sh={col:fxr_col(o.color,'#000000'),op:fxr_num(o.op,.6),blend:o.blend||'multiply',ox:ox*sc,oy:oy*sc,size:Math.max(0,size)*sc,spread:fxr_pct(o.spread,0),noise:fxr_frac(o.noise),knock:o.knock!==false};
  }
  o=fx.ishadow;
  if(o&&o.on){
    const a=fxr_num(o.angle,120)*Math.PI/180,d=fxr_num(o.dist,6);
    N.ish={col:fxr_col(o.color,'#000000'),op:fxr_num(o.op,.7),blend:o.blend||'multiply',ox:-Math.cos(a)*d*sc,oy:Math.sin(a)*d*sc,size:Math.max(0,fxr_num(o.size,fxr_num(o.blur,10)))*sc,choke:fxr_pct(o.choke,0),noise:fxr_frac(o.noise)};
  }
  o=fx.glow;
  if(o&&o.on)N.gl={col:fxr_col(o.color,'#ffd54f'),op:fxr_num(o.op,.8),blend:o.blend||'screen',size:Math.max(0,fxr_num(o.size,fxr_num(o.blur,18)))*sc,spread:fxr_pct(o.spread,0),noise:fxr_frac(o.noise),knock:o.knock!==false};
  o=fx.iglow;
  if(o&&o.on)N.ig={col:fxr_col(o.color,'#ffffbe'),op:fxr_num(o.op,.75),blend:o.blend||'screen',size:Math.max(0,fxr_num(o.size,fxr_num(o.blur,12)))*sc,choke:fxr_pct(o.choke,0),center:o.source==='center',noise:fxr_frac(o.noise)};
  o=fx.bevel;
  if(o&&o.on)N.bv={style:o.style||'inner',tech:o.technique==='chisel'?'chisel':'smooth',depth:Math.max(0,fxr_num(o.depth,100))/100,down:o.dir==='down',size:Math.max(.5,fxr_num(o.size,8)*sc),soften:Math.max(0,fxr_num(o.soften,0))*sc,
    ang:fxr_num(o.angle,120)*Math.PI/180,alt:clamp(fxr_num(o.altitude,30),1,89)*Math.PI/180,hc:fxr_col(o.hiColor,'#ffffff'),ho:fxr_num(o.hiOp,.75),hb:o.hiBlend||'screen',sc:fxr_col(o.shColor,'#000000'),so:fxr_num(o.shOp,.75),sb:o.shBlend||'multiply'};
  o=fx.satin;
  if(o&&o.on){const a=fxr_num(o.angle,19)*Math.PI/180,d=fxr_num(o.dist,11);
    N.sa={col:fxr_col(o.color,'#000000'),op:fxr_num(o.op,.5),blend:o.blend||'multiply',ox:-Math.cos(a)*d*sc,oy:Math.sin(a)*d*sc,size:Math.max(0,fxr_num(o.size,14))*sc,inv:o.invert!==false};}
  o=fx.overlay;
  if(o&&o.on)N.ov={col:fxr_col(o.color,'#f2b134'),op:fxr_num(o.op,1),blend:o.blend||'source-over'};
  o=fx.grad;
  if(o&&o.on&&o.stops&&o.stops.length)N.gr=fxr_normGrad(o,1,fxr_num(o.op,1),o.blend||'source-over');
  o=fx.pat;
  if(o&&o.on)N.pt={id:o.id,scale:Math.max(.01,fxr_num(o.scale,100)/100)*sc,op:fxr_num(o.op,1),blend:o.blend||'source-over'};
  o=fx.stroke;
  if(o&&o.on){const grad=o.fillType==='gradient'&&o.stops&&o.stops.length;
    N.sk={col:fxr_col(o.color,'#000000'),w:Math.max(0,fxr_num(o.w,fxr_num(o.width,6)))*sc,pos:o.pos==='inside'||o.pos==='center'?o.pos:'outside',op:fxr_num(o.op,1),blend:o.blend||'source-over',gr:grad?fxr_normGrad(o,1,1,'source-over'):null};}
  return N;
}
function fxr_normGrad(o,sc,op,blend){
  return {stops:o.stops,style:o.style||'linear',ang:fxr_num(o.angle,90)*Math.PI/180,scale:Math.max(.01,fxr_num(o.scale,100)/100),rev:!!o.reverse,op:op,blend:blend};
}
function fxr_padN(N){
  let p=0;
  if(N.sh)p=Math.max(p,Math.hypot(N.sh.ox,N.sh.oy)+N.sh.size*1.5+2);
  if(N.gl)p=Math.max(p,N.gl.size*1.5+2);
  if(N.sk&&N.sk.pos!=='inside')p=Math.max(p,(N.sk.pos==='center'?N.sk.w/2:N.sk.w)+2);
  if(N.bv&&N.bv.style!=='inner')p=Math.max(p,N.bv.size*1.4+N.bv.soften*1.5+3);
  return p;
}
function fxr_pad(fx){return Math.ceil(fxr_padN(fxr_norm(fx,1)));}

/* ---------- float-mask toolkit (single channel Float32Array, clamp-to-edge) ---------- */
function fxr_boxH(s,t,W,H,r){
  const inv=1/(2*r+1),W1=W-1;
  for(let y=0;y<H;y++){const o=y*W;let acc=(r+1)*s[o];
    for(let i=1;i<=r;i++)acc+=s[o+(i<W1?i:W1)];
    for(let x=0;x<W;x++){t[o+x]=acc*inv;const a=x+r+1,b=x-r;acc+=s[o+(a<W?a:W1)]-s[o+(b>0?b:0)];}}
}
function fxr_boxV(s,t,W,H,r,acc){
  const inv=1/(2*r+1),H1=H-1;
  for(let x=0;x<W;x++)acc[x]=(r+1)*s[x];
  for(let i=1;i<=r;i++){const o=(i<H1?i:H1)*W;for(let x=0;x<W;x++)acc[x]+=s[o+x];}
  for(let y=0;y<H;y++){const o=y*W;for(let x=0;x<W;x++)t[o+x]=acc[x]*inv;
    const a=(y+r+1<H?y+r+1:H1)*W,b=(y-r>0?y-r:0)*W;for(let x=0;x<W;x++)acc[x]+=s[a+x]-s[b+x];}
}
/* in-place gaussian approximation (3 boxes); big sigmas run on a 2x/4x downscaled copy for speed */
function fxr_blur(m,W,H,sigma,ws){
  if(sigma<.35)return m;
  if(sigma>9&&W>8&&H>8){
    const f=sigma>20?4:2,w2=Math.ceil(W/f),h2=Math.ceil(H/f),s=new Float32Array(w2*h2),t=new Float32Array(w2*h2),acc=new Float64Array(w2);
    for(let y=0;y<h2;y++)for(let x=0;x<w2;x++){let a=0,c=0;for(let j=0;j<f;j++){const yy=y*f+j;if(yy>=H)break;for(let i=0;i<f;i++){const xx=x*f+i;if(xx>=W)break;a+=m[yy*W+xx];c++;}}s[y*w2+x]=a/c;}
    fxr_blur(s,w2,h2,sigma/f,{tmp:t,acc:acc});
    for(let y=0;y<H;y++){let fy=(y+.5)/f-.5;if(fy<0)fy=0;let y0=fy|0;if(y0>h2-1)y0=h2-1;const y1=y0+1<h2?y0+1:y0,wy=fy-y0;
      for(let x=0;x<W;x++){let fx=(x+.5)/f-.5;if(fx<0)fx=0;let x0=fx|0;if(x0>w2-1)x0=w2-1;const x1=x0+1<w2?x0+1:x0,wx=fx-x0;
        const a=s[y0*w2+x0]*(1-wx)+s[y0*w2+x1]*wx,b=s[y1*w2+x0]*(1-wx)+s[y1*w2+x1]*wx;m[y*W+x]=a*(1-wy)+b*wy;}}
    return m;
  }
  const n=3,wi=Math.sqrt(12*sigma*sigma/n+1);let wl=Math.floor(wi);if(wl%2===0)wl--;const wu=wl+2;
  const mi=Math.round((12*sigma*sigma-n*wl*wl-4*n*wl-3*n)/(-4*wl-4));
  for(let k=0;k<n;k++){const r=((k<mi?wl:wu)-1)>>1;if(r<1)continue;fxr_boxH(m,ws.tmp,W,H,r);fxr_boxV(ws.tmp,m,W,H,r,ws.acc);}
  return m;
}
function fxr_shift(m,W,H,dx,dy){
  const o=new Float32Array(W*H);
  for(let y=0;y<H;y++){let sy=y-dy;sy=sy<0?0:sy>H-1?H-1:sy;const so=sy*W,d=y*W;
    for(let x=0;x<W;x++){let sx=x-dx;sx=sx<0?0:sx>W-1?W-1:sx;o[d+x]=m[so+sx];}}
  return o;
}
function fxr_noise(m,amt,seed){
  let s=seed|0||1;
  for(let i=0;i<m.length;i++){const v=m[i];if(v>.002&&v<.998){s^=s<<13;s^=s>>>17;s^=s<<5;const r=(s>>>0)/4294967296;m[i]=v*(1-amt)+amt*(v>r?1:0);}}
}
/* exact euclidean distance (px) to the nearest source pixel (src=1). Felzenszwalb row pass, exact two-sweep column pass. */
function fxr_edt(src,W,H){
  const INF=1e10,n=W*H,g=new Float32Array(n),cnt=new Float32Array(W);
  cnt.fill(1e5);
  for(let y=0;y<H;y++){const o=y*W;for(let x=0;x<W;x++){const c=src[o+x]?0:cnt[x]+1;cnt[x]=c;g[o+x]=c;}}
  cnt.fill(1e5);
  for(let y=H-1;y>=0;y--){const o=y*W;for(let x=0;x<W;x++){const c=src[o+x]?0:cnt[x]+1;cnt[x]=c;if(c<g[o+x])g[o+x]=c;}}
  const f=new Float64Array(W),d=new Float64Array(W),z=new Float64Array(W+1),v=new Int32Array(W);
  for(let y=0;y<H;y++){
    const o=y*W;let any=false;
    for(let x=0;x<W;x++){const c=g[o+x];if(c<9e4){f[x]=c*c;any=true;}else f[x]=INF;}
    if(!any){for(let x=0;x<W;x++)g[o+x]=1e5;continue;}
    let k=0;v[0]=0;z[0]=-1e30;z[1]=1e30;
    for(let q=1;q<W;q++){
      let s;
      for(;;){const p=v[k];s=((f[q]+q*q)-(f[p]+p*p))/(2*q-2*p);if(s<=z[k])k--;else break;}
      k++;v[k]=q;z[k]=s;z[k+1]=1e30;
    }
    k=0;
    for(let q=0;q<W;q++){while(z[k+1]<q)k++;const p=v[k],dd=q-p;d[q]=dd*dd+f[p];}
    for(let x=0;x<W;x++)g[o+x]=Math.sqrt(d[x]);
  }
  return g;
}
/* gradient lookup + fill */
function fxr_parseCol(c){
  if(typeof c!=='string')return [0,0,0,1];let h=c.replace('#','');if(h.length===3||h.length===4)h=h.split('').map(x=>x+x).join('');
  const n=parseInt(h.slice(0,6),16)||0;return [n>>16&255,n>>8&255,n&255,h.length>=8?parseInt(h.slice(6,8),16)/255:1];
}
function fxr_gradLUT(stops,rev){
  const st=stops.map(s=>({p:clamp(fxr_num(s.p,0),0,1),c:fxr_parseCol(s.c)})).sort((a,b)=>a.p-b.p),L=new Uint8ClampedArray(512*4);
  let k=0;
  for(let i=0;i<512;i++){
    const t=i/511;while(k<st.length-1&&st[k+1].p<t)k++;
    let c;
    if(t<=st[0].p)c=st[0].c;else if(k>=st.length-1||t>=st[st.length-1].p)c=st[st.length-1].c;
    else{const a=st[k],b=st[k+1],u=b.p>a.p?(t-a.p)/(b.p-a.p):0;c=[a.c[0]+(b.c[0]-a.c[0])*u,a.c[1]+(b.c[1]-a.c[1])*u,a.c[2]+(b.c[2]-a.c[2])*u,a.c[3]+(b.c[3]-a.c[3])*u];}
    L[i*4]=c[0];L[i*4+1]=c[1];L[i*4+2]=c[2];L[i*4+3]=c[3]*255;
  }
  return L;
}
/* writes RGBA into d (alpha multiplied by mask if given); bbox (bx,by,bw,bh) in buffer coords */
function fxr_gradFill(d,mask,W,H,g,bx,by,bw,bh){
  const lut=fxr_gradLUT(g.stops),cx=bx+bw/2,cy=by+bh/2,ca=Math.cos(g.ang),sa=Math.sin(g.ang),sc=g.scale;
  let Ln=(Math.abs(bw*ca)+Math.abs(bh*sa))*sc;if(Ln<1e-3)Ln=1;
  let R=Math.max(bw,bh)/2*sc;if(R<1e-3)R=1;
  const sty=g.style,rev=g.rev,TP=Math.PI*2;
  for(let y=0;y<H;y++){const dy=y+.5-cy;
    for(let x=0;x<W;x++){
      const i=y*W+x,dx=x+.5-cx;let t;
      switch(sty){
        case 'radial':t=Math.sqrt(dx*dx+dy*dy)/R;break;
        case 'angle':{t=(Math.atan2(-dy,dx)-g.ang)/TP;t-=Math.floor(t);break;}
        case 'reflected':t=Math.abs(dx*ca-dy*sa)*2/Ln;break;
        case 'diamond':{const u=dx*ca-dy*sa,v=dx*sa+dy*ca;t=(Math.abs(u)+Math.abs(v))/R;break;}
        default:t=.5+(dx*ca-dy*sa)/Ln;
      }
      if(rev)t=1-t;t=t<0?0:t>1?1:t;
      const k=((t*511+.5)|0)*4,j=i*4;
      d[j]=lut[k];d[j+1]=lut[k+1];d[j+2]=lut[k+2];d[j+3]=mask?lut[k+3]*mask[i]:lut[k+3];
    }}
}

/* ---------- main ---------- */
function fxr_render(lay,fx,opts){
  opts=opts||{};
  const sc=opts.scale>0?opts.scale:1,fo=opts.fillOpacity==null?1:clamp(opts.fillOpacity,0,1);
  const W0=lay.width,H0=lay.height,out=mkCanvas(W0,H0),octx=cctx(out);
  const N=fxr_norm(fx,sc);
  if(!fxr_hasAny(fx)||!(N.sh||N.ish||N.gl||N.ig||N.bv||N.sa||N.ov||N.gr||N.pt||N.sk)){octx.globalAlpha=fo;octx.drawImage(lay,0,0);return out;}
  const sd=cctx(lay).getImageData(0,0,W0,H0).data;
  let bx0=W0,by0=H0,bx1=-1,by1=-1,maxA=0;
  for(let y=0;y<H0;y++){const o=y*W0*4+3;let a0=-1,a1=-1;
    for(let x=0;x<W0;x++){const a=sd[o+x*4];if(a){if(a0<0)a0=x;a1=x;if(a>maxA)maxA=a;}}
    if(a0>=0){if(a0<bx0)bx0=a0;if(a1>bx1)bx1=a1;if(y<by0)by0=y;by1=y;}}
  if(bx1<0)return out;
  maxA/=255;
  const pad=Math.ceil(fxr_padN(N)),rx0=Math.max(-2,bx0-pad-2),ry0=Math.max(-2,by0-pad-2),rx1=Math.min(W0+2,bx1+1+pad+2),ry1=Math.min(H0+2,by1+1+pad+2); /* >=2px transparent border so distance fields see the shape edge even at canvas bounds */
  const W=rx1-rx0,H=ry1-ry0,n=W*H;
  const A=new Float32Array(n),base=new Uint8ClampedArray(n*4),fa=fo*255;
  const cx0=Math.max(0,rx0),cx1=Math.min(W0,rx1);
  for(let y=0;y<H;y++){
    const yy=y+ry0;if(yy<0||yy>=H0)continue;
    const so=(yy*W0+cx0)*4,o=y*W+(cx0-rx0);
    base.set(sd.subarray(so,so+(cx1-cx0)*4),o*4);
    for(let x=0,m=cx1-cx0;x<m;x++){const a=base[(o+x)*4+3];A[o+x]=a/255;base[(o+x)*4+3]=a?fa:0;}
  }
  const ws={tmp:new Float32Array(n),acc:new Float64Array(W)};
  const stk=mkCanvas(W,H),sx=cctx(stk);sx.putImageData(new ImageData(base,W,H),0,0);
  const S=mkCanvas(W,H),scx=cctx(S),simg=scx.createImageData(W,H),sdat=simg.data;
  const bbx=bx0-rx0,bby=by0-ry0,bbw=bx1-bx0+1,bbh=by1-by0+1;
  /* scratch helpers */
  function put(mask,rgb){
    const r=rgb[0],g=rgb[1],b=rgb[2];
    for(let i=0,j=0;i<n;i++,j+=4){sdat[j]=r;sdat[j+1]=g;sdat[j+2]=b;sdat[j+3]=mask[i]*255+.5;}
    scx.putImageData(simg,0,0);
  }
  function blit(t,ox,oy,op,blend){t.globalAlpha=clamp(op,0,1);t.globalCompositeOperation=blend;t.drawImage(S,ox,oy);t.globalAlpha=1;t.globalCompositeOperation='source-over';}
  /* distance fields (lazy) */
  const thr=Math.max(.02,Math.min(.5,maxA/2));
  let Bm=null,dOut=null,dIn=null;
  function getB(){if(!Bm){Bm=new Uint8Array(n);for(let i=0;i<n;i++)Bm[i]=A[i]>=thr?1:0;}return Bm;}
  function getOut(){if(!dOut){const B=getB(),d=fxr_edt(B,W,H);for(let i=0;i<n;i++)d[i]=B[i]?0:Math.max(0,d[i]-.5);dOut=d;}return dOut;}
  function getIn(){if(!dIn){const B=getB(),iv=new Uint8Array(n);for(let i=0;i<n;i++)iv[i]=B[i]?0:1;const d=fxr_edt(iv,W,H);for(let i=0;i<n;i++)d[i]=B[i]?Math.max(0,d[i]-.5):0;dIn=d;}return dIn;}
  function grownOuter(d){ /* A dilated by d px (soft edge) */
    const B=getB(),o=getOut(),g=new Float32Array(n);
    for(let i=0;i<n;i++){let v=A[i];if(!B[i]){const c=(d-o[i]+.5)*maxA;if(c>v)v=c>maxA?maxA:c;}g[i]=v;}return g;
  }
  function invMask(d){ /* 1-A with the shape shrunk by d px */
    const B=getB(),inn=d>0?getIn():null,g=new Float32Array(n);
    for(let i=0;i<n;i++){let v=1-A[i];if(inn&&B[i]){const c=d-inn[i]+.5;if(c>v)v=c>1?1:c;}g[i]=v;}return g;
  }
  let seed=12345;
  /* 1 drop shadow */
  if(N.sh){const e=N.sh,d=e.size*e.spread;
    let m=d>.01?grownOuter(d):A;
    m=fxr_shift(m,W,H,Math.round(e.ox),Math.round(e.oy));
    fxr_blur(m,W,H,(e.size-d)/2,ws);
    if(e.noise>0)fxr_noise(m,e.noise,seed++);
    if(e.knock)for(let i=0;i<n;i++)m[i]*=1-A[i];
    put(m,e.col);blit(octx,rx0,ry0,e.op,e.blend);
  }
  /* 2 outer glow */
  if(N.gl){const e=N.gl,d=e.size*e.spread;
    let m=d>.01?grownOuter(d):Float32Array.from(A);
    fxr_blur(m,W,H,(e.size-d)/2,ws);
    if(e.noise>0)fxr_noise(m,e.noise,seed++);
    if(e.knock)for(let i=0;i<n;i++)m[i]*=1-A[i];
    put(m,e.col);blit(octx,rx0,ry0,e.op,e.blend);
  }
  /* 3 bevel outer part + inner part maps */
  let bevMaps=null;
  if(N.bv){const e=N.bv,sz=e.size,st=e.style,B=getB(),Z=null;
    const inn=st==='outer'?null:getIn(),outd=st==='inner'?null:getOut(),h=new Float32Array(n),K=e.depth*sz*(e.down?-1:1),chisel=e.tech==='chisel';
    for(let i=0;i<n;i++){
      const s=B[i]?(inn?inn[i]:0):-(outd?outd[i]:0);let t;
      switch(st){
        case 'outer':t=1+s/sz;break;
        case 'emboss':t=.5+s/(2*sz);break;
        case 'pillow':t=Math.abs(s)/sz;break;
        default:t=s/sz;
      }
      t=t<0?0:t>1?1:t;
      h[i]=(chisel?t:(st==='emboss'?t*t*(3-2*t):Math.sin(t*1.5707963)))*K;
    }
    fxr_blur(h,W,H,chisel?.6+e.soften*.5:Math.max(.8,sz*.22)+e.soften*.5,ws);
    const hi=new Float32Array(n),sh=new Float32Array(n),ca=Math.cos(e.ang),sa=Math.sin(e.ang),cl=Math.cos(e.alt),Lx=ca*cl,Ly=-sa*cl,Lz=Math.sin(e.alt),inv1=1/(1-Lz+1e-6),inv2=1/Math.max(Lz,.25);
    for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){
      const i=y*W+x,hx=(h[i+1]-h[i-1])*.5,hy=(h[i+W]-h[i-W])*.5;
      if(hx===0&&hy===0)continue;
      const s=(Lz-hx*Lx-hy*Ly)/Math.sqrt(hx*hx+hy*hy+1);
      if(s>Lz){const v=(s-Lz)*inv1;hi[i]=v>1?1:v;}else{const v=(Lz-s)*inv2;sh[i]=v>1?1:v;}
    }
    bevMaps={hi,sh};
    if(st!=='inner'){ /* outer part: beneath the shape, only where the shape does not fully cover */
      const hi2=new Float32Array(n),sh2=new Float32Array(n);
      for(let i=0;i<n;i++)if(A[i]<.999){hi2[i]=hi[i];sh2[i]=sh[i];}
      put(sh2,e.sc);blit(octx,rx0,ry0,e.so,e.sb);
      put(hi2,e.hc);blit(octx,rx0,ry0,e.ho,e.hb);
    }
  }
  /* 4 stroke (outer part beneath, inner part into the stack) */
  let strokeIn=null;
  if(N.sk&&N.sk.w>0){const e=N.sk,w=e.w,B=getB(),pos=e.pos;
    const inn=pos!=='outside'?getIn():null,outd=pos!=='inside'?getOut():null;
    const cin=pos==='outside'?null:new Float32Array(n),cout=pos==='inside'?null:new Float32Array(n),hw=w/2;
    for(let i=0;i<n;i++){
      const s=B[i]?(inn?inn[i]:0):-(outd?outd[i]:0),a=A[i];let c;
      if(pos==='outside'){c=s+w+.5;c=c<0?0:c>1?1:c;if(a<.999)cout[i]=c;}
      else if(pos==='inside'){c=w-s+.5;c=c<0?0:c>1?1:c;if(a>0)cin[i]=c;}
      else{let c1=s+hw+.5,c2=hw-s+.5;c1=c1<0?0:c1>1?1:c1;c2=c2<0?0:c2>1?1:c2;c=c1*c2;if(a>0)cin[i]=c;if(a<.999)cout[i]=c;}
    }
    const draw=(m,t,ox,oy)=>{
      if(e.gr){fxr_gradFill(sdat,m,W,H,e.gr,bbx,bby,bbw,bbh);scx.putImageData(simg,0,0);blit(t,ox,oy,e.op,e.blend);}
      else{put(m,e.col);blit(t,ox,oy,e.op,e.blend);}
    };
    if(cout)draw(cout,octx,rx0,ry0);
    if(cin)strokeIn=cin;
  }
  /* ---- shape-clipped stack ---- */
  if(N.ov){sx.globalAlpha=clamp(N.ov.op,0,1);sx.globalCompositeOperation=N.ov.blend;sx.fillStyle='rgb('+N.ov.col.join(',')+')';sx.fillRect(0,0,W,H);sx.globalAlpha=1;sx.globalCompositeOperation='source-over';}
  if(N.gr){fxr_gradFill(sdat,null,W,H,N.gr,bbx,bby,bbw,bbh);scx.putImageData(simg,0,0);blit(sx,0,0,N.gr.op,N.gr.blend);}
  if(N.pt&&typeof opts.patternFn==='function'){
    const tile=opts.patternFn(N.pt.id);
    if(tile&&tile.width&&tile.height){
      scx.clearRect(0,0,W,H);scx.save();scx.translate(bbx,bby);scx.scale(N.pt.scale,N.pt.scale);
      scx.fillStyle=scx.createPattern(tile,'repeat');scx.fillRect(-bbx/N.pt.scale,-bby/N.pt.scale,W/N.pt.scale,H/N.pt.scale);scx.restore();
      blit(sx,0,0,N.pt.op,N.pt.blend);
    }
  }
  if(N.sa){const e=N.sa,m=fxr_shift(A,W,H,Math.round(e.ox),Math.round(e.oy)),m2=fxr_shift(A,W,H,-Math.round(e.ox),-Math.round(e.oy));
    for(let i=0;i<n;i++){const v=m[i]-m2[i];m[i]=v<0?-v:v;}
    fxr_blur(m,W,H,e.size/2,ws);
    if(e.inv)for(let i=0;i<n;i++)m[i]=1-m[i];
    put(m,e.col);blit(sx,0,0,e.op,e.blend);
  }
  if(N.ig){const e=N.ig,d=e.size*e.choke,m=invMask(d);
    fxr_blur(m,W,H,(e.size-d)/2,ws);
    if(e.noise>0)fxr_noise(m,e.noise,seed++);
    if(e.center)for(let i=0;i<n;i++)m[i]=1-m[i];
    put(m,e.col);blit(sx,0,0,e.op,e.blend);
  }
  if(N.ish){const e=N.ish,d=e.size*e.choke;let m=invMask(d);
    m=fxr_shift(m,W,H,Math.round(e.ox),Math.round(e.oy));
    fxr_blur(m,W,H,(e.size-d)/2,ws);
    if(e.noise>0)fxr_noise(m,e.noise,seed++);
    put(m,e.col);blit(sx,0,0,e.op,e.blend);
  }
  if(bevMaps){const e=N.bv;
    put(bevMaps.sh,e.sc);blit(sx,0,0,e.so,e.sb);
    put(bevMaps.hi,e.hc);blit(sx,0,0,e.ho,e.hb);
  }
  if(strokeIn){const e=N.sk;
    if(e.gr){fxr_gradFill(sdat,strokeIn,W,H,e.gr,bbx,bby,bbw,bbh);scx.putImageData(simg,0,0);}else put(strokeIn,e.col);
    blit(sx,0,0,e.op,e.blend);
  }
  /* clip stack to exact layer alpha, composite */
  for(let i=0,j=0;i<n;i++,j+=4){sdat[j]=0;sdat[j+1]=0;sdat[j+2]=0;sdat[j+3]=A[i]*255+.5;}
  scx.putImageData(simg,0,0);
  sx.globalCompositeOperation='destination-in';sx.drawImage(S,0,0);sx.globalCompositeOperation='source-over';
  octx.drawImage(stk,rx0,ry0);
  return out;
}
