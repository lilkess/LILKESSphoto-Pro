Readable source code of LILKESSphoto Pro (the program text only).
src/ holds the program in numbered modules, lib_adv/ the image libraries, web/ the page and style templates.
The store pictures and AI models are not in this zip: they are in parts 2 and 3 (www/store and www/models).
tools/build_capacitor.py rebuilds the Android project folder from these sources plus the store and model data.
build.py builds the single-file web/PWA version.
