/* ===== File menu (Photoshop style), Save As dialog, extra file formats: PDF, BMP, TIFF, GIF ===== */

/* ---------- small helpers ---------- */
const FENC=new TextEncoder();
const fileBase=()=>(doc&&doc.name||'design').replace(/[^\w\- ]+/g,'_');
const canvasBlob=(c,type,q)=>new Promise(r=>c.toBlob(r,type,q));
async function deflateBytes(u8){
  if(typeof CompressionStream==='undefined')return null;
  const cs=new CompressionStream('deflate'),w=cs.writable.getWriter();w.write(u8);w.close();
  return new Uint8Array(await new Response(cs.readable).arrayBuffer());
}
function flatCanvas(scale,bg){
  scale=scale||1;
  if(Math.abs(scale-1)>0.001)return hiResRun(scale,()=>{const c=mkCanvas(doc.w,doc.h),x=cctx(c);if(bg){x.fillStyle=bg;x.fillRect(0,0,c.width,c.height);}compose(x,1);return c;});
  const c=mkCanvas(Math.round(doc.w*scale),Math.round(doc.h*scale)),x=cctx(c);
  if(bg){x.fillStyle=bg;x.fillRect(0,0,c.width,c.height);}
  compose(x,scale);return c;
}
/* the pieces to export as pages / pictures: each artboard, or the whole picture */
function boardCanvases(scale,bg){
  const L=(doc.extra&&doc.extra.boards)||[];scale=scale||1;
  if(!L.length)return [{name:doc.name||'design',canvas:flatCanvas(scale,bg)}];
  const src=flatCanvas(scale,null);
  return L.map(b=>{
    const c=mkCanvas(Math.round(b.w*scale),Math.round(b.h*scale)),x=cctx(c);
    if(bg){x.fillStyle=bg;x.fillRect(0,0,c.width,c.height);}
    x.drawImage(src,b.x*scale,b.y*scale,b.w*scale,b.h*scale,0,0,c.width,c.height);return {name:b.name,canvas:c};
  });
}

/* ---------- BMP (24-bit, on white) ---------- */
function encodeBMP(c){
  const w=c.width,h=c.height,x=cctx(mkCanvas(w,h));x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(c,0,0);
  const d=x.getImageData(0,0,w,h).data,rb=Math.ceil(w*3/4)*4,size=54+rb*h,out=new Uint8Array(size),dv=new DataView(out.buffer);
  out[0]=0x42;out[1]=0x4d;dv.setUint32(2,size,true);dv.setUint32(10,54,true);dv.setUint32(14,40,true);dv.setInt32(18,w,true);dv.setInt32(22,h,true);
  dv.setUint16(26,1,true);dv.setUint16(28,24,true);dv.setUint32(34,rb*h,true);dv.setInt32(38,2835,true);dv.setInt32(42,2835,true);
  for(let y=0;y<h;y++){let o=54+(h-1-y)*rb;for(let xx=0;xx<w;xx++){const i=(y*w+xx)*4;out[o++]=d[i+2];out[o++]=d[i+1];out[o++]=d[i];}}
  return new Blob([out],{type:'image/bmp'});
}

/* ---------- TIFF (uncompressed RGBA) ---------- */
function encodeTIFF2(c,dpi){
  const w=c.width,h=c.height,d=cctx(c).getImageData(0,0,w,h).data,n=13,ifdOff=8,ifdLen=2+n*12+4,bpsOff=ifdOff+ifdLen,resOff=bpsOff+8,dataOff=resOff+16,total=dataOff+w*h*4;
  const out=new Uint8Array(total),dv=new DataView(out.buffer);
  out[0]=0x49;out[1]=0x49;dv.setUint16(2,42,true);dv.setUint32(4,ifdOff,true);
  let p=ifdOff;dv.setUint16(p,n,true);p+=2;
  const ent=(tag,type,cnt,val)=>{dv.setUint16(p,tag,true);dv.setUint16(p+2,type,true);dv.setUint32(p+4,cnt,true);if(type===3&&cnt===1)dv.setUint16(p+8,val,true);else dv.setUint32(p+8,val,true);p+=12;};
  ent(256,4,1,w);ent(257,4,1,h);ent(258,3,4,bpsOff);ent(259,3,1,1);ent(262,3,1,2);ent(273,4,1,dataOff);ent(277,3,1,4);ent(278,4,1,h);ent(279,4,1,w*h*4);
  ent(282,5,1,resOff);ent(283,5,1,resOff+8);ent(296,3,1,2);ent(338,3,1,2);
  dv.setUint32(p,0,true);
  for(let i=0;i<4;i++)dv.setUint16(bpsOff+i*2,8,true);
  dv.setUint32(resOff,dpi||72,true);dv.setUint32(resOff+4,1,true);dv.setUint32(resOff+8,dpi||72,true);dv.setUint32(resOff+12,1,true);
  out.set(d,dataOff);
  return new Blob([out],{type:'image/tiff'});
}

/* ---------- GIF (256 colours, one frame) ---------- */
function encodeGIF(c){
  const w=c.width,h=c.height,d=cctx(c).getImageData(0,0,w,h).data,hist=new Uint32Array(32768);
  let hasT=false;
  for(let i=0;i<d.length;i+=4){if(d[i+3]<128){hasT=true;continue;}hist[(d[i]>>3)<<10|(d[i+1]>>3)<<5|d[i+2]>>3]++;}
  // median cut on the 5-bit histogram
  let boxes=[];const cols=[];for(let k=0;k<32768;k++)if(hist[k])cols.push(k);
  const maxC=hasT?255:256;
  const mk=list=>{let rn=31,rx=0,gn=31,gx=0,bn=31,bx=0;for(const k of list){const r=k>>10,g=k>>5&31,b=k&31;if(r<rn)rn=r;if(r>rx)rx=r;if(g<gn)gn=g;if(g>gx)gx=g;if(b<bn)bn=b;if(b>bx)bx=b;}return {list,rn,rx,gn,gx,bn,bx,ax:Math.max(rx-rn,gx-gn,bx-bn)};};
  if(cols.length)boxes=[mk(cols)];
  while(boxes.length<maxC){
    let bi=-1,bs=0;boxes.forEach((b,i)=>{if(b.list.length>1&&b.ax*1000+b.list.length>bs){bs=b.ax*1000+b.list.length;bi=i;}});
    if(bi<0)break;const b=boxes[bi],ch=(b.rx-b.rn>=b.gx-b.gn&&b.rx-b.rn>=b.bx-b.bn)?10:(b.gx-b.gn>=b.bx-b.bn?5:0);
    const s=b.list.slice().sort((x,y)=>((x>>ch)&31)-((y>>ch)&31));
    let tot=0;for(const k of s)tot+=hist[k];let acc=0,cut=1;for(let i=0;i<s.length-1;i++){acc+=hist[s[i]];if(acc>=tot/2){cut=i+1;break;}}
    boxes.splice(bi,1,mk(s.slice(0,cut)),mk(s.slice(cut)));
  }
  const pal=[],map=new Int16Array(32768).fill(-1);
  boxes.forEach((b,i)=>{let r=0,g=0,bl=0,t=0;for(const k of b.list){const n=hist[k];r+=(k>>10)*n;g+=(k>>5&31)*n;bl+=(k&31)*n;t+=n;map[k]=i;}pal.push([Math.round(r/t*8+4),Math.round(g/t*8+4),Math.round(bl/t*8+4)]);});
  const tIdx=hasT?pal.length:-1;if(hasT)pal.push([0,0,0]);
  let bits=1;while((1<<bits)<pal.length)bits++;if(bits<2)bits=2;
  const idx=new Uint8Array(w*h);
  for(let i=0,j=0;i<d.length;i+=4,j++){
    if(d[i+3]<128){idx[j]=tIdx;continue;}
    const k=(d[i]>>3)<<10|(d[i+1]>>3)<<5|d[i+2]>>3;idx[j]=map[k]<0?0:map[k];
  }
  const out=[];const u16=v=>out.push(v&255,v>>8&255);
  out.push(0x47,0x49,0x46,0x38,0x39,0x61);u16(w);u16(h);out.push(0x80|(bits-1),0,0);
  for(let i=0;i<(1<<bits);i++){const q=pal[i]||[0,0,0];out.push(q[0],q[1],q[2]);}
  if(hasT)out.push(0x21,0xf9,4,1,0,0,tIdx,0);
  out.push(0x2c);u16(0);u16(0);u16(w);u16(h);out.push(0);
  // LZW
  const minCode=bits,clear=1<<minCode,eoi=clear+1;let codeSize=minCode+1,next=eoi+1,dict=new Map();
  out.push(minCode);const block=[];let cur=0,curBits=0;
  const emit=code=>{cur|=code<<curBits;curBits+=codeSize;while(curBits>=8){block.push(cur&255);cur>>=8;curBits-=8;if(block.length===255){out.push(255,...block);block.length=0;}}};
  emit(clear);let prefix=idx[0];
  for(let i=1;i<idx.length;i++){
    const k=idx[i],key=prefix*4096+k+1,hit=dict.get(key);
    if(hit!==undefined){prefix=hit;continue;}
    emit(prefix);
    if(next<4096){dict.set(key,next++);if(next>(1<<codeSize)&&codeSize<12)codeSize++;}
    else{emit(clear);dict=new Map();codeSize=minCode+1;next=eoi+1;}
    prefix=k;
  }
  emit(prefix);emit(eoi);if(curBits>0){block.push(cur&255);}
  if(block.length)out.push(block.length,...block);
  out.push(0,0x3b);
  return new Blob([new Uint8Array(out)],{type:'image/gif'});
}

/* ---------- PDF ---------- */
async function buildPDF(o){
  o=o||{};const dpi=o.dpi||doc.dpi||72,pages=o.pages,q=(o.quality==null?92:o.quality)/100,lossless=!!o.lossless;
  const chunks=[],offs=[];let pos=0;
  const put=u8=>{chunks.push(u8);pos+=u8.length;};const str=s=>put(FENC.encode(s));
  const nObj=2+1+pages.length*3+pages.length; // catalog, pages, info, per page (page,content,image) + smasks (worst case)
  void nObj;
  let counter=3;const newId=()=>++counter;
  const pageIds=[],objects=[]; // {id, build()}
  let iccId=0;
  const imgObjs=[];
  if(o.icc){iccId=newId();objects.push({id:iccId,dict:'/N 3 /Alternate /DeviceRGB',stream:o.icc});}
  for(const pg of pages){
    const c=pg.canvas,w=c.width,h=c.height;
    const pageId=newId(),contentId=newId(),imgId=newId();pageIds.push(pageId);
    const x=cctx(c),id=x.getImageData(0,0,w,h),d=id.data;
    let hasAlpha=false;for(let i=3;i<d.length;i+=4)if(d[i]<255){hasAlpha=true;break;}
    let imgDict,imgBytes,smask=null;
    if(o.cmyk){
      const cm=new Uint8Array(w*h*4);
      for(let i=0,j=0;i<d.length;i+=4,j+=4){const a=d[i+3]/255,r=(d[i]*a+255*(1-a))/255,g=(d[i+1]*a+255*(1-a))/255,b2=(d[i+2]*a+255*(1-a))/255,k=1-Math.max(r,g,b2);
        if(k>=0.9999){cm[j+3]=255;}else{const ik=1/(1-k);cm[j]=(1-r-k)*ik*255;cm[j+1]=(1-g-k)*ik*255;cm[j+2]=(1-b2-k)*ik*255;cm[j+3]=k*255;}}
      imgBytes=await deflateBytes(cm);imgDict='/Type /XObject /Subtype /Image /Width '+w+' /Height '+h+' /ColorSpace /DeviceCMYK /BitsPerComponent 8 /Filter /FlateDecode';
    }else if(!lossless&&!hasAlpha){
      const b=await canvasBlob(c,'image/jpeg',q);imgBytes=new Uint8Array(await b.arrayBuffer());
      imgDict='/Type /XObject /Subtype /Image /Width '+w+' /Height '+h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode';
    }else{
      const rgb=new Uint8Array(w*h*3),al=hasAlpha?new Uint8Array(w*h):null;
      for(let i=0,j=0,k=0;i<d.length;i+=4,j+=3,k++){rgb[j]=d[i];rgb[j+1]=d[i+1];rgb[j+2]=d[i+2];if(al)al[k]=d[i+3];}
      const z=await deflateBytes(rgb);
      if(z){imgBytes=z;imgDict='/Type /XObject /Subtype /Image /Width '+w+' /Height '+h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode';}
      else{const t=mkCanvas(w,h),tx=cctx(t);tx.fillStyle='#fff';tx.fillRect(0,0,w,h);tx.drawImage(c,0,0);const b=await canvasBlob(t,'image/jpeg',q);imgBytes=new Uint8Array(await b.arrayBuffer());imgDict='/Type /XObject /Subtype /Image /Width '+w+' /Height '+h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode';}
      if(al&&z){const za=await deflateBytes(al);if(za){const sid=newId();smask={id:sid,bytes:za,dict:'/Type /XObject /Subtype /Image /Width '+w+' /Height '+h+' /ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode'};imgDict+=' /SMask '+sid+' 0 R';}}
    }
    if(iccId&&!o.cmyk)imgDict=imgDict.replace('/ColorSpace /DeviceRGB','/ColorSpace [/ICCBased '+iccId+' 0 R]');
    const pw=(w*72/dpi*(o.pageScale||1)).toFixed(2),ph=(h*72/dpi*(o.pageScale||1)).toFixed(2);
    const mk=pg.marks,mg=mk?mk.marginPt:0,bl=mk?mk.bleedPt:0,PW=(+pw+2*mg).toFixed(2),PH=(+ph+2*mg).toFixed(2);
    let boxes='',extra='';
    if(mk){
      boxes=' /BleedBox ['+mg.toFixed(2)+' '+mg.toFixed(2)+' '+(mg+ +pw).toFixed(2)+' '+(mg+ +ph).toFixed(2)+'] /TrimBox ['+(mg+bl).toFixed(2)+' '+(mg+bl).toFixed(2)+' '+(mg+ +pw-bl).toFixed(2)+' '+(mg+ +ph-bl).toFixed(2)+']';
      if(mk.crop){
        const x0=mg+bl,y0=mg+bl,x1=mg+ +pw-bl,y1=mg+ +ph-bl,gap=bl+2.83,L=Math.max(4,mg-gap-1),f=v=>v.toFixed(2);
        const ln=(a,b2,c2,d2)=>f(a)+' '+f(b2)+' m '+f(c2)+' '+f(d2)+' l S ';
        extra=' 0 0 0 1 K 0.5 w '+ln(x0-gap,y0,x0-gap-L,y0)+ln(x0,y0-gap,x0,y0-gap-L)+ln(x1+gap,y0,x1+gap+L,y0)+ln(x1,y0-gap,x1,y0-gap-L)
          +ln(x0-gap,y1,x0-gap-L,y1)+ln(x0,y1+gap,x0,y1+gap+L)+ln(x1+gap,y1,x1+gap+L,y1)+ln(x1,y1+gap,x1,y1+gap+L);
      }
    }
    objects.push({id:pageId,dict:'/Type /Page /Parent 2 0 R /MediaBox [0 0 '+PW+' '+PH+']'+boxes+' /Resources << /XObject << /Im0 '+imgId+' 0 R >> >> /Contents '+contentId+' 0 R'});
    const cs=FENC.encode('q '+pw+' 0 0 '+ph+' '+mg.toFixed(2)+' '+mg.toFixed(2)+' cm /Im0 Do Q'+extra);
    objects.push({id:contentId,dict:'',stream:cs});
    objects.push({id:imgId,dict:imgDict,stream:imgBytes});
    if(smask)objects.push({id:smask.id,dict:smask.dict,stream:smask.bytes});
  }
  const esc2=s=>String(s||'').replace(/[\\()]/g,'\\$&').replace(/[^\x20-\x7e]/g,'?');
  const info=doc.info||{},now=new Date(),pd='D:'+now.getUTCFullYear()+String(now.getUTCMonth()+1).padStart(2,'0')+String(now.getUTCDate()).padStart(2,'0')+String(now.getUTCHours()).padStart(2,'0')+String(now.getUTCMinutes()).padStart(2,'0')+String(now.getUTCSeconds()).padStart(2,'0')+'Z';
  str('%PDF-1.5\n');put(new Uint8Array([0x25,0xe2,0xe3,0xcf,0xd3,0x0a]));
  const wr=(id,dict,stream)=>{offs[id]=pos;str(id+' 0 obj\n');if(stream){str('<< '+dict+(dict?' ':'')+'/Length '+stream.length+' >>\nstream\n');put(stream);str('\nendstream\nendobj\n');}else str('<< '+dict+' >>\nendobj\n');};
  wr(1,'/Type /Catalog /Pages 2 0 R');
  wr(2,'/Type /Pages /Kids ['+pageIds.map(i=>i+' 0 R').join(' ')+'] /Count '+pageIds.length);
  wr(3,'/Title ('+esc2(info.title||doc.name)+') /Author ('+esc2(info.author)+') /Subject ('+esc2(info.desc)+') /Keywords ('+esc2(info.keywords)+') /Creator (LILKESSphoto Pro) /Producer (LILKESSphoto Pro) /CreationDate ('+pd+')');
  objects.sort((a,b)=>a.id-b.id).forEach(ob=>wr(ob.id,ob.dict,ob.stream));
  const total=counter+1,xr=pos;
  str('xref\n0 '+total+'\n0000000000 65535 f \n');
  for(let i=1;i<total;i++)str(String(offs[i]||0).padStart(10,'0')+' 00000 n \n');
  str('trailer\n<< /Size '+total+' /Root 1 0 R /Info 3 0 R >>\nstartxref\n'+xr+'\n%%EOF\n');
  let len=0;chunks.forEach(c=>len+=c.length);const out=new Uint8Array(len);let q2=0;chunks.forEach(c=>{out.set(c,q2);q2+=c.length;});
  return new Blob([out],{type:'application/pdf'});
}

/* ---------- ZIP with many files (stored) ---------- */
function zipMany(files){
  const parts=[],cen=[];let off=0;
  const u16=(a,v)=>a.push(v&255,v>>8&255),u32=(a,v)=>a.push(v&255,v>>8&255,v>>16&255,v>>>24&255);
  for(const f of files){
    const nb=FENC.encode(f.name),crc=crc32(f.data),h=[];
    u32(h,0x04034b50);u16(h,20);u16(h,0);u16(h,0);u16(h,0);u16(h,0x21);u32(h,crc);u32(h,f.data.length);u32(h,f.data.length);u16(h,nb.length);u16(h,0);
    parts.push(new Uint8Array(h),nb,f.data);
    const c=[];u32(c,0x02014b50);u16(c,20);u16(c,20);u16(c,0);u16(c,0);u16(c,0);u16(c,0x21);u32(c,crc);u32(c,f.data.length);u32(c,f.data.length);u16(c,nb.length);u16(c,0);u16(c,0);u16(c,0);u16(c,0);u32(c,0);u32(c,off);
    cen.push(new Uint8Array(c),nb);off+=h.length+nb.length+f.data.length;
  }
  let cl=0;cen.forEach(x=>cl+=x.length);const e=[];u32(e,0x06054b50);u16(e,0);u16(e,0);u16(e,files.length);u16(e,files.length);u32(e,cl);u32(e,off);u16(e,0);
  return new Blob([...parts,...cen,new Uint8Array(e)],{type:'application/zip'});
}

/* ---------- one place that makes a file in any format ---------- */
const SAVE_FORMATS=[
  ['psd','Photoshop (*.PSD)','psd','application/octet-stream'],
  ['pdf','Photoshop PDF (*.PDF)','pdf','application/pdf'],
  ['png','PNG (*.PNG)','png','image/png'],
  ['jpeg','JPEG (*.JPG)','jpg','image/jpeg'],
  ['webp','WebP (*.WEBP)','webp','image/webp'],
  ['tiff','TIFF (*.TIF)','tif','image/tiff'],
  ['bmp','BMP (*.BMP)','bmp','image/bmp'],
  ['gif','GIF (*.GIF)','gif','image/gif']
];
async function makeFile(fmt,o){
  o=o||{};flush();const sc=o.scale||1;
  if(fmt==='psd'){const u8=await buildPSDAsync(o);return new Blob([u8],{type:'application/octet-stream'});}
  if(fmt==='pdf'){
    const pages=o.allBoards&&((doc.extra&&doc.extra.boards)||[]).length?boardCanvases(sc,'#ffffff'):[{name:doc.name,canvas:flatCanvas(sc,'#ffffff')}];
    return buildPDF({pages,quality:o.quality,lossless:o.lossless,dpi:o.dpi||(doc.dpi||72)*sc});
  }
  if(fmt==='bmp')return encodeBMP(flatCanvas(sc,'#ffffff'));
  if(fmt==='tiff')return encodeTIFF2(flatCanvas(sc,null),o.dpi||(doc.dpi||72));
  if(fmt==='gif')return encodeGIF(flatCanvas(sc,o.matte||null));
  if(fmt==='jpeg')return setDpiBlob(await canvasBlob(flatCanvas(sc,o.matte||'#ffffff'),'image/jpeg',(o.quality||92)/100),o.dpi);
  if(fmt==='webp')return canvasBlob(flatCanvas(sc,null),'image/webp',(o.quality||92)/100);
  return setDpiBlob(await canvasBlob(flatCanvas(sc,null),'image/png'),o.dpi);
}
const extOf=fmt=>(SAVE_FORMATS.find(f=>f[0]===fmt)||[])[2]||'png';

/* ---------- Save As / Save a Copy ---------- */
function openSaveAs(copy){
  if(!doc){toast('Create or open a design first');return;}
  const hasText=doc.layers.some(l=>l.type==='text'),hasBoards=((doc.extra&&doc.extra.boards)||[]).length>0;
  const fmt0=S.saveFmt||(doc.srcFmt||'psd');
  modalOpen(copy?'Save a Copy':'Save As',
   '<div class="row"><label style="flex:1">File name <input type="text" id="sa-name" value="'+esc(fileBase())+'" style="width:100%"></label></div>'
   +'<div class="row"><label>Format <select id="sa-fmt">'+SAVE_FORMATS.map(f=>'<option value="'+f[0]+'"'+(f[0]===fmt0?' selected':'')+'>'+f[1]+'</option>').join('')+'</select></label></div>'
   +'<div class="row" id="sa-hires"><label>Size <select id="sa-sc"><option value="1">100% (original)</option><option value="2">200% (2x, sharp text)</option><option value="3">300% (3x)</option><option value="4">400% (4x)</option></select></label><label>Print resolution <select id="sa-dpi"><option value="">Keep ('+(doc.dpi||72)+' ppi)</option><option value="72">72 ppi (screen)</option><option value="150">150 ppi</option><option value="300">300 ppi (print)</option><option value="600">600 ppi</option></select></label></div>'
   +'<div id="sa-opts" class="saopts"></div><p class="muted" id="sa-note" style="margin:8px 0 0"></p>',
   [{label:'Cancel'},{label:'Save',primary:true,close:false,cb:()=>{doSaveAs(copy);return false;}}],root=>{
     const paint=()=>{
       const f=$('#sa-fmt').value,box=$('#sa-opts');let h='',note='';
       if(f==='psd'){
         h='<label class="row"><input type="checkbox" id="sa-text" checked> Keep text layers editable in Photoshop</label>'
          +'<label class="row"><input type="checkbox" id="sa-fx" checked> Keep layer styles (shadows, strokes, glows, gradients) editable</label>'
          +'<div class="muted">Adjustment layers cannot be stored as adjustments in a PSD yet; they appear only in the flattened preview.</div>';
         note='Layers, masks, blend modes, opacity, fill, clipping masks, text and layer styles are saved in the same PSD format Photoshop uses.'+(hasText?'':' ');
       }else if(f==='pdf'){
         h='<label class="row"><input type="checkbox" id="sa-boards"'+(hasBoards?' checked':' disabled')+'> Each artboard becomes a page</label>'
          +'<label class="row">Image quality <select id="sa-pq"><option value="100">Maximum (lossless)</option><option value="95">High</option><option value="85" selected>Medium</option><option value="70">Small file</option></select></label>';
         note='The PDF opens in any PDF viewer and in Photoshop. Pages are pictures of your design.';
       }else if(f==='jpeg'||f==='webp'){
         h='<label class="row">Quality <input type="range" id="sa-q" min="30" max="100" value="92" style="width:140px"><output id="sa-qv">92</output></label>';
         if(f==='jpeg')note='JPEG has no transparency: empty areas become white.';
       }else if(f==='gif')note='GIF keeps up to 256 colours and simple transparency.';
       else if(f==='bmp')note='BMP is saved with a white background.';
       else if(f==='tiff')note='TIFF keeps transparency and full quality.';
       else note='PNG keeps transparency and full quality.';
       $('#sa-hires').style.display=f==='psd'?'none':'';
       box.innerHTML=h;$('#sa-note').textContent=note;
       const q=$('#sa-q');if(q)q.oninput=()=>{$('#sa-qv').textContent=q.value;};
     };
     $('#sa-fmt').onchange=paint;paint();$('#sa-name').select();
   });
}
async function doSaveAs(copy){
  const fmt=$('#sa-fmt').value,name=($('#sa-name').value||'design').replace(/[\\/:*?"<>|]+/g,'_');
  const o={scale:$('#sa-sc')?+$('#sa-sc').value:1,dpi:$('#sa-dpi')&&$('#sa-dpi').value?+$('#sa-dpi').value:0,text:!$('#sa-text')||$('#sa-text').checked,fx:!$('#sa-fx')||$('#sa-fx').checked,allBoards:$('#sa-boards')&&$('#sa-boards').checked,quality:$('#sa-pq')?+$('#sa-pq').value:($('#sa-q')?+$('#sa-q').value:92),lossless:$('#sa-pq')&&$('#sa-pq').value==='100'};
  S.saveFmt=fmt;closeModal();toast('Saving '+name+'.'+extOf(fmt)+'...');
  try{
    await new Promise(r=>setTimeout(r,30));
    const blob=await makeFile(fmt,o);
    if(!blob){toast('Could not create the file');return;}
    await saveBlob(blob,name+'.'+extOf(fmt));
    if(!copy){doc.srcFmt=fmt;doc.name=name;renderTabs();}
  }catch(err){console.error(err);toast('Could not create the '+extOf(fmt).toUpperCase()+' file');}
}
ACT.saveAs=()=>openSaveAs(false);
ACT.saveCopy=()=>openSaveAs(true);
ACT.savePSD=()=>{S.saveFmt='psd';openSaveAs(false);};

/* ---------- Export submenu ---------- */
ACT.quickExport=async()=>{if(!doc){toast('Create or open a design first');return;}flush();toast('Exporting PNG...');const b=await makeFile('png');await saveBlob(b,fileBase()+'.png');};
ACT.exportLayers=async()=>{
  if(!doc){toast('Create or open a design first');return;}flush();toast('Exporting layers...');
  const files=[];let i=0;
  for(const l of doc.layers){
    if(l.type==='adjust')continue;
    const c=flatLayer(l),bb=alphaBBox(c);if(!bb)continue;
    const t=mkCanvas(bb.w,bb.h);cctx(t).drawImage(c,-bb.x,-bb.y);
    const b=await canvasBlob(t,'image/png');i++;
    files.push({name:String(i).padStart(2,'0')+'_'+(l.name||'layer').replace(/[^\w\- ]+/g,'_').slice(0,40)+'.png',data:new Uint8Array(await b.arrayBuffer())});
  }
  if(!files.length){toast('No layers with pictures to export');return;}
  await saveBlob(zipMany(files),fileBase()+'_layers.zip');
};
ACT.exportBoardsZip=async()=>{
  if(!doc){toast('Create or open a design first');return;}
  const L=(doc.extra&&doc.extra.boards)||[];if(!L.length){toast('Make an artboard first with the Artboard tool');return;}
  flush();const files=[];
  for(const p of boardCanvases(1,null)){const b=await canvasBlob(p.canvas,'image/png');files.push({name:p.name.replace(/[^\w\- ]+/g,'_')+'.png',data:new Uint8Array(await b.arrayBuffer())});}
  await saveBlob(zipMany(files),fileBase()+'_artboards.zip');
};
ACT.exportBoardsPDF=async()=>{
  if(!doc)return;const L=(doc.extra&&doc.extra.boards)||[];if(!L.length){toast('Make an artboard first with the Artboard tool');return;}
  flush();toast('Making the PDF...');const b=await makeFile('pdf',{allBoards:true,quality:90});await saveBlob(b,fileBase()+'_artboards.pdf');
};
ACT.share=async()=>{
  if(!doc)return;flush();
  try{
    const b=await makeFile('png'),f=new File([b],fileBase()+'.png',{type:'image/png'});
    if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:doc.name});return;}
  }catch(err){if(err&&err.name==='AbortError')return;}
  toast('Sharing is not available here. Use Export instead.');ACT.exportAs();
};

/* ---------- Revert, File Info, Print, Exit ---------- */
ACT.revert=()=>{
  if(!doc)return;
  const to=doc.savedHi!=null?Math.min(doc.savedHi,hist.length-1):0;
  if(hi===to){toast('Nothing to revert');return;}
  jumpTo(to);toast('Reverted. You can undo this from History.');
};
ACT.fileInfo=()=>{
  if(!doc)return;const i=doc.info||{};
  const f=(id,l,v,ml)=>'<label class="fld">'+l+(ml?'<textarea id="'+id+'" rows="3">'+esc(v||'')+'</textarea>':'<input type="text" id="'+id+'" value="'+esc(v||'')+'">')+'</label>';
  const tl=doc.layers.filter(l=>l.type==='text').length;
  modalOpen('File Info',f('fi-title','Document title',i.title||doc.name)+f('fi-author','Author',i.author)+f('fi-desc','Description',i.desc,true)+f('fi-keys','Keywords',i.keywords)+f('fi-copy','Copyright notice',i.copyright)
    +'<div class="h">Details</div><p class="muted">'+doc.w+' x '+doc.h+' px, '+(doc.dpi||72)+' ppi<br>'+doc.layers.length+' layers ('+tl+' text), RGB, 8 bits per channel<br>'+(((doc.extra&&doc.extra.boards)||[]).length)+' artboards</p>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{doc.info={title:$('#fi-title').value,author:$('#fi-author').value,desc:$('#fi-desc').value,keywords:$('#fi-keys').value,copyright:$('#fi-copy').value};doc.modified=true;}}]);
};
ACT.print=()=>{
  if(!doc)return;flush();
  const c=flatCanvas(1,'#ffffff'),img=new Image();
  img.onload=()=>{
    let pa=document.getElementById('printarea');if(!pa){pa=document.createElement('div');pa.id='printarea';document.body.appendChild(pa);}
    pa.innerHTML='';pa.appendChild(img);document.body.classList.add('printing');
    setTimeout(()=>{window.print();setTimeout(()=>{document.body.classList.remove('printing');pa.innerHTML='';},500);},100);
  };
  img.src=c.toDataURL('image/png');
};
ACT.exitApp=()=>{
  const dirty=docs.some(d=>d.doc.modified);
  const go=()=>{try{window.close();}catch(err){}toast('You can close this tab or window now');};
  if(dirty){modalOpen('Exit','<p>Some designs have unsaved changes. Close the app anyway?</p>',[{label:'Cancel'},{label:'Exit',primary:true,cb:go}]);}else go();
};

/* ---------- Open Recent submenu (cached) ---------- */
let recentCache=[];
async function refreshRecent(){try{const l=await listProjects();if(l)recentCache=l.slice(0,12);}catch(err){}}
refreshRecent();
(function(){
  const _sp=saveProject;
  saveProject=async function(){const r=await _sp.apply(this,arguments);if(doc)doc.savedHi=hi;refreshRecent();return r;};
})();

/* ---------- build the File menu ---------- */
(function(){
  const M=MENUS.find(m=>m.label==='File');
  const recent={label:'Open Recent',get items(){
    if(!recentCache.length)return [al('(nothing saved on this device yet)','',()=>{})];
    return recentCache.map(p=>al(p.name+'  ('+p.w+' x '+p.h+')','',()=>loadProject(p.id))).concat([SEP,al('Browse all saved designs...','',()=>openRecentDialog())]);
  }};
  M.items=[
    al('New...','Ctrl+N','new'),al('Open...','Ctrl+O','open'),al('Browse designs and templates','',()=>showWelcome()),recent,
    SEP,
    mi('Close','Ctrl+W','closeDoc'),mi('Close All','Ctrl+Alt+W','closeAll'),SEP,
    mi('Save to this device','Ctrl+S','saveProject'),mi('Save As...','Ctrl+Shift+S','saveAs'),mi('Save a Copy...','Ctrl+Alt+S','saveCopy'),mi('Revert','F12','revert'),SEP,
    sub('Export',[mi('Quick Export as PNG','','quickExport'),mi('Export As...','Ctrl+Alt+Shift+W','exportAs'),SEP,mi('Export Layers to Files (ZIP)','','exportLayers'),mi('Export Artboards (PNG, ZIP)','','exportBoardsZip'),mi('Export Artboards to PDF','','exportBoardsPDF'),mi('Export Slices','','exportSlices'),SEP,mi('Save for Web (Legacy)...','Ctrl+Alt+Shift+S','exportAs')]),
    mi('Share...','','share'),SEP,
    mi('Place Embedded...','','place'),mi('Place Linked...','','place'),SEP,
    mi('File Info...','Ctrl+Alt+Shift+I','fileInfo'),SEP,
    mi('Print...','Ctrl+P','print'),SEP,
    mi('Exit','Ctrl+Q','exitApp'),SEP,
    al('Welcome screen','','welcome')
  ];
  const walk=its=>its.forEach(it=>{if(it.items&&!Object.getOwnPropertyDescriptor(it,'items').get)walk(it.items);else if(it.key){const k=it.key.replace(/^Ctrl\+Shift\+Alt\+/,'Ctrl+Alt+Shift+');SHORT[k]=it;}});
  Object.keys(SHORT).forEach(k=>{if(/^(Ctrl\+Shift\+S|Ctrl\+Alt\+E|Ctrl\+Alt\+Shift\+S|Ctrl\+Alt\+Shift\+W|Ctrl\+Alt\+Shift\+I|F12|Ctrl\+P|Ctrl\+Q|Ctrl\+Alt\+S)$/.test(k))delete SHORT[k];});
  walk(M.items);
})();
