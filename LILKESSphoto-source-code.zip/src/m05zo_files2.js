/* ===== Own file format (.lkphoto), Save to the file you opened, Save sheet on phones, brush limits ===== */
const LKP_EXT='lkphoto',LKP_MAGIC='LKPHOTO1';
SAVE_FORMATS.unshift(['lkp','LILKESSphoto project (*.LKPHOTO) - keeps layers, text and masks','lkphoto','application/x-lilkessphoto']);
async function projToBlob(){
  flush();const layers=[],blobs=[];
  const put=async c=>{const b=await toPngBlob(c);blobs.push(b);return blobs.length-1;};
  for(const l of doc.layers){
    const mt=meta(l);mt.orig=null;
    layers.push({meta:mt,b:await put(l.canvas),m:l.mask?await put(l.mask):-1,o:l.orig?await put(l.orig):-1,k:(mkSettingsOf(l)?await put(mkSettingsOf(l).base):-1),kp:(mkSettingsOf(l)?mkSettingsOf(l).p:null)});
  }
  const k=240/Math.max(doc.w,doc.h),tc=mkCanvas(Math.max(1,Math.round(doc.w*k)),Math.max(1,Math.round(doc.h*k)));compose(cctx(tc),k);
  const thumb=tc.toDataURL('image/jpeg',0.8);
  const head={v:1,name:doc.name,w:doc.w,h:doc.h,ppi:doc.ppi||72,nextId:doc.nextId,active:doc.active,guides:doc.guides||[],paths:clone(doc.paths||[]),extra:clone(doc.extra||null),comments:clone(doc.comments||[]),frames:clone(doc.frames||[]),info:clone(doc.info||null),thumb,layers,sizes:[]};
  const bufs=[];for(const b of blobs){const a=new Uint8Array(await b.arrayBuffer());bufs.push(a);head.sizes.push(a.length);}
  const hb=new TextEncoder().encode(JSON.stringify(head)),pre=new Uint8Array(12);
  pre.set(new TextEncoder().encode(LKP_MAGIC),0);new DataView(pre.buffer).setUint32(8,hb.length,true);
  return new Blob([pre,hb,...bufs],{type:'application/x-lilkessphoto'});
}
async function openProjFile(file){
  try{
    const buf=await file.arrayBuffer(),u=new Uint8Array(buf);
    if(new TextDecoder().decode(u.subarray(0,8))!==LKP_MAGIC){toast('That is not a LILKESSphoto project file');return false;}
    const hl=new DataView(buf).getUint32(8,true),head=JSON.parse(new TextDecoder().decode(u.subarray(12,12+hl)));
    let off=12+hl;const offs=head.sizes.map(n=>{const o=off;off+=n;return [o,n];});
    const img=async i=>{if(i<0)return null;const [o,n]=offs[i],bmp=await createImageBitmap(new Blob([u.subarray(o,o+n)],{type:'image/png'})),c=mkCanvas(bmp.width,bmp.height);cctx(c).drawImage(bmp,0,0);return c;};
    startDoc(head.name||file.name.replace(/\.[^.]+$/,''),head.w,head.h,head.ppi||72);doc.guides=head.guides||[];
    for(const L of head.layers){{const lay=Object.assign({},L.meta,{canvas:await img(L.b),ver:0,mask:await img(L.m),mver:0,pvv:0,orig:await img(L.o)});if(lay.mask&&L.k>=0&&L.kp)lay.mk={base:await img(L.k),p:Object.assign({dens:100,feather:0},L.kp),mver:0,shown:lay.mask};doc.layers.push(lay);}}
    doc.nextId=head.nextId;doc.paths=head.paths||[];doc.ap=doc.paths.length?0:-1;doc.extra=head.extra||null;doc.comments=head.comments||[];doc.frames=head.frames||[];if(head.info)doc.info=head.info;
    finishDoc();doc.active=head.active;doc.srcFmt='lkp';refreshAll();redraw();setTool('move');return true;
  }catch(err){console.error(err);toast('Could not open that project file');return false;}
}
{const _mf=makeFile;makeFile=async function(fmt,o){if(fmt==='lkp')return projToBlob();return _mf.apply(this,arguments);};}
{const _oa=openAnyFile;openAnyFile=async function(file){const n=(file.name||'').toLowerCase();if(n.endsWith('.'+LKP_EXT)){toast('Opening project...');return openProjFile(file);}return _oa.apply(this,arguments);};
 window.__openFile=openAnyFile;
 const fi=document.getElementById('file');if(fi)fi.setAttribute('accept','image/*,.psd,.'+LKP_EXT);
 window.addEventListener('drop',e=>{const f=[...(e.dataTransfer?e.dataTransfer.files:[])].filter(x=>(x.name||'').toLowerCase().endsWith('.'+LKP_EXT));f.forEach(x=>openAnyFile(x));},true);}
/* ---- remember the file a design came from, so Save writes back to it ---- */
const fmtOfName=n=>{const e=((n||'').toLowerCase().match(/\.([a-z0-9]+)$/)||[])[1];return ({psd:'psd',png:'png',jpg:'jpeg',jpeg:'jpeg',webp:'webp',tif:'tiff',tiff:'tiff',bmp:'bmp',gif:'gif',pdf:'pdf',lkphoto:'lkp'})[e]||null;};
const canPick=()=>typeof window.showOpenFilePicker==='function';
async function openWithHandle(){
  try{
    const hs=await window.showOpenFilePicker({multiple:true,types:[{description:'Pictures and projects',accept:{'image/*':['.png','.jpg','.jpeg','.webp','.gif','.bmp','.tif','.tiff'],'application/octet-stream':['.psd','.'+LKP_EXT]}}]});
    for(const h of hs){
      const f=await h.getFile(),before=doc,n=docs.length;await openAnyFile(f);
      for(let i=0;i<60&&docs.length===n&&doc===before;i++)await new Promise(r=>setTimeout(r,50));
      if(doc&&doc!==before||docs.length>n){doc.fh=h;doc.srcFmt=fmtOfName(f.name)||doc.srcFmt||'png';doc.srcName=f.name;}
    }
  }catch(err){if(!err||err.name!=='AbortError'){console.error(err);pickFile('open');}}
}
ACT.open=()=>{if(canPick())openWithHandle();else pickFile('open');};
{const al2=MENUS.find(m=>m.label==='File');}
/* ---- Save: write back to the same file; Save As the first time ---- */
async function writeHandle(h,blob){
  if(h.queryPermission){let p=await h.queryPermission({mode:'readwrite'});if(p!=='granted')p=await h.requestPermission({mode:'readwrite'});if(p!=='granted')throw new Error('denied');}
  const w=await h.createWritable();await w.write(blob);await w.close();
}
ACT.saveSmart=async()=>{
  if(!doc){toast('Create or open a design first');return;}
  flush();
  const fmt=doc.srcFmt&&fmtOfName('x.'+extOf(doc.srcFmt))?doc.srcFmt:null;
  if(doc.fh&&fmt){
    try{
      toast('Saving...');
      const blob=await makeFile(fmt,{}),
        warn=(fmt==='jpeg'||fmt==='png'||fmt==='webp'||fmt==='gif'||fmt==='bmp'||fmt==='tiff')&&doc.layers.length>1&&!doc.flatWarned;
      await writeHandle(doc.fh,blob);
      doc.modified=false;doc.savedHi=hi;renderTabs();
      try{await saveProject();}catch(e){}
      toast('Saved to '+(doc.fh.name||'your file')+(warn?'. This format is flat. Use Save As > LILKESSphoto project to keep layers.':''));
      if(warn)doc.flatWarned=true;
      return;
    }catch(err){console.error(err);toast('Could not write to that file. Choose where to save it.');}
  }
  if(!doc.fh&&typeof window.showSaveFilePicker!=='function'&&doc.srcFmt){ // no file system access: download again under the same name
    const blob=await makeFile(doc.srcFmt,{});await saveBlob(blob,fileBase()+'.'+extOf(doc.srcFmt));doc.modified=false;renderTabs();try{await saveProject();}catch(e){}return;
  }
  S.saveFmt=doc.srcFmt||'lkp';openSaveAs(false);
};
ACT.saveDevice=async()=>{await doSaveProject();};
/* after Save As, remember where it went */
{const _dsa=doSaveAs;doSaveAs=async function(copy){LASTFH=null;await _dsa.apply(this,arguments);if(!copy&&doc){if(LASTFH){doc.fh=LASTFH;doc.srcName=LASTFH.name;}LASTFH=null;doc.modified=false;doc.savedHi=hi;renderTabs();try{await saveProject();}catch(e){}}};}
/* phones and browsers without a save window: use the share sheet so you can pick Files / Drive / Downloads */
{
  const _sb2=saveBlob;
  saveBlob=async function(blob,name){
    if(typeof window.showSaveFilePicker!=='function'&&navigator.canShare&&navigator.share&&PREFS.shareSave!==false&&isMobile()){
      try{const f=new File([blob],name,{type:blob.type||'application/octet-stream'});
        if(navigator.canShare({files:[f]})){await navigator.share({files:[f],title:name});toast('Pick where to keep '+name);return;}
      }catch(err){if(err&&err.name==='AbortError'){toast('Save cancelled');return;}}
    }
    return _sb2(blob,name);
  };
}
/* File menu */
{
  const M=MENUS.find(m=>m.label==='File');
  if(M){
    M.items.forEach(it=>{if(it.label==='Save to this device'){it.label='Save';it.key='Ctrl+S';it.fn=()=>ACT.saveSmart();it.dis=()=>!doc;}});
    const i=M.items.findIndex(it=>it.label==='Save');
    if(i>=0)M.items.splice(i+1,0,mi('Save as project (.lkphoto)...','','saveProjectFile'),mi('Save in app (this device)','','saveDevice'));
  }
  ACT.saveProjectFile=()=>{S.saveFmt='lkp';openSaveAs(false);};
}
/* Ctrl+S key */
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&!e.shiftKey&&!e.altKey&&e.key.toLowerCase()==='s'){e.preventDefault();e.stopPropagation();ACT.saveSmart();}},true);
/* installed app: files opened from the desktop or phone file manager keep their file, so Save writes back to them */
if('launchQueue' in window){window.launchQueue.setConsumer(async lp=>{for(const h of (lp.files||[])){try{const f=await h.getFile(),before=doc,n=docs.length;hideWelcome&&hideWelcome();await openAnyFile(f);for(let i=0;i<60&&docs.length===n&&doc===before;i++)await new Promise(r=>setTimeout(r,50));if(doc){doc.fh=h;doc.srcFmt=fmtOfName(f.name)||'png';}}catch(e){console.error(e);}}});}
