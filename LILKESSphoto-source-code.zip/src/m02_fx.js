
/* ===== text and shape layers ===== */
const scratch=mkCanvas(4,4).getContext('2d');
function fontSpec(p){return (p.italic?'italic ':'')+(p.bold?700:400)+' '+p.size+'px "'+p.font+'",'+fontFallback(p.font);}
function renderText(l){
  const p=l.props,spec=fontSpec(p),txt=p.caps?p.text.toUpperCase():p.text,lines=p.vert?Array.from(txt.replace(/\n/g,'')):txt.split('\n');
  scratch.font=spec;
  let mw=1;for(const t of lines)mw=Math.max(mw,scratch.measureText(t).width);
  const pad=Math.ceil(p.size*0.12+p.sw+p.shadow*1.6+4),lh=p.size*p.lh;
  const c=l.canvas;c.width=Math.ceil(mw+pad*2);c.height=Math.ceil(lines.length*lh+pad*2);
  const ctx=cctx(c);ctx.font=spec;ctx.textBaseline='middle';ctx.textAlign=p.vert?'center':p.align;ctx.lineJoin='round';
  const x=(p.align==='left'&&!p.vert)?pad:(p.align==='right'&&!p.vert)?c.width-pad:c.width/2;
  lines.forEach((t,i)=>{
    const y=pad+(i+.5)*lh;
    if(p.sw>0){ctx.strokeStyle=p.stroke;ctx.lineWidth=p.sw*2;ctx.strokeText(t,x,y);}
    if(p.shadow>0){ctx.shadowColor=p.shadowColor;ctx.shadowBlur=p.shadow;ctx.shadowOffsetY=p.shadow/3;}
    ctx.fillStyle=p.color;ctx.fillText(t,x,y);
    ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.shadowOffsetY=0;
  });
  l.mask=null;touch(l);
  if(document.fonts&&!document.fonts.check(spec,'Aa')){
    document.fonts.load(spec,'Aa').then(()=>{if(l.props&&l.props.font===p.font){renderText(l);}}).catch(()=>{});
  }
}
function rr(ctx,x,y,w,h,r){
  r=Math.min(r,w/2,h/2);ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();
}
function renderShape(l){
  const p=l.props,pad=Math.ceil(p.sw/2)+3,w=Math.max(2,Math.round(p.w)),h=Math.max(2,Math.round(p.h));
  const c=l.canvas;c.width=w+pad*2;c.height=h+pad*2;
  const ctx=cctx(c);ctx.translate(pad,pad);ctx.beginPath();
  switch(p.kind){
    case 'round':rr(ctx,0,0,w,h,p.radius);break;
    case 'ellipse':ctx.ellipse(w/2,h/2,w/2,h/2,0,0,Math.PI*2);break;
    case 'triangle':ctx.moveTo(w/2,0);ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();break;
    case 'star':for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,k=i%2?0.42:1;const px=w/2+Math.cos(a)*k*w/2,py=h/2+Math.sin(a)*k*h/2;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();break;
    case 'line':ctx.moveTo(0,p.flip?h:0);ctx.lineTo(w,p.flip?0:h);break;
    case 'polygon':{const n=Math.max(3,p.sides|0||6);for(let i=0;i<n;i++){const a=-Math.PI/2+i*2*Math.PI/n,px=w/2+Math.cos(a)*w/2,py=h/2+Math.sin(a)*h/2;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();break;}
    case 'custom':case 'path':{const np=shapeNorm(p);if(np)vec_trace(ctx,np,[w,0,0,h,0,0]);break;}
    default:ctx.rect(0,0,w,h);
  }
  if(p.kind!=='line'&&p.fill&&!p.nofill){ctx.fillStyle=p.fill;ctx.fill('evenodd');}
  if(p.sw>0){ctx.strokeStyle=p.stroke;ctx.lineWidth=p.sw;ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();}
  l.mask=null;touch(l);
}
function renderAny(l){if(l.type==='text')renderText(l);else if(l.type==='shape')renderShape(l);}
function bake(l){
  if(l.type==='text'){const p=l.props,k=l.s;p.size=Math.max(6,Math.round(p.size*k));p.sw=+(p.sw*k).toFixed(1);p.shadow=+(p.shadow*k).toFixed(1);l.s=1;renderText(l);}
  else if(l.type==='shape'){const p=l.props,k=l.s;p.w*=k;p.h*=k;p.sw=+(p.sw*k).toFixed(1);p.radius*=k;if(p.cr)p.cr=p.cr.map(v=>v*k);if(p.vr)p.vr*=k;l.s=1;renderShape(l);}
}
function rasterize(l){if(l.type==='text'||l.type==='shape'){l.type='image';l.props=null;}}

/* ===== colour maths ===== */
const cp=img=>new Uint8ClampedArray(img.data);
const mkImg=(d,w,h)=>new ImageData(d,w,h);
function rgb2hsl(r,g,b){
  r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;const d=mx-mn;
  if(d>0){s=l>0.5?d/(2-mx-mn):d/(mx+mn);if(mx===r)h=(g-b)/d+(g<b?6:0);else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h/=6;}
  return [h,s,l];
}
function hue2rgb(p,q,t){if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;}
function hsl2rgb(h,s,l){
  let r,g,b;
  if(s===0){r=g=b=l;}else{const q=l<0.5?l*(1+s):l+s-l*s,p=2*l-q;r=hue2rgb(p,q,h+1/3);g=hue2rgb(p,q,h);b=hue2rgb(p,q,h-1/3);}
  return [r*255,g*255,b*255];
}
function applyLut(img,lut){const d=cp(img);for(let i=0;i<d.length;i+=4){d[i]=lut[d[i]];d[i+1]=lut[d[i+1]];d[i+2]=lut[d[i+2]];}return mkImg(d,img.width,img.height);}
function lutLevels(ib,g,iw,ob,ow){
  const lut=new Uint8Array(256);
  for(let i=0;i<256;i++){let v=clamp((i-ib)/Math.max(1,iw-ib),0,1);v=Math.pow(v,1/g);lut[i]=clamp(Math.round(ob+v*(ow-ob)),0,255);}
  return lut;
}
function curveLut(pts){
  const P=pts.slice().sort((a,b)=>a[0]-b[0]),n=P.length,xs=P.map(q=>q[0]),ys=P.map(q=>q[1]),lut=new Uint8Array(256);
  if(n<2){for(let i=0;i<256;i++)lut[i]=i;return lut;}
  const dx=[],m=[];
  for(let i=0;i<n-1;i++){dx[i]=(xs[i+1]-xs[i])||1e-6;m[i]=(ys[i+1]-ys[i])/dx[i];}
  const t=new Array(n);t[0]=m[0];t[n-1]=m[n-2];
  for(let i=1;i<n-1;i++){
    if(m[i-1]*m[i]<=0)t[i]=0;
    else{const w1=2*dx[i]+dx[i-1],w2=dx[i]+2*dx[i-1];t[i]=(w1+w2)/(w1/m[i-1]+w2/m[i]);}
  }
  for(let x=0;x<256;x++){
    if(x<=xs[0]){lut[x]=clamp(Math.round(ys[0]),0,255);continue;}
    if(x>=xs[n-1]){lut[x]=clamp(Math.round(ys[n-1]),0,255);continue;}
    let i=0;while(i<n-2&&x>xs[i+1])i++;
    const h=dx[i],u=(x-xs[i])/h,u2=u*u,u3=u2*u;
    const y=(2*u3-3*u2+1)*ys[i]+(u3-2*u2+u)*h*t[i]+(-2*u3+3*u2)*ys[i+1]+(u3-u2)*h*t[i+1];
    lut[x]=clamp(Math.round(y),0,255);
  }
  return lut;
}

/* ===== adjustments (panel sliders) ===== */
const ADJ0={exposure:0,brightness:0,contrast:0,highlights:0,shadows:0,saturation:0,warmth:0,sharpen:0,blur:0,smooth:0,vignette:0,fade:0,grain:0,gray:0,sepia:0,lo:0,hi:255,gamma:1,mix:100};
function skinSmooth(d,w,h,amount){
  const bl=new Uint8ClampedArray(d);
  boxBlur(bl,w,h,Math.max(2,Math.round(Math.max(w,h)/220)),3);
  for(let i=0;i<d.length;i+=4){
    const R=d[i],G=d[i+1],B=d[i+2];
    const cb=128-0.168736*R-0.331264*G+0.5*B,cr=128+0.5*R-0.418688*G-0.081312*B;
    if(!(cb>=77&&cb<=127&&cr>=133&&cr<=173))continue;
    const diff=(0.299*R+0.587*G+0.114*B)-(0.299*bl[i]+0.587*bl[i+1]+0.114*bl[i+2]);
    const k=amount*Math.exp(-(diff*diff)/(2*20*20));
    d[i]=R+(bl[i]-R)*k;d[i+1]=G+(bl[i+1]-G)*k;d[i+2]=B+(bl[i+2]-B)*k;
  }
}
function processAdjust(base,p){
  const w=base.width,h=base.height,d=new Uint8ClampedArray(base.data);
  const mul=Math.pow(2,p.exposure/50),add=p.brightness*1.27,C=p.contrast*2.55,cf=(259*(C+255))/(255*(259-C));
  const sat=1+p.saturation/100,wr=p.warmth*0.35,fade=p.fade/100*0.28,gr=p.gray/100,sp=p.sepia/100;
  const useLv=p.lo>0||p.hi<255||p.gamma!==1,span=Math.max(1,p.hi-p.lo),ig=1/p.gamma;
  const sh=p.shadows*0.5,hl=p.highlights*0.5;
  for(let i=0;i<d.length;i+=4){
    let r=d[i],g=d[i+1],b=d[i+2];
    if(useLv){r=255*Math.pow(clamp((r-p.lo)/span,0,1),ig);g=255*Math.pow(clamp((g-p.lo)/span,0,1),ig);b=255*Math.pow(clamp((b-p.lo)/span,0,1),ig);}
    if(mul!==1){r*=mul;g*=mul;b*=mul;}
    if(sh||hl){const L=clamp((0.299*r+0.587*g+0.114*b)/255,0,1),k=sh*(1-L)*(1-L)+hl*L*L;r+=k;g+=k;b+=k;}
    if(add){r+=add;g+=add;b+=add;}
    if(C){r=cf*(r-128)+128;g=cf*(g-128)+128;b=cf*(b-128)+128;}
    if(sat!==1){const L=0.299*r+0.587*g+0.114*b;r=L+(r-L)*sat;g=L+(g-L)*sat;b=L+(b-L)*sat;}
    if(wr){r+=wr;g+=wr*0.15;b-=wr;}
    if(fade){r=r*(1-fade)+90*fade;g=g*(1-fade)+90*fade;b=b*(1-fade)+90*fade;}
    if(gr){const L=0.299*r+0.587*g+0.114*b;r+=(L-r)*gr;g+=(L-g)*gr;b+=(L-b)*gr;}
    if(sp){const tr=0.393*r+0.769*g+0.189*b,tg=0.349*r+0.686*g+0.168*b,tb=0.272*r+0.534*g+0.131*b;r+=(tr-r)*sp;g+=(tg-g)*sp;b+=(tb-b)*sp;}
    d[i]=r;d[i+1]=g;d[i+2]=b;
  }
  if(p.smooth>0)skinSmooth(d,w,h,p.smooth/100);
  if(p.blur>0)boxBlur(d,w,h,Math.max(1,Math.round(p.blur*Math.max(1,Math.max(w,h)/1000))),2);
  if(p.sharpen>0){
    const bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(1,Math.round(Math.max(w,h)/1200)),2);
    const k=p.sharpen/100*1.6;
    for(let i=0;i<d.length;i++){if((i&3)===3)continue;d[i]=d[i]+(d[i]-bl[i])*k;}
  }
  if(p.vignette>0||p.grain>0){
    const v=p.vignette/100,gn=p.grain*0.9;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4;let f=1;
      if(v){const dx=(x/w-0.5)*2,dy=(y/h-0.5)*2,t=clamp((Math.min(1,Math.hypot(dx,dy)/1.4142)-0.3)/0.7,0,1);f=1-v*0.85*t*t*(3-2*t);}
      const n=gn?(Math.random()-0.5)*gn:0;
      d[i]=d[i]*f+n;d[i+1]=d[i+1]*f+n;d[i+2]=d[i+2]*f+n;
    }
  }
  if(p.mix<100){const m=p.mix/100,bd=base.data;for(let i=0;i<d.length;i++){if((i&3)!==3)d[i]=bd[i]+(d[i]-bd[i])*m;}}
  return new ImageData(d,w,h);
}
function autoLevels(id){
  const d=id.data,hs=new Uint32Array(256);let n=0,sum=0;
  for(let i=0;i<d.length;i+=4){if(d[i+3]<10)continue;const L=Math.round(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]);hs[L]++;n++;sum+=L;}
  if(!n)return {lo:0,hi:255,gamma:1};
  let acc=0,lo=0,hi=255;const t=n*0.005;
  for(let i=0;i<256;i++){acc+=hs[i];if(acc>t){lo=i;break;}}
  acc=0;for(let i=255;i>=0;i--){acc+=hs[i];if(acc>t){hi=i;break;}}
  if(hi-lo<30){lo=0;hi=255;}
  const m=clamp((sum/n-lo)/(hi-lo),0.05,0.95);
  return {lo,hi,gamma:+clamp(Math.log(m)/Math.log(0.46),0.75,1.7).toFixed(2)};
}
const PRESETS=[
  {n:'Original',p:{}},{n:'Auto fix',auto:true},
  {n:'Vivid',p:{saturation:35,contrast:18,sharpen:25}},
  {n:'Warm',p:{warmth:35,saturation:10,brightness:4}},
  {n:'Cool',p:{warmth:-35,contrast:8}},
  {n:'Golden hour',p:{warmth:50,saturation:20,highlights:-15,vignette:25,contrast:10}},
  {n:'Portrait glow',p:{smooth:70,brightness:6,warmth:10,highlights:-10,saturation:6}},
  {n:'Soft skin',p:{smooth:100}},
  {n:'Black & white',p:{gray:100,contrast:20}},
  {n:'Noir',p:{gray:100,contrast:45,vignette:45,brightness:-6}},
  {n:'Vintage',p:{sepia:40,fade:35,contrast:-8,vignette:30,grain:20}},
  {n:'Faded',p:{fade:45,saturation:-15,contrast:-10}},
  {n:'Drama',p:{contrast:40,saturation:-10,shadows:-20,sharpen:40,vignette:25}},
  {n:'Cinema',p:{warmth:-12,contrast:25,saturation:-8,shadows:10,vignette:35}},
  {n:'Crisp',p:{sharpen:70,contrast:10}},
  {n:'Dreamy',p:{blur:3,brightness:10,saturation:12,fade:15,mix:60}}
];
function presetParams(pr,src){
  const p=Object.assign({},ADJ0);
  if(pr.auto)Object.assign(p,autoLevels(src),{saturation:10,shadows:8});else Object.assign(p,pr.p);
  return p;
}

/* ===== effect session: live preview on a small copy, commit at full size ===== */
const layerById=id=>doc&&doc.layers.find(l=>l.id===id)||null;
let sess=null;
const adj={p:Object.assign({},ADJ0)};
function sessBegin(kind,fn,params,label){
  const l=active();
  if(!l){toast('Select a layer first');return null;}
  if(l.locked){toast('This layer is locked');return null;}
  if(sess&&(sess.lid!==l.id||sess.kind!==kind))sessCancelQuiet();
  if(!sess){
    const w=l.canvas.width,h=l.canvas.height;
    const base=cctx(l.canvas).getImageData(0,0,w,h),k=Math.min(1,(S.previewMax||900)/Math.max(w,h));
    let small=base;
    if(k<1){const c=mkCanvas(w*k,h*k);cctx(c).drawImage(l.canvas,0,0,c.width,c.height);small=cctx(c).getImageData(0,0,c.width,c.height);}
    sess={kind,lid:l.id,base,small,k:small.width/w,fn,p:params,dirty:false,raf:0,
      selSmall:S.sel?selAlphaLocal(l,small.width,small.height):null,selFull:S.sel?selAlphaLocal(l):null,
      prevType:l.type,prevProps:l.props,label:label||'Adjust',fxid:kind==='adjust'?'_adj':null};
    if(l.type==='text'||l.type==='shape'){l.type='image';l.props=null;}
  }
  sess.fn=fn;sess.p=params;sess.label=label||sess.label;
  return sess;
}
function sessPreview(){
  if(!sess)return;
  sess.dirty=true;cancelAnimationFrame(sess.raf);
  sess.raf=requestAnimationFrame(()=>{
    if(!sess)return;const l=layerById(sess.lid);if(!l)return;
    if(sess.hidePrev){l.pv=null;l.pvv++;redraw();return;}
    let out=sess.fn(sess.small,sess.p,{scale:sess.k});
    if(sess.selSmall)out=mixSel(sess.small,out,sess.selSmall);
    if(!l.pv||l.pv.width!==out.width||l.pv.height!==out.height)l.pv=mkCanvas(out.width,out.height);
    cctx(l.pv).putImageData(out,0,0);l.pvv++;redraw();
  });
  setFoot();
}
function sessFinish(){
  if(!sess)return;const s=sess;cancelAnimationFrame(s.raf);
  if(!s.dirty){sessCancelQuiet();return;}
  const l=layerById(s.lid);
  if(l){
    let out=s.fn(s.base,s.p,{scale:1});
    if(s.selFull)out=mixSel(s.base,out,s.selFull);
    if(l.smart&&s.fxid){smartAdd(l,s);}else{cctx(l.canvas).putImageData(out,0,0);l.pv=null;l.pvv++;l.ver++;}
  }
  sess=null;closeFxDlg();
  if(s.kind==='adjust'){adj.p=Object.assign({},ADJ0);syncAdj();}
  commit(s.label);renderProps();setFoot();redraw();
}
function sessCancelQuiet(){
  if(!sess){return;}
  const s=sess;cancelAnimationFrame(s.raf);
  const l=layerById(s.lid);
  if(l){l.pv=null;l.pvv++;if(s.prevType&&(s.prevType==='text'||s.prevType==='shape')){l.type=s.prevType;l.props=s.prevProps;}}
  sess=null;closeFxDlg();
  if(s.kind==='adjust'){adj.p=Object.assign({},ADJ0);syncAdj();}
  setFoot();if(doc)redraw();
}
function adjChanged(){
  if(!sessBegin('adjust',processAdjust,adj.p,'Adjustments'))return;
  sessPreview();
}
function applyPreset(pr){
  if(!sessBegin('adjust',processAdjust,adj.p,'Look: '+pr.n))return;
  adj.p=presetParams(pr,sess.small);sess.p=adj.p;syncAdj();sessPreview();
}
function resetAdj(){sessCancelQuiet();adj.p=Object.assign({},ADJ0);syncAdj();if(S.tab==='filters')renderFilters();}

/* ===== effects library: image adjustments and filters ===== */
const FX={};
const P=(k,label,min,max,def,step)=>({k,label,min,max,def,step:step||1});
function defFx(id,group,name,params,fn,o){FX[id]=Object.assign({id,group,name,params,fn},o||{});}
const sc=(v,c)=>Math.max(0,v*((c&&c.scale)||1));
const lumA=(img)=>{const d=img.data,L=new Float32Array(img.width*img.height);for(let i=0,k=0;i<d.length;i+=4,k++)L[k]=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];return L;};

function warp(img,fn){
  const w=img.width,h=img.height,s=img.data,out=new Uint8ClampedArray(s.length),o=[0,0];
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    fn(x,y,o);
    let sx=o[0],sy=o[1];sx=sx<0?0:sx>w-1?w-1:sx;sy=sy<0?0:sy>h-1?h-1:sy;
    const x0=Math.floor(sx),y0=Math.floor(sy),x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1),fx=sx-x0,fy=sy-y0;
    const a=(y0*w+x0)*4,b=(y0*w+x1)*4,c=(y1*w+x0)*4,d=(y1*w+x1)*4,t=(y*w+x)*4;
    for(let k=0;k<4;k++){out[t+k]=(s[a+k]*(1-fx)+s[b+k]*fx)*(1-fy)+(s[c+k]*(1-fx)+s[d+k]*fx)*fy;}
  }
  return mkImg(out,w,h);
}

/* Image > Adjustments */
defFx('bc','adjust','Brightness / Contrast',[P('b','Brightness',-100,100,0),P('c','Contrast',-100,100,0)],(img,p)=>processAdjust(img,Object.assign({},ADJ0,{brightness:p.b,contrast:p.c})));
defFx('levels','adjust','Levels',[P('ib','Input black',0,253,0),P('g','Midtones (gamma)',0.1,5,1,0.01),P('iw','Input white',2,255,255),P('ob','Output black',0,255,0),P('ow','Output white',0,255,255)],(img,p)=>applyLut(img,lutLevels(p.ib,p.g,Math.max(p.iw,p.ib+1),p.ob,p.ow)));
defFx('curves','adjust','Curves',[],(img,p)=>applyLut(img,curveLut(p.pts)),{custom:'curves'});
defFx('exposure','adjust','Exposure',[P('e','Exposure',-100,100,0)],(img,p)=>processAdjust(img,Object.assign({},ADJ0,{exposure:p.e})));
defFx('shadhi','adjust','Shadows / Highlights',[P('s','Shadows',-100,100,30),P('h','Highlights',-100,100,-20)],(img,p)=>processAdjust(img,Object.assign({},ADJ0,{shadows:p.s,highlights:p.h})));
defFx('vibrance','adjust','Vibrance',[P('v','Vibrance',-100,100,40)],(img,p)=>{
  const d=cp(img),k0=p.v/100;
  for(let i=0;i<d.length;i+=4){
    const r=d[i],g=d[i+1],b=d[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),s=(mx-mn)/255,L=0.299*r+0.587*g+0.114*b,k=1+k0*(1-s)*1.2;
    d[i]=L+(r-L)*k;d[i+1]=L+(g-L)*k;d[i+2]=L+(b-L)*k;
  }
  return mkImg(d,img.width,img.height);
});
defFx('huesat','adjust','Hue / Saturation',[P('h','Hue',-180,180,0),P('s','Saturation',-100,100,0),P('l','Lightness',-100,100,0)],(img,p)=>{
  const d=cp(img);
  for(let i=0;i<d.length;i+=4){
    let [h,s,l]=rgb2hsl(d[i],d[i+1],d[i+2]);
    h=(h+p.h/360+1)%1;s=clamp(s*(1+p.s/100),0,1);
    l=p.l>0?l+(1-l)*p.l/100:l*(1+p.l/100);
    const c=hsl2rgb(h,s,l);d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];
  }
  return mkImg(d,img.width,img.height);
});
defFx('colbal','adjust','Color Balance',[P('r','Cyan to Red',-100,100,0),P('g','Magenta to Green',-100,100,0),P('b','Yellow to Blue',-100,100,0)],(img,p)=>{
  const d=cp(img);
  for(let i=0;i<d.length;i+=4){
    const L=(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])/255,w=1-Math.abs(2*L-1)*0.6;
    d[i]+=p.r*0.5*w;d[i+1]+=p.g*0.5*w;d[i+2]+=p.b*0.5*w;
  }
  return mkImg(d,img.width,img.height);
});
defFx('bw','adjust','Black & White',[P('r','Reds',-50,200,30),P('g','Greens',-50,200,59),P('b','Blues',-50,200,11)],(img,p)=>{
  const d=cp(img);
  for(let i=0;i<d.length;i+=4){const v=(d[i]*p.r+d[i+1]*p.g+d[i+2]*p.b)/100;d[i]=d[i+1]=d[i+2]=v;}
  return mkImg(d,img.width,img.height);
});
defFx('temp','adjust','Colour Temperature',[P('t','Cooler to warmer',-100,100,20)],(img,p)=>processAdjust(img,Object.assign({},ADJ0,{warmth:p.t})));
defFx('poster','adjust','Posterize',[P('n','Levels',2,32,5)],(img,p)=>{
  const lut=new Uint8Array(256),n=Math.round(p.n);
  for(let i=0;i<256;i++)lut[i]=Math.round(Math.floor(i/256*n)/(n-1)*255);
  return applyLut(img,lut);
});
defFx('thresh','adjust','Threshold',[P('t','Threshold level',1,255,128)],(img,p)=>{
  const d=cp(img);
  for(let i=0;i<d.length;i+=4){const v=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]>=p.t?255:0;d[i]=d[i+1]=d[i+2]=v;}
  return mkImg(d,img.width,img.height);
});
defFx('invert','adjust','Invert',[],(img)=>{const d=cp(img);for(let i=0;i<d.length;i+=4){d[i]=255-d[i];d[i+1]=255-d[i+1];d[i+2]=255-d[i+2];}return mkImg(d,img.width,img.height);},{immediate:true});
defFx('desat','adjust','Desaturate',[],(img)=>{const d=cp(img);for(let i=0;i<d.length;i+=4){const v=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];d[i]=d[i+1]=d[i+2]=v;}return mkImg(d,img.width,img.height);},{immediate:true});
defFx('autotone','adjust','Auto Tone',[],(img)=>processAdjust(img,Object.assign({},ADJ0,autoLevels(img),{saturation:6})),{immediate:true});
defFx('autocon','adjust','Auto Contrast',[],(img)=>{const a=autoLevels(img);return applyLut(img,lutLevels(a.lo,1,Math.max(a.hi,a.lo+1),0,255));},{immediate:true});
defFx('autocol','adjust','Auto Color',[],(img)=>{
  const d=cp(img);let r=0,g=0,b=0,n=0;
  for(let i=0;i<d.length;i+=4){if(d[i+3]<10)continue;r+=d[i];g+=d[i+1];b+=d[i+2];n++;}
  if(!n)return mkImg(d,img.width,img.height);
  r/=n;g/=n;b/=n;const m=(r+g+b)/3,gr=clamp(m/Math.max(r,1),0.7,1.4),gg=clamp(m/Math.max(g,1),0.7,1.4),gb=clamp(m/Math.max(b,1),0.7,1.4);
  for(let i=0;i<d.length;i+=4){d[i]*=gr;d[i+1]*=gg;d[i+2]*=gb;}
  return mkImg(d,img.width,img.height);
},{immediate:true});

/* Filter > Blur */
defFx('gauss','blur','Gaussian Blur',[P('r','Radius (px)',0.5,100,8,0.5)],(img,p,c)=>{
  const d=cp(img),r=Math.round(sc(p.r,c)*0.85);if(r<1)return mkImg(d,img.width,img.height);
  boxBlur(d,img.width,img.height,r,3);return mkImg(d,img.width,img.height);
});
defFx('box','blur','Box Blur',[P('r','Radius (px)',1,100,6)],(img,p,c)=>{
  const d=cp(img),r=Math.round(sc(p.r,c));if(r<1)return mkImg(d,img.width,img.height);
  boxBlur(d,img.width,img.height,r,1);return mkImg(d,img.width,img.height);
});
/* Motion blur along any angle. The picture is cut into straight lines at that angle and every line gets a running-sum box blur,
   so it stays fast at any distance. Edges repeat, like Photoshop. */
function motionBlurData(s,w,h,ang,dist){
  const a=ang*Math.PI/180,dx=Math.cos(a),dy=-Math.sin(a),out=new Uint8ClampedArray(s.length);
  const xMajor=Math.abs(dx)>=Math.abs(dy),sl=xMajor?dy/dx:dx/dy,stepLen=Math.sqrt(1+sl*sl);
  const n=Math.max(1,Math.round(dist/stepLen)),left=n>>1;
  if(n<2){out.set(s);return out;}
  const M=xMajor?w:h,Mn=xMajor?h:w,sh=Math.round((M-1)*sl);
  const k0=-Math.max(0,sh),k1=Mn-1-Math.min(0,sh);
  const idx=new Int32Array(M),P=new Float64Array((M+1)*4);
  for(let k=k0;k<=k1;k++){
    let m=0;
    for(let t=0;t<M;t++){const mi=k+Math.round(t*sl);if(mi<0||mi>=Mn)continue;idx[m++]=xMajor?mi*w+t:t*w+mi;}
    if(!m)continue;
    P[0]=P[1]=P[2]=P[3]=0;
    for(let i=0;i<m;i++){const o=idx[i]*4,al=s[o+3]/255,q=(i+1)*4;P[q]=P[q-4]+s[o]*al;P[q+1]=P[q-3]+s[o+1]*al;P[q+2]=P[q-2]+s[o+2]*al;P[q+3]=P[q-1]+al;}
    const f=idx[0]*4,l=idx[m-1]*4,fa=s[f+3]/255,la=s[l+3]/255;
    for(let i=0;i<m;i++){
      const lo=i-left,hi=i+(n-1-left),a0=lo<0?0:lo,a1=(hi>m-1?m-1:hi)+1;
      let r=P[a1*4]-P[a0*4],g=P[a1*4+1]-P[a0*4+1],b=P[a1*4+2]-P[a0*4+2],al=P[a1*4+3]-P[a0*4+3];
      if(lo<0){const c=-lo;r+=s[f]*fa*c;g+=s[f+1]*fa*c;b+=s[f+2]*fa*c;al+=fa*c;}
      if(hi>m-1){const c=hi-(m-1);r+=s[l]*la*c;g+=s[l+1]*la*c;b+=s[l+2]*la*c;al+=la*c;}
      const o=idx[i]*4;
      if(al>1e-6){out[o]=r/al;out[o+1]=g/al;out[o+2]=b/al;}
      out[o+3]=al/n*255;
    }
  }
  return out;
}
defFx('motion','blur','Motion Blur',[Object.assign(P('a','Angle',-360,360,0),{dial:true,unit:'°'}),Object.assign(P('d','Distance',1,2000,10),{unit:' px'})],(img,p,c)=>{
  return mkImg(motionBlurData(img.data,img.width,img.height,p.a,sc(p.d,c)),img.width,img.height);
});
defFx('radial','blur','Radial Blur',[P('m','Amount',1,100,10),Object.assign(P('t','Method (0 = Spin, 1 = Zoom)',0,1,0),{}),P('q','Quality (1 draft, 2 good, 3 best)',1,3,2),P('cx','Center X %',0,100,50),P('cy','Center Y %',0,100,50)],(img,p)=>{
  const w=img.width,h=img.height,s=img.data,out=new Uint8ClampedArray(s.length),n=[0,8,16,32][Math.round(p.q)],cx=w*p.cx/100,cy=h*p.cy/100,zoom=p.t>=0.5;
  const amt=p.m/100,maxA=amt*Math.PI/3,maxZ=amt*0.35;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    let r=0,g=0,b=0,al=0;
    for(let i=0;i<n;i++){
      const t=n>1?i/(n-1)-0.5:0;let sx,sy;
      if(zoom){const k=1-maxZ*(t+0.5);sx=cx+(x-cx)*k;sy=cy+(y-cy)*k;}
      else{const an=maxA*t,c=Math.cos(an),sn=Math.sin(an),vx=x-cx,vy=y-cy;sx=cx+vx*c-vy*sn;sy=cy+vx*sn+vy*c;}
      sx=Math.round(sx);sy=Math.round(sy);sx=sx<0?0:sx>=w?w-1:sx;sy=sy<0?0:sy>=h?h-1:sy;
      const o=(sy*w+sx)*4,a=s[o+3];r+=s[o]*a;g+=s[o+1]*a;b+=s[o+2]*a;al+=a;
    }
    const t=(y*w+x)*4;if(al>0){out[t]=r/al;out[t+1]=g/al;out[t+2]=b/al;}out[t+3]=al/n;
  }
  return mkImg(out,w,h);
});
defFx('blurmore','blur','Blur More',[],(img)=>{const d=cp(img);boxBlur(d,img.width,img.height,2,2);return mkImg(d,img.width,img.height);},{immediate:true});
defFx('blur1','blur','Blur',[],(img)=>{const d=cp(img);boxBlur(d,img.width,img.height,1,1);return mkImg(d,img.width,img.height);},{immediate:true});
defFx('average','blur','Average',[],(img)=>{
  const d=cp(img);let r=0,g=0,b=0,n=0;
  for(let i=0;i<d.length;i+=4){const a=d[i+3];r+=d[i]*a;g+=d[i+1]*a;b+=d[i+2]*a;n+=a;}
  if(n){r/=n;g/=n;b/=n;for(let i=0;i<d.length;i+=4){d[i]=r;d[i+1]=g;d[i+2]=b;}}
  return mkImg(d,img.width,img.height);
},{immediate:true});
defFx('tilt','blur','Tilt-Shift Blur',[P('r','Blur amount',1,60,14),P('f','Focus position %',0,100,50),P('w','Sharp band %',2,80,20)],(img,p,c)=>{
  const w=img.width,h=img.height,d=cp(img),bl=cp(img);
  boxBlur(bl,w,h,Math.max(1,Math.round(sc(p.r,c))),3);
  for(let y=0;y<h;y++){
    const dist=Math.abs(y/h-p.f/100)-p.w/200,t=clamp(dist/(0.25),0,1),k=t*t*(3-2*t);
    if(k<=0)continue;
    for(let x=0;x<w;x++){const o=(y*w+x)*4;for(let q=0;q<4;q++)d[o+q]+=(bl[o+q]-d[o+q])*k;}
  }
  return mkImg(d,w,h);
});
/* Filter > Sharpen */
function unsharp(img,amount,radius,thr,c){
  const w=img.width,h=img.height,d=cp(img),bl=cp(img);
  boxBlur(bl,w,h,Math.max(1,Math.round(sc(radius,c))),2);
  const k=amount/100;
  for(let i=0;i<d.length;i+=4)for(let q=0;q<3;q++){const diff=d[i+q]-bl[i+q];if(Math.abs(diff)>=thr)d[i+q]+=diff*k;}
  return mkImg(d,w,h);
}
defFx('sharpen','sharpen','Sharpen',[P('a','Amount',10,300,100)],(img,p,c)=>unsharp(img,p.a,1.2,0,c));
defFx('unsharp','sharpen','Unsharp Mask',[P('a','Amount %',1,500,120),P('r','Radius (px)',0.5,40,2,0.5),P('t','Threshold',0,60,0)],(img,p,c)=>unsharp(img,p.a,p.r,p.t,c));
/* Filter > Noise */
defFx('noise','noise','Add Noise',[P('a','Amount',1,100,15),P('m','Monochrome (1 = on)',0,1,0)],(img,p)=>{
  const d=cp(img),k=p.a*2.2;
  for(let i=0;i<d.length;i+=4){
    const n=(Math.random()-0.5)*k;
    if(p.m>=1){d[i]+=n;d[i+1]+=n;d[i+2]+=n;}else{d[i]+=(Math.random()-0.5)*k;d[i+1]+=(Math.random()-0.5)*k;d[i+2]+=(Math.random()-0.5)*k;}
  }
  return mkImg(d,img.width,img.height);
});
defFx('median','noise','Reduce Noise (median)',[P('n','Strength',1,3,1)],(img,p)=>{
  const w=img.width,h=img.height;let s=img.data,out=null;const v=new Array(9);
  for(let pass=0;pass<Math.round(p.n);pass++){
    out=new Uint8ClampedArray(s.length);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const o=(y*w+x)*4;
      for(let ch=0;ch<3;ch++){
        let k=0;
        for(let dy=-1;dy<=1;dy++){const yy=y+dy<0?0:y+dy>=h?h-1:y+dy;for(let dx=-1;dx<=1;dx++){const xx=x+dx<0?0:x+dx>=w?w-1:x+dx;v[k++]=s[(yy*w+xx)*4+ch];}}
        for(let i=1;i<9;i++){const t=v[i];let j=i-1;while(j>=0&&v[j]>t){v[j+1]=v[j];j--;}v[j+1]=t;}
        out[o+ch]=v[4];
      }
      out[o+3]=s[o+3];
    }
    s=out;
  }
  return mkImg(out,w,h);
});
/* Filter > Stylize */
defFx('emboss','stylize','Emboss',[P('a','Angle',0,360,135),P('h','Height',1,10,3,0.5)],(img,p)=>{
  const w=img.width,h=img.height,L=lumA(img),d=cp(img),a=p.a*Math.PI/180,dx=Math.round(Math.cos(a)),dy=Math.round(-Math.sin(a));
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const x1=clamp(x+dx,0,w-1),y1=clamp(y+dy,0,h-1),x0=clamp(x-dx,0,w-1),y0=clamp(y-dy,0,h-1);
    const v=(L[y1*w+x1]-L[y0*w+x0])*p.h+128,o=(y*w+x)*4;d[o]=d[o+1]=d[o+2]=v;
  }
  return mkImg(d,w,h);
});
defFx('edges','stylize','Find Edges',[P('s','Strength',0.5,6,2,0.1)],(img,p)=>{
  const w=img.width,h=img.height,L=lumA(img),d=cp(img),at=(x,y)=>L[clamp(y,0,h-1)*w+clamp(x,0,w-1)];
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const gx=-at(x-1,y-1)-2*at(x-1,y)-at(x-1,y+1)+at(x+1,y-1)+2*at(x+1,y)+at(x+1,y+1);
    const gy=-at(x-1,y-1)-2*at(x,y-1)-at(x+1,y-1)+at(x-1,y+1)+2*at(x,y+1)+at(x+1,y+1);
    const v=255-Math.sqrt(gx*gx+gy*gy)*p.s*0.5,o=(y*w+x)*4;d[o]=d[o+1]=d[o+2]=v;
  }
  return mkImg(d,w,h);
});
defFx('sketch','stylize','Pencil Sketch',[P('r','Line softness',2,40,12)],(img,p,c)=>{
  const w=img.width,h=img.height,d=cp(img),inv=new Uint8ClampedArray(d.length);
  for(let i=0;i<d.length;i+=4){const g=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];inv[i]=inv[i+1]=inv[i+2]=255-g;inv[i+3]=255;}
  boxBlur(inv,w,h,Math.max(1,Math.round(sc(p.r,c))),3);
  for(let i=0;i<d.length;i+=4){const g=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],v=Math.min(255,g*255/(256-inv[i]));d[i]=d[i+1]=d[i+2]=v;}
  return mkImg(d,w,h);
});
defFx('glow','stylize','Soft Glow',[P('r','Radius (px)',2,80,18),P('s','Strength',5,100,50)],(img,p,c)=>{
  const w=img.width,h=img.height,d=cp(img),bl=cp(img);
  boxBlur(bl,w,h,Math.max(1,Math.round(sc(p.r,c))),3);const k=p.s/100;
  for(let i=0;i<d.length;i+=4)for(let q=0;q<3;q++){const sc2=255-(255-d[i+q])*(255-bl[i+q])/255;d[i+q]+=(sc2-d[i+q])*k;}
  return mkImg(d,w,h);
});
/* Filter > Pixelate */
defFx('mosaic','pixelate','Mosaic',[P('s','Cell size (px)',2,120,16)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,d=new Uint8ClampedArray(s.length),cell=Math.max(2,Math.round(sc(p.s,c)));
  for(let y0=0;y0<h;y0+=cell)for(let x0=0;x0<w;x0+=cell){
    const x1=Math.min(w,x0+cell),y1=Math.min(h,y0+cell);let r=0,g=0,b=0,a=0,n=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const o=(y*w+x)*4;r+=s[o];g+=s[o+1];b+=s[o+2];a+=s[o+3];n++;}
    r/=n;g/=n;b/=n;a/=n;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const o=(y*w+x)*4;d[o]=r;d[o+1]=g;d[o+2]=b;d[o+3]=a;}
  }
  return mkImg(d,w,h);
});
/* Filter > Distort */
defFx('twirl','distort','Twirl',[P('a','Angle',-720,720,200),P('r','Radius %',10,100,70)],(img,p)=>{
  const w=img.width,h=img.height,cx=w/2,cy=h/2,R=Math.min(w,h)/2*p.r/100,A=p.a*Math.PI/180;
  return warp(img,(x,y,o)=>{
    const dx=x-cx,dy=y-cy,dist=Math.hypot(dx,dy);
    if(dist>=R){o[0]=x;o[1]=y;return;}
    const t=1-dist/R,ang=A*t*t,cs=Math.cos(ang),sn=Math.sin(ang);
    o[0]=cx+dx*cs-dy*sn;o[1]=cy+dx*sn+dy*cs;
  });
});
defFx('spherize','distort','Spherize / Pinch',[P('a','Amount',-100,100,50)],(img,p)=>{
  const w=img.width,h=img.height,cx=w/2,cy=h/2,R=Math.min(w,h)/2,a=p.a/100,e=a>=0?1+a*1.2:1/(1-a*0.8);
  return warp(img,(x,y,o)=>{
    const dx=x-cx,dy=y-cy,dist=Math.hypot(dx,dy);
    if(dist>=R||dist===0){o[0]=x;o[1]=y;return;}
    const nd=dist/R,src=R*Math.pow(nd,e),k=src/dist;
    o[0]=cx+dx*k;o[1]=cy+dy*k;
  });
});
defFx('ripple','distort','Ripple',[P('a','Amplitude (px)',1,60,10),P('w','Wavelength (px)',10,400,80)],(img,p,c)=>{
  const A=sc(p.a,c),W=Math.max(4,sc(p.w,c));
  return warp(img,(x,y,o)=>{o[0]=x+A*Math.sin(2*Math.PI*y/W);o[1]=y+A*Math.sin(2*Math.PI*x/W);});
});
/* Retouch */
defFx('skin','retouch','Skin Smoothing',[P('a','Amount',5,100,60)],(img,p)=>{
  const d=cp(img);skinSmooth(d,img.width,img.height,p.a/100);return mkImg(d,img.width,img.height);
});
const FX_GROUPS={blur:'Blur',sharpen:'Sharpen',noise:'Noise',stylize:'Stylize',pixelate:'Pixelate',distort:'Distort',retouch:'Retouch'};
let lastFx=null;

/* ===== effect dialog ===== */
let fxState=null;
function openFx(id){
  if(!doc){toast('Create or open a design first');return;}
  const def=FX[id];if(!def)return;
  flush();
  if(!active()){toast('Select a layer first');return;}
  if(def.immediate){
    if(!sessBegin('filter',def.fn,{},def.name))return;
    sess.fxid=id;sess.dirty=true;sessFinish();lastFx={id,p:{}};return;
  }
  const p={};def.params.forEach(q=>{p[q.k]=q.def;});
  if(def.custom==='curves')p.pts=[[0,0],[255,255]];
  if(!sessBegin('filter',def.fn,p,def.name))return;
  sess.fxid=id;fxState={def,p};buildFxDlg();
  document.body.classList.add('fx-open');$('#fxdlg').hidden=false;sessPreview();
}
function runLastFx(){
  if(!lastFx){toast('Run a filter first');return;}
  const def=FX[lastFx.id];if(!def||!doc)return;flush();
  if(!sessBegin('filter',def.fn,JSON.parse(JSON.stringify(lastFx.p)),def.name))return;
  sess.fxid=lastFx.id;sess.dirty=true;sessFinish();
}
function buildFxDlg(){
  const {def,p}=fxState;$('#fxtitle').textContent=def.name;
  let h=def.params.map(q=>(q.dial?'<div class="dialrow"><div class="dial" data-dk="'+q.k+'"><i></i></div><span class="muted">Drag the dial to set the direction</span></div>':'')+'<label class="sl"><span title="'+esc(q.label)+'">'+esc(q.label)+'</span><input type="range" data-k="'+q.k+'" min="'+q.min+'" max="'+q.max+'" step="'+q.step+'" value="'+p[q.k]+'"><input type="number" class="nv" data-k="'+q.k+'" min="'+q.min+'" max="'+q.max+'" step="'+q.step+'" value="'+p[q.k]+'">'+(q.unit?'<em class="un">'+q.unit+'</em>':'')+'</label>').join('');
  if(def.custom==='curves')h='<canvas id="crv" width="256" height="256" aria-label="Curve editor"></canvas><p class="muted" style="margin:6px 0 0">Tap or drag on the graph. Double-tap a point to remove it.</p>';
  $('#fxbody').innerHTML=h;$('#fxprev').checked=true;
  if(def.custom==='curves')initCurves();
  $$('#fxbody .dial').forEach(initDial);
}
function fxSync(k,v){
  const q=fxState.def.params.find(x=>x.k===k);if(q)v=clamp(v,q.min,q.max);
  fxState.p[k]=v;$$('#fxbody [data-k="'+k+'"]').forEach(el=>{if(+el.value!==v)el.value=v;});
  const d=$('#fxbody .dial[data-dk="'+k+'"] i');if(d)d.style.transform='rotate('+(-v)+'deg)';
}
function initDial(el){
  const k=el.dataset.dk;fxSync(k,fxState.p[k]);
  const set=e=>{const r=el.getBoundingClientRect(),ang=Math.atan2(-(e.clientY-(r.top+r.height/2)),e.clientX-(r.left+r.width/2))*180/Math.PI;let v=Math.round(ang);if(e.shiftKey)v=Math.round(v/15)*15;fxSync(k,v);sessPreview();};
  el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);set(e);const mv=ev=>set(ev),up=()=>{el.removeEventListener('pointermove',mv);el.removeEventListener('pointerup',up);};el.addEventListener('pointermove',mv);el.addEventListener('pointerup',up);});
}
$('#fxbody').addEventListener('input',e=>{
  const k=e.target.dataset&&e.target.dataset.k;if(!k||!fxState)return;
  if(e.target.value===''||isNaN(+e.target.value))return;
  fxSync(k,+e.target.value);sessPreview();
});
$('#fxprev').addEventListener('change',e=>{if(!sess)return;sess.hidePrev=!e.target.checked;sessPreview();});
function fxReset(){
  if(!fxState)return;
  fxState.def.params.forEach(q=>{fxState.p[q.k]=q.def;});
  if(fxState.def.custom==='curves')fxState.p.pts=[[0,0],[255,255]];
  buildFxDlg();sessPreview();
}
function fxCancel(){sessCancelQuiet();closeFxDlg();}
function fxOk(){
  if(!sess)return;toast('Applying...');
  const id=fxState&&fxState.def.id,p=fxState?JSON.parse(JSON.stringify(fxState.p)):{};
  setTimeout(()=>{if(sess){sess.dirty=true;sessFinish();lastFx={id,p};}closeFxDlg();},30);
}
function closeFxDlg(){fxState=null;const d=$('#fxdlg');if(d)d.hidden=true;document.body.classList.remove('fx-open');}
function initCurves(){
  const cv=$('#crv'),x=cv.getContext('2d');let drag=-1;
  const pts=fxState.p.pts;
  const draw=()=>{
    x.clearRect(0,0,256,256);x.fillStyle='#1d1d1d';x.fillRect(0,0,256,256);
    x.strokeStyle='#3b3b3b';x.lineWidth=1;x.beginPath();
    for(let i=1;i<4;i++){x.moveTo(i*64,0);x.lineTo(i*64,256);x.moveTo(0,i*64);x.lineTo(256,i*64);}x.stroke();
    x.strokeStyle='#555';x.beginPath();x.moveTo(0,256);x.lineTo(256,0);x.stroke();
    const lut=curveLut(pts);x.strokeStyle='#e8e8e8';x.lineWidth=2;x.beginPath();
    for(let i=0;i<256;i++){const yy=255-lut[i];i?x.lineTo(i,yy):x.moveTo(i,yy);}x.stroke();
    pts.forEach(q=>{x.fillStyle='#2d8ceb';x.strokeStyle='#fff';x.lineWidth=1.5;x.beginPath();x.arc(q[0],255-q[1],5,0,7);x.fill();x.stroke();});
  };
  const pos=e=>{const r=cv.getBoundingClientRect();return [clamp((e.clientX-r.left)/r.width*256,0,255),clamp(255-(e.clientY-r.top)/r.height*256,0,255)];};
  const near=q=>{let b=-1,bd=14;pts.forEach((p2,i)=>{const dd=Math.hypot(p2[0]-q[0],p2[1]-q[1]);if(dd<bd){bd=dd;b=i;}});return b;};
  cv.addEventListener('pointerdown',e=>{
    e.preventDefault();cv.setPointerCapture(e.pointerId);const q=pos(e);let i=near(q);
    if(i<0){pts.push(q);i=pts.length-1;}
    drag=i;draw();sessPreview();
  });
  cv.addEventListener('pointermove',e=>{
    if(drag<0)return;const q=pos(e),first=pts[drag]===pts.slice().sort((a,b)=>a[0]-b[0])[0],last=pts[drag]===pts.slice().sort((a,b)=>a[0]-b[0])[pts.length-1];
    pts[drag][1]=q[1];if(!first&&!last)pts[drag][0]=clamp(q[0],1,254);
    draw();sessPreview();
  });
  const end=()=>{drag=-1;};
  cv.addEventListener('pointerup',end);cv.addEventListener('pointercancel',end);
  cv.addEventListener('dblclick',e=>{
    const i=near(pos(e));if(i<0||pts.length<=2)return;
    const sorted=pts.slice().sort((a,b)=>a[0]-b[0]);if(pts[i]===sorted[0]||pts[i]===sorted[sorted.length-1])return;
    pts.splice(i,1);draw();sessPreview();
  });
  draw();
}
