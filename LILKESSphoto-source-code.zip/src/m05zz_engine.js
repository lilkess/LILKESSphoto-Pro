/* ===== Graphics engine: real Lanczos / bicubic resampling (in a background worker), device memory limits,
   memory-aware history, zoom presets and high-quality display at any zoom ===== */

/* ---------- resampler ---------- */
function rsEngineFactory(){
  const K={
    lanczos:{sup:3,f:x=>{x=Math.abs(x);if(x>=3)return 0;if(x<1e-8)return 1;const p=Math.PI*x;return 3*Math.sin(p)*Math.sin(p/3)/(p*p);}},
    bicubic:{sup:2,f:x=>{x=Math.abs(x);const a=-0.5;if(x<1)return (a+2)*x*x*x-(a+3)*x*x+1;if(x<2)return a*x*x*x-5*a*x*x+8*a*x-4*a;return 0;}},
    bilinear:{sup:1,f:x=>{x=Math.abs(x);return x<1?1-x:0;}}
  };
  /* taps for one axis: for each output pixel, the first source pixel, how many, and normalised weights */
  function taps(nIn,nOut,kind){
    const k=K[kind],sc=nIn/nOut,fs=Math.max(1,sc),sup=k.sup*fs,start=new Int32Array(nOut),cnt=new Int32Array(nOut),off=new Int32Array(nOut);
    let total=0;const tmp=[];
    for(let o=0;o<nOut;o++){
      const c=(o+0.5)*sc-0.5;let a=Math.max(0,Math.ceil(c-sup)),b=Math.min(nIn-1,Math.floor(c+sup));if(b<a){a=b=Math.min(nIn-1,Math.max(0,Math.round(c)));}
      let s=0;const w=[];for(let i=a;i<=b;i++){const v=k.f((i-c)/fs);w.push(v);s+=v;}
      if(Math.abs(s)<1e-9){w.length=0;w.push(1);s=1;}
      start[o]=a;cnt[o]=w.length;off[o]=total;for(let i=0;i<w.length;i++)tmp.push(w[i]/s);total+=w.length;
    }
    return {start,cnt,off,w:Float32Array.from(tmp)};
  }
  /* src: RGBA Uint8ClampedArray. Works in premultiplied alpha so transparent edges get no dark or light halos. */
  function resample(src,w,h,nw,nh,kind,onRow){
    const out=new Uint8ClampedArray(nw*nh*4);
    if(kind==='nearest'){
      for(let y=0;y<nh;y++){const sy=Math.min(h-1,Math.floor((y+0.5)*h/nh));for(let x=0;x<nw;x++){const sx=Math.min(w-1,Math.floor((x+0.5)*w/nw)),i=(sy*w+sx)*4,j=(y*nw+x)*4;out[j]=src[i];out[j+1]=src[i+1];out[j+2]=src[i+2];out[j+3]=src[i+3];}
        if(onRow&&(y&63)===0)if(onRow(y/nh)===false)return null;}
      return out;
    }
    const tx=taps(w,nw,kind),ty=taps(h,nh,kind),cache=new Map();
    const rowH=y=>{
      let r=cache.get(y);if(r)return r;r=new Float32Array(nw*4);const b=y*w*4;
      for(let x=0;x<nw;x++){
        const s=tx.start[x],n=tx.cnt[x],o=tx.off[x];let R=0,G=0,B=0,A=0;
        for(let i=0;i<n;i++){const j=b+(s+i)*4,a=src[j+3]*(1/255),wt=tx.w[o+i];A+=a*wt;R+=src[j]*a*wt;G+=src[j+1]*a*wt;B+=src[j+2]*a*wt;}
        const q=x*4;r[q]=R;r[q+1]=G;r[q+2]=B;r[q+3]=A;
      }
      cache.set(y,r);return r;
    };
    const acc=new Float32Array(nw*4);
    for(let y=0;y<nh;y++){
      const s=ty.start[y],n=ty.cnt[y],o=ty.off[y];acc.fill(0);
      for(let i=0;i<n;i++){const r=rowH(s+i),wt=ty.w[o+i];for(let q=0;q<acc.length;q++)acc[q]+=r[q]*wt;}
      for(const key of cache.keys()){if(key<s)cache.delete(key);else break;}
      const jb=y*nw*4;
      for(let x=0;x<nw;x++){
        const q=x*4;let A=acc[q+3];if(A<0)A=0;if(A>1)A=1;
        if(A<=0.0005){out[jb+q]=out[jb+q+1]=out[jb+q+2]=out[jb+q+3]=0;continue;}
        const inv=1/Math.max(A,1e-6);
        out[jb+q]=acc[q]*inv;out[jb+q+1]=acc[q+1]*inv;out[jb+q+2]=acc[q+2]*inv;out[jb+q+3]=A*255;
      }
      if(onRow&&(y&63)===0)if(onRow(y/nh)===false)return null;
    }
    return out;
  }
  return {resample,taps};
}
const RSE=rsEngineFactory();
const RS_KINDS={lanczos:'lanczos',bicubic:'bicubic',bilinear:'bilinear',nearest:'nearest'};
/* 'auto' = Lanczos when making smaller, bicubic when making larger */
const rsPick=(mode,w,h,nw,nh)=>mode==='auto'?((nw*nh<w*h)?'lanczos':'bicubic'):mode;
let RS_WORKER=null;
function rsWorkerGet(){
  if(RS_WORKER)return RS_WORKER;
  try{
    const src='const RSE=('+rsEngineFactory.toString()+')();onmessage=e=>{const m=e.data;try{const o=RSE.resample(m.data,m.w,m.h,m.nw,m.nh,m.kind,null);postMessage({id:m.id,out:o},o?[o.buffer]:[]);}catch(err){postMessage({id:m.id,err:String(err)});}};';
    RS_WORKER=new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));
  }catch(e){RS_WORKER=null;}
  return RS_WORKER;
}
let rsJobId=0;const rsJobs=new Map();
function rsCancelAll(){if(RS_WORKER){RS_WORKER.terminate();RS_WORKER=null;}rsJobs.forEach(j=>j.res(null));rsJobs.clear();}
/* async, off the main thread; resolves to a canvas (or null when cancelled) */
function resampleAsync(c,nw,nh,mode){
  nw=Math.max(1,Math.round(nw));nh=Math.max(1,Math.round(nh));
  const kind=RS_KINDS[rsPick(mode||'auto',c.width,c.height,nw,nh)];
  if(!kind)return Promise.resolve(resampleCanvas(c,nw,nh,mode));
  if(c.width===nw&&c.height===nh)return Promise.resolve(c);
  const id=cctx(c).getImageData(0,0,c.width,c.height),w=rsWorkerGet();
  const done=data=>{if(!data)return null;const o=mkCanvas(nw,nh);cctx(o).putImageData(new ImageData(data,nw,nh),0,0);return o;};
  if(!w)return new Promise(r=>setTimeout(()=>r(done(RSE.resample(id.data,c.width,c.height,nw,nh,kind,null))),0));
  return new Promise((res,rej)=>{
    const jid=++rsJobId;rsJobs.set(jid,{res,rej});
    const h=e=>{const m=e.data;if(m.id!==jid)return;w.removeEventListener('message',h);rsJobs.delete(jid);if(m.err)rej(new Error(m.err));else res(done(m.out));};
    w.addEventListener('message',h);
    w.postMessage({id:jid,data:id.data,w:c.width,h:c.height,nw,nh,kind},[id.data.buffer]);
  });
}
/* the old synchronous entry point learns the new methods; results made ahead of time in the worker are used first */
const RS_PRE=new WeakMap();
{
  const _rc=resampleCanvas;
  resampleCanvas=function(c,nw,nh,mode){
    nw=Math.max(1,Math.round(nw));nh=Math.max(1,Math.round(nh));
    const pre=RS_PRE.get(c);if(pre&&pre.w===nw&&pre.h===nh&&pre.mode===mode)return pre.res;
    const kind=RS_KINDS[rsPick(mode,c.width,c.height,nw,nh)];
    if(kind){
      if(c.width===nw&&c.height===nh)return c;
      const id=cctx(c).getImageData(0,0,c.width,c.height),d=RSE.resample(id.data,c.width,c.height,nw,nh,kind,null),o=mkCanvas(nw,nh);
      cctx(o).putImageData(new ImageData(d,nw,nh),0,0);return o;
    }
    return _rc(c,nw,nh,mode);
  };
}
if(!S.resampleMode||S.resampleMode==='smooth')S.resampleMode='auto';

/* ---------- device limits ---------- */
function canAlloc(w,h){
  try{const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');if(!x||c.width!==w||c.height!==h)return false;
    x.fillStyle='#fff';x.fillRect(w-1,h-1,1,1);const ok=x.getImageData(w-1,h-1,1,1).data[3]===255;c.width=c.height=1;return ok;}catch(e){return false;}
}
const memBudget=()=>{const g=Math.min(8,navigator.deviceMemory||4);return g*1e9*0.45;};
/* returns '' when fine, otherwise a plain-language reason */
function docSizeProblem(w,h,layers,what){
  layers=layers||2;what=what||'design';
  if(!(w>=1&&h>=1))return 'Choose a width and height of at least 1 pixel.';
  if(w>32000||h>32000)return 'That is more than 32000 pixels on one side, which is beyond what any browser canvas can hold.';
  const bytes=w*h*4*(layers+2);
  if(bytes>memBudget())return 'A '+w+' x '+h+' '+what+' needs about '+Math.round(bytes/1e6)+' MB of memory for '+layers+' layer'+(layers>1?'s':'')+', but this device only has about '+Math.round(memBudget()/1e6)+' MB to spare. Try a smaller size.';
  if(!canAlloc(w,h))return 'This device cannot create a '+w+' x '+h+' picture (its canvas limit is lower). Try a smaller size, for example half the width and height.';
  return '';
}

/* ---------- history keeps within the device memory budget ---------- */
function histBytes(){
  const seen=new Set();let n=0;
  for(const s of hist){for(const q of s.layers){for(const c of [q.canvas,q.mask]){if(c&&!seen.has(c)){seen.add(c);n+=c.width*c.height*4;}}}}
  return n;
}
{
  const _cm=commit;
  commit=function(label){
    _cm(label);
    if(!doc||hist.length<4)return;
    const budget=memBudget()*0.6;let b=histBytes(),cut=0;
    while(hist.length>3&&b>budget&&hi>1){hist.shift();hi--;cut++;b=histBytes();}
    if(cut){FTH_PH=hi;updateUndo();if(S.tab==='history')renderHistory();if(!doc._histNote){doc._histNote=true;toast('This design is large, so undo keeps the last '+hist.length+' steps to save memory.');}}
  };
}

/* ---------- zoom ---------- */
const ZOOM_STEPS=[0.25,0.5,1,2,4,8];
ACT.zoomTo=pct=>{if(!doc||!(pct>0))return;const r=vp.getBoundingClientRect();zoomAt(pct/100,r.width/2,r.height/2);};
ACT.zactual=()=>{if(!doc)return;const r=vp.getBoundingClientRect(),z=1/(window.devicePixelRatio||1);zoomAt(z,r.width/2,r.height/2);toast('Actual pixels: '+(Math.round(z*100))+'% (one image pixel per screen pixel)');};
ACT.zfitcanvas=()=>{if(!doc)return;const r=vp.getBoundingClientRect(),z=clamp((r.width-44)/doc.w,0.02,32);S.zoom=z;S.px=(r.width-doc.w*z)/2;S.py=Math.max(22,(r.height-doc.h*z)/2);S.autoFit=false;applyView();};
ACT.zcustom=()=>{if(!doc)return;askNumber('Zoom','Zoom percent',Math.round(S.zoom*100),2,3200,v=>ACT.zoomTo(v));};
(()=>{
  const M=MENUS.find(m=>m.label==='View');if(!M)return;
  const i=M.items.findIndex(x=>x.label==='100%');
  const z=p=>mi(p+'%','','zoomTo',{fn:()=>ACT.zoomTo(p),check:()=>!!doc&&Math.abs(S.zoom*100-p)<0.5});
  const sm=sub('Zoom to',[z(25),z(50),z(100),z(200),z(400),z(800),SEP,mi('Fit to Screen (whole design)','Ctrl+0','zfit'),mi('Fit to Canvas (fill the width)','','zfitcanvas'),mi('Actual Pixels (1 image pixel = 1 screen pixel)','Ctrl+Alt+0','zactual'),mi('Custom...','','zcustom')],{dis:()=>!doc});
  M.items.splice(i+1,0,sm);
})();
/* the zoom box accepts any percentage */
{const zi=document.getElementById('zoomin');if(zi&&!zi._zz){zi._zz=1;zi.addEventListener('change',()=>{const v=parseFloat(String(zi.value).replace('%',''));if(v>0&&doc)ACT.zoomTo(clamp(v,2,3200));});}}

/* ---------- display quality: the picture is never resized, only shown ---------- */
const VLO=document.createElement('canvas');VLO.id='vlo';VLO.style.cssText='position:absolute;left:0;top:0;pointer-events:none;display:none';
view.after(VLO);
const VQ={t:0,shown:false,key:''};
function vloHide(){if(VQ.shown){VLO.style.display='none';view.style.visibility='';VQ.shown=false;}}
function vloBuild(){
  if(!doc||S.zoom>=0.72||document.hidden)return;
  const dpr=window.devicePixelRatio||1,tw=Math.max(1,Math.round(doc.w*S.zoom*dpr)),th=Math.max(1,Math.round(doc.h*S.zoom*dpr));
  if(tw>=view.width)return;
  /* halve in steps with the browser's high quality filter so no detail is skipped (a single big jump aliases) */
  let cur=view;
  while(cur.width/2>tw*1.01&&cur.height/2>th*1.01){const n=mkCanvas(Math.round(cur.width/2),Math.round(cur.height/2)),x=cctx(n);x.imageSmoothingQuality='high';x.drawImage(cur,0,0,n.width,n.height);cur=n;}
  VLO.width=tw;VLO.height=th;const x=VLO.getContext('2d');x.clearRect(0,0,tw,th);x.imageSmoothingQuality='high';x.drawImage(cur,0,0,tw,th);
  VLO.style.width=doc.w+'px';VLO.style.height=doc.h+'px';VLO.style.display='block';view.style.visibility='hidden';VQ.shown=true;
}
function vqSchedule(){clearTimeout(VQ.t);if(!doc||S.zoom>=0.72)return;VQ.t=setTimeout(()=>{try{vloBuild();}catch(e){}},140);}
{
  const _r=render;
  render=function(){vloHide();_r();vqSchedule();};
  const _av=applyView;
  applyView=function(){
    _av();
    const px=doc&&S.zoom>=3;
    view.style.imageRendering=over.style.imageRendering=px?'pixelated':'';
    if(doc&&S.zoom>=0.72)vloHide();else vqSchedule();
  };
}
