/* ===== Filter Gallery, Liquify, Vanishing Point (perspective plane), 3D extrude, Filter menu ===== */
defFx('gallery','_hid','Filter Gallery',[],(img,p,c)=>{let cur=img;for(const e of (p.stack||[])){const d=FX[e.id];if(d&&!e.off)cur=d.fn(cur,e.p,c);}return cur;});
const GAL_CATS=[['artistic','Artistic'],['brush','Brush Strokes'],['distort','Distort'],['sketch','Sketch'],['stylize','Stylize'],['texture','Texture'],['blur','Blur'],['pixelate','Pixelate'],['sharpen','Sharpen'],['noise','Noise'],['render','Render']];
function galDefaults(id){const p={};FX[id].params.forEach(q=>p[q.k]=q.def);return p;}
ACT.filterGallery=function(){
  if(!doc){toast('Create or open a design first');return;}flush();const l=active();if(!l){toast('Select a layer first');return;}
  if(l.type==='adjust'){toast('Select a photo layer');return;}
  const base=flatLayer(l),k=Math.min(1,520/Math.max(base.width,base.height)),sm=mkCanvas(Math.round(base.width*k),Math.round(base.height*k));cctx(sm).drawImage(base,0,0,sm.width,sm.height);
  const small=cctx(sm).getImageData(0,0,sm.width,sm.height);let stack=[],sel=-1,zoom=1,raf=0;
  const cats=GAL_CATS.map(([g,n])=>{const ids=Object.keys(FX).filter(i=>FX[i].group===g&&!FX[i].custom&&FX[i].params!==undefined);return ids.length?'<details class="gcat"'+(g==='artistic'?' open':'')+'><summary>'+n+'</summary><div class="gthumbs">'+ids.map(i=>'<button class="gth" data-id="'+i+'" title="'+esc(FX[i].name)+'"><canvas width="56" height="42" data-th="'+i+'"></canvas><span>'+esc(FX[i].name)+'</span></button>').join('')+'</div></details>':'';}).join('');
  modalOpen('Filter Gallery','<div class="gal"><div class="gal-prev"><canvas id="gal-c"></canvas><div class="gal-z"><button id="gal-zm">−</button><span id="gal-zl">100%</span><button id="gal-zp">+</button></div></div><div class="gal-side"><div class="gal-cats">'+cats+'</div><div class="gal-set"><b id="gal-nm">Pick an effect</b><div id="gal-ps"></div><div class="gal-stack-h">Effect layers <small>(applied bottom to top)</small></div><div id="gal-stack"></div><div class="row"><button id="gal-dup">New effect layer</button><button id="gal-del">Delete</button></div></div></div></div>',
   [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{if(!stack.length){toast('Add at least one effect');return false;}
     const s=JSON.parse(JSON.stringify(stack));if(!sessBegin('filter',FX.gallery.fn,{stack:s},'Filter Gallery'))return;sess.fxid='gallery';sess.dirty=true;sessFinish();lastFx={id:'gallery',p:{stack:s}};}}],
   body=>{
    const cv=body.querySelector('#gal-c'),cx=cv.getContext('2d');cv.width=small.width;cv.height=small.height;
    const draw=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{let img=new ImageData(new Uint8ClampedArray(small.data),small.width,small.height);
      try{for(const e of stack){if(e.off)continue;img=FX[e.id].fn(img,e.p,{scale:k});}}catch(err){console.error(err);}cx.putImageData(img,0,0);});};
    const renderSet=()=>{const e=stack[sel],ps=body.querySelector('#gal-ps');if(!e){body.querySelector('#gal-nm').textContent='Pick an effect';ps.innerHTML='';}else{const d=FX[e.id];body.querySelector('#gal-nm').textContent=d.name;
      ps.innerHTML=d.params.map(q=>'<label class="sl"><span title="'+esc(q.label)+'">'+esc(q.label)+'</span><input type="range" data-k="'+q.k+'" min="'+q.min+'" max="'+q.max+'" step="'+q.step+'" value="'+e.p[q.k]+'"><input type="number" class="nv" data-k="'+q.k+'" min="'+q.min+'" max="'+q.max+'" step="'+q.step+'" value="'+e.p[q.k]+'"></label>').join('')||'<p class="muted">No settings</p>';}
      body.querySelector('#gal-stack').innerHTML=stack.map((e,i)=>'<div class="gst'+(i===sel?' on':'')+'" data-i="'+i+'"><input type="checkbox" data-eye="'+i+'" '+(e.off?'':'checked')+' title="Show/hide"><span>'+esc(FX[e.id].name)+'</span><button data-up="'+i+'" title="Move up">↑</button></div>').join('');};
    body.addEventListener('input',ev=>{const t=ev.target,e=stack[sel];if(!e||!t.dataset.k)return;const v=+t.value;e.p[t.dataset.k]=v;body.querySelectorAll('[data-k="'+t.dataset.k+'"]').forEach(o=>{if(o!==t)o.value=v;});draw();});
    body.addEventListener('click',ev=>{const t=ev.target.closest('button,input,.gst');if(!t)return;
      if(t.classList.contains('gth')){const id=t.dataset.id;if(sel>=0&&stack[sel]&&body.dataset.fresh==='1'){stack[sel]={id,p:galDefaults(id)};}else{stack.push({id,p:galDefaults(id)});sel=stack.length-1;}body.dataset.fresh='1';renderSet();draw();return;}
      if(t.dataset.eye!==undefined){stack[+t.dataset.eye].off=!t.checked;draw();return;}
      if(t.dataset.up!==undefined){const i=+t.dataset.up;if(i<stack.length-1){[stack[i],stack[i+1]]=[stack[i+1],stack[i]];sel=i+1;renderSet();draw();}return;}
      if(t.classList.contains('gst')){sel=+t.dataset.i;body.dataset.fresh='1';renderSet();return;}
      if(t.id==='gal-dup'){body.dataset.fresh='0';if(sel>=0)stack.push({id:stack[sel].id,p:JSON.parse(JSON.stringify(stack[sel].p))});sel=stack.length-1;renderSet();draw();return;}
      if(t.id==='gal-del'){if(sel>=0){stack.splice(sel,1);sel=stack.length-1;renderSet();draw();}return;}
      if(t.id==='gal-zm'||t.id==='gal-zp'){zoom=clamp(zoom*(t.id==='gal-zp'?1.25:0.8),0.25,4);cv.style.width=small.width*zoom+'px';body.querySelector('#gal-zl').textContent=Math.round(zoom*100)+'%';}
    });
    // lazily-drawn thumbnails
    const th=cctx(mkCanvas(56,42));const tsm=mkCanvas(56,42);cctx(tsm).drawImage(sm,0,0,56,42);const tid=cctx(tsm).getImageData(0,0,56,42);
    body.querySelectorAll('canvas[data-th]').forEach((c,i)=>setTimeout(()=>{try{const o=FX[c.dataset.th].fn(new ImageData(new Uint8ClampedArray(tid.data),56,42),galDefaults(c.dataset.th),{scale:0.1});c.getContext('2d').putImageData(o,0,0);}catch(e){}},30*i));
    draw();
   },{wide:true});
};
/* ===== Liquify ===== */
ACT.liquify=function(){
  if(!doc){toast('Create or open a design first');return;}flush();const l=active();if(!l){toast('Select a layer first');return;}
  if(l.type==='adjust'){toast('Select a photo layer');return;}
  const base=flatLayer(l),W=base.width,H=base.height,k=Math.min(1,640/Math.max(W,H)),w=Math.round(W*k),h=Math.round(H*k);
  const sc0=mkCanvas(w,h);cctx(sc0).drawImage(base,0,0,w,h);const src=cctx(sc0).getImageData(0,0,w,h);
  const fx=new Float32Array(w*h),fy=new Float32Array(w*h);let tool='fwd',size=90,press=50,rate=50,dens=50,showMesh=false,undo=[];
  const render=(cx)=>{const o=new Uint8ClampedArray(src.data.length),s=src.data;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k0=y*w+x;let sx=x+fx[k0],sy=y+fy[k0];sx=sx<0?0:sx>w-1.001?w-1.001:sx;sy=sy<0?0:sy>h-1.001?h-1.001:sy;const x0=sx|0,y0=sy|0,tx=sx-x0,ty=sy-y0,i=(y0*w+x0)*4,o4=k0*4;
      for(let q=0;q<4;q++)o[o4+q]=(s[i+q]*(1-tx)+s[i+4+q]*tx)*(1-ty)+(s[i+w*4+q]*(1-tx)+s[i+w*4+4+q]*tx)*ty;}
    cx.putImageData(new ImageData(o,w,h),0,0);};
  const brush=(x,y,dx,dy)=>{const R=size*k/2*1.0,R2=R*R,x1=Math.max(0,Math.floor(x-R)),x2=Math.min(w-1,Math.ceil(x+R)),y1=Math.max(0,Math.floor(y-R)),y2=Math.min(h-1,Math.ceil(y+R)),pr=press/100,rt=rate/100;
    for(let yy=y1;yy<=y2;yy++)for(let xx=x1;xx<=x2;xx++){const ddx=xx-x,ddy=yy-y,d2=ddx*ddx+ddy*ddy;if(d2>R2)continue;const fall=1-Math.sqrt(d2)/R,f=fall*fall*(3-2*fall)*pr,i=yy*w+xx;
      if(tool==='fwd'){fx[i]-=dx*f;fy[i]-=dy*f;}
      else if(tool==='rec'){fx[i]*=1-f*0.35*(rt+0.3);fy[i]*=1-f*0.35*(rt+0.3);}
      else if(tool==='cw'||tool==='ccw'){const a=(tool==='cw'?1:-1)*f*0.12*(rt+0.3),cs=Math.cos(a),sn=Math.sin(a),nx=ddx*cs-ddy*sn,ny=ddx*sn+ddy*cs;fx[i]+=(nx-ddx);fy[i]+=(ny-ddy);}
      else if(tool==='pucker'){fx[i]+=ddx*f*0.08*(rt+0.3);fy[i]+=ddy*f*0.08*(rt+0.3);}
      else if(tool==='bloat'){fx[i]-=ddx*f*0.08*(rt+0.3);fy[i]-=ddy*f*0.08*(rt+0.3);}
      else if(tool==='left'){fx[i]-=-dy*f*0.5*0+(-dy)*f*0.9;fy[i]-=dx*f*0.9*0;fy[i]+=0;}
    }};
  const tools=[['fwd','Forward Warp (W)'],['rec','Reconstruct (R)'],['cw','Twirl Clockwise (C)'],['ccw','Twirl Counter-clockwise'],['pucker','Pucker (S)'],['bloat','Bloat (B)']];
  modalOpen('Liquify','<div class="liq"><div class="liq-tools">'+tools.map(([t,n])=>'<button data-lt="'+t+'" class="'+(t===tool?'on':'')+'" title="'+n+'">'+n.split(' (')[0]+'</button>').join('')+'<hr><label class="sl"><span>Brush size</span><input type="range" id="lq-s" min="10" max="500" value="90"></label><label class="sl"><span>Pressure</span><input type="range" id="lq-p" min="1" max="100" value="50"></label><label class="sl"><span>Rate</span><input type="range" id="lq-r" min="1" max="100" value="50"></label><button id="lq-u">Undo stroke</button><button id="lq-all">Reconstruct all</button><label class="opt"><input type="checkbox" id="lq-prev" checked> Preview</label></div><div class="liq-c"><canvas id="lq-c"></canvas></div></div>',
   [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const t=paintTarget('Liquify');if(!t)return;
      // upscale displacement field to document size
      const fc=mkCanvas(W,H),o=new Uint8ClampedArray(W*H*4),s=base.getContext('2d').getImageData(0,0,W,H).data;
      for(let y=0;y<H;y++)for(let x=0;x<W;x++){const gx=Math.min(w-1.001,x*k),gy=Math.min(h-1.001,y*k),x0=gx|0,y0=gy|0,tx=gx-x0,ty=gy-y0,a=y0*w+x0,bi=(v)=>(v[a]*(1-tx)+v[a+1]*tx)*(1-ty)+(v[a+w]*(1-tx)+v[a+w+1]*tx)*ty;
        let sx=x+bi(fx)/k,sy=y+bi(fy)/k;sx=clamp(sx,0,W-1.001);sy=clamp(sy,0,H-1.001);const xx=sx|0,yy=sy|0,u=sx-xx,v=sy-yy,i=(yy*W+xx)*4,q4=(y*W+x)*4;for(let q=0;q<4;q++)o[q4+q]=(s[i+q]*(1-u)+s[i+4+q]*u)*(1-v)+(s[i+W*4+q]*(1-u)+s[i+W*4+4+q]*u)*v;}
      cctx(fc).putImageData(new ImageData(o,W,H),0,0);
      if(t===l&&l.type!=='text'&&l.type!=='shape'){const x=cctx(l.canvas);}
      paintDoc(t,fc,{op:1,blend:'source-over'});commit('Liquify');refreshLayers();redraw();toast('Liquify applied');}}],
   body=>{
    const cv=body.querySelector('#lq-c'),cx=cv.getContext('2d');cv.width=w;cv.height=h;render(cx);
    body.querySelectorAll('[data-lt]').forEach(b=>b.onclick=()=>{tool=b.dataset.lt;body.querySelectorAll('[data-lt]').forEach(o=>o.classList.toggle('on',o===b));});
    body.querySelector('#lq-s').oninput=e=>size=+e.target.value;body.querySelector('#lq-p').oninput=e=>press=+e.target.value;body.querySelector('#lq-r').oninput=e=>rate=+e.target.value;
    body.querySelector('#lq-u').onclick=()=>{const u=undo.pop();if(u){fx.set(u[0]);fy.set(u[1]);render(cx);}};
    body.querySelector('#lq-all').onclick=()=>{undo.push([fx.slice(),fy.slice()]);fx.fill(0);fy.fill(0);render(cx);};
    body.querySelector('#lq-prev').onchange=e=>{if(e.target.checked)render(cx);else cx.putImageData(src,0,0);};
    let drag=null,raf=0;const pos=e=>{const r=cv.getBoundingClientRect();return [(e.clientX-r.left)*w/r.width,(e.clientY-r.top)*h/r.height];};
    cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);undo.push([fx.slice(),fy.slice()]);if(undo.length>20)undo.shift();drag=pos(e);if(tool!=='fwd'){brush(drag[0],drag[1],0,0);render(cx);}});
    cv.addEventListener('pointermove',e=>{if(!drag)return;const p=pos(e),dx=p[0]-drag[0],dy=p[1]-drag[1];
      if(tool==='fwd'){const st=Math.max(1,Math.ceil(Math.hypot(dx,dy)/(size*k/6)));for(let i=1;i<=st;i++)brush(drag[0]+dx*i/st,drag[1]+dy*i/st,dx/st,dy/st);drag=p;}
      else{brush(p[0],p[1],0,0);drag=p;}
      cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>render(cx));});
    cv.addEventListener('pointerup',()=>{drag=null;});
   },{wide:true});
};
/* ===== Vanishing Point: honest basic version = perspective plane flatten/tilt ===== */
defFx('vanish','distort','Perspective Plane',[P('tl','Top edge squeeze %',-60,60,0),P('bl','Bottom edge squeeze %',-60,60,0),P('lt','Left edge squeeze %',-60,60,0),P('rt','Right edge squeeze %',-60,60,0)],(img,p)=>{
  const w=img.width,h=img.height;
  return warp(img,(x,y,o)=>{const u=x/w,v=y/h,sx=(p.tl*(1-v)+p.bl*v)/100,sy=(p.lt*(1-u)+p.rt*u)/100;const kx=1-sx,ky=1-sy;o[0]=w/2+(x-w/2)/Math.max(0.2,kx);o[1]=h/2+(y-h/2)/Math.max(0.2,ky);});
});
ACT.vanishingPoint=function(){openFx('vanish');toast('Vanishing Point (basic): tilts the picture on a perspective plane. The full Photoshop clone-in-perspective is not included.');};
/* ===== 3D (2.5D extrude, honest) ===== */
ACT.extrude3d=function(){
  if(!doc){toast('Create or open a design first');return;}flush();const l=active();if(!l){toast('Select a layer first');return;}
  modalOpen('3D Extrude (2.5D)','<div class="saform"><label class="sl"><span>Depth</span><input type="range" id="e3-d" min="2" max="80" value="24"></label><label class="sl"><span>Angle</span><input type="range" id="e3-a" min="0" max="360" value="45"></label><label class="opt">Side shade <input type="color" id="e3-c" value="#333333"></label><p class="muted">Makes a solid-looking extrusion of the layer shape as a new layer below. It is a flat 2.5D effect, not a real 3D model.</p></div>',
   [{label:'Cancel'},{label:'Extrude',primary:true,cb:()=>{const D=+$('#e3-d').value,A=+$('#e3-a').value*Math.PI/180,col=hexRGB($('#e3-c').value),fl=flatLayer(l),w=fl.width,h=fl.height,ex=mkCanvas(w,h),x=cctx(ex);
     const dx=Math.cos(A),dy=-Math.sin(A);const tint=mkCanvas(w,h),tx=cctx(tint);
     for(let i=D;i>=1;i--){tx.globalCompositeOperation='source-over';tx.clearRect(0,0,w,h);tx.drawImage(fl,0,0);tx.globalCompositeOperation='source-in';tx.fillStyle='rgb('+Math.round(col[0]*(0.6+0.4*(1-i/D)))+','+Math.round(col[1]*(0.6+0.4*(1-i/D)))+','+Math.round(col[2]*(0.6+0.4*(1-i/D)))+')';tx.fillRect(0,0,w,h);x.drawImage(tint,dx*i,dy*i);}
     x.drawImage(fl,0,0);const nl=addLayer({name:'3D Extrude',above:true});paintDoc(nl,ex,{op:1,blend:'source-over'});commit('3D Extrude');refreshLayers();redraw();}}]);
};
/* ===== New Filter menu ===== */
{
  const F=MENUS.find(m=>m.label==='Filter');
  const G=g=>sub(FX_GROUPS[g]||g,fxGroup(g),'');
  const grpItems=(g)=>Object.keys(FX).filter(i=>FX[i].group===g).map(i=>fxi(i,i));
  const bl=['average','blur','blurmore','box','gaussian','lensblur','motion','radial','shapeblur','smartblur','surfaceblur'];
  void bl;
  F.items=[
    mi('Last Filter','Ctrl+F','lastFilter'),SEP,
    mi('Convert for Smart Filters','','toSmart'),
    mi('Filter Gallery...','','filterGallery'),
    mi('Adaptive Wide Angle...','Alt+Shift+Ctrl+A','wideAngle'),
    mi('Camera Raw Filter...','Ctrl+Shift+A','cameraRaw'),
    mi('Lens Correction...','Shift+Ctrl+R','lensCorr'),
    mi('Liquify...','Shift+Ctrl+X','liquify'),
    mi('Vanishing Point...','Alt+Ctrl+V','vanishingPoint'),SEP,
    mi('3D','','extrude3d'),SEP,
    sub('Blur',fxGroup('blur'),''),sub('Blur Gallery',fxGroup('blurgal'),''),sub('Distort',fxGroup('distort'),''),sub('Noise',fxGroup('noise'),''),sub('Pixelate',fxGroup('pixelate'),''),sub('Render',fxGroup('render'),''),sub('Sharpen',fxGroup('sharpen'),''),sub('Stylize',fxGroup('stylize'),''),SEP,
    sub('Artistic',fxGroup('artistic'),''),sub('Brush Strokes',fxGroup('brush'),''),sub('Sketch',fxGroup('sketch'),''),sub('Texture',fxGroup('texture'),''),SEP,
    sub('Other',fxGroup('other'),''),mi('Retouch Studio...','','retouch'),sub('Retouch',fxGroup('retouch'),'')
  ];
  ACT.wideAngle=()=>openFx('wideangle');ACT.lensCorr=()=>openFx('lenscorr');
}
