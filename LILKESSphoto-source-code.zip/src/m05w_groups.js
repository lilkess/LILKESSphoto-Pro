/* ===== Layer groups, multi-select and drag-to-reorder ===== */
function moveMove(p){
  const d=drag,l=d.l,dx=p.x-d.p0.x,dy=p.y-d.p0.y;
  if(!d.moved&&Math.hypot(dx,dy)*S.zoom<3)return;
  d.moved=true;
  if(d.mode==='move'){
    let nx=d.x0+dx,ny=d.y0+dy;
    if(S.snap){[nx,ny]=snapLayer(l,nx,ny);}
    l.x=nx;l.y=ny;
    if(l.group){
      if(!d.mates)d.mates=doc.layers.filter(m=>m!==l&&m.group===l.group&&!posLocked(m)).map(m=>({m,x:m.x,y:m.y}));
      d.mates.forEach(q=>{q.m.x=q.x+(nx-d.x0);q.m.y=q.y+(ny-d.y0);});
    }
  }else if(d.mode==='scale'){
    l.s=clamp(d.s0*Math.hypot(p.x-l.x,p.y-l.y)/d.d0,0.01,60);
  }else{
    let r=d.r0+Math.atan2(p.y-l.y,p.x-l.x)-d.a0;const sn=Math.PI/12,nr=Math.round(r/sn)*sn;
    if(Math.abs(nr-r)<0.05)r=nr;l.r=r;
  }
  redraw();
}
function grpNames(){if(!doc.extra)doc.extra={};if(!doc.extra.groups)doc.extra.groups={};if(!doc.extra.gcol)doc.extra.gcol={};return doc.extra;}
function grpSel(){const s=new Set(doc.msel||[]);if(doc.active)s.add(doc.active);return [...s].map(id=>doc.layers.find(l=>l.id===id)).filter(Boolean);}
ACT.group=function(){
  if(!doc)return;flush();const L=grpSel();
  if(L.length<2){toast('Ctrl-click (or Shift-click) two or more layers in the Layers list, then press Group');return;}
  const ex=grpNames(),gid=Math.max(0,...Object.keys(ex.groups).map(Number))+1;ex.groups[gid]='Group '+gid;
  L.forEach(l=>l.group=gid);
  // make the members sit together, at the position of the top-most one
  const idx=L.map(l=>doc.layers.indexOf(l)),top=Math.max(...idx),members=doc.layers.filter(l=>l.group===gid);
  const rest=doc.layers.filter(l=>l.group!==gid),pos=rest.filter(l=>doc.layers.indexOf(l)<top).length+1;
  rest.splice(Math.min(rest.length,pos-0),0,...members);doc.layers=rest;
  doc.msel=[];commit('Group layers');refreshLayers();renderProps();redraw();toast(L.length+' layers grouped. Moving one moves them all.');
};
ACT.ungroup=function(){
  if(!doc)return;flush();const a=active();if(!a||!a.group){toast('Select a layer that is in a group');return;}
  const g=a.group;doc.layers.forEach(l=>{if(l.group===g)l.group=0;});const ex=grpNames();delete ex.groups[g];delete ex.gcol[g];
  commit('Ungroup layers');refreshLayers();renderProps();redraw();
};
{
  const _rl=refreshLayers;
  refreshLayers=function(){
    _rl();
    const box=$('#layerlist');if(!box||!doc)return;
    const ex=grpNames(),rows=[...box.querySelectorAll('.lrow')],seen={};
    const ms=new Set(doc.msel||[]);
    rows.forEach(r=>{
      r.draggable=true;
      const l=doc.layers.find(x=>x.id===+r.dataset.id);if(!l)return;
      if(ms.has(l.id))r.classList.add('multi');
      if(l.group){
        r.classList.add('ingrp');r.style.setProperty('--gc','hsl('+((l.group*67)%360)+',60%,55%)');
        if(!seen[l.group]){seen[l.group]=true;
          const mem=doc.layers.filter(x=>x.group===l.group),col=!!ex.gcol[l.group],allVis=mem.some(x=>x.visible),allLock=mem.every(x=>x.locked);
          const h=document.createElement('div');h.className='lrow ghead';h.dataset.g=l.group;h.style.setProperty('--gc','hsl('+((l.group*67)%360)+',60%,55%)');
          h.innerHTML='<button class="eye" data-ga="col" title="Collapse or expand">'+(col?'&#9656;':'&#9662;')+'</button><button class="eye" data-ga="vis" title="Show or hide group">'+(allVis?EYE:EYEOFF)+'</button><span class="nm">&#128193; '+esc(ex.groups[l.group]||'Group')+' <small class="muted">('+mem.length+')</small></span><button class="eye" data-ga="lock" title="Lock or unlock group">'+(allLock?LOCK:UNLOCK)+'</button>';
          r.parentNode.insertBefore(h,r);
        }
        if(ex.gcol[l.group])r.style.display='none';
      }
    });
  };
  const box=$('#layerlist');
  box.addEventListener('click',e=>{
    const h=e.target.closest('.ghead');
    if(h){
      e.stopPropagation();const g=+h.dataset.g,a=e.target.closest('[data-ga]'),ex=grpNames(),mem=doc.layers.filter(l=>l.group===g);
      if(a&&a.dataset.ga==='col'){ex.gcol[g]=!ex.gcol[g];refreshLayers();return;}
      if(a&&a.dataset.ga==='vis'){flush();const v=!mem.some(l=>l.visible);mem.forEach(l=>l.visible=v);commit('Group visibility');redraw();return;}
      if(a&&a.dataset.ga==='lock'){flush();const v=!mem.every(l=>l.locked);mem.forEach(l=>l.locked=v);commit('Group lock');return;}
      doc.msel=mem.map(l=>l.id);selectLayer(mem[mem.length-1].id);return;
    }
    const row=e.target.closest('.lrow');if(!row||e.target.closest('button,input'))return;
    const id=+row.dataset.id;
    if(e.ctrlKey||e.metaKey||e.shiftKey){
      e.stopImmediatePropagation();
      const s=new Set(doc.msel||[]);
      if(e.shiftKey&&doc.active){const order=[...doc.layers].reverse().map(l=>l.id),a=order.indexOf(doc.active),b=order.indexOf(id);order.slice(Math.min(a,b),Math.max(a,b)+1).forEach(x=>s.add(x));}
      else if(s.has(id))s.delete(id);else s.add(id);
      doc.msel=[...s];refreshLayers();return;
    }
    doc.msel=[];
  },true);
  box.addEventListener('dblclick',e=>{
    const nm=e.target.closest('.ghead .nm');if(!nm)return;
    const g=+nm.closest('.ghead').dataset.g,ex=grpNames(),n=prompt('Group name',ex.groups[g]||'Group');
    if(n){ex.groups[g]=n;commit('Rename group');refreshLayers();}
  });
  /* drag to reorder */
  let dragId=null;
  box.addEventListener('dragstart',e=>{const r=e.target.closest('.lrow:not(.ghead)');if(!r)return;dragId=+r.dataset.id;e.dataTransfer.effectAllowed='move';try{e.dataTransfer.setData('text/plain',String(dragId));}catch(_){}});
  box.addEventListener('dragover',e=>{if(dragId==null)return;const r=e.target.closest('.lrow');if(!r)return;e.preventDefault();
    box.querySelectorAll('.dropt,.dropb').forEach(x=>x.classList.remove('dropt','dropb'));
    const rc=r.getBoundingClientRect();r.classList.add(e.clientY<rc.top+rc.height/2?'dropt':'dropb');});
  box.addEventListener('dragleave',e=>{if(!box.contains(e.relatedTarget))box.querySelectorAll('.dropt,.dropb').forEach(x=>x.classList.remove('dropt','dropb'));});
  box.addEventListener('drop',e=>{
    if(dragId==null)return;e.preventDefault();
    const r=e.target.closest('.lrow');box.querySelectorAll('.dropt,.dropb').forEach(x=>x.classList.remove('dropt','dropb'));
    const id=dragId;dragId=null;if(!r)return;
    const src=doc.layers.find(l=>l.id===id);if(!src)return;
    let tgt=r.classList.contains('ghead')?doc.layers.filter(l=>l.group===+r.dataset.g).slice(-1)[0]:doc.layers.find(l=>l.id===+r.dataset.id);
    if(!tgt||tgt===src)return;
    const rc=r.getBoundingClientRect(),above=e.clientY<rc.top+rc.height/2;
    flush();doc.layers.splice(doc.layers.indexOf(src),1);
    let ti=doc.layers.indexOf(tgt);
    // the list shows the top layer first, so "above" in the list means a higher index
    doc.layers.splice(above?ti+1:ti,0,src);
    src.group=tgt.group||0;
    commit('Reorder layers');refreshLayers();redraw();
  });
  box.addEventListener('dragend',()=>{dragId=null;box.querySelectorAll('.dropt,.dropb').forEach(x=>x.classList.remove('dropt','dropb'));});
  const bar=document.querySelector('.lbar');
  if(bar)bar.insertAdjacentHTML('afterbegin','<button data-act="group" title="Group selected layers (Ctrl-click layers to select several)">Group</button><button data-act="ungroup" title="Ungroup">Ungroup</button>');
  const L=MENUS.find(m=>m.label==='Layer');
  if(L)L.items.splice(1,0,mi('Group layers','Ctrl+G','group'),mi('Ungroup layers','Ctrl+Shift+G','ungroup'),SEP);
  document.addEventListener('keydown',e=>{if(!doc||(typeof CR!=='undefined'&&CR))return;const t=e.target;if(t&&/INPUT|TEXTAREA|SELECT/.test(t.tagName))return;
    if((e.ctrlKey||e.metaKey)&&!e.altKey&&(e.key==='g'||e.key==='G')){e.preventDefault();e.shiftKey?ACT.ungroup():ACT.group();}});
}
