/* ===== Editable gradient fills for shapes (and every template background) ===== */
function gsRgba(c,a){
  let r=0,g=0,b=0;c=String(c||'#000000');
  if(c[0]==='#'){if(c.length===4)c='#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];r=parseInt(c.slice(1,3),16);g=parseInt(c.slice(3,5),16);b=parseInt(c.slice(5,7),16);}
  else{const m=c.match(/[\d.]+/g);if(m){r=+m[0];g=+m[1];b=+m[2];}}
  return 'rgba('+r+','+g+','+b+','+(a==null?1:a)+')';
}
function gsDefault(c){return {kind:'linear',angle:180,cx:0.5,cy:0.5,r:0.7,stops:[{o:0,c:c||'#f2b134',a:1},{o:1,c:'#ffffff',a:1}]};}
function shapeGradient(ctx,g,w,h){
  let gr;
  if(g.kind==='radial'){const R=Math.max(1,(g.r==null?0.7:g.r)*Math.max(w,h));gr=ctx.createRadialGradient((g.cx==null?.5:g.cx)*w,(g.cy==null?.5:g.cy)*h,0,(g.cx==null?.5:g.cx)*w,(g.cy==null?.5:g.cy)*h,R);}
  else{const a=(g.angle||0)*Math.PI/180,dx=Math.sin(a),dy=-Math.cos(a),L=Math.abs(w*dx)+Math.abs(h*dy)||1,cx=w/2,cy=h/2;gr=ctx.createLinearGradient(cx-dx*L/2,cy-dy*L/2,cx+dx*L/2,cy+dy*L/2);}
  const st=[...g.stops].sort((x,y)=>x.o-y.o);
  st.forEach(s=>gr.addColorStop(Math.min(1,Math.max(0,s.o)),gsRgba(s.c,s.a)));
  return gr;
}
function renderShape(l){
  const p=l.props,pad=Math.ceil(p.sw/2)+3,w=Math.max(2,Math.round(p.w)),h=Math.max(2,Math.round(p.h));
  const c=l.canvas;c.width=w+pad*2;c.height=h+pad*2;
  const ctx=cctx(c);ctx.translate(pad,pad);ctx.beginPath();
  switch(p.kind){
    case 'round':rr(ctx,0,0,w,h,p.radius);break;
    case 'ellipse':ctx.ellipse(w/2,h/2,w/2,h/2,0,0,Math.PI*2);break;
    case 'triangle':ctx.moveTo(w/2,0);ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();break;
    case 'star':for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,k=i%2?0.42:1;const px=w/2+Math.cos(a)*k*w/2,py=h/2+Math.sin(a)*k*h/2;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();break;
    case 'line':ctx.moveTo(0,p.flip?h:0);ctx.lineTo(w,p.flip?0:h);break;
    case 'polygon':{const n=Math.max(3,p.sides|0||6);for(let i=0;i<n;i++){const a=-Math.PI/2+i*2*Math.PI/n,px=w/2+Math.cos(a)*w/2,py=h/2+Math.sin(a)*h/2;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();break;}
    case 'custom':case 'path':{const np=shapeNorm(p);if(np)vec_trace(ctx,np,[w,0,0,h,0,0]);break;}
    default:ctx.rect(0,0,w,h);
  }
  if(p.kind!=='line'&&!p.nofill&&(p.grad||p.fill)){ctx.fillStyle=p.grad?shapeGradient(ctx,p.grad,w,h):p.fill;ctx.fill('evenodd');}
  if(p.sw>0){ctx.strokeStyle=p.stroke;ctx.lineWidth=p.sw;ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();}
  l.mask=null;touch(l);
}
/* template backgrounds are now editable gradient shapes instead of locked pictures */
function tBgShape(name,fill,grad){
  const l=addLayer({name,type:'shape',w:10,h:10,x:doc.w/2,y:doc.h/2,locked:true,props:{kind:'rect',fill,stroke:'#000000',sw:0,radius:0,w:doc.w,h:doc.h,flip:false,nofill:false,grad:grad||null}});
  renderShape(l);return l;
}
function tGrad(c1,c2,deg){return tBgShape('Background gradient',c1,{kind:'linear',angle:deg,cx:.5,cy:.5,r:.7,stops:[{o:0,c:c1,a:1},{o:1,c:c2,a:1}]});}
function tSolid(c){return tBgShape('Background',c,null);}
function tRadial(c1,c2,cx,cy,r){return tBgShape('Background gradient',c1,{kind:'radial',angle:0,cx,cy,r,stops:[{o:0,c:c1,a:1},{o:1,c:c2,a:1}]});}
/* ---- Properties: gradient editor ---- */
function gsPanel(l){
  const p=l.props,g=p.grad,on=!!g;
  let h='<div class="h">Fill type</div><div class="row"><select id="gs-kind"><option value="solid"'+(!on?' selected':'')+'>Solid colour</option><option value="linear"'+(on&&g.kind==='linear'?' selected':'')+'>Linear gradient</option><option value="radial"'+(on&&g.kind==='radial'?' selected':'')+'>Radial gradient</option></select></div>';
  if(on){
    const sorted=[...g.stops].map((s,i)=>[s,i]).sort((a,b)=>a[0].o-b[0].o);
    h+='<div class="gbar" style="background:linear-gradient(90deg,'+sorted.map(a=>gsRgba(a[0].c,a[0].a)+' '+Math.round(a[0].o*100)+'%').join(',')+'),repeating-conic-gradient(#777 0 25%,#999 0 50%) 0 0/10px 10px"></div>';
    if(g.kind==='linear')h+='<label class="sl"><span>Angle</span><input type="range" data-gs="angle" min="0" max="360" step="1" value="'+Math.round(g.angle||0)+'"><output>'+Math.round(g.angle||0)+'</output></label>';
    else h+='<label class="sl"><span>Centre X</span><input type="range" data-gs="cx" min="0" max="100" value="'+Math.round((g.cx==null?.5:g.cx)*100)+'"><output>'+Math.round((g.cx==null?.5:g.cx)*100)+'</output></label><label class="sl"><span>Centre Y</span><input type="range" data-gs="cy" min="0" max="100" value="'+Math.round((g.cy==null?.5:g.cy)*100)+'"><output>'+Math.round((g.cy==null?.5:g.cy)*100)+'</output></label><label class="sl"><span>Radius</span><input type="range" data-gs="r" min="5" max="200" value="'+Math.round((g.r==null?.7:g.r)*100)+'"><output>'+Math.round((g.r==null?.7:g.r)*100)+'</output></label>';
    h+='<div class="h">Colour stops</div>';
    sorted.forEach(a=>{const s=a[0],i=a[1];h+='<div class="gsrow" data-i="'+i+'"><input type="color" data-gs="c" value="'+gsHex(s.c)+'" title="Stop colour"><input type="number" data-gs="o" min="0" max="100" value="'+Math.round(s.o*100)+'" title="Position %"><input type="range" data-gs="a" min="0" max="100" value="'+Math.round(s.a*100)+'" title="Opacity"><button data-gsdel="'+i+'" title="Remove stop"'+(g.stops.length<=2?' disabled':'')+'>&times;</button></div>';});
    h+='<div class="row"><button id="gs-add">Add stop</button><button id="gs-rev">Reverse</button></div>';
  }
  return h;
}
function gsHex(c){c=String(c||'#000');if(c[0]==='#'&&c.length===7)return c;if(c[0]==='#'&&c.length===4)return '#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];const m=c.match(/[\d.]+/g);if(!m)return '#000000';return '#'+[0,1,2].map(i=>Math.round(+m[i]).toString(16).padStart(2,'0')).join('');}
{
  const _rp4=renderProps;
  renderProps=function(){
    _rp4();
    const l=doc&&active();if(!l||l.type!=='shape'||!l.props||l.props.kind==='line')return;
    const box=$('#tab-props'),anchor=box.querySelector('#p-sfill');if(!anchor)return;
    const row=anchor.closest('.row');if(!row)return;
    if(l.props.grad)row.style.display='none';
    row.insertAdjacentHTML('afterend','<div id="gs-wrap">'+gsPanel(l)+'</div>');
  };
  const tp=$('#tab-props');
  const edit=(fn,commitNow)=>{const l=active();if(!l||l.type!=='shape')return;fn(l,l.props);renderShape(l);redraw();if(commitNow){commit('Gradient');renderProps();}else pend=true;};
  tp.addEventListener('change',e=>{if(e.target.id==='gs-kind'){
    const v=e.target.value;edit((l,p)=>{if(v==='solid'){p.grad=null;}else{if(!p.grad)p.grad=gsDefault(p.fill);p.grad.kind=v;if(v==='radial'&&p.grad.r==null)p.grad.r=.7;}p.nofill=false;},true);}
    else if(e.target.dataset&&e.target.dataset.gs&&e.target.type==='color'){/* committed by input */}});
  tp.addEventListener('input',e=>{
    const t=e.target,k=t.dataset&&t.dataset.gs;if(!k)return;
    const row=t.closest('.gsrow'),v=t.type==='color'?t.value:+t.value;
    if(t.type==='range'&&t.nextElementSibling&&t.nextElementSibling.tagName==='OUTPUT')t.nextElementSibling.textContent=t.value;
    edit((l,p)=>{const g=p.grad;if(!g)return;
      if(row){const s=g.stops[+row.dataset.i];if(!s)return;if(k==='c'){s.c=v;if(g.stops[0]===s)p.fill=v;}else if(k==='o')s.o=Math.max(0,Math.min(1,v/100));else if(k==='a')s.a=v/100;}
      else if(k==='angle')g.angle=v;else if(k==='cx'||k==='cy'||k==='r')g[k]=v/100;});
    const bar=tp.querySelector('.gbar');if(bar){const g=active().props.grad;bar.style.background='linear-gradient(90deg,'+[...g.stops].sort((a,b)=>a.o-b.o).map(s=>gsRgba(s.c,s.a)+' '+Math.round(s.o*100)+'%').join(',')+'),repeating-conic-gradient(#777 0 25%,#999 0 50%) 0 0/10px 10px';}
  });
  tp.addEventListener('click',e=>{
    const t=e.target.closest('button');if(!t)return;
    if(t.id==='gs-add')edit((l,p)=>{const g=p.grad;const s=[...g.stops].sort((a,b)=>a.o-b.o);let bi=0,bd=0;for(let i=0;i<s.length-1;i++)if(s[i+1].o-s[i].o>bd){bd=s[i+1].o-s[i].o;bi=i;}g.stops.push({o:(s[bi].o+s[bi+1].o)/2,c:s[bi].c,a:1});},true);
    else if(t.id==='gs-rev')edit((l,p)=>{p.grad.stops.forEach(s=>s.o=1-s.o);},true);
    else if(t.dataset.gsdel!=null)edit((l,p)=>{if(p.grad.stops.length>2)p.grad.stops.splice(+t.dataset.gsdel,1);},true);
  });
}
