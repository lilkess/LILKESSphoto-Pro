/* ===== Smart object: Edit contents in its own tab, save, and the layer refreshes ===== */
{
  const st=document.createElement('style');
  st.textContent='.th{position:relative}.soic{position:absolute;right:-1px;bottom:-1px;width:15px;height:15px;line-height:0;background:#1d1f24;border:1px solid #8a8fa0;border-radius:3px;padding:1px;cursor:pointer;z-index:2;color:#e8eaf0}.soic:hover{background:#3b6cff;border-color:#fff}.soic svg{width:11px;height:11px}.dtab.so .dn::before{content:"\\25A3 ";opacity:.8}';
  document.head.appendChild(st);
}
const SO_ICON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/></svg>';
function soSnapshot(d){
  return {w:d.w,h:d.h,nextId:d.nextId,active:d.active,layers:d.layers.map(l=>Object.assign(meta(l),{canvas:cloneCanvas(l.canvas),mask:l.mask?cloneCanvas(l.mask):null,ver:l.ver,mver:l.mver||0}))};
}
function soOpen(l){
  const parent=doc,lid=l.id;
  const ex=docs.findIndex(e=>e.doc.soLink&&e.doc.soLink.parent===parent&&e.doc.soLink.lid===lid);
  if(ex>=0){switchDoc(ex);toast('This smart object is already open in its own tab.');return;}
  const src=l.orig||l.canvas,so=l.so,w=so?so.w:src.width,h=so?so.h:src.height,nm=l.name;
  flush();
  startDoc(nm+' (smart object)',w,h,parent.ppi||parent.dpi||72);
  doc.soLink={parent,lid};doc.ppi=parent.ppi||parent.dpi||72;
  if(so){
    doc.layers=so.layers.map(q=>Object.assign(meta(q),{canvas:cloneCanvas(q.canvas),ver:0,mver:q.mver||0,mask:q.mask?cloneCanvas(q.mask):null,pvv:0}));
    doc.nextId=so.nextId;doc.active=so.active;
  }else{
    const n=addLayer({name:nm,w,h});cctx(n.canvas).drawImage(src,0,0);
  }
  finishDoc();doc.modified=false;renderTabs();
  toast('Editing the contents of "'+nm+'". Press Ctrl+S to send your changes back to the layer.');
}
ACT.smartEdit=D(()=>{
  const l=active();if(!l)return;
  if(doc.soLink&&doc.layers.length&&!l.smart){toast('Convert this layer to a smart object first (Layer > Smart object).');return;}
  if(!l.smart){toast('Convert this layer to a smart object first (Layer > Smart object).');return;}
  soOpen(l);
});
async function soApply(){
  const link=doc&&doc.soLink;if(!link)return false;
  flush();
  const child=doc,pi=docs.findIndex(e=>e.doc===link.parent);
  if(pi<0){toast('The design this came from is closed. Reopen it and edit the smart object again.');return false;}
  if(!child.layers.some(l=>l.visible)){toast('Nothing visible to send back. Show at least one layer.');return false;}
  const flat=flatCanvas(1),sod=soSnapshot(child);
  switchDoc(pi);
  const L=doc.layers.find(x=>x.id===link.lid);
  if(!L||!L.smart){const ci=docs.findIndex(e=>e.doc===child);if(ci>=0)switchDoc(ci);toast('That smart object layer is no longer in the design.');return false;}
  L.orig=flat;L.so=sod;smartRebuild(L);touch&&touch(L);
  commit('Update smart object contents');
  const ci=docs.findIndex(e=>e.doc===child);if(ci>=0)switchDoc(ci);
  child.modified=false;child.savedHi=hi;renderTabs();
  toast('Layer "'+L.name+'" updated from its smart object.');
  return true;
}
ACT.smartUpdate=async()=>{if(!doc||!doc.soLink){toast('Open a smart object with Edit contents first.');return;}await soApply();};
{
  const _ss=ACT.saveSmart;
  ACT.saveSmart=async function(){if(doc&&doc.soLink){await soApply();return;}return _ss.apply(this,arguments);};
  const _asb=askSaveBeforeClose;
  askSaveBeforeClose=function(i){
    const e=docs[i];
    if(!e||!e.doc.soLink)return _asb(i);
    modalOpen('Close smart object','<p>Send your changes to <b>'+esc(e.doc.name.replace(' (smart object)',''))+'</b> before closing?</p>',[
      {label:'Cancel'},
      {label:'Discard',cb:()=>{closeDoc(i,true);}},
      {label:'Update layer',primary:true,cb:async()=>{if(i!==cur)switchDoc(i);const ok=await soApply();if(ok)closeDoc(docs.findIndex(x=>x.doc===e.doc),true);}}
    ]);
  };
  const _rt=renderTabs;
  renderTabs=function(){_rt();$$('#tabs .dtab').forEach(t=>{const e=docs[+t.dataset.i];if(e&&e.doc.soLink)t.classList.add('so');});};
  const _rl=refreshLayers;
  refreshLayers=function(){
    _rl();if(!doc)return;
    $$('#layerlist .lrow').forEach(row=>{
      const l=doc.layers.find(x=>x.id===+row.dataset.id);if(!l||!l.smart)return;
      const th=row.querySelector('[data-a=pix]');if(!th||th.querySelector('.soic'))return;
      th.insertAdjacentHTML('beforeend','<span class="soic" data-soedit="1" role="button" aria-label="Edit smart object contents" title="Smart object. Click to edit its contents in a new tab.">'+SO_ICON+'</span>');
    });
  };
  const box=$('#layerlist');
  const hit=(e,sel)=>{const t=e.target.closest(sel);if(!t)return null;const row=t.closest('.lrow');return row?doc&&doc.layers.find(x=>x.id===+row.dataset.id):null;};
  box.addEventListener('click',e=>{const l=hit(e,'[data-soedit]');if(!l)return;e.stopPropagation();e.preventDefault();selectLayer(l.id);ACT.smartEdit();},true);
  box.addEventListener('dblclick',e=>{const l=hit(e,'[data-a=pix]');if(!l||!l.smart)return;e.stopPropagation();e.preventDefault();selectLayer(l.id);ACT.smartEdit();},true);
}
