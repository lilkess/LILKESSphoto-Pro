/* ===== Render, Stylize, Artistic, Brush strokes, Sketch, Texture, lens ===== */
defFx('clouds','render','Clouds',[P('s','Scale',10,400,120),P('d','Detail (octaves)',1,7,5),P('seed','Seed',1,999,7),P('c','Colour (0 fg/bg grey, 1 colour)',0,1,0)],(img,p,c)=>{
  const w=img.width,h=img.height,o=new Uint8ClampedArray(img.data.length),sc2=Math.max(4,sc(p.s,c)),fg=hexRGB(S.fg||'#000000'),bg=hexRGB(S.bg||'#ffffff');
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const v=clamp((fxFbm(x/sc2,y/sc2,p.seed,Math.round(p.d))-0.25)*2,0,1),i=(y*w+x)*4;for(let q=0;q<3;q++)o[i+q]=p.c>=0.5?fg[q]+(bg[q]-fg[q])*v:v*255;o[i+3]=255;}
  return mkImg(o,w,h);
});
defFx('difclouds','render','Difference Clouds',[P('s','Scale',10,400,120),P('seed','Seed',1,999,3)],(img,p,c)=>{
  const w=img.width,h=img.height,o=cp(img),sc2=Math.max(4,sc(p.s,c));
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const v=clamp((fxFbm(x/sc2,y/sc2,p.seed,5)-0.25)*2,0,1)*255,i=(y*w+x)*4;for(let q=0;q<3;q++)o[i+q]=Math.abs(o[i+q]-v);}
  return mkImg(o,w,h);
});
defFx('fibers','render','Fibers',[P('v','Variance',1,64,16),P('st','Strength',1,64,4),P('seed','Seed',1,999,5)],(img,p,c)=>{
  const w=img.width,h=img.height,o=new Uint8ClampedArray(img.data.length),fg=hexRGB(S.fg||'#000'),bg=hexRGB(S.bg||'#fff'),vs=Math.max(2,sc(p.v,c)*1.5),st=p.st;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(vs*8)+fxNoise(x/20,y/(vs*1.5),p.seed)*0.1,y/(vs*0.4),p.seed,3)*(1+st/20),v=clamp((n-0.3)*1.8,0,1),i=(y*w+x)*4;for(let q=0;q<3;q++)o[i+q]=fg[q]+(bg[q]-fg[q])*v;o[i+3]=255;}
  return mkImg(o,w,h);
});
defFx('lensflare','render','Lens Flare',[P('x','X %',0,100,30),P('y','Y %',0,100,30),P('b','Brightness %',10,300,100),P('ty','Lens (0 50-300mm, 1 35mm, 2 105mm, 3 movie prime)',0,3,0)],(img,p)=>{
  const w=img.width,h=img.height,o=cp(img),fx=w*p.x/100,fy=h*p.y/100,cx=w/2,cy=h/2,B=p.b/100,R=Math.min(w,h),ty=Math.round(p.ty);
  const add=(x0,y0,rad,col,a)=>{const x1=Math.max(0,Math.floor(x0-rad)),x2=Math.min(w-1,Math.ceil(x0+rad)),y1=Math.max(0,Math.floor(y0-rad)),y2=Math.min(h-1,Math.ceil(y0+rad));
    for(let y=y1;y<=y2;y++)for(let x=x1;x<=x2;x++){const d=Math.hypot(x-x0,y-y0)/rad;if(d>=1)continue;const k=(1-d)*(1-d)*a*B,i=(y*w+x)*4;for(let q=0;q<3;q++)o[i+q]=255-(255-o[i+q])*(255-col[q]*k)/255;}};
  const ring=(x0,y0,rad,col,a)=>{const x1=Math.max(0,Math.floor(x0-rad*1.2)),x2=Math.min(w-1,Math.ceil(x0+rad*1.2)),y1=Math.max(0,Math.floor(y0-rad*1.2)),y2=Math.min(h-1,Math.ceil(y0+rad*1.2));
    for(let y=y1;y<=y2;y++)for(let x=x1;x<=x2;x++){const d=Math.hypot(x-x0,y-y0)/rad,k=Math.max(0,1-Math.abs(d-1)*6)*a*B,i=(y*w+x)*4;if(k>0)for(let q=0;q<3;q++)o[i+q]=255-(255-o[i+q])*(255-col[q]*k)/255;}};
  add(fx,fy,R*0.45,[255,240,210],0.95);add(fx,fy,R*0.12,[255,255,255],1);
  const cols=[[255,160,90],[120,255,170],[110,150,255],[255,110,200],[255,230,120]],n=ty===1?4:ty===2?3:5;
  for(let i=0;i<n;i++){const t=0.35+i*0.4,x=fx+(cx-fx)*t*2*(ty===3?0.6:1),y=fy+(cy-fy)*t*2*(ty===3?0.6:1);add(x,y,R*(0.05+0.04*((i*7)%4)),cols[i%5],0.45);if(i%2===0)ring(x,y,R*0.1,cols[(i+1)%5],0.5);}
  if(ty===3){for(let x=0;x<w;x++){const k=Math.exp(-Math.abs(fy-h/2)/20),i=((Math.round(fy))*w+x)*4;if(i>=0&&i<o.length)for(let q=0;q<3;q++)o[i+q]=Math.min(255,o[i+q]+90*B*Math.exp(-Math.abs(x-fx)/(w*0.4)));}}
  return mkImg(o,w,h);
});
defFx('vignette','render','Vignette (Render)',[P('a','Amount',-100,100,-50),P('m','Midpoint',0,100,50),P('f','Feather',0,100,60),P('rd','Roundness',-100,100,0)],(img,p)=>{
  const w=img.width,h=img.height,o=cp(img),cx=w/2,cy=h/2,rd=p.rd/100,rx=w/2*(rd<0?1+rd*0.5:1),ry=h/2*(rd>0?1-rd*0.5:1),mid=p.m/100,fe=Math.max(0.02,p.f/100);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const e=Math.hypot((x-cx)/rx,(y-cy)/ry)/1.2,k=fxSS((e-mid*0.8)/fe),i=(y*w+x)*4,a=p.a/100;for(let q=0;q<3;q++)o[i+q]=a<0?o[i+q]*(1+a*k):o[i+q]+(255-o[i+q])*a*k;}
  return mkImg(o,w,h);
});
defFx('lighting','render','Lighting Effects',[P('x','Light X %',0,100,35),P('y','Light Y %',0,100,30),P('r','Radius %',5,150,70),P('i','Intensity',0,100,70),P('am','Ambient',0,100,25),P('sp','Texture relief',0,100,40)],(img,p)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),L=lumA(img),lx=w*p.x/100,ly=h*p.y/100,R=Math.max(w,h)*p.r/100,am=p.am/100,it=p.i/100,rl=p.sp/100*3;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=y*w+x,i=k*4,nx=((L[Math.min(w*h-1,k+1)]-L[Math.max(0,k-1)]))/255*rl,ny=((L[Math.min(w*h-1,k+w)]-L[Math.max(0,k-w)]))/255*rl,dx=lx-x,dy=ly-y,d=Math.hypot(dx,dy),fall=Math.max(0,1-d/R),dir=(dx*nx+dy*ny)/(d+1)*40,li=am+it*fall*fall*(1+dir);
    for(let q=0;q<3;q++)o[i+q]=clamp(s[i+q]*li,0,255);o[i+3]=s[i+3];}
  return mkImg(o,w,h);
});
defFx('treeprev','render','Frame (Border)',[P('t','Thickness',1,100,16),P('sh','Inner shadow',0,100,30)],(img,p,c)=>{
  const w=img.width,h=img.height,o=cp(img),t=Math.round(sc(p.t,c)),col=hexRGB(S.fg||'#fff'),sh=sc(p.sh,c);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const d=Math.min(x,y,w-1-x,h-1-y),i=(y*w+x)*4;if(d<t)for(let q=0;q<3;q++)o[i+q]=col[q];else if(d<t+sh){const k=1-(d-t)/sh;for(let q=0;q<3;q++)o[i+q]*=1-k*0.6;}}
  return mkImg(o,w,h);
});
/* ---- Stylize ---- */
defFx('solarize','stylize','Solarize',[P('t','Threshold',0,255,128)],(img,p)=>fxOut(img,(s,o)=>{for(let i=0;i<s.length;i+=4){for(let q=0;q<3;q++)o[i+q]=s[i+q]<p.t?s[i+q]:255-s[i+q];}}));
defFx('extrude','stylize','Extrude',[P('s','Size',2,60,12),P('d','Depth',1,255,40)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{const k=Math.max(2,Math.round(sc(p.s,c)));
  for(let y0=0;y0<h;y0+=k)for(let x0=0;x0<w;x0+=k){const ci=(Math.min(h-1,y0+(k>>1))*w+Math.min(w-1,x0+(k>>1)))*4;
    for(let y=y0;y<Math.min(h,y0+k);y++)for(let x=x0;x<Math.min(w,x0+k);x++){const i=(y*w+x)*4,e=(x-x0<2||y-y0<2)?1.15:(x0+k-x<=2||y0+k-y<=2)?0.75:1;for(let q=0;q<3;q++)o[i+q]=s[ci+q]*e;}}}));
defFx('wind','stylize','Wind',[P('l','Length',5,200,50),P('dir','Direction (0 right, 1 left)',0,1,0),P('st','Strength',10,100,70)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const len=sc(p.l,c),dir=p.dir>=0.5?-1:1,rnd=fxRnd(3),E=lumA(img);const e=fxSobel(E,w,h);
  for(let y=0;y<h;y++){let run=0;for(let xi=0;xi<w;xi++){const x=dir>0?xi:w-1-xi,k=y*w+x,i=k*4;if(e[k]>p.st*1.2&&rnd()<0.3)run=len*(0.4+rnd()*0.6);
    if(run>0){for(let q=0;q<3;q++){const j=(y*w+Math.max(0,Math.min(w-1,x-dir*Math.round(len*0.3))))*4;o[i+q]=Math.max(o[i+q],s[j+q]*0.9);}run-=1;}else for(let q=0;q<3;q++)o[i+q]=s[i+q];o[i+3]=s[i+3];}}
}));
defFx('tiles','stylize','Tiles',[P('n','Number of tiles',2,50,10),P('m','Max offset %',1,99,10)],(img,p)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),tw=w/p.n,th=h/Math.round(p.n*h/w),rnd=fxRnd(9),mx=p.m/100,off=new Map();
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const tx=Math.floor(x/tw),ty=Math.floor(y/th),key=tx+','+ty;if(!off.has(key))off.set(key,[(rnd()-0.5)*2*mx*tw,(rnd()-0.5)*2*mx*th]);const d=off.get(key),sx=clamp(Math.round(x+d[0]),0,w-1),sy=clamp(Math.round(y+d[1]),0,h-1),i=(y*w+x)*4,j=(sy*w+sx)*4;
    const edge=Math.min(x-tx*tw,y-ty*th)<1?0.6:1;for(let q=0;q<3;q++)o[i+q]=s[j+q]*edge;o[i+3]=s[j+3];}
  return mkImg(o,w,h);
});
defFx('glowedges','stylize','Glowing Edges',[P('w','Edge width',1,14,2),P('b','Edge brightness',0,20,8),P('sm','Smoothness',1,15,5)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const t=cp(img);fxGB(t,w,h,Math.max(0,sc(p.sm,c)*0.3));const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(t,k*4);
  const e=fxSobel(L,w,h),k0=p.b/6;for(let k=0,i=0;k<w*h;k++,i+=4){const v=clamp(e[k]*k0*0.5*Math.sqrt(p.w),0,255);for(let q=0;q<3;q++)o[i+q]=clamp(v*(0.4+0.6*s[i+q]/255),0,255);o[i+3]=s[i+3];}
}));
defFx('traceedge','stylize','Trace Contour',[P('l','Level',0,255,128)],(img,p)=>fxOut(img,(s,o,w,h)=>{
  const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4)>p.l?1:0;for(let i=0;i<o.length;i+=4){o[i]=o[i+1]=o[i+2]=255;o[i+3]=255;}
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const k=y*w+x;if(L[k]!==L[k+1]||L[k]!==L[k+w]){const i=k*4;o[i]=s[i];o[i+1]=s[i+1];o[i+2]=s[i+2];}}
}));
/* ---- Artistic ---- */
defFx('cutout','artistic','Cutout',[P('n','Levels',2,8,4),P('s','Edge simplicity',0,10,4)],(img,p,c)=>{const m=fxMedian(img,Math.max(1,Math.round(1+p.s/2)));const d=m.data,st=255/(Math.round(p.n)-1);for(let i=0;i<d.length;i+=4)for(let q=0;q<3;q++)d[i+q]=Math.round(d[i+q]/st)*st;return m;});
defFx('posteredges','artistic','Poster Edges',[P('t','Edge thickness',0,10,2),P('i','Edge intensity',0,10,4),P('p','Posterization',2,10,5)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const m=fxMedian(img,2).data,st=255/(Math.round(p.p)-1),L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4);const e=fxSobel(L,w,h);
  for(let k=0,i=0;k<w*h;k++,i+=4){const ed=clamp(e[k]*p.i/40,0,1);for(let q=0;q<3;q++)o[i+q]=Math.round(m[i+q]/st)*st*(1-ed*0.9);o[i+3]=s[i+3];}}));
defFx('paintdaubs','artistic','Paint Daubs',[P('b','Brush size',1,30,8),P('sh','Sharpness',0,40,10)],(img,p,c)=>{const m=fxMedian(img,Math.max(1,Math.round(sc(p.b,c)*0.5)));return unsharp(m,p.sh*6,1.5,0,c);});
defFx('wateroil','artistic','Watercolor',[P('d','Brush detail',1,14,9),P('sh','Shadow intensity',0,10,1),P('t','Texture',1,3,1)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const m=fxMedian(img,Math.max(1,Math.round(sc(p.d,c)*0.3)));const d=m.data;fxGB(d,w,h,1);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,n=(fxNoise(x/3,y/3,2)-0.5)*14*p.t;for(let q=0;q<3;q++){const v=d[i+q],v2=Math.round(v/20)*20*0.4+v*0.6;o[i+q]=clamp(v2*(1-p.sh*0.02)+n+8,0,255);}o[i+3]=s[i+3];}}));
defFx('drybrush','artistic','Dry Brush',[P('b','Brush size',0,10,2),P('d','Detail',1,10,8),P('t','Texture',1,3,1)],(img,p,c)=>{let m=fxMedian(img,Math.max(1,Math.round(1+p.b)));const d=m.data,st=255/ (4+Math.round(p.d)),rnd=fxRnd(2);for(let i=0;i<d.length;i+=4)for(let q=0;q<3;q++)d[i+q]=clamp(Math.round(d[i+q]/st)*st+(rnd()-0.5)*6*p.t,0,255);return m;});
defFx('plastic','artistic','Plastic Wrap',[P('h','Highlight strength',0,20,15),P('d','Detail',1,15,9),P('sm','Smoothness',1,15,7)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const b=cp(img);fxGB(b,w,h,Math.max(1,sc(p.sm,c)*0.8));const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(b,k*4);const e=fxSobel(L,w,h);
  for(let k=0,i=0;k<w*h;k++,i+=4){const hl=clamp(e[k]*p.h/60,0,1)*180;for(let q=0;q<3;q++)o[i+q]=clamp(s[i+q]*0.85+hl*(0.5+0.5*s[i+q]/255),0,255);o[i+3]=s[i+3];}}));
defFx('neonglow','artistic','Neon Glow',[P('s','Glow size',1,40,10),P('b','Glow brightness',0,50,15)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4);const e=fxSobel(L,w,h),gl=new Uint8ClampedArray(s.length),col=hexRGB(S.fg||'#ff2bd6');
  for(let k=0,i=0;k<w*h;k++,i+=4){const v=clamp(e[k]*1.2,0,255)/255;for(let q=0;q<3;q++)gl[i+q]=(s[i+q]*0.6+col[q]*0.4)*v;gl[i+3]=255;}
  const g2=new Uint8ClampedArray(gl);fxGB(g2,w,h,Math.max(1,sc(p.s,c)*0.4));
  for(let i=0;i<s.length;i+=4){for(let q=0;q<3;q++)o[i+q]=clamp(s[i+q]*0.25+gl[i+q]*1.2+g2[i+q]*p.b/8,0,255);o[i+3]=s[i+3];}}));
defFx('colorpencil','artistic','Colored Pencil',[P('w','Pencil width',1,24,4),P('p','Stroke pressure',0,15,8),P('pa','Paper brightness',0,50,25)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4);const e=fxSobel(L,w,h),m=fxMedian(img,1).data,pa=180+p.pa;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=y*w+x,i=k*4,hatch=0.5+0.5*Math.sin((x+y)*Math.PI/Math.max(1.5,sc(p.w,c)*0.5)),ed=clamp(e[k]*p.p/50,0,1);for(let q=0;q<3;q++){const base=pa+(m[i+q]-pa)*(0.5+0.35*hatch);o[i+q]=clamp(base*(1-ed*0.5),0,255);}o[i+3]=s[i+3];}}));
/* ---- Sketch ---- */
defFx('halftonepat','sketch','Halftone Pattern',[P('sz','Size',1,12,4),P('co','Contrast',0,50,20),P('ty','Type (0 dot,1 line,2 circle)',0,2,0)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const sz=Math.max(2,sc(p.sz,c)*2);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,L=clamp((fxLum(s,i)/255-0.5)*(1+p.co/25)+0.5,0,1),u=(x%sz)/sz-0.5,v=(y%sz)/sz-0.5;let on;const ty=Math.round(p.ty);
    if(ty===1)on=Math.abs(v)*2<1-L;else if(ty===2){const r=Math.hypot(u,v)*2;on=Math.abs(r-(1-L))<0.25;}else on=Math.hypot(u,v)*1.414<Math.sqrt(1-L)*0.95;
    const col=on?0:255;o[i]=o[i+1]=o[i+2]=col;o[i+3]=255;}}));
defFx('charcoal','sketch','Charcoal',[P('t','Thickness',1,7,3),P('d','Detail',0,5,3),P('b','Light/dark balance',0,100,50)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4);const e=fxSobel(L,w,h);
  for(let k=0,i=0;k<w*h;k++,i+=4){const v=255-clamp(e[k]*(0.5+p.d/3)*(0.8+p.t*0.1),0,255),sh=(1-L[k]/255)*(p.b/100)*60;o[i]=o[i+1]=o[i+2]=clamp(v-sh+(fxNoise((k%w)/2,(k/w|0)/2,1)-0.5)*10,0,255);o[i+3]=s[i+3];}}));
defFx('chalk','sketch','Chalk & Charcoal',[P('c','Charcoal area',0,20,6),P('ch','Chalk area',0,20,6),P('st','Stroke pressure',0,5,2)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,L=fxLum(s,i),n=(fxNoise(x/1.5,y/1.5,4)-0.5)*40;let v;if(L<110)v=40+n*0.5+L*(p.c/20);else if(L>150)v=215+n*0.4+(L-150)*(p.ch/60);else v=128+n*0.4;o[i]=o[i+1]=o[i+2]=clamp(v,0,255);o[i+3]=s[i+3];}}));
defFx('stamp','sketch','Stamp',[P('b','Light/dark balance',1,50,25),P('s','Smoothness',1,50,5)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const b=cp(img);fxGB(b,w,h,sc(p.s,c)*0.2);const fg=hexRGB(S.fg||'#000'),bg=hexRGB(S.bg||'#fff'),thr=255*(1-p.b/100);
  for(let i=0;i<s.length;i+=4){const on=fxLum(b,i)<thr;for(let q=0;q<3;q++)o[i+q]=on?fg[q]:bg[q];o[i+3]=255;}}));
defFx('reticulation','sketch','Reticulation',[P('d','Density',1,50,12),P('b','Black level',0,50,10),P('w','White level',0,50,10)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const rnd=fxRnd(8);for(let i=0;i<s.length;i+=4){const L=fxLum(s,i)/255,n=rnd()*(p.d/50)+L*(1-p.d/50),v=n<0.5?(p.b>0?0:30):255;for(let q=0;q<3;q++)o[i+q]=v*(n<0.5?1:1);o[i+3]=255;}}));
defFx('photocopy','sketch','Photocopy',[P('d','Detail',1,24,8),P('da','Darkness',1,50,12)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const b=cp(img);fxGB(b,w,h,Math.max(1,sc(p.d,c)*0.3));const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(b,k*4);const e=fxSobel(L,w,h);
  for(let k=0,i=0;k<w*h;k++,i+=4){const v=e[k]*p.da/18>60?0:255;o[i]=o[i+1]=o[i+2]=v;o[i+3]=255;}}));
defFx('bas','sketch','Bas Relief',[P('d','Detail',1,15,8),P('sm','Smoothness',1,15,5),P('ang','Light angle',0,360,135)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const b=cp(img);fxGB(b,w,h,Math.max(0,sc(p.sm,c)*0.3));const a=p.ang*Math.PI/180,dx=Math.round(Math.cos(a)*1.5),dy=Math.round(-Math.sin(a)*1.5),amp=p.d/3;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,j=(clamp(y+dy,0,h-1)*w+clamp(x+dx,0,w-1))*4,k=(clamp(y-dy,0,h-1)*w+clamp(x-dx,0,w-1))*4,v=clamp(128+(fxLum(b,j)-fxLum(b,k))*amp,0,255);o[i]=o[i+1]=o[i+2]=v;o[i+3]=s[i+3];}}));
/* ---- Texture ---- */
defFx('grain','texture','Grain',[P('i','Intensity',0,100,40),P('co','Contrast',0,100,50),P('sz','Size',1,6,1)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const k=Math.max(1,Math.round(sc(p.sz,c))),rnd=fxRnd(13);for(let y0=0;y0<h;y0+=k)for(let x0=0;x0<w;x0+=k){const n=(rnd()-0.5)*p.i*2.2;
    for(let y=y0;y<Math.min(h,y0+k);y++)for(let x=x0;x<Math.min(w,x0+k);x++){const i=(y*w+x)*4,L=fxLum(s,i)/255,m=1-Math.abs(L-0.5)*(p.co/100)*1.2;for(let q=0;q<3;q++)o[i+q]=clamp(s[i+q]+n*m,0,255);}}}));
defFx('canvas','texture','Texturizer (Canvas)',[P('s','Scaling',1,20,4),P('r','Relief',0,20,4),P('l','Light angle',0,360,135)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const sz=Math.max(1,sc(p.s,c)),a=p.l*Math.PI/180;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,t=Math.sin(x/sz*2)*Math.cos(y/sz*2)*0.5+0.3*Math.sin((x+y)/sz*1.3)+(fxNoise(x/sz,y/sz,5)-0.5)*0.4,sh=1+t*p.r*0.03*1;for(let q=0;q<3;q++)o[i+q]=clamp(s[i+q]*sh,0,255);o[i+3]=s[i+3];}}));
defFx('craquelure','texture','Craquelure',[P('cs','Crack spacing',2,100,30),P('cd','Crack depth',0,10,6)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const C=fxCells(w,h,Math.max(6,sc(p.cs,c)),31);for(let k=0,i=0;k<w*h;k++,i+=4){const x=k%w,y=(k/w)|0;let edge=0;if(x+1<w&&C.id[k]!==C.id[k+1])edge=1;if(y+1<h&&C.id[k]!==C.id[k+w])edge=1;for(let q=0;q<3;q++)o[i+q]=edge?s[i+q]*(1-p.cd/12):s[i+q]*(1+0.04);o[i+3]=s[i+3];}}));
defFx('stainedglass','texture','Stained Glass',[P('c','Cell size',4,100,24),P('b','Border',0,10,3)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,cell=Math.max(4,sc(p.c,c)),C=fxCells(w,h,cell,17),sum=new Float64Array(C.n*3),cnt=new Float64Array(C.n),o=new Uint8ClampedArray(s.length);
  for(let k=0,i=0;k<w*h;k++,i+=4){const id=C.id[k];for(let q=0;q<3;q++)sum[id*3+q]+=s[i+q];cnt[id]++;}
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=y*w+x,i=k*4,id=C.id[k];let edge=0;if(x+1<w&&C.id[k+1]!==id)edge=1;if(y+1<h&&C.id[k+w]!==id)edge=1;const bw=p.b;let e=edge;for(let q=0;q<3;q++)o[i+q]=e?30:sum[id*3+q]/cnt[id];o[i+3]=255;}
  return mkImg(o,w,h);
});
defFx('mosaictiles','texture','Mosaic Tiles',[P('t','Tile size',2,60,12),P('g','Grout',1,12,2)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const t=Math.max(3,Math.round(sc(p.t,c)));for(let y0=0;y0<h;y0+=t)for(let x0=0;x0<w;x0+=t){let r=0,g=0,b=0,n=0;for(let y=y0;y<Math.min(h,y0+t);y++)for(let x=x0;x<Math.min(w,x0+t);x++){const i=(y*w+x)*4;r+=s[i];g+=s[i+1];b+=s[i+2];n++;}
    for(let y=y0;y<Math.min(h,y0+t);y++)for(let x=x0;x<Math.min(w,x0+t);x++){const i=(y*w+x)*4,gr=(x-x0<p.g||y-y0<p.g);o[i]=gr?60:r/n;o[i+1]=gr?60:g/n;o[i+2]=gr?60:b/n;o[i+3]=s[i+3];}}}));
/* ---- Brush strokes ---- */
defFx('sprayed','brush','Sprayed Strokes',[P('l','Stroke length',0,20,12),P('r','Spray radius',0,25,7),P('d','Direction (0 right-diag, 1 left-diag, 2 vertical, 3 horizontal)',0,3,0)],(img,p,c)=>{
  const R=sc(p.r,c)+1,rnd=fxRnd(6),w=img.width,h=img.height,d=Math.round(p.d),taps=[],ang=[Math.PI/4,-Math.PI/4,Math.PI/2,0][d];
  for(let i=0;i<14;i++){const t=(rnd()-0.5)*p.l*sc(1,c),j=(rnd()-0.5)*R;taps.push([Math.cos(ang)*t-Math.sin(ang)*j,Math.sin(ang)*t+Math.cos(ang)*j]);}
  return fxTapBlur(img,taps);});
defFx('accented','brush','Accented Edges',[P('w','Edge width',1,14,2),P('b','Edge brightness',0,50,38)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4);const e=fxSobel(L,w,h);for(let k=0,i=0;k<w*h;k++,i+=4){const m=clamp(e[k]/200,0,1),v=m*p.b*5;for(let q=0;q<3;q++)o[i+q]=clamp(s[i+q]*(1-m*0.4)+v,0,255);o[i+3]=s[i+3];}}));
defFx('inkoutline','brush','Ink Outlines',[P('s','Stroke length',1,50,4),P('da','Dark intensity',0,50,20),P('li','Light intensity',0,50,10)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const L=new Float32Array(w*h);for(let k=0;k<w*h;k++)L[k]=fxLum(s,k*4);const e=fxSobel(L,w,h),m=fxMedian(img,2).data;for(let k=0,i=0;k<w*h;k++,i+=4){const ink=clamp(e[k]*p.da/180,0,1);for(let q=0;q<3;q++)o[i+q]=clamp((m[i+q]+p.li)*(1-ink),0,255);o[i+3]=s[i+3];}}));
/* ---- Lens Correction (also exposed as a dialog below) ---- */
defFx('lenscorr','adjust','Lens Correction',[P('d','Remove distortion',-100,100,0),P('ca','Chromatic aberration (R/B shift)',-30,30,0),P('vi','Vignette amount',-100,100,0),P('vm','Vignette midpoint',0,100,50),P('vh','Vertical perspective',-100,100,0),P('hp','Horizontal perspective',-100,100,0),P('an','Angle',-45,45,0),P('sc','Scale %',50,150,100)],(img,p)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),cx=w/2,cy=h/2,Rm=Math.hypot(cx,cy),k=p.d/100*0.6,an=p.an*Math.PI/180,ca=Math.cos(an),sa=Math.sin(an),S2=100/p.sc;
  const smp=(fx,fy,q)=>{fx=clamp(fx,0,w-1.001);fy=clamp(fy,0,h-1.001);const x0=fx|0,y0=fy|0,tx=fx-x0,ty=fy-y0,i=(y0*w+x0)*4+q;return (s[i]*(1-tx)+s[i+4]*tx)*(1-ty)+(s[i+w*4]*(1-tx)+s[i+w*4+4]*tx)*ty;};
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){let u=(x-cx)/cx,v=(y-cy)/cy;
    const pv=1+v*p.vh/200,ph=1+u*p.hp/200;u=u/pv*S2*(1);v=v/ph*S2;
    const ru=u*ca-v*sa,rv=u*sa+v*ca;u=ru;v=rv;const r2=u*u+v*v,f=1+k*r2,i=(y*w+x)*4;
    const sx=cx+u*f*cx,sy=cy+v*f*cy;
    for(let q=0;q<3;q++){const sh=q===0?-p.ca:q===2?p.ca:0,ex=sh*(u*f),ey=sh*(v*f);o[i+q]=smp(sx+ex,sy+ey,q);}o[i+3]=smp(sx,sy,3);
    if(p.vi){const d=Math.hypot(x-cx,y-cy)/Rm,t=fxSS((d-p.vm/100*0.6)/0.8),vv=p.vi/100;for(let q=0;q<3;q++)o[i+q]=vv>0?o[i+q]+(255-o[i+q])*vv*t:o[i+q]*(1+vv*t);}}
  return mkImg(o,w,h);
});
defFx('wideangle','distort','Adaptive Wide Angle',[P('t','Projection (0 fisheye, 1 perspective, 2 cylindrical)',0,2,1),P('fo','Focal length',8,100,24),P('cr','Crop factor',0.5,5,1,0.1),P('sc','Scale %',50,200,100),P('ho','Horizon angle',-30,30,0)],(img,p)=>{
  const w=img.width,h=img.height,cx=w/2,cy=h/2,t=Math.round(p.t),f0=Math.max(8,p.fo*p.cr),k=clamp(60/f0,0,3),S2=100/p.sc,an=p.ho*Math.PI/180,ca=Math.cos(an),sa=Math.sin(an);
  return warp(img,(x,y,o)=>{let u=(x-cx)/cx*S2,v=(y-cy)/cy*S2;const ru=u*ca-v*sa,rv=u*sa+v*ca;u=ru;v=rv;
    if(t===0){const r=Math.hypot(u,v),a=Math.atan(r*k*0.9)/(Math.atan(k*0.9)||1);const f=r>0?a/r:1;o[0]=cx+u*f*cx;o[1]=cy+v*f*cy;}
    else if(t===1){const r=Math.hypot(u,v),f=r>0?Math.tan(r*k*0.7)/(Math.tan(k*0.7)||1)/Math.max(r,1e-6)*Math.min(1,r)||1:1;o[0]=cx+u*(1+k*0.15*(r*r-1))*cx;o[1]=cy+v*(1+k*0.15*(r*r-1))*cy;}
    else{o[0]=cx+Math.tan(u*k*0.6)/(Math.tan(k*0.6)||1)*cx;o[1]=cy+v*(1+k*0.1*u*u)*cy;}});
});
