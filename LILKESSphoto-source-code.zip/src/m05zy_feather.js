/* ===== Feather: selection feather, non-destructive mask feather, Properties panel, Pen "Make Selection" =====
   Two different features:
   - Selection Feather softens the edge of the active selection (S.sel). It always works on the selection alpha, in IMAGE pixels.
   - Mask Feather softens the shown edge of a layer mask. The original mask is kept apart (l.mk.base) and the shown mask
     (l.mask) is rebuilt from base + settings every time, so changing the value again never blurs the mask a second time. */

/* ---------- engine: Gaussian-like blur on float planes, image pixels ---------- */
function fthBoxes(sigma,n){
  const wi=Math.sqrt(12*sigma*sigma/n+1);let wl=Math.floor(wi);if(wl%2===0)wl--;const wu=wl+2;
  const m=Math.round((12*sigma*sigma-n*wl*wl-4*n*wl-3*n)/(-4*wl-4)),r=[];
  for(let i=0;i<n;i++)r.push(((i<m?wl:wu)-1)/2);return r;
}
function fthKernelBlur(a,w,h,sigma){
  const R=Math.max(1,Math.ceil(sigma*3)),k=new Float32Array(2*R+1);let s=0;
  for(let i=-R;i<=R;i++){k[i+R]=Math.exp(-i*i/(2*sigma*sigma));s+=k[i+R];}for(let i=0;i<k.length;i++)k[i]/=s;
  const t=new Float32Array(w*h),o=new Float32Array(w*h);
  for(let y=0;y<h;y++){const b=y*w;for(let x=0;x<w;x++){let v=0;for(let i=-R;i<=R;i++){const xx=x+i<0?0:x+i>=w?w-1:x+i;v+=a[b+xx]*k[i+R];}t[b+x]=v;}}
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){let v=0;for(let i=-R;i<=R;i++){const yy=y+i<0?0:y+i>=h?h-1:y+i;v+=t[yy*w+x]*k[i+R];}o[y*w+x]=v;}
  return o;
}
/* sigma in pixels. Edges repeat the border pixels, so a selection that touches the image edge is not faded there. */
function fthGauss(a,w,h,sigma){
  if(!(sigma>0.05))return Float32Array.from(a);
  if(sigma<=4)return fthKernelBlur(a,w,h,sigma);
  let o=a;for(const r of fthBoxes(sigma,3))o=cut__box(o,w,h,Math.max(1,r));return o;
}
const fthRadiusToSigma=r=>r/2;      /* a feather radius of r px gives a soft edge about r px each side of the old edge */
function fthPlane(c){const w=c.width,h=c.height,d=cctx(c).getImageData(0,0,w,h).data,a=new Float32Array(w*h);for(let i=0;i<a.length;i++)a[i]=d[i*4+3]/255;return a;}
function fthCanvas(a,w,h){
  const c=mkCanvas(w,h),x=cctx(c),id=x.createImageData(w,h),d=id.data;
  for(let i=0;i<a.length;i++){const v=a[i]<0?0:a[i]>1?1:a[i];d[i*4]=d[i*4+1]=d[i*4+2]=255;d[i*4+3]=Math.round(v*255);}
  x.putImageData(id,0,0);return c;
}
/* the feather range follows the image: the slider reaches about an eighth of the long side, the number box twice that */
const fthSliderMax=(w,h)=>Math.max(60,Math.round(Math.max(w,h)/8));
const fthNumMax=(w,h)=>Math.max(200,Math.round(Math.max(w,h)/2));
const fthRound=v=>Math.round(v*10)/10;

/* ---------- history: selection marks + mask settings ---------- */
let FTH_NEXTMARK=null,FTH_PH=0;
{
  const _sn=snapshot;
  snapshot=function(label){
    const s=_sn(label);
    s.layers.forEach((q,i)=>{const l=doc.layers[i];q.mk=(l&&mkSynced(l))?{base:l.mk.base,p:Object.assign({},l.mk.p)}:null;});
    if(FTH_NEXTMARK){s.selMark=FTH_NEXTMARK;FTH_NEXTMARK=null;}
    return s;
  };
  const _cm=commit;commit=function(label){_cm(label);FTH_PH=hi;};
  const _rs=restore;
  restore=function(s){
    const from=FTH_PH,to=hi;
    _rs(s);
    doc.layers.forEach((l,i)=>{const q=s.layers[i];l.mk=(q&&q.mk&&l.mask)?{base:q.mk.base,p:Object.assign({},q.mk.p),mver:l.mver,shown:l.mask}:null;});
    if(to<from){for(let k=from;k>to;k--){const m=hist[k]&&hist[k].selMark;if(m)S.sel=m.before||null;}}
    else if(to>from){for(let k=from+1;k<=to;k++){const m=hist[k]&&hist[k].selMark;if(m)S.sel=m.after||null;}}
    FTH_PH=to;FTH_KEY=null;redraw();renderProps();
  };
}
function commitSel(label,before){FTH_NEXTMARK={before:before||null,after:S.sel||null};commit(label);}

/* ---------- selection model: S.sel -> {base, settings} so the settings can be changed again without re-blurring ---------- */
const SELM=new WeakMap();
const SELD=()=>({feather:0,smooth:0,expand:0,contract:0});
function selState(){
  if(!S.sel)return null;
  let m=SELM.get(S.sel);
  if(!m){m={base:cloneCanvas(S.sel.c),p:SELD()};SELM.set(S.sel,m);}
  return m;
}
function selCompute(base,p){
  const w=base.width,h=base.height;let a=fthPlane(base);
  const net=(p.expand||0)-(p.contract||0);
  if(net!==0||p.smooth>0){
    let bin=new Uint8Array(w*h);for(let i=0;i<a.length;i++)bin[i]=a[i]>0.5?1:0;
    if(net>0)bin=cut__dilate(bin,w,h,net);else if(net<0)bin=cut__erode(bin,w,h,-net);
    a=new Float32Array(w*h);for(let i=0;i<a.length;i++)a[i]=bin[i];
    if(p.smooth>0){const b=fthGauss(a,w,h,p.smooth);for(let i=0;i<a.length;i++)a[i]=b[i]>0.5?1:0;}   /* round off jagged corners */
    a=fthGauss(a,w,h,0.7);                                                                           /* anti-aliased edge */
  }
  if(p.feather>0)a=fthGauss(a,w,h,fthRadiusToSigma(p.feather));
  return fthCanvas(a,w,h);
}
/* writes the result into S.sel (live, no history); returns false when nothing is left */
function selSet(patch){
  const m=selState();if(!m)return false;
  Object.assign(m.p,patch);
  const n=selCompute(m.base,m.p),s=selScan(n);
  if(!s){toast('Nothing would stay selected with those settings');return false;}
  s.c=n;SELM.set(s,m);S.sel=s;FTH_SELREF=s;redraw();return true;
}
let FTH_SELREF=null;
/* Select > Modify dialogs: live preview, OK keeps it, Cancel puts the original selection back */
function selModDialog(kind){
  if(!doc){toast('Open a design first');return;}
  if(!S.sel){toast('Make a selection first. Feather, Smooth, Expand and Contract work on the active selection.');return;}
  const orig=S.sel,W=doc.w,H=doc.h;
  const T={feather:['Feather Selection','Feather radius','px',fthNumMax(W,H),0.1],smooth:['Smooth Selection','Sample radius','px',100,1],expand:['Expand Selection','Expand by','px',fthNumMax(W,H),1],contract:['Contract Selection','Contract by','px',fthNumMax(W,H),1]}[kind];
  const def=kind==='feather'?5:kind==='smooth'?4:10;
  /* the dialog works on the selection as it is now; settings are cumulative with earlier operations, like Photoshop */
  const baseSel=cloneCanvas(orig.c);let done=false;
  const run=v=>{
    const p=SELD();p[kind]=v;const n=selCompute(baseSel,p),s=selScan(n);
    if(!s)return false;s.c=n;SELM.set(s,{base:baseSel,p});S.sel=s;redraw();return true;
  };
  modalOpen(T[0],'<div class="row"><label>'+T[1]+' <input type="number" id="fd-v" value="'+def+'" min="0" max="'+T[3]+'" step="'+T[4]+'" style="width:96px"> '+T[2]+'</label></div>'
    +'<p class="muted">Measured in image pixels, so zooming does not change the result. The selection updates while you type. Cancel keeps the original selection.</p>',
    [{label:'Cancel',cb:()=>{S.sel=orig;redraw();}},
     {label:'OK',primary:true,cb:()=>{const v=clamp(+$('#fd-v').value||0,0,T[3]);if(!run(v)){toast('Nothing would stay selected with that value');S.sel=orig;redraw();return;}done=true;
       commitSel(T[0],orig);toast(T[0].replace(' Selection','')+' applied: '+v+' px');renderProps();}}],
    root=>{
      const i=root.querySelector('#fd-v');i.focus();i.select();run(def);
      i.addEventListener('input',()=>{const v=clamp(+i.value||0,0,T[3]);if(!run(v)){S.sel=orig;redraw();}});
    });
  modalCancel=()=>{if(!done){S.sel=orig;redraw();}};
}
ACT.selFeather=()=>selModDialog('feather');
ACT.selSmooth=()=>selModDialog('smooth');
ACT.selExpand=()=>selModDialog('expand');
ACT.selContract=()=>selModDialog('contract');
ACT.selGrow=ACT.selExpand;ACT.selShrink=ACT.selContract;
/* other code calls selMorph(kind,r): use the same engine, in image pixels */
selMorph=function(kind,r){
  if(!S.sel){toast('Make a selection first');return;}
  const before=S.sel,p=SELD();
  p[kind==='grow'?'expand':kind==='shrink'?'contract':kind]=r;
  const n=selCompute(cloneCanvas(before.c),p),s=selScan(n);
  if(!s){toast('Nothing would stay selected');return;}
  s.c=n;S.sel=s;S.lastSel=before;redraw();commitSel(kind==='feather'?'Feather selection':'Modify selection',before);renderProps();
};
/* the Select > Modify items: greyed out with no selection */
(()=>{
  const M=MENUS.find(m=>m.label==='Select');if(!M)return;
  const md=M.items.find(x=>x.label==='Modify');if(!md)return;
  md.items.forEach(it=>{if(it.label){it.dis=()=>!doc||!S.sel;}});
  const f=md.items.find(x=>x.label==='Feather...');if(f)f.title='Soften the edge of the selection';
})();

/* ---------- Pen: Make Selection dialog (Feather Radius, Anti-aliased, New / Add / Subtract / Intersect) ---------- */
function pathRaw(aa){
  const ph=needPath();if(!ph)return null;
  const c=mkCanvas(doc.w,doc.h),x=cctx(c);x.fillStyle='#fff';x.beginPath();vec_trace(x,ph.path);x.fill('evenodd');
  if(!aa){const id=x.getImageData(0,0,c.width,c.height),d=id.data;for(let i=3;i<d.length;i+=4)d[i]=d[i]>127?255:0;x.putImageData(id,0,0);}
  return c;
}
function makeSelFromPath(o){
  const raw=pathRaw(o.aa!==false);if(!raw)return false;
  const before=S.sel,mode=(!S.sel||o.mode==='new')?'new':o.mode,r=Math.max(0,+o.feather||0);
  const n=r>0?fthCanvas(fthGauss(fthPlane(raw),raw.width,raw.height,fthRadiusToSigma(r)),raw.width,raw.height):raw;
  if(mode==='int'||mode==='sub'){if(!S.sel){toast('Make a selection first');return false;}}
  const had=S.sel;setSelection(n,mode);
  if(S.sel===had&&mode!=='new'){toast('The path changed nothing');return false;}
  if(!S.sel){toast('The path selects nothing. Close the path around the area first.');S.sel=before;return false;}
  /* a new selection from a path remembers the sharp path, so Feather in the Properties panel can change it later */
  if(mode==='new'){const p=SELD();p.feather=r;SELM.set(S.sel,{base:cloneCanvas(raw),p});}
  commitSel('Selection from path'+(r>0?' (feather '+r+' px)':''),before);renderProps();
  return true;
}
function penSelDialog(){
  if(!doc){toast('Open a design first');return;}
  const ph=needPath();if(!ph)return;
  const has=!!S.sel,W=doc.w,H=doc.h;
  modalOpen('Make Selection',
    '<div class="row"><label>Feather radius <input type="number" id="ms-f" value="0" min="0" max="'+fthNumMax(W,H)+'" step="0.1" style="width:90px"> px</label></div>'
    +'<div class="row"><label><input type="checkbox" id="ms-aa" checked> Anti-aliased</label></div>'
    +'<div class="muted" style="margin:8px 0 2px">Operation</div>'
    +'<label class="rrow"><input type="radio" name="ms-m" value="new" checked> New selection</label>'
    +'<label class="rrow"><input type="radio" name="ms-m" value="add"'+(has?'':' disabled')+'> Add to selection</label>'
    +'<label class="rrow"><input type="radio" name="ms-m" value="sub"'+(has?'':' disabled')+'> Subtract from selection</label>'
    +'<label class="rrow"><input type="radio" name="ms-m" value="int"'+(has?'':' disabled')+'> Intersect with selection</label>'
    +'<p class="muted">0 px gives a sharp edge. A larger radius softens it. The radius is in image pixels. You can still change the Feather later in the Properties panel.</p>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const m=document.querySelector('input[name="ms-m"]:checked');
      if(!makeSelFromPath({feather:clamp(+$('#ms-f').value||0,0,fthNumMax(W,H)),aa:$('#ms-aa').checked,mode:m?m.value:'new'}))return;
      toast('Selection made from the path');}}],
    root=>{const i=root.querySelector('#ms-f');i.focus();i.select();});
}
ACT.pathSel=D(penSelDialog);
ACT.pathMakeSel=ACT.pathSel;
ACT.pathFeather=D(()=>{if(!S.sel){if(!needPath())return;penSelDialog();return;}selModDialog('feather');});

/* ---------- mask model: l.mk = {base (never edited), p:{dens,feather}, mver, shown} ---------- */
const MKD=()=>({dens:100,feather:0});
let FTH_KEY=null;
const mkSynced=l=>!!(l&&l.mask&&l.mk&&l.mk.mver===l.mver&&l.mk.shown===l.mask);
function mkEnsure(l){
  if(!l||!l.mask){if(l)l.mk=null;return null;}
  if(!mkSynced(l))l.mk={base:cloneCanvas(l.mask),p:MKD(),mver:l.mver,shown:l.mask};
  return l.mk;
}
function mkCompute(base,p){
  const w=base.width,h=base.height;let a=fthPlane(base);
  if(p.feather>0)a=fthGauss(a,w,h,fthRadiusToSigma(p.feather));
  const dn=Math.max(0,Math.min(1,p.dens/100));
  if(dn<1)for(let i=0;i<a.length;i++)a[i]=a[i]*dn+(1-dn);
  return a;
}
function mkRebuild(l){
  const m=mkEnsure(l);if(!m)return;
  const w=l.mask.width,h=l.mask.height,x=cctx(l.mask);
  if(m.p.feather<=0&&m.p.dens>=100){x.save();x.globalCompositeOperation='copy';x.drawImage(m.base,0,0);x.restore();}   /* exactly the original */
  else{x.save();x.globalCompositeOperation='copy';x.drawImage(fthCanvas(mkCompute(m.base,m.p),w,h),0,0);x.restore();}
  l.mver++;m.mver=l.mver;l._vc=null;touch(l);redraw();
}
/* mask Invert keeps the settings: the original is inverted and the shown mask rebuilt from it */
function mkInvert(l){
  const m=mkEnsure(l);if(!m)return;
  const w=m.base.width,h=m.base.height,n=mkCanvas(w,h),x=cctx(n);x.fillStyle='#fff';x.fillRect(0,0,w,h);x.globalCompositeOperation='destination-out';x.drawImage(m.base,0,0);
  m.base=n;mkRebuild(l);
}
/* the disable / view-mask commands bump the version without changing the mask data */
maskTouch=function(l,label){const ok=mkSynced(l);l.mver++;if(ok)l.mk.mver=l.mver;touch(l);if(label)commit(label);refreshLayers();redraw();};
{const _mt=meta;meta=function(l){return _mt(l);};}
function mkSettingsOf(l){return mkSynced(l)?{p:Object.assign({},l.mk.p),base:l.mk.base}:null;}

/* ---------- Properties panel ---------- */
const fthSld=(t,max)=>Math.round(1000*Math.sqrt(Math.max(0,Math.min(1,t/max))));
const fthFromSld=(s,max)=>fthRound(max*Math.pow(s/1000,2));
function fthRow(scope,key,label,val,max,numMax,unit,note){
  const sl=unit==='px'?fthSld(val,max):val;
  return '<div class="fth" data-fs="'+scope+'" data-fk="'+key+'" data-fmax="'+max+'" data-fnum="'+numMax+'" data-fu="'+unit+'"><label class="sl"><span>'+label+'</span>'
    +'<input type="range" data-ft="sld" min="0" max="'+(unit==='px'?1000:100)+'" step="'+(unit==='px'?1:1)+'" value="'+sl+'" aria-label="'+label+' slider">'
    +'<input type="number" class="nv" data-ft="num" min="0" max="'+numMax+'" step="'+(unit==='px'?0.1:1)+'" value="'+val+'" aria-label="'+label+' value"><em>'+unit+'</em></label>'
    +'<div class="fthb"><button data-ft="dec" title="Smaller (Down arrow in the box does the same)">−</button><button data-ft="inc" title="Larger">+</button><button data-ft="rst" title="Reset to '+(key==='dens'?'100':'0')+'">Reset</button></div>'+(note?'<div class="muted fn">'+note+'</div>':'')+'</div>';
}
function maskGroup(l){
  const m=mkEnsure(l),w=l.mask.width,h=l.mask.height,mx=fthSliderMax(w,h),nm=fthNumMax(w,h);
  const d=document.createElement('div');d.id='p-mkp';d.className='pgroup';
  d.innerHTML='<h4>Layer Mask Properties'+(l.mOff?' (disabled)':'')+'</h4>'
   +fthRow('mask','dens','Density',m.p.dens,100,100,'%')
   +fthRow('mask','feather','Feather',m.p.feather,mx,nm,'px','Softens the mask edge. The original mask is kept, so you can lower this to sharpen it again.')
   +'<div class="pbtns mk3"><button data-mkp="inv">Invert mask</button><button data-mkp="dis" aria-pressed="'+!!l.mOff+'">'+(l.mOff?'Enable mask':'Disable mask')+'</button>'
   +'<button data-mkp="view" aria-pressed="'+!!l.mView+'">'+(l.mView?'Exit mask view':'View mask')+'</button><button data-mkp="refine" class="primary">Refine Mask...</button>'
   +'<button data-mkp="sel">Load as selection</button><button data-mkp="apply">Apply mask</button><button data-mkp="del">Delete mask</button></div>'
   +'<p class="muted">Density and Feather change the mask only. The photo is never touched. Apply mask is the only step that erases pixels.</p>';
  return d;
}
function selGroup(){
  const m=selState(),W=doc.w,H=doc.h,mx=fthSliderMax(W,H),nm=fthNumMax(W,H),p=m.p;
  const d=document.createElement('div');d.id='p-selp';d.className='pgroup';
  d.innerHTML='<h4>Selection Properties</h4>'
   +fthRow('sel','feather','Feather',p.feather,mx,nm,'px','Soft edge of the selection. Changing it again starts from the original edge.')
   +fthRow('sel','smooth','Smooth',p.smooth,60,100,'px')
   +fthRow('sel','expand','Expand',p.expand,Math.max(50,mx/2),nm,'px')
   +fthRow('sel','contract','Contract',p.contract,Math.max(50,mx/2),nm,'px')
   +'<div class="pbtns mk3"><button data-selp="sam" class="primary">Select and Mask...</button><button data-selp="hair">Refine hair edges</button><button data-selp="rmbg">Remove background</button>'
   +'<button data-selp="mask">Make layer mask</button><button data-selp="inv">Invert</button><button data-selp="save">Save selection</button><button data-selp="none">Deselect</button></div>'
   +'<p class="muted">Feather here is the Selection Feather. After you make a layer mask, its own Feather appears when you click the mask thumbnail.</p>';
  return d;
}
function shapeGroup(l){
  const d=document.createElement('div');d.id='p-shpp';d.className='pgroup';
  d.innerHTML='<h4>Shape to selection or mask</h4>'
   +'<div class="pbtns mk3"><button data-shp="sel">Selection from shape...</button><button data-shp="mask">Mask from shape (layer below)...</button></div>'
   +'<p class="muted">The shape layer stays an editable vector. The feather is applied to a raster copy of its outline, so it softens the selection or mask, not the shape itself. This is different from anti-aliasing, which only smooths the edge by one pixel.</p>';
  return d;
}
function pathGroup(){
  const d=document.createElement('div');d.id='p-pthp';d.className='pgroup';
  d.innerHTML='<h4>Path Properties</h4><div class="pbtns mk3"><button data-pth="sel" class="primary">Make Selection...</button><button data-pth="mask">Make layer mask</button></div>'
   +'<p class="muted">Make Selection asks for a Feather radius and whether to add to, subtract from or intersect with the current selection.</p>';
  return d;
}
{
  const _rp=renderProps;
  renderProps=function(){
    _rp();
    const root=document.getElementById('tab-props');if(!root||!doc)return;
    const oldm=document.getElementById('p-maskp');if(oldm)oldm.remove();
    ['p-mkp','p-selp','p-shpp','p-pthp','p-mkhint'].forEach(i=>{const e=document.getElementById(i);if(e)e.remove();});
    const l=active();
    if(S.sel&&!SM.on)root.appendChild(selGroup());
    if(l&&l.mask){
      if(l.editMask)root.appendChild(maskGroup(l));
      else{const d=document.createElement('div');d.id='p-mkhint';d.className='pgroup';d.innerHTML='<h4>Layer Mask</h4><p class="muted">This layer has a mask. Click its thumbnail in the Layers panel to edit its Density and Feather.</p><div class="pbtns mk3"><button data-mkp="pick">Edit mask properties</button></div>';root.appendChild(d);}
    }
    if(l&&l.type==='shape'&&!pxLocked(l))root.appendChild(shapeGroup(l));
    try{const ph=curPath(false);if(ph&&ph.path.subs.some(s=>s.pts.length>1)&&['pen','dsel','psel'].includes(S.tool))root.appendChild(pathGroup());}catch(e){}
    FTH_SELREF=S.sel;
  };
}
/* the panel follows the real state: when the selection changes anywhere, redraw the panel once */
{
  const _do=drawOver;
  drawOver=function(){_do();if(SM.on||FTH_BUSY)return;if(S.sel!==FTH_SELREF){FTH_SELREF=S.sel;clearTimeout(FTH_T);FTH_T=setTimeout(()=>{if(!FTH_BUSY&&doc)renderProps();},30);}};
}
let FTH_T=0,FTH_BUSY=false,FTH_RAF=0,FTH_PEND=null,FTH_COMMIT=0,FTH_BEFORE=null;
const fthSched=fn=>{FTH_PEND=fn;if(!FTH_RAF)FTH_RAF=requestAnimationFrame(()=>{FTH_RAF=0;const f=FTH_PEND;FTH_PEND=null;if(f)f();});};
const fthFlush=()=>{if(FTH_RAF){cancelAnimationFrame(FTH_RAF);FTH_RAF=0;}const f=FTH_PEND;FTH_PEND=null;if(f)f();};
function fthApply(scope,key,v,live){
  const l=active();
  if(scope==='mask'){
    if(!l||!l.mask)return;const m=mkEnsure(l);if(m.p[key]===v&&live!=='force')return;m.p[key]=v;
    const run=()=>mkRebuild(l);if(live==='now')run();else fthSched(run);
  }else{
    if(!S.sel)return;const m=selState();if(!FTH_BEFORE)FTH_BEFORE=S.sel;
    const run=()=>selSet({[key]:v});if(live==='now')run();else fthSched(run);
  }
}
function fthLabel(scope,key,v){return (scope==='mask'?'Mask ':'Selection ')+(key==='dens'?'density '+v+'%':key+' '+v+(key==='dens'?'':' px'));}
function fthCommit(scope,key,v){
  fthFlush();clearTimeout(FTH_COMMIT);
  if(scope==='mask'){commit(fthLabel(scope,key,v));}
  else{const b=FTH_BEFORE;FTH_BEFORE=null;if(S.sel&&b!==S.sel)commitSel(fthLabel(scope,key,v),b);}
}
function fthRead(el){const g=el.closest('.fth');return {g,scope:g.dataset.fs,key:g.dataset.fk,max:+g.dataset.fmax,nm:+g.dataset.fnum,unit:g.dataset.fu};}
function fthSync(g,v,from){
  const n=g.querySelector('[data-ft="num"]'),s=g.querySelector('[data-ft="sld"]'),max=+g.dataset.fmax;
  if(n&&from!=='num')n.value=v;if(s&&from!=='sld')s.value=g.dataset.fu==='px'?fthSld(v,max):v;
}
document.addEventListener('input',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.ft||!t.closest('.fth'))return;
  const r=fthRead(t);let v;
  if(t.dataset.ft==='sld')v=r.unit==='px'?fthFromSld(+t.value,r.max):+t.value;
  else if(t.dataset.ft==='num'){v=+t.value;if(!isFinite(v))return;v=Math.max(0,Math.min(r.nm,v));if(r.unit==='px')v=fthRound(v);}
  else return;
  fthSync(r.g,v,t.dataset.ft);FTH_BUSY=true;fthApply(r.scope,r.key,v);
  clearTimeout(FTH_COMMIT);FTH_COMMIT=setTimeout(()=>{fthCommit(r.scope,r.key,v);FTH_BUSY=false;},700);   /* arrow keys in the box do not fire "change" until blur */
});
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset||!t.dataset.ft||!t.closest('.fth'))return;
  const r=fthRead(t),n=r.g.querySelector('[data-ft="num"]'),v=r.unit==='px'?fthRound(+n.value):+n.value;
  fthCommit(r.scope,r.key,v);FTH_BUSY=false;
});
document.addEventListener('click',e=>{
  const t=e.target.closest&&e.target.closest('[data-ft]');if(!t||t.tagName!=='BUTTON'||!t.closest('.fth'))return;
  const r=fthRead(t),n=r.g.querySelector('[data-ft="num"]');let v=+n.value||0;
  const step=r.unit==='px'?(v<10?0.5:v<50?1:5):5;
  if(t.dataset.ft==='dec')v=Math.max(0,v-step);else if(t.dataset.ft==='inc')v=Math.min(r.nm,v+step);else v=r.key==='dens'?100:0;
  if(r.unit==='px')v=fthRound(v);
  fthSync(r.g,v);FTH_BUSY=true;fthApply(r.scope,r.key,v,'now');fthCommit(r.scope,r.key,v);FTH_BUSY=false;
});
/* mask buttons */
document.addEventListener('click',e=>{
  const t=e.target.closest&&e.target.closest('[data-mkp]');if(!t)return;const l=active();if(!l||!l.mask)return;const k=t.dataset.mkp;
  if(k==='pick'){l.editMask=true;refreshLayers();renderProps();return;}
  if(k==='inv'){mkInvert(l);commit('Invert mask');renderProps();return;}
  if(k==='dis'||k==='view'||k==='del'){maskCmd(k);return;}
  if(k==='apply'){
    modalOpen('Apply mask','<p><b>This erases pixels.</b> Applying the mask permanently removes the hidden parts of this layer, using the mask as it looks now (with its Density and Feather). The mask is then removed and cannot be edited any more.</p><p class="muted">Undo brings it back.</p>',
      [{label:'Cancel'},{label:'Apply mask',primary:true,cb:()=>{const q=active();if(!q||!q.mask)return;q.mView=false;q.mOff=false;setMask('apply');q.mk=null;renderProps();toast('Mask applied to the layer');}}]);return;}
  if(k==='refine'){ACT.selMaskFromMask();return;}
  if(k==='sel'){
    const c=mkCanvas(l.mask.width,l.mask.height);cctx(c).drawImage(l.mask,0,0);setSelection(layerToDocCanvas(l,c),'new');toast('Mask loaded as a selection');renderProps();return;}
});
/* selection / shape / path buttons */
document.addEventListener('click',e=>{
  const t=e.target.closest&&e.target.closest('[data-selp],[data-shp],[data-pth]');if(!t)return;
  if(t.dataset.selp){const k=t.dataset.selp;
    if(k==='sam')ACT.selMask();
    else if(k==='hair'){ACT.selMask();if(SM.on){SM.p.hair=60;const i=document.querySelector('#sampanel [data-sm="hair"]');if(i){i.value=60;const b=document.querySelector('#sampanel [data-smv="hair"]');if(b)b.textContent=60;}smUpdate(true,true);}}
    else if(k==='rmbg')ACT.removeBg&&ACT.removeBg();
    else if(k==='mask')ACT.maskSel&&ACT.maskSel();
    else if(k==='inv'){const b=S.sel;ACT.selInv();commitSel('Invert selection',b);renderProps();}
    else if(k==='save')ACT.saveSel&&ACT.saveSel();
    else if(k==='none')ACT.selNone();
  }
  else if(t.dataset.pth){if(t.dataset.pth==='sel')penSelDialog();else ACT.pathMask();}
  else if(t.dataset.shp){shapeDialog(t.dataset.shp);}
});
/* shape layer -> selection / mask with feather (the vector shape is not changed) */
function shapeDialog(kind){
  const l=active();if(!l||l.type!=='shape'){toast('Select a shape layer first');return;}
  const W=doc.w,H=doc.h;
  modalOpen(kind==='sel'?'Selection from shape':'Mask from shape','<div class="row"><label>Feather radius <input type="number" id="sh-f" value="0" min="0" max="'+fthNumMax(W,H)+'" step="0.1" style="width:90px"> px</label></div>'
    +'<p class="muted">'+(kind==='sel'?'Makes a selection from the outline of the shape.':'Makes a layer mask on the layer below the shape. Its Feather stays adjustable in Properties.')+' The shape layer itself stays a vector.</p>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const r=clamp(+$('#sh-f').value||0,0,fthNumMax(W,H)),raw=layerToDocCanvas(l,l.canvas);
      if(kind==='sel'){
        const before=S.sel,n=r>0?fthCanvas(fthGauss(fthPlane(raw),W,H,fthRadiusToSigma(r)),W,H):raw;
        setSelection(n,'new');if(!S.sel){toast('The shape selects nothing');return;}
        const p=SELD();p.feather=r;SELM.set(S.sel,{base:cloneCanvas(raw),p});commitSel('Selection from shape',before);renderProps();toast('Selection made from the shape');return;}
      const i=doc.layers.indexOf(l),tg=doc.layers[i-1];
      if(!tg||tg.type==='adjust'){toast('Put a photo layer below the shape first');return;}
      if(tg.mask){toast('The layer below already has a mask. Delete it first.');return;}
      const keep=S.sel;S.sel=null;setSelection(raw,'new');
      if(!S.sel){S.sel=keep;toast('The shape selects nothing');return;}
      const loc=selAlphaCanvasLocal(tg),m=mkCanvas(loc.width,loc.height);cctx(m).drawImage(loc,0,0);S.sel=keep;
      tg.mask=m;tg.mOff=false;tg.mView=false;tg.editMask=true;tg.mver++;touch(tg);mkEnsure(tg);tg.mk.p.feather=r;if(r>0)mkRebuild(tg);
      doc.active=tg.id;commit('Mask from shape');refreshLayers();renderProps();toast('Layer mask made from the shape');
    }}],root=>{root.querySelector('#sh-f').focus();});
}
/* Refine Mask opens the Select and Mask workspace on the mask itself */
ACT.selMaskFromMask=D(()=>{
  const l=active();if(!l||!l.mask){toast('This layer has no mask');return;}
  const keep=S.sel;S.sel=null;ACT.selMask();
  if(!SM.on){S.sel=keep;return;}
  SM.origSel=keep;SM.fm={keep};
});
{const _sc=smClose;smClose=function(apply){const fm=SM.fm;_sc(apply);if(fm){SM.fm=null;S.sel=fm.keep;FTH_SELREF=null;redraw();renderProps();}};}

/* ---------- Select and Mask: "On Layers" preview ---------- */
{
  const _pb=smPreviewBuild;smPreviewBuild=function(){_pb();SM.stamp=(SM.stamp||0)+1;};
  const _ls=layerSource;
  layerSource=function(l){
    if(SM.on&&SM.p.view==='layers'&&SM.alpha&&l.id===SM.lid&&doc===SM.doc){
      const key=SM.stamp+':'+l.ver;
      if(!l._smc||l._smc.key!==key){
        const w=l.canvas.width,h=l.canvas.height,n=mkCanvas(w,h),x=cctx(n);x.drawImage(l.canvas,0,0);x.globalCompositeOperation='destination-in';
        x.drawImage(aiAlphaCanvas(SM.alpha,SM.ww,SM.hh,w,h),0,0);l._smc={key,canvas:n};
      }
      return l._smc.canvas;
    }
    return _ls(l);
  };
}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent='.fth{margin:4px 0 8px}.fth .sl{display:grid;grid-template-columns:62px 1fr 64px 18px;gap:6px;align-items:center}.fth .nv{width:64px}.fth em{font-style:normal;opacity:.7;font-size:11px}'
 +'.fthb{display:flex;gap:4px;margin:2px 0 0 68px}.fthb button{padding:1px 8px;font-size:12px}.fth .fn{margin:2px 0 0 68px;font-size:11px}.pbtns.mk3{display:flex;flex-wrap:wrap;gap:5px;margin:6px 0}.pbtns.mk3 button{flex:1 1 auto}.rrow{display:block;margin:3px 0}';
 document.head.appendChild(st);}
