/* ===== Photo Studio (built-in plugin): one-slider AI-style enhance, light, atmosphere, portrait and sky tools ===== */
const PS_DEF=[
 ['Enhance','enh','Enhance (auto)',0,100,0],
 ['Light','exp','Exposure',-100,100,0],['Light','brl','Brilliance',-100,100,0],['Light','con','Contrast',-100,100,0],['Light','sup','Supercontrast',0,100,0],['Light','sl','Studio light',0,100,0],['Light','sla','Light direction',0,360,315],
 ['Colour','wrm','Warmth',-100,100,0],['Colour','tnt','Tint',-100,100,0],['Colour','sat','Saturation',-100,100,0],['Colour','vib','Vibrance',-100,100,0],['Colour','spl','Teal and orange',0,100,0],
 ['Detail','str','Structure',-100,100,0],['Detail','ssh','Supersharp',0,100,0],['Detail','nr','Noise reduction',0,100,0],
 ['Atmosphere','dh','Dehaze',-100,100,0],['Atmosphere','fog','Fog',0,100,0],['Atmosphere','gh','Golden hour',0,100,0],['Atmosphere','glo','Glow',0,100,0],
 ['Portrait','skn','Skin smoothing',0,100,0],['Portrait','bok','Background blur (finds the subject)',0,100,0],
 ['Finish','vg','Vignette',-100,100,0],['Finish','grn','Film grain',0,100,0]
];
const PS_SKIES={none:'No sky change',day:'Blue day',sunset:'Sunset',dramatic:'Dramatic storm',night:'Night',pastel:'Soft pastel'};
const PS_LOOKS={
 'Cinematic':{enh:30,con:20,spl:55,sat:-8,vg:30,grn:15},
 'Golden hour':{gh:70,wrm:25,brl:20,glo:20,enh:20},
 'Moody':{exp:-15,con:35,sat:-20,vg:45,str:25,fog:12},
 'Fresh and bright':{exp:12,brl:35,vib:30,wrm:-6,enh:25},
 'Vintage film':{wrm:22,sat:-22,con:-8,grn:45,vg:25,spl:25},
 'Black and white':{sat:-100,con:35,str:35,vg:25,grn:20},
 'Soft portrait':{skn:60,brl:25,glo:25,wrm:8,enh:15},
 'Crisp landscape':{enh:45,dh:30,str:35,sup:30,vib:30}
};
const PS={base:null,pw:0,ph:0,sub:null,skyMask:null,P:{},sky:'none',skyAmt:100,work:null,busy:false};
const psClamp=v=>v<0?0:v>255?255:v;
function psBox(src,w,h,r){
  r=Math.max(1,r|0);const tmp=new Float32Array(w*h),out=new Float32Array(w*h),k=1/(2*r+1);
  for(let y=0;y<h;y++){const o=y*w;let s=0;for(let i=-r;i<=r;i++)s+=src[o+Math.min(w-1,Math.max(0,i))];
    for(let x=0;x<w;x++){tmp[o+x]=s*k;s+=src[o+Math.min(w-1,x+r+1)]-src[o+Math.max(0,x-r)];}}
  for(let x=0;x<w;x++){let s=0;for(let i=-r;i<=r;i++)s+=tmp[Math.min(h-1,Math.max(0,i))*w+x];
    for(let y=0;y<h;y++){out[y*w+x]=s*k;s+=tmp[Math.min(h-1,y+r+1)*w+x]-tmp[Math.max(0,y-r)*w+x];}}
  return out;
}
function psBlur(p,w,h,r){r=Math.max(1,r);let a=p;const rr=Math.max(1,Math.round(r/1.7));for(let i=0;i<3;i++)a=psBox(a,w,h,rr);return a;}
function psProcess(src,P,sub,skyM,skyCv){
  const w=src.width,h=src.height,n=w*h,m=Math.max(w,h),R=f=>Math.max(1,Math.round(m*f));
  const s=src.data,r=new Float32Array(n),g=new Float32Array(n),b=new Float32Array(n);
  for(let i=0,j=0;i<n;i++,j+=4){r[i]=s[j];g[i]=s[j+1];b[i]=s[j+2];}
  const lum=i=>0.299*r[i]+0.587*g[i]+0.114*b[i];
  const has=k=>P[k]!==undefined&&P[k]!==0;
  // sky replacement first so everything else is applied on top
  if(skyM&&skyCv&&P.__sky&&P.__sky!=='none'){
    const sd=cctx(skyCv).getImageData(0,0,w,h).data,k0=(P.__skyAmt==null?100:P.__skyAmt)/100;
    for(let i=0;i<n;i++){const a=skyM[i]/255*k0;if(a<=0)continue;const j=i*4;
      // keep a little of the old brightness so trees and edges do not look cut out
      r[i]=r[i]*(1-a)+sd[j]*a;g[i]=g[i]*(1-a)+sd[j+1]*a;b[i]=b[i]*(1-a)+sd[j+2]*a;}
  }
  if(has('enh')){
    const k=P.enh/100,hist=new Uint32Array(256);for(let i=0;i<n;i++)hist[Math.round(lum(i))]++;
    let a=0,lo=0,hi=255;const t=n*0.005;for(let v=0;v<256;v++){a+=hist[v];if(a>t){lo=v;break;}}a=0;for(let v=255;v>=0;v--){a+=hist[v];if(a>t){hi=v;break;}}
    const l2=lo*k,h2=255-(255-hi)*k,sc=255/Math.max(40,h2-l2);let mean=0;for(let i=0;i<n;i++)mean+=lum(i);mean/=n;
    const gam=Math.log(0.46)/Math.log(Math.max(0.1,Math.min(0.9,((mean-l2)*sc)/255)));const gg=1+(gam-1)*k*0.6;
    for(let i=0;i<n;i++){let R0=Math.pow(psClamp((r[i]-l2)*sc)/255,gg)*255,G0=Math.pow(psClamp((g[i]-l2)*sc)/255,gg)*255,B0=Math.pow(psClamp((b[i]-l2)*sc)/255,gg)*255;
      const L=0.299*R0+0.587*G0+0.114*B0,mx=Math.max(R0,G0,B0),mn=Math.min(R0,G0,B0),sat=mx?(mx-mn)/mx:0,v=1+k*0.35*(1-sat);
      r[i]=L+(R0-L)*v;g[i]=L+(G0-L)*v;b[i]=L+(B0-L)*v;}
  }
  if(has('exp')){const f=Math.pow(2,P.exp/50);for(let i=0;i<n;i++){r[i]*=f;g[i]*=f;b[i]*=f;}}
  if(has('brl')){const k=P.brl/100;for(let i=0;i<n;i++){const L=lum(i)/255,up=1+k*0.7*(1-L)*(1-L),dn=k*22*L*L*L;r[i]=r[i]*up-dn;g[i]=g[i]*up-dn;b[i]=b[i]*up-dn;}}
  if(has('con')){const k=1+P.con/100;for(let i=0;i<n;i++){r[i]=(r[i]-128)*k+128;g[i]=(g[i]-128)*k+128;b[i]=(b[i]-128)*k+128;}}
  if(has('dh')){
    const amt=P.dh/100;
    if(amt>0){const mn=new Float32Array(n);for(let i=0;i<n;i++)mn[i]=Math.min(r[i],g[i],b[i]);const dc=psBlur(mn,w,h,R(0.012));
      const srt=Float32Array.from(dc).sort();let A=0,c=0;for(let i=Math.floor(n*0.998);i<n;i++){A+=srt[i];c++;}A=Math.max(120,A/c);
      for(let i=0;i<n;i++){const t=Math.max(0.3,1-0.92*dc[i]/A);r[i]=r[i]+((r[i]-A)/t+A-r[i])*amt;g[i]=g[i]+((g[i]-A)/t+A-g[i])*amt;b[i]=b[i]+((b[i]-A)/t+A-b[i])*amt;}}
    else{const a=-amt*0.35;for(let i=0;i<n;i++){r[i]=r[i]*(1-a)+232*a;g[i]=g[i]*(1-a)+232*a;b[i]=b[i]*(1-a)+232*a;}}
  }
  if(has('str')||has('sup')){
    const sA=(P.str||0)/100*1.3,sB=(P.sup||0)/100*0.9;
    const bs=has('str')?[psBlur(r,w,h,R(0.007)),psBlur(g,w,h,R(0.007)),psBlur(b,w,h,R(0.007))]:null;
    const bl=has('sup')?[psBlur(r,w,h,R(0.05)),psBlur(g,w,h,R(0.05)),psBlur(b,w,h,R(0.05))]:null;
    for(let i=0;i<n;i++){let dr=0,dg=0,db=0;
      if(bs){dr+=(r[i]-bs[0][i])*sA;dg+=(g[i]-bs[1][i])*sA;db+=(b[i]-bs[2][i])*sA;}
      if(bl){dr+=(r[i]-bl[0][i])*sB;dg+=(g[i]-bl[1][i])*sB;db+=(b[i]-bl[2][i])*sB;}
      r[i]+=dr;g[i]+=dg;b[i]+=db;}
  }
  if(has('wrm')||has('tnt')){const w1=(P.wrm||0)/300,t1=(P.tnt||0)/400;for(let i=0;i<n;i++){r[i]*=1+w1+t1*0.5;b[i]*=1-w1+t1*0.5;g[i]*=1-t1;}}
  if(has('sat')||has('vib')){const sa=1+(P.sat||0)/100,vb=(P.vib||0)/100;
    for(let i=0;i<n;i++){const L=lum(i),mx=Math.max(r[i],g[i],b[i]),mn=Math.min(r[i],g[i],b[i]),sat=mx>0?(mx-mn)/mx:0,k=sa*(1+vb*(1-sat));r[i]=L+(r[i]-L)*k;g[i]=L+(g[i]-L)*k;b[i]=L+(b[i]-L)*k;}}
  if(has('spl')){const k=P.spl/100;for(let i=0;i<n;i++){const L=psClamp(lum(i))/255,sh=(1-L)*(1-L),hi=L*L;r[i]+=k*(-18*sh+30*hi);g[i]+=k*(10*sh+8*hi);b[i]+=k*(28*sh-26*hi);}}
  if(has('gh')){const k=P.gh/100;for(let y=0,i=0;y<h;y++)for(let x=0;x<w;x++,i++){const f=Math.max(0,1-Math.hypot((x-w*0.85)/(w*0.9),(y-h*0.1)/(h*0.9))),L=lum(i)/255;
    r[i]=r[i]*(1+k*0.2)+k*(40*f+10*L);g[i]=g[i]*(1+k*0.03)+k*(14*f);b[i]=b[i]*(1-k*0.3)-k*(10*f);}}
  if(has('sl')){const k=P.sl/100,a=(P.sla==null?315:P.sla)*Math.PI/180,cx=Math.cos(a),cy=Math.sin(a);
    for(let y=0,i=0;y<h;y++)for(let x=0;x<w;x++,i++){const t=((x-w/2)*cx+(y-h/2)*cy)/(m*0.55),f=1+k*0.5*Math.max(-1,Math.min(1,t))*-1;r[i]*=f;g[i]*=f;b[i]*=f;}}
  if(has('fog')){const k=P.fog/100,sm=Math.max(2,R(0.25));let nz=new Float32Array(n);for(let y=0,i=0;y<h;y++)for(let x=0;x<w;x++,i++)nz[i]=fxFbm(x/sm*1.2,y/sm*1.2,5,4);
    for(let y=0,i=0;y<h;y++)for(let x=0;x<w;x++,i++){const a=k*0.55*Math.min(1,nz[i]*1.4)*(0.45+0.55*y/h);r[i]=r[i]*(1-a)+226*a;g[i]=g[i]*(1-a)+229*a;b[i]=b[i]*(1-a)+235*a;}}
  if(has('glo')){const k=P.glo/100,br=new Float32Array(n),bg=new Float32Array(n),bb=new Float32Array(n);
    for(let i=0;i<n;i++){const L=lum(i)/255,t=Math.max(0,(L-0.55)/0.45);br[i]=r[i]*t;bg[i]=g[i]*t;bb[i]=b[i]*t;}
    const rad=R(0.03),B1=psBlur(br,w,h,rad),B2=psBlur(bg,w,h,rad),B3=psBlur(bb,w,h,rad);
    for(let i=0;i<n;i++){r[i]=255-(255-r[i])*(255-B1[i]*k*1.1)/255;g[i]=255-(255-g[i])*(255-B2[i]*k*1.1)/255;b[i]=255-(255-b[i])*(255-B3[i]*k*1.1)/255;}}
  if(has('skn')||has('nr')){
    const ks=(P.skn||0)/100,kn=(P.nr||0)/100,rad=Math.max(1,R(ks?0.0035:0.0012));const br=psBlur(r,w,h,rad),bg=psBlur(g,w,h,rad),bb=psBlur(b,w,h,rad);
    for(let i=0;i<n;i++){
      const Y=0.299*r[i]+0.587*g[i]+0.114*b[i],cb=128-0.1687*r[i]-0.3313*g[i]+0.5*b[i],cr=128+0.5*r[i]-0.4187*g[i]-0.0813*b[i];
      const skin=Math.max(0,1-Math.max(Math.abs(cb-102)/26,Math.abs(cr-150)/26,Y<30?1:0)),L2=0.299*br[i]+0.587*bg[i]+0.114*bb[i],diff=Math.abs(Y-L2);
      const a=Math.min(1,ks*skin*Math.exp(-(diff*diff)/(18*18))*1.1+kn*Math.exp(-(diff*diff)/(10*10))*0.85);
      if(a>0){r[i]+=(br[i]-r[i])*a;g[i]+=(bg[i]-g[i])*a;b[i]+=(bb[i]-b[i])*a;}}
  }
  if(has('bok')&&sub){
    const k=P.bok/100,rad=Math.max(2,R(0.012+0.035*k)),br=psBlur(r,w,h,rad),bg=psBlur(g,w,h,rad),bb=psBlur(b,w,h,rad),mk=new Float32Array(n);
    for(let i=0;i<n;i++)mk[i]=sub[i]/255;const sm=psBlur(mk,w,h,Math.max(1,R(0.003)));
    for(let i=0;i<n;i++){const a=Math.min(1,Math.max(0,sm[i]*1.15-0.05));r[i]=br[i]+(r[i]-br[i])*a;g[i]=bg[i]+(g[i]-bg[i])*a;b[i]=bb[i]+(b[i]-bb[i])*a;}
  }
  if(has('ssh')){const k=P.ssh/100*1.6,rad=Math.max(1,R(0.0016)),bl=[psBlur(r,w,h,rad),psBlur(g,w,h,rad),psBlur(b,w,h,rad)];
    for(let i=0;i<n;i++){r[i]+=(r[i]-bl[0][i])*k;g[i]+=(g[i]-bl[1][i])*k;b[i]+=(b[i]-bl[2][i])*k;}}
  if(has('vg')){const k=P.vg/100;for(let y=0,i=0;y<h;y++)for(let x=0;x<w;x++,i++){const d=Math.hypot((x-w/2)/(w/2),(y-h/2)/(h/2))/1.4142,t=Math.max(0,d-0.35)/0.65,f=k>0?1-k*0.75*t*t:1+(-k)*0.6*t*t;r[i]*=f;g[i]*=f;b[i]*=f;}}
  if(has('grn')){const k=P.grn/100*34;for(let y=0,i=0;y<h;y++)for(let x=0;x<w;x++,i++){const L=lum(i)/255,nz=(fxHash(x,y,11)+fxHash(x>>1,y>>1,12)*0.6-0.8)*k*(1-Math.abs(L-0.5)*1.2);r[i]+=nz;g[i]+=nz;b[i]+=nz;}}
  const out=new ImageData(w,h),o=out.data;
  for(let i=0,j=0;i<n;i++,j+=4){o[j]=psClamp(r[i]);o[j+1]=psClamp(g[i]);o[j+2]=psClamp(b[i]);o[j+3]=s[j+3];}
  return out;
}
/* sky: find it (top-connected, blue or bright and flat) and paint a new one */
function psFindSky(img){
  const w=img.width,h=img.height,d=img.data,n=w*h,cand=new Uint8Array(n);
  for(let y=0;y<h*0.8;y++)for(let x=0;x<w;x++){const i=(y*w+x),j=i*4,r=d[j],g=d[j+1],b=d[j+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),L=(r+g+b)/3,sat=mx?(mx-mn)/mx:0;
    const blue=b>r+10&&b>=g-12&&L>70,white=L>190&&sat<0.14,dusk=(r>g&&g>b&&L>110&&y<h*0.5&&sat>0.15&&sat<0.7&&x>=0);
    if(blue||white||dusk)cand[i]=1;}
  const q=new Int32Array(n),sky=new Uint8Array(n);let qh=0,qt=0;
  for(let x=0;x<w;x++)if(cand[x]){sky[x]=1;q[qt++]=x;}
  while(qh<qt){const p=q[qh++],x=p%w,y=(p/w)|0;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=w||ny>=h)continue;const k=ny*w+nx;if(cand[k]&&!sky[k]){sky[k]=1;q[qt++]=k;}}}
  const f=new Float32Array(n);for(let i=0;i<n;i++)f[i]=sky[i]*255;
  const sm=psBlur(f,w,h,Math.max(1,Math.round(Math.max(w,h)*0.004))),out=new Uint8ClampedArray(n);
  let cnt=0;for(let i=0;i<n;i++){const v=sm[i];out[i]=v<40?0:v>215?255:(v-40)/175*255;if(out[i]>128)cnt++;}
  return {mask:out,frac:cnt/n};
}
function psSkyCanvas(kind,w,h){
  const c=mkCanvas(w,h),x=cctx(c);
  const sets={day:[[0,'#2b6fd0'],[0.55,'#6fb2f0'],[1,'#cfe8fb']],sunset:[[0,'#2a2f6b'],[0.4,'#b4507a'],[0.7,'#f08a4b'],[1,'#ffd27a']],dramatic:[[0,'#2b3340'],[0.5,'#5c6772'],[1,'#a7a89f']],night:[[0,'#04081a'],[0.6,'#0d1b3f'],[1,'#25406e']],pastel:[[0,'#a9c8f5'],[0.5,'#f2c9e0'],[1,'#fde6c8']]}[kind]||[[0,'#6fb2f0'],[1,'#cfe8fb']];
  const g=x.createLinearGradient(0,0,0,h);sets.forEach(s=>g.addColorStop(s[0],s[1]));x.fillStyle=g;x.fillRect(0,0,w,h);
  const id=x.getImageData(0,0,w,h),d=id.data,m=Math.max(w,h),cl=kind==='night'?0.12:kind==='dramatic'?0.9:kind==='sunset'?0.45:0.55;
  for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){const j=(y*w+xx)*4,nz=fxFbm(xx/(m*0.22),y/(m*0.1),9,5),a=Math.max(0,(nz-0.5)*2.2)*cl;
    const tone=kind==='sunset'?[255,214,190]:kind==='dramatic'?[196,200,205]:kind==='night'?[90,110,150]:[255,255,255];
    d[j]=d[j]*(1-a)+tone[0]*a;d[j+1]=d[j+1]*(1-a)+tone[1]*a;d[j+2]=d[j+2]*(1-a)+tone[2]*a;}
  if(kind==='night'){for(let i=0;i<w*h/1600;i++){const px=(fxHash(i,1,3)*w)|0,py=(fxHash(i,2,3)*h*0.8)|0,j=(py*w+px)*4,v=150+fxHash(i,3,3)*105;d[j]=d[j+1]=d[j+2]=v;}}
  x.putImageData(id,0,0);return c;
}
/* ---- window ---- */
function openPhotoStudio(){
  const l=doc&&active();if(!l||l.type==='adjust'||l.locked){toast('Select an unlocked photo layer first');return;}
  ensureRaster(l);
  const full=l.canvas,k=Math.min(1,960/Math.max(full.width,full.height)),pw=Math.max(2,Math.round(full.width*k)),ph=Math.max(2,Math.round(full.height*k));
  const pc=mkCanvas(pw,ph);cctx(pc).drawImage(full,0,0,pw,ph);
  Object.assign(PS,{base:cctx(pc).getImageData(0,0,pw,ph),pw,ph,sub:null,skyMask:null,P:{sla:315},sky:'none',skyAmt:100,full:l});
  PS_DEF.forEach(d=>{PS.P[d[1]]=d[5];});
  const groups=[...new Set(PS_DEF.map(d=>d[0]))];
  const sliders=g=>PS_DEF.filter(d=>d[0]===g).map(d=>'<label class="sl"><span>'+d[2]+'</span><input type="range" data-ps="'+d[1]+'" min="'+d[3]+'" max="'+d[4]+'" value="'+d[5]+'"><output>'+d[5]+'</output></label>').join('');
  modalOpen('Photo Studio','<div class="ps"><div class="psv"><canvas id="ps-cv"></canvas><div class="row psb"><button id="ps-before" title="Hold to see the original">Hold: before</button><button id="ps-auto">Auto enhance</button><button id="ps-reset">Reset</button></div></div><div class="psc"><div class="h">Looks</div><div class="pschips">'+Object.keys(PS_LOOKS).map(k=>'<button class="chip" data-look="'+esc(k)+'">'+esc(k)+'</button>').join('')+'</div>'
   +groups.map(g=>'<details class="tpanel"'+(g==='Enhance'||g==='Light'?' open':'')+'><summary>'+g+'</summary>'+sliders(g)+(g==='Atmosphere'?'<div class="row"><label class="opt">Sky <select id="ps-sky">'+Object.keys(PS_SKIES).map(k=>'<option value="'+k+'">'+PS_SKIES[k]+'</option>').join('')+'</select></label></div><p class="muted" id="ps-skynote"></p>':'')+'</details>').join('')+'</div></div>',
   [{label:'Cancel'},{label:'Apply as new layer',cb:()=>psApply(true)},{label:'Apply',primary:true,cb:()=>psApply(false)}],root=>{
    const cv=root.querySelector('#ps-cv');cv.width=pw;cv.height=ph;const cx=cv.getContext('2d');let tm=0,showBefore=false;
    const draw=()=>{try{if(showBefore){cx.putImageData(PS.base,0,0);return;}
      const P=Object.assign({},PS.P,{__sky:PS.sky,__skyAmt:PS.skyAmt});
      const out=psProcess(PS.base,P,PS.sub,PS.skyMask,PS.sky!=='none'?PS.skyCv:null);cx.putImageData(out,0,0);}catch(e){console.error(e);}};
    const later=()=>{clearTimeout(tm);tm=setTimeout(draw,25);};
    const ensureSub=()=>{if(PS.sub)return;toast('Finding the subject...');try{const r=cut_removeBackground(pc,{});PS.sub=r.alpha;}catch(e){toast('Could not find a subject');}};
    const setAll=()=>{root.querySelectorAll('[data-ps]').forEach(i=>{i.value=PS.P[i.dataset.ps];i.nextElementSibling.textContent=i.value;});};
    root.addEventListener('input',e=>{const t=e.target;if(t.dataset.ps){PS.P[t.dataset.ps]=+t.value;t.nextElementSibling.textContent=t.value;if(t.dataset.ps==='bok'&&+t.value>0)setTimeout(()=>{ensureSub();later();},10);else later();}});
    root.addEventListener('change',e=>{const t=e.target;if(t.id==='ps-sky'){PS.sky=t.value;const note=root.querySelector('#ps-skynote');
      if(t.value==='none'){note.textContent='';later();return;}
      const f=psFindSky(PS.base);PS.skyMask=f.mask;PS.skyCv=psSkyCanvas(t.value,pw,ph);note.textContent=f.frac<0.02?'No clear sky found in this picture.':'Sky found ('+Math.round(f.frac*100)+'% of the picture).';later();}});
    root.addEventListener('click',e=>{const c=e.target.closest('[data-look]');if(c){const L=PS_LOOKS[c.dataset.look];PS_DEF.forEach(d=>{PS.P[d[1]]=L[d[1]]!==undefined?L[d[1]]:d[5];});if(PS.P.bok>0)ensureSub();setAll();later();}});
    root.querySelector('#ps-auto').onclick=()=>{PS_DEF.forEach(d=>{PS.P[d[1]]=d[5];});PS.P.enh=65;PS.P.brl=15;PS.P.vib=15;PS.P.str=12;setAll();later();};
    root.querySelector('#ps-reset').onclick=()=>{PS_DEF.forEach(d=>{PS.P[d[1]]=d[5];});PS.sky='none';root.querySelector('#ps-sky').value='none';root.querySelector('#ps-skynote').textContent='';setAll();later();};
    const bb=root.querySelector('#ps-before');['pointerdown'].forEach(ev=>bb.addEventListener(ev,()=>{showBefore=true;draw();}));['pointerup','pointerleave','pointercancel'].forEach(ev=>bb.addEventListener(ev,()=>{if(showBefore){showBefore=false;draw();}}));
    draw();
  },{wide:true});
}
function psApply(asNew){
  const l=PS.full;if(!l||!doc.layers.includes(l))return;
  setTimeout(()=>{try{
    toast('Applying...');const W=l.canvas.width,H=l.canvas.height,src=cctx(l.canvas).getImageData(0,0,W,H);
    let sub=null,skyM=null,skyCv=null;
    const up=(arr,w0,h0)=>{const c=cut_alphaToCanvas(arr,w0,h0),t=mkCanvas(W,H),x=cctx(t);x.imageSmoothingQuality='high';x.drawImage(c,0,0,W,H);const d=x.getImageData(0,0,W,H).data,o=new Uint8ClampedArray(W*H);for(let i=0;i<o.length;i++)o[i]=d[i*4+3];return o;};
    if(PS.P.bok>0&&PS.sub)sub=up(PS.sub,PS.pw,PS.ph);
    if(PS.sky!=='none'&&PS.skyMask){skyM=up(PS.skyMask,PS.pw,PS.ph);skyCv=psSkyCanvas(PS.sky,W,H);}
    const out=psProcess(src,Object.assign({},PS.P,{__sky:PS.sky,__skyAmt:PS.skyAmt}),sub,skyM,skyCv);
    if(asNew){const nl=addLayer({name:l.name+' (studio)',type:'image',w:W,h:H,x:l.x,y:l.y,above:true});nl.s=l.s;nl.r=l.r;cctx(nl.canvas).putImageData(out,0,0);commit('Photo Studio');refreshLayers();}
    else{cctx(l.canvas).putImageData(out,0,0);touch(l);commit('Photo Studio');}
    redraw();toast('Photo Studio applied');
  }catch(e){console.error(e);toast('Could not apply that');}},30);
}
ACT.photoStudio=openPhotoStudio;
{const pm=MENUS.find(m=>m.label==='Plugins');if(pm){const d=Object.getOwnPropertyDescriptor(pm,'items'),g=d.get;Object.defineProperty(pm,'items',{get(){const a=g.call(pm);const i=a.findIndex(x=>x.label==='Mockup Batch...');a.splice(i>=0?i:1,0,al('Photo Studio (enhance, sky, portrait)...','','photoStudio'));return a;}});}}
PLUG_BUILTIN.push({name:'Photo Studio',version:'1.0',desc:'One-slider Enhance, light, dehaze, glow, golden hour, skin smoothing, background blur and sky replacement, with looks. Works on this device, no internet.',open:'photoStudio'});
