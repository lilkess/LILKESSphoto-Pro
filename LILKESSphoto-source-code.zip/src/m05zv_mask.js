/* ===== complete layer mask system =====
   A mask is a canvas stored on the layer (l.mask). Its alpha channel is the mask value:
   opaque = white = visible, transparent = black = hidden, in between = partly visible.
   The photo canvas is never painted on while the mask is edited.
   Extra state: l.mOff (mask disabled), l.mView (View Mask mode, screen only, never exported). */

/* ---- state carried through undo/redo and saved files ---- */
const _meta0=meta;
meta=function(l){const o=_meta0(l);o.mOff=!!l.mOff;return o;};

/* ---- compositing: disabled mask, View Mask (screen only) ---- */
let MVON=false;
const _compose0=compose;
compose=function(ctx,scale){MVON=(typeof vctx!=='undefined'&&ctx===vctx);try{return _compose0(ctx,scale);}finally{MVON=false;}};
const _ls0=layerSource;
layerSource=function(l){
  const src=l.pv||l.canvas;
  if(l.mask&&l.mView&&MVON){
    const key=l.ver+':'+l.mver+':'+l.pvv+':'+l.mView+':'+(l.mOff?1:0);
    if(!l._vc||l._vc.key!==key){
      const w=src.width,h=src.height,n=mkCanvas(w,h),x=cctx(n),mode=l.mView===true?'bw':l.mView;
      const base=()=>l.mOff?src:_ls0(l);
      if(mode==='bw'){x.fillStyle='#000';x.fillRect(0,0,w,h);const t=mkCanvas(w,h),tx=cctx(t);tx.fillStyle='#fff';tx.fillRect(0,0,w,h);tx.globalCompositeOperation='destination-in';tx.drawImage(l.mask,0,0,w,h);x.drawImage(t,0,0);}
      else if(mode==='white'){x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(base(),0,0);}
      else if(mode==='overlay'){x.drawImage(src,0,0);const t=mkCanvas(w,h),tx=cctx(t);tx.fillStyle='rgba(255,0,0,.55)';tx.fillRect(0,0,w,h);tx.globalCompositeOperation='destination-out';tx.drawImage(l.mask,0,0,w,h);x.drawImage(t,0,0);}
      else x.drawImage(base(),0,0);
      l._vc={key,canvas:n};
    }
    return l._vc.canvas;
  }
  if(l.mask&&l.mOff)return src;
  return _ls0(l);
};

/* ---- helpers ---- */
const maskLayer=(quiet)=>{const l=active();if(!l){if(!quiet)toast('Select a layer first');return null;}if(l.locked){if(!quiet)toast('This layer is locked');return null;}if(l.type==='adjust'){if(!quiet)toast('Adjustment layers already have their own mask. Pick a photo layer.');return null;}return l;};
function selHasPixels(){return !!(S.sel&&S.sel.bbox&&S.sel.bbox.w>0&&S.sel.bbox.h>0);}
function maskTouch(l,label){l.mver++;touch(l);if(label)commit(label);refreshLayers();redraw();}
/* selection -> layer mask: selected = white (visible), the rest = black (hidden). Any old mask is kept and combined with it. */
function maskFromSelection(l){
  if(!selHasPixels()){toast('Make a selection first (Select Subject, Pen, Lasso, Wand...)');return false;}
  const w=l.canvas.width,h=l.canvas.height,n=mkCanvas(w,h),x=cctx(n);
  x.drawImage(selAlphaCanvasLocal(l),0,0);
  if(l.mask){x.globalCompositeOperation='destination-in';x.drawImage(l.mask,0,0,w,h);}
  l.mask=n;l.mOff=false;l.mView=false;l.editMask=true;
  maskTouch(l,'Layer mask from selection');return true;
}
const _maskReveal0=ACT.maskReveal;
ACT.maskReveal=D(()=>{
  const l=maskLayer();if(!l)return;
  if(selHasPixels()){if(maskFromSelection(l))toast('Layer mask added. The selected area stays visible and the rest is hidden. Your picture is not erased.');return;}
  if(l.mask){l.editMask=true;l.mOff=false;refreshLayers();renderProps();toast('This layer already has a mask. Its properties are open.');return;}
  _maskReveal0();
});
ACT.maskSel=D(()=>{const l=maskLayer();if(!l)return;if(maskFromSelection(l))toast('Layer mask made from the selection');});
ACT.maskHideSel=D(()=>{const l=maskLayer();if(!l)return;if(!selHasPixels()){toast('Make a selection first');return;}setMask('hsel');});

/* ---- Select Subject (honest: reports failure, keeps manual tools usable) ---- */
const alphaCover=a=>{let n=0;for(let i=0;i<a.length;i++)if(a[i]>127)n++;return n/a.length;};
const _brDetect0=brDetect;
brDetect=async function(canvas,kind){
  const r=await _brDetect0(canvas,kind);
  const c=alphaCover(r.alpha);
  if(c<0.004)throw new Error('no subject');
  if(c>0.985)throw new Error('whole picture');
  return r;
};
ACT.selSubject=D(()=>{
  const l=maskLayer();if(!l)return;
  if(!isPixelLayer(l)){toast('Select a photo layer first');return;}
  toast('Finding the subject...');
  setTimeout(async()=>{
    try{
      const r=await brDetect(l.canvas,(S.bgr&&S.bgr.subject)||'auto');
      const m=cut_alphaToCanvas(r.alpha,l.canvas.width,l.canvas.height);
      setSelection(layerToDocCanvas(l,m),'new');
      toast((r.how==='person'?'Person selected. ':'Subject selected. ')+'Click Add Layer Mask to hide the background.');
      subjBarShow();
    }catch(err){
      console.error(err);
      toast(err&&err.message==='whole picture'?'The subject fills the whole picture, so there is no background to separate. Use the Lasso, Pen or Quick Selection tool instead.':'Could not find a clear subject in this picture. Nothing was changed. Try the Object Selection, Quick Selection or Pen tool.');
    }
  },40);
});

/* ---- Pen tool: path <-> selection <-> mask ---- */
const penNeed=()=>needPath();
const pathToSel=(mode,msg)=>D(()=>{if(pathAsSelection(mode))toast(msg);});
ACT.pathSelNew=pathToSel('new','Selection made from the path');
ACT.pathSelAdd=pathToSel('add','Path added to the selection');
ACT.pathSelSub=D(()=>{if(!S.sel){toast('Make a selection first, then subtract the path from it');return;}if(pathAsSelection('sub'))toast('Path subtracted from the selection');});
ACT.pathSelInt=D(()=>{if(!S.sel){toast('Make a selection first, then intersect the path with it');return;}if(pathAsSelection('int'))toast('Selection kept only where it overlaps the path');});
ACT.pathFeather=D(()=>{
  if(!S.sel){if(!penNeed())return;pathAsSelection('new');}
  askNumber('Feather selection','Feather radius (px)',8,1,250,v=>selMorph('feather',v));
});
ACT.pathInvert=D(()=>{
  if(!S.sel){if(!penNeed())return;pathAsSelection('new');}
  selInverse();toast('Selection inverted');
});
ACT.pathRefine=D(()=>{
  const ph=penNeed();if(!ph)return;
  let n=0;ph.path.subs.forEach(s=>{if(s.pts.length>2){vec_autoSmooth(s,0.5);n++;}});
  if(!n){toast('Add at least 3 points to the path first');return;}
  commit('Refine path');redraw();toast('Path smoothed. Drag points or handles with the Direct Selection tool to adjust it, then make the selection or mask.');
});
ACT.pathMaskFeather=D(()=>{ACT.pathSelNew();});
const PEN_OPS='<span class="opt seg" role="group" aria-label="Path to selection and mask">'
  +'<button data-act="pathSelAdd" title="Add the path to the current selection">+ Selection</button>'
  +'<button data-act="pathSelSub" title="Subtract the path from the current selection">- Selection</button>'
  +'<button data-act="pathSelInt" title="Keep only the overlap of the path and the selection">Intersect</button></span>'
  +'<button data-act="pathFeather" title="Soften the selection edge">Feather</button>'
  +'<button data-act="pathInvert" title="Swap selected and unselected">Invert</button>'
  +'<button data-act="pathRefine" title="Smooth the corners of the path">Refine path</button>'
  +'<button class="primary" data-act="pathMask" title="Create a layer mask from the path">Mask from path</button>';
for(const id of ['dsel','psel']){const T=TOOLS[id];if(T&&T.opts&&!T._mk){const o=T.opts;T.opts=()=>o()+PEN_OPS;T._mk=1;}}
{const _po=penOpts;penOpts=function(extra){return _po((extra||'')+PEN_OPS);};}
/* extra entries in the Pen right-click menu */
{const _ph=ACT.pathMask;ACT.pathMask=D(()=>{_ph();const l=active();if(l&&l.mask){l.mOff=false;l.editMask=true;refreshLayers();renderProps();}});}

/* ---- mask commands for the Properties panel ---- */
function maskCmd(k){
  const l=active();if(!l||!l.mask){toast('This layer has no mask');return;}
  if(k==='dis'){l.mOff=!l.mOff;maskTouch(l,l.mOff?'Disable mask':'Enable mask');toast(l.mOff?'Mask disabled. The whole layer shows. Enable it to bring the mask back.':'Mask enabled');renderProps();return;}
  if(k==='view'){l.mView=l.mView?false:'bw';l._vc=null;maskTouch(l);renderProps();toast(l.mView?'Viewing the mask: white is visible, black is hidden':'Back to the normal view');return;}
  if(k==='del'){l.mView=false;l.mOff=false;setMask('del');renderProps();toast('Mask deleted. The picture is untouched.');return;}
  if(k==='apply'){
    modalOpen('Apply mask','<p>Applying the mask permanently erases the hidden parts of this layer. The mask is then removed.</p><p class="muted">You can still undo it with Undo.</p>',
      [{label:'Cancel'},{label:'Apply mask',primary:true,cb:()=>{const q=active();if(!q||!q.mask)return;q.mView=false;if(q.mOff){q.mOff=false;}setMask('apply');renderProps();toast('Mask applied to the layer');}}]);return;}
  if(k==='rest'){
    const w=l.mask.width,h=l.mask.height,x=cctx(l.mask);x.save();x.globalCompositeOperation='source-over';x.fillStyle='#fff';x.clearRect(0,0,w,h);x.fillRect(0,0,w,h);x.restore();
    l.mOff=false;maskTouch(l,'Restore original visibility');renderProps();toast('Everything is visible again. The mask is kept, so you can paint it again.');return;}
  if(k==='refine'){
    const m=maskState(l);m.p.smooth=Math.max(m.p.smooth,30);m.p.contrast=Math.max(m.p.contrast,20);maskRebuild(l,m);commit('Refine mask');renderProps();redraw();toast('Mask edge cleaned. Use the sliders for more control.');return;}
  if(k==='sam'){selectAndMask(l);return;}
}
/* Select and Mask: view modes plus Smooth / Feather / Contrast / Shift edge, with Cancel */
function selectAndMask(l){
  const m=maskState(l),p0=Object.assign({},m.p),base0=cloneCanvas(l.mask);
  const sl=(k,lab,min,max)=>'<label class="sl"><span>'+lab+'</span><input type="range" data-sam="'+k+'" min="'+min+'" max="'+max+'" value="'+m.p[k]+'"></label>';
  modalOpen('Select and Mask',
    '<label class="opt">View <select id="sam-view"><option value="overlay">Overlay (red = hidden)</option><option value="bw">Black and white</option><option value="white">On white</option><option value="layer">On layer</option></select></label>'
    +sl('smooth','Smooth',0,100)+sl('feather','Feather',0,100)+sl('contrast','Contrast',-100,100)+sl('shift','Shift edge',-100,100)
    +'<p class="muted">Changes only the mask. The picture is never altered. Cancel puts the mask back as it was.</p>',
    [{label:'Cancel',cb:()=>{l.mask=base0;l.mView=false;m.p=p0;maskTouch(l);renderProps();}},
     {label:'OK',primary:true,cb:()=>{l.mView=false;maskTouch(l,'Select and Mask');renderProps();}}],
    ()=>{
      l.mView='overlay';maskTouch(l);
      const root=$('#mbody');
      root.querySelector('#sam-view').onchange=e=>{l.mView=e.target.value;l._vc=null;l.mver++;touch(l);redraw();};
      root.addEventListener('input',e=>{const t=e.target;if(!t.dataset||!t.dataset.sam)return;m.p[t.dataset.sam]=+t.value;maskRebuild(l,m);redraw();});
    });
}
/* mask panel: extra command rows */
{const _rp2=renderProps;
 renderProps=function(){
  _rp2();
  const d=document.getElementById('p-maskp');if(!d)return;const l=doc&&active();if(!l||!l.mask)return;
  d.querySelector('h4').textContent='Layer Mask Properties'+(l.mOff?' (disabled)':'');
  const r=document.createElement('div');r.className='pbtns mk2';
  r.innerHTML='<button data-mk2="dis" aria-pressed="'+!!l.mOff+'">'+(l.mOff?'Enable mask':'Disable mask')+'</button>'
    +'<button data-mk2="view" aria-pressed="'+!!l.mView+'">'+(l.mView?'Exit mask view':'View mask')+'</button>'
    +'<button data-mk2="refine">Refine mask</button><button data-mk2="sam">Select and Mask...</button>'
    +'<button data-mk2="rest" title="Make the whole layer visible again, keep the mask">Restore original visibility</button>'
    +'<button data-mk2="apply">Apply mask</button><button data-mk2="del">Delete mask</button>';
  const rs=d.querySelector('#mk-rs');if(rs)rs.textContent='Reset mask';
  d.insertBefore(r,d.querySelector('p.muted'));
 };
 document.addEventListener('click',e=>{const t=e.target.closest&&e.target.closest('[data-mk2]');if(t)maskCmd(t.dataset.mk2);});
}
/* disabled masks show a cross on the thumbnail; the properties panel opens when the mask thumbnail is clicked */
{const _rl=refreshLayers;refreshLayers=function(){
  _rl();if(!doc)return;
  doc.layers.forEach(l=>{if(!l.mask)return;const row=document.querySelector('#layerlist .lrow[data-id="'+l.id+'"] .th.mk');if(row){row.classList.toggle('moff',!!l.mOff);row.title=l.mOff?'Layer mask (disabled). Click it, then Enable mask':'Layer mask';}});
};}
{const lc=document.getElementById('layerlist');if(lc)lc.addEventListener('click',e=>{const a=e.target.closest&&e.target.closest('[data-a="mask"]');if(a){const t=document.querySelector('[data-tab="props"]');if(t&&S.tab!=='props'&&typeof setTab==='function'){try{setTab('props');}catch(x){}}setTimeout(()=>{try{renderProps();}catch(x){}},0);}});}
