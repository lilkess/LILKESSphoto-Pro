/* ===== Text: letter spacing ===== */
function renderText(l){
  const p=l.props,spec=fontSpec(p),txt=p.caps?p.text.toUpperCase():p.text,lines=p.vert?Array.from(txt.replace(/\n/g,'')):txt.split('\n');
  const lsp=((p.ls||0)*p.size/100)+'px';
  scratch.font=spec;try{scratch.letterSpacing=lsp;}catch(e){}
  let mw=1;for(const t of lines)mw=Math.max(mw,scratch.measureText(t).width);
  try{scratch.letterSpacing='0px';}catch(e){}
  const pad=Math.ceil(p.size*0.12+p.sw+p.shadow*1.6+4+Math.max(0,(p.ls||0))*p.size/100),lh=p.size*p.lh;
  const c=l.canvas;c.width=Math.ceil(mw+pad*2);c.height=Math.ceil(lines.length*lh+pad*2);
  const ctx=cctx(c);ctx.font=spec;try{ctx.letterSpacing=lsp;}catch(e){}ctx.textBaseline='middle';ctx.textAlign=p.vert?'center':p.align;ctx.lineJoin='round';
  const x=(p.align==='left'&&!p.vert)?pad:(p.align==='right'&&!p.vert)?c.width-pad:c.width/2;
  lines.forEach((t,i)=>{
    const y=pad+(i+.5)*lh;
    if(p.sw>0){ctx.strokeStyle=p.stroke;ctx.lineWidth=p.sw*2;ctx.strokeText(t,x,y);}
    if(p.shadow>0){ctx.shadowColor=p.shadowColor;ctx.shadowBlur=p.shadow;ctx.shadowOffsetY=p.shadow/3;}
    ctx.fillStyle=p.color;ctx.fillText(t,x,y);
    ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.shadowOffsetY=0;
  });
  l.mask=null;touch(l);
  if(document.fonts&&!document.fonts.check(spec,'Aa')){
    document.fonts.load(spec,'Aa').then(()=>{if(l.props&&l.props.font===p.font){renderText(l);}}).catch(()=>{});
  }
}
TMAP['p-tls']='ls';
{
  const _rp5=renderProps;
  renderProps=function(){
    _rp5();
    const l=doc&&active();if(!l||l.type!=='text')return;
    const lh=document.querySelector('#tab-props #p-lh');if(!lh)return;
    const lab=lh.closest('label');if(!lab)return;
    lab.insertAdjacentHTML('afterend',psl('Letter spacing','p-tls',-20,120,Math.round(l.props.ls||0)));
  };
}
