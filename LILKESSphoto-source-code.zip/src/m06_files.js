
/* ===== PSD reader and writer (8 and 16 bit RGB or grayscale, layers, groups, masks) ===== */
const PSD_IN={'norm':'source-over','mul ':'multiply','scrn':'screen','over':'overlay','dark':'darken','lite':'lighten','div ':'color-dodge','idiv':'color-burn','sLit':'soft-light','hLit':'hard-light','diff':'difference','smud':'exclusion','hue ':'hue','sat ':'saturation','colr':'color','lum ':'luminosity'};
const PSD_OUT={};Object.keys(PSD_IN).forEach(k=>{PSD_OUT[PSD_IN[k]]=k;});

async function inflateBytes(u8){
  const r=new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate')));
  return new Uint8Array(await r.arrayBuffer());
}
function unpackRows(u8,q,counts,cOff,h,rowBytes,raw,rawOff){
  for(let y=0;y<h;y++){
    const e=q+counts[cOff+y],o=rawOff+y*rowBytes;let ro=o;
    while(q<e&&ro<o+rowBytes){
      const n=u8[q++];
      if(n<128){for(let k=0;k<=n&&ro<o+rowBytes;k++)raw[ro++]=u8[q++];}
      else if(n>128){const v=u8[q++];for(let k=0;k<257-n&&ro<o+rowBytes;k++)raw[ro++]=v;}
    }
    q=e;
  }
  return q;
}
function predictDecode(raw,w,h,bps){
  const rb=w*bps;
  for(let y=0;y<h;y++){
    const o=y*rb;
    if(bps===1){for(let x=1;x<w;x++)raw[o+x]=(raw[o+x]+raw[o+x-1])&255;}
    else{for(let x=1;x<w;x++){const a=(raw[o+x*2]<<8|raw[o+x*2+1])+(raw[o+x*2-2]<<8|raw[o+x*2-1]);raw[o+x*2]=(a>>8)&255;raw[o+x*2+1]=a&255;}}
  }
}
async function decodePlane(u8,start,len,comp,w,h,depth){
  if(w<=0||h<=0)return new Uint8Array(0);
  const bps=depth/8,rowBytes=w*bps;let raw;
  if(comp===0)raw=u8.subarray(start,start+rowBytes*h);
  else if(comp===1){
    const dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength),counts=new Uint16Array(h);
    for(let y=0;y<h;y++)counts[y]=dv.getUint16(start+y*2);
    raw=new Uint8Array(rowBytes*h);unpackRows(u8,start+h*2,counts,0,h,rowBytes,raw,0);
  }else if(comp===2||comp===3){
    raw=await inflateBytes(u8.subarray(start,start+len));
    if(comp===3)predictDecode(raw,w,h,bps);
  }else throw new Error('compression');
  if(bps===1)return raw;
  const out=new Uint8Array(w*h);for(let i=0;i<w*h;i++)out[i]=raw[i*2];
  return out;
}
async function readPSD(ab){
  const u8=new Uint8Array(ab),dv=new DataView(ab);let p=0;
  const u16=()=>{const v=dv.getUint16(p);p+=2;return v;},i16=()=>{const v=dv.getInt16(p);p+=2;return v;};
  const u32=()=>{const v=dv.getUint32(p);p+=4;return v;},i32=()=>{const v=dv.getInt32(p);p+=4;return v;};
  const str4=()=>{const s=String.fromCharCode(u8[p],u8[p+1],u8[p+2],u8[p+3]);p+=4;return s;};
  if(u8.length<30||str4()!=='8BPS')throw new Error('notpsd');
  const ver=u16();if(ver===2)throw new Error('psb');if(ver!==1)throw new Error('notpsd');
  p+=6;const chans=u16(),H=u32(),W=u32(),depth=u16(),mode=u16();
  if(mode!==3&&mode!==1)throw new Error('mode');
  if(depth!==8&&depth!==16)throw new Error('depth');
  {const a=u32();p+=a;}{const b=u32();p+=b;}
  const lmLen=u32(),lmEnd=p+lmLen,recs=[];let skipped=0;
  if(lmLen>0){
    const liLen=u32();
    if(liLen>0){
      const cnt=Math.abs(i16());
      for(let i=0;i<cnt;i++){
        const r={top:i32(),left:i32(),bottom:i32(),right:i32()},nch=u16();r.ch=[];
        for(let k=0;k<nch;k++)r.ch.push({id:i16(),len:u32()});
        str4();r.bm=str4();r.op=u8[p++]/255;r.clip=u8[p++]===1;const fl=u8[p++];r.visible=!(fl&2);p++;
        const exLen=u32(),exEnd=p+exLen;
        const mLen=u32(),mStart=p;
        if(mLen>=20){r.mask={top:i32(),left:i32(),bottom:i32(),right:i32(),def:u8[p],flags:u8[p+1]};}
        p=mStart+mLen;
        {const bl=u32();p+=bl;}
        const nl=u8[p];let nm='';for(let k=0;k<nl;k++)nm+=String.fromCharCode(u8[p+1+k]);r.name=nm;p+=1+nl;p+=(4-((1+nl)%4))%4;
        r.sect=0;
        while(p+12<=exEnd){
          const sig=str4(),key=str4(),len=u32(),ds=p;void sig;
          if(key==='luni'){const n=dv.getUint32(ds);let s='';for(let k=0;k<n;k++)s+=String.fromCharCode(dv.getUint16(ds+4+k*2));r.name=s;}
          else if(key==='lsct')r.sect=dv.getUint32(ds);
          else if(key==='TySh')r.isText=true;
          p=ds+len;
        }
        p=exEnd;recs.push(r);
      }
      for(const r of recs){
        const w=r.right-r.left,h=r.bottom-r.top,planes={};
        for(const c of r.ch){
          const start=p+2,comp=dv.getUint16(p),len=c.len-2;
          if(c.id>=-1&&c.id<=2&&w>0&&h>0)planes[c.id]=await decodePlane(u8,start,len,comp,w,h,depth);
          else if(c.id===-2&&r.mask){const mw=r.mask.right-r.mask.left,mh=r.mask.bottom-r.mask.top;if(mw>0&&mh>0)planes[-2]=await decodePlane(u8,start,len,comp,mw,mh,depth);}
          p+=c.len;
        }
        r.planes=planes;
      }
    }
  }
  p=lmEnd;
  const layers=[],stack=[];
  for(let i=recs.length-1;i>=0;i--){
    const r=recs[i];
    if(r.sect===3){stack.pop();continue;}
    if(r.sect===1||r.sect===2){stack.push({vis:r.visible,op:r.op});continue;}
    const w=r.right-r.left,h=r.bottom-r.top;
    if(w<=0||h<=0||!r.planes||!r.planes[0]){skipped++;continue;}
    const cv=mkCanvas(w,h),ctx=cctx(cv),id=ctx.createImageData(w,h),d=id.data,P=r.planes;
    const R=P[0],G=mode===1?P[0]:(P[1]||P[0]),B=mode===1?P[0]:(P[2]||P[0]),A=P[-1];
    for(let k=0;k<w*h;k++){const o=k*4;d[o]=R[k];d[o+1]=G[k];d[o+2]=B[k];d[o+3]=A?A[k]:255;}
    ctx.putImageData(id,0,0);
    let maskCv=null;
    if(r.mask&&P[-2]&&!(r.mask.flags&2)){
      const mk=r.mask,mw=mk.right-mk.left,mh=mk.bottom-mk.top;
      maskCv=mkCanvas(w,h);const mx=cctx(maskCv),mid=mx.createImageData(w,h),md=mid.data;
      for(let y=0;y<h;y++)for(let x=0;x<w;x++){
        const ax=r.left+x-mk.left,ay=r.top+y-mk.top;
        let mv=(ax>=0&&ay>=0&&ax<mw&&ay<mh)?P[-2][ay*mw+ax]:mk.def;
        if(mk.flags&4)mv=255-mv;
        const o=(y*w+x)*4;md[o]=md[o+1]=md[o+2]=255;md[o+3]=mv;
      }
      mx.putImageData(mid,0,0);
    }
    layers.push({name:r.name||'Layer',x:r.left+w/2,y:r.top+h/2,canvas:cv,mask:maskCv,
      opacity:r.op*stack.reduce((a,g)=>a*g.op,1),visible:r.visible&&stack.every(g=>g.vis),blend:PSD_IN[r.bm]||'source-over',text:!!r.isText,clip:!!r.clip});
  }
  layers.reverse();
  if(!layers.length){
    const comp=dv.getUint16(p);p+=2;const bps=depth/8,n=W*H,pl=[];
    if(comp===0){for(let c=0;c<chans;c++){const raw=u8.subarray(p+c*n*bps,p+(c+1)*n*bps);pl.push(bps===1?raw:raw.filter((v,i2)=>i2%2===0));}}
    else if(comp===1){
      const counts=new Uint16Array(chans*H);for(let i=0;i<chans*H;i++)counts[i]=dv.getUint16(p+i*2);
      let q=p+chans*H*2;const rb=W*bps;
      for(let c=0;c<chans;c++){const raw=new Uint8Array(rb*H);q=unpackRows(u8,q,counts,c*H,H,rb,raw,0);pl.push(bps===1?raw:raw.filter((v,i2)=>i2%2===0));}
    }else throw new Error('compression');
    const cv=mkCanvas(W,H),ctx=cctx(cv),id=ctx.createImageData(W,H),d=id.data;
    for(let k=0;k<n;k++){const o=k*4;d[o]=pl[0][k];d[o+1]=mode===1?pl[0][k]:pl[1][k];d[o+2]=mode===1?pl[0][k]:pl[2][k];d[o+3]=(mode===3&&chans>=4)?pl[3][k]:255;}
    ctx.putImageData(id,0,0);
    layers.push({name:'Background',x:W/2,y:H/2,canvas:cv,mask:null,opacity:1,visible:true,blend:'source-over',text:false});
  }
  return {w:W,h:H,layers,skipped};
}
async function openPSD(ab,fname){
  try{
    const r=await readPSD(ab);
    if(r.w*r.h>90e6){toast('That file is too large for this device');return;}
    startDoc((fname||'PSD').replace(/\.psd$/i,''),r.w,r.h,72);
    for(const L of r.layers){
      const l=addLayer({name:L.name,type:'image',w:L.canvas.width,h:L.canvas.height,x:L.x,y:L.y,select:false});
      cctx(l.canvas).drawImage(L.canvas,0,0);l.opacity=L.opacity;l.blend=L.blend;l.visible=L.visible;
      if(L.mask)l.mask=L.mask;l.clip=!!L.clip;
    }
    finishDoc();setTool('move');setTab('layers');
    const txt=r.layers.filter(l=>l.text).length;
    toast('Opened '+r.layers.length+' layer'+(r.layers.length===1?'':'s')+(txt?'. Text layers open as pictures.':'')+(r.skipped?' '+r.skipped+' adjustment layers were skipped.':''));
  }catch(err){
    const m=err&&err.message;
    toast(m==='psb'?'Large PSB files are not supported yet':m==='mode'?'Only RGB and grayscale PSD files are supported yet':m==='depth'?'Only 8-bit and 16-bit PSD files are supported yet':m==='notpsd'?'That does not look like a PSD file':'This PSD could not be read');
  }
}

/* writer */
class BW{
  constructor(n){this.b=new Uint8Array(n||1<<20);this.dv=new DataView(this.b.buffer);this.p=0;}
  ens(n){if(this.p+n>this.b.length){let m=this.b.length*2;while(m<this.p+n)m*=2;const nb=new Uint8Array(m);nb.set(this.b);this.b=nb;this.dv=new DataView(nb.buffer);}}
  u8(v){this.ens(1);this.b[this.p++]=v;}
  u16(v){this.ens(2);this.dv.setUint16(this.p,v);this.p+=2;}
  i16(v){this.ens(2);this.dv.setInt16(this.p,v);this.p+=2;}
  u32(v){this.ens(4);this.dv.setUint32(this.p,v);this.p+=4;}
  i32(v){this.ens(4);this.dv.setInt32(this.p,v);this.p+=4;}
  str(s){for(let i=0;i<s.length;i++)this.u8(s.charCodeAt(i));}
  bytes(a){this.ens(a.length);this.b.set(a,this.p);this.p+=a.length;}
  patch32(pos,v){this.dv.setUint32(pos,v);}
}
function packBitsRow(row,out){
  const n=row.length;let i=0;
  while(i<n){
    let run=1;while(i+run<n&&run<128&&row[i+run]===row[i])run++;
    if(run>1){out.push(257-run,row[i]);i+=run;}
    else{
      let j=i;while(j<n&&j-i<128&&!(j+2<n&&row[j]===row[j+1]&&row[j]===row[j+2]))j++;
      if(j===i)j=i+1;
      out.push(j-i-1);for(let k=i;k<j;k++)out.push(row[k]);i=j;
    }
  }
}
function rleChannel(plane,w,h){
  const counts=new Uint16Array(h),out=[];
  for(let y=0;y<h;y++){const s=out.length;packBitsRow(plane.subarray(y*w,(y+1)*w),out);counts[y]=out.length-s;}
  const res=new Uint8Array(2+h*2+out.length),dv=new DataView(res.buffer);
  dv.setUint16(0,1);for(let y=0;y<h;y++)dv.setUint16(2+y*2,counts[y]);
  res.set(out,2+h*2);return res;
}
function psdLayerData(l){
  const W=doc.w,H=doc.h,c=flatLayer(l),x=cctx(c);
  const d=x.getImageData(0,0,W,H).data;
  let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++)for(let xx=0;xx<W;xx++)if(d[(y*W+xx)*4+3]>0){if(xx<x0)x0=xx;if(xx>x1)x1=xx;if(y<y0)y0=y;if(y>y1)y1=y;}
  if(x1<0)return {top:0,left:0,bottom:0,right:0,chans:[0,1,2,3].map(()=>new Uint8Array([0,0]))};
  const w=x1-x0+1,h=y1-y0+1,pl=[0,1,2,3].map(()=>new Uint8Array(w*h));
  for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){
    const o=((y+y0)*W+xx+x0)*4,k=y*w+xx;
    pl[0][k]=d[o+3];pl[1][k]=d[o];pl[2][k]=d[o+1];pl[3][k]=d[o+2];
  }
  return {top:y0,left:x0,bottom:y1+1,right:x1+1,chans:pl.map(q=>rleChannel(q,w,h))};
}
function buildPSD(){
  const W=doc.w,H=doc.h,bw=new BW(1<<22);
  bw.str('8BPS');bw.u16(1);for(let i=0;i<6;i++)bw.u8(0);bw.u16(3);bw.u32(H);bw.u32(W);bw.u16(8);bw.u16(3);
  bw.u32(0);bw.u32(0);
  const lmPos=bw.p;bw.u32(0);
  const liPos=bw.p;bw.u32(0);
  bw.i16(doc.layers.length);
  const items=doc.layers.map(l=>Object.assign(psdLayerData(l),{l}));
  const ids=[-1,0,1,2];
  for(const it of items){
    const l=it.l;
    bw.i32(it.top);bw.i32(it.left);bw.i32(it.bottom);bw.i32(it.right);bw.u16(4);
    ids.forEach((id,k)=>{bw.i16(id);bw.u32(it.chans[k].length);});
    bw.str('8BIM');bw.str(PSD_OUT[l.blend]||'norm');
    bw.u8(Math.round(clamp(l.opacity,0,1)*255));bw.u8(0);bw.u8(l.visible?0:2);bw.u8(0);
    const nm=(l.name||'Layer').slice(0,120),asc=nm.replace(/[^\x20-\x7e]/g,'_').slice(0,31);
    const pasLen=Math.ceil((1+asc.length)/4)*4;
    const uniData=4+nm.length*2,uniPad=Math.ceil(uniData/4)*4;
    bw.u32(4+4+pasLen+12+uniPad);
    bw.u32(0);bw.u32(0);
    bw.u8(asc.length);bw.str(asc);for(let k=1+asc.length;k<pasLen;k++)bw.u8(0);
    bw.str('8BIM');bw.str('luni');bw.u32(uniPad);bw.u32(nm.length);
    for(let k=0;k<nm.length;k++)bw.u16(nm.charCodeAt(k));
    for(let k=uniData;k<uniPad;k++)bw.u8(0);
  }
  for(const it of items)for(const ch of it.chans)bw.bytes(ch);
  let liLen=bw.p-liPos-4;if(liLen%2){bw.u8(0);liLen++;}
  bw.patch32(liPos,liLen);
  bw.u32(0);
  bw.patch32(lmPos,bw.p-lmPos-4);
  const fc=mkCanvas(W,H),fx=cctx(fc);fx.fillStyle='#fff';fx.fillRect(0,0,W,H);compose(fx,1);
  const fd=fx.getImageData(0,0,W,H).data;
  bw.u16(0);
  for(let c=0;c<3;c++){const pl=new Uint8Array(W*H);for(let k=0;k<W*H;k++)pl[k]=fd[k*4+c];bw.bytes(pl);}
  return bw.b.slice(0,bw.p);
}

/* small ZIP writer (stored) for hosts that refuse the .psd extension */
function crc32(u8){
  let c,crc=0xFFFFFFFF;
  if(!crc32.t){crc32.t=[];for(let n=0;n<256;n++){c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;crc32.t[n]=c>>>0;}}
  for(let i=0;i<u8.length;i++)crc=crc32.t[(crc^u8[i])&255]^(crc>>>8);
  return (crc^0xFFFFFFFF)>>>0;
}
function zipStore(name,data){
  const nb=new TextEncoder().encode(name),crc=crc32(data),b=new BW(data.length+400);
  b.u32(0x04034b50);b.u16(20);b.u16(0);b.u16(0);b.u16(0);b.u16(0x21);b.u32(crc);
  b.u32(data.length);b.u32(data.length);b.u16(nb.length);b.u16(0);b.bytes(nb);b.bytes(data);
  const cd=b.p;
  b.u32(0x02014b50);b.u16(20);b.u16(20);b.u16(0);b.u16(0);b.u16(0);b.u16(0x21);b.u32(crc);b.u32(data.length);b.u32(data.length);
  b.u16(nb.length);b.u16(0);b.u16(0);b.u16(0);b.u16(0);b.u32(0);b.u32(0);b.bytes(nb);
  const cdLen=b.p-cd;
  b.u32(0x06054b50);b.u16(0);b.u16(0);b.u16(1);b.u16(1);b.u32(cdLen);b.u32(cd);b.u16(0);
  return b.b.slice(0,b.p);
}
function blobToBase64(blob){
  return new Promise((res,rej)=>{const fr=new FileReader();fr.onerror=()=>rej(fr.error);fr.onload=()=>res(String(fr.result).split(',')[1]||'');fr.readAsDataURL(blob);});
}
async function saveBlob(blob,name){
  const Cap=window.Capacitor;
  if(Cap&&Cap.isNativePlatform&&Cap.isNativePlatform()&&Cap.Plugins&&Cap.Plugins.Filesystem&&Cap.Plugins.Share){
    try{
      const b64=await blobToBase64(blob);
      const r=await Cap.Plugins.Filesystem.writeFile({path:name,data:b64,directory:'CACHE'});
      await Cap.Plugins.Share.share({title:name,url:r.uri});toast('Pick where to save it');return;
    }catch(err){if(err&&/cancel/i.test(String(err.message||err)))return;toast('Could not save the file on this device');return;}
  }
  let dl=null;
  try{dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;}catch(err){dl=null;}
  if(dl){
    try{await dl.save({filename:name,data:blob});toast('Saved');return;}
    catch(err){
      if(err&&err.code==='declined')return;
      if(err&&err.code==='rejected_extension'&&/\.psd$/i.test(name)){
        try{const z=zipStore(name,new Uint8Array(await blob.arrayBuffer()));await dl.save({filename:name+'.zip',data:new Blob([z])});toast('Saved as a ZIP. Unzip it to get your PSD file.');return;}catch(e2){}
      }
      toast('Could not save from this page. Press and hold the picture to save it.');return;
    }
  }
  const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(u),8000);toast('Saving '+name);
}
function savePSDFile(){
  flush();toast('Preparing PSD...');
  setTimeout(()=>{
    try{const u8=buildPSD();saveBlob(new Blob([u8],{type:'application/octet-stream'}),(doc.name||'design').replace(/[^\w\- ]+/g,'_')+'.psd');}
    catch(err){toast('Could not create the PSD file');}
  },40);
}

/* ===== opening pictures ===== */
function fileToCanvas(file,max){
  return new Promise((res,rej)=>{
    const url=URL.createObjectURL(file),img=new Image();
    img.onload=()=>{
      let w=img.naturalWidth,h=img.naturalHeight;const k=Math.min(1,(max||4096)/Math.max(w,h));
      w=Math.round(w*k);h=Math.round(h*k);const c=mkCanvas(w,h);cctx(c).drawImage(img,0,0,w,h);URL.revokeObjectURL(url);res(c);
    };
    img.onerror=()=>{URL.revokeObjectURL(url);rej(new Error('decode'));};img.src=url;
  });
}
async function openPhoto(file){
  try{
    const c=await fileToCanvas(file,4096);
    startDoc((file.name||'Photo').replace(/\.[^.]+$/,'').slice(0,40),c.width,c.height,72);
    const l=addLayer({name:'Background',type:'image',w:c.width,h:c.height});
    cctx(l.canvas).drawImage(c,0,0);finishDoc();setTool('move');setTab('filters');toast('Photo opened. Try a look, or the skin smoothing brush.');
  }catch(err){toast('That file could not be opened as an image');}
}
async function placeImage(file,clip){
  if(!doc){openPhoto(file);return;}
  flush();
  try{
    const c=await fileToCanvas(file,3000);
    const base=active();
    if(clip&&base&&base.ph){ // replacing a photo in a template frame: drop the old picture first
      let k=doc.layers.indexOf(base)+1;while(k<doc.layers.length&&doc.layers[k].clip&&doc.layers[k].type==='image'){doc.layers.splice(k,1);}
      doc.active=base.id;
    }
    const l=addLayer({name:(file.name||'Image').replace(/\.[^.]+$/,'').slice(0,24),type:'image',w:c.width,h:c.height,above:true});
    cctx(l.canvas).drawImage(c,0,0);
    if(clip&&base&&doc.layers.indexOf(base)>=0){const b=layerBounds(base);l.s=Math.max((b.x1-b.x0)/c.width,(b.y1-b.y0)/c.height);l.x=(b.x0+b.x1)/2;l.y=(b.y0+b.y1)/2;l.clip=true;l.name+=' (clipped)';}
    else l.s=Math.min(1,doc.w*0.9/c.width,doc.h*0.9/c.height);
    commit(clip?'Place in shape':'Place image');setTool('move');toast('Image placed. Drag it, resize it, or edit it.');
  }catch(err){toast('That file could not be opened as an image');}
}
async function openAnyFile(file){
  const n=(file.name||'').toLowerCase();
  if(n.endsWith('.psd')||file.type==='image/vnd.adobe.photoshop'){toast('Opening PSD...');openPSD(await file.arrayBuffer(),file.name);}
  else openPhoto(file);
}
let fileMode='open';
function pickFile(mode){fileMode=mode;$('#file').click();}
$('#file').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(fileMode==='place')placeImage(f);else if(fileMode==='clip')placeImage(f,true);else openAnyFile(f);});
window.addEventListener('dragover',e=>{e.preventDefault();document.body.classList.add('dragging');});
window.addEventListener('dragleave',e=>{if(!e.relatedTarget)document.body.classList.remove('dragging');});
window.addEventListener('drop',e=>{
  e.preventDefault();document.body.classList.remove('dragging');
  const files=[...(e.dataTransfer?e.dataTransfer.files:[])];if(!files.length)return;
  const onCanvas=!!e.target.closest&&!!e.target.closest('#vp')&&doc&&$('#welcome').hidden;
  files.forEach(f=>{
    const n=(f.name||'').toLowerCase();
    if(n.endsWith('.psd'))openAnyFile(f);
    else if(f.type.startsWith('image/'))onCanvas?placeImage(f):openPhoto(f);
  });
});
document.addEventListener('paste',e=>{
  if(/INPUT|TEXTAREA/.test((e.target.tagName||'')))return;
  const it=[...(e.clipboardData?e.clipboardData.files:[])].find(f=>f.type.startsWith('image/'));if(it){e.preventDefault();doc&&$('#welcome').hidden?placeImage(it):openPhoto(it);}
});

/* ===== projects saved on this device (IndexedDB) ===== */
function idbOpen(){
  return new Promise((res,rej)=>{
    try{
      const r=indexedDB.open('lilkessphoto',1);
      r.onupgradeneeded=()=>{r.result.createObjectStore('projects',{keyPath:'id'});r.result.createObjectStore('meta',{keyPath:'id'});};
      r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);
    }catch(err){rej(err);}
  });
}
const idbReq=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});
const toPngBlob=c=>new Promise(r=>c.toBlob(r,'image/png'));
async function saveProject(){
  flush();
  const layers=[];
  for(const l of doc.layers){
    const blob=await toPngBlob(l.canvas),maskBlob=l.mask?await toPngBlob(l.mask):null;
    const mt0=meta(l);mt0.orig=null;const origBlob=l.orig?await toPngBlob(l.orig):null;
    const mks=mkSettingsOf(l);layers.push({meta:mt0,blob,maskBlob,origBlob,mkBase:mks?await toPngBlob(mks.base):null,mkP:mks?mks.p:null});
  }
  const k=160/Math.max(doc.w,doc.h),tc=mkCanvas(doc.w*k,doc.h*k);compose(cctx(tc),k);
  const id=doc.projId||('p'+Date.now());doc.projId=id;
  const rec={id,name:doc.name,w:doc.w,h:doc.h,ppi:doc.ppi||72,nextId:doc.nextId,active:doc.active,guides:doc.guides||[],layers,paths:clone(doc.paths||[]),extra:clone(doc.extra||null),comments:clone(doc.comments||[]),frames:clone(doc.frames||[]),updated:Date.now()};
  const mt={id,name:doc.name,w:doc.w,h:doc.h,thumb:tc.toDataURL('image/jpeg',0.8),updated:rec.updated};
  const db=await idbOpen(),tx=db.transaction(['projects','meta'],'readwrite');
  tx.objectStore('projects').put(rec);tx.objectStore('meta').put(mt);
  await new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error);});
  db.close();
}
async function doSaveProject(){
  try{await saveProject();doc.modified=false;renderTabs();toast('Saved to this device');}
  catch(err){toast('Could not save here. Use Save as PSD instead.');}
}
async function listProjects(){
  try{const db=await idbOpen(),a=await idbReq(db.transaction('meta').objectStore('meta').getAll());db.close();return a.sort((x,y)=>y.updated-x.updated);}
  catch(err){return null;}
}
async function deleteProject(id){
  try{const db=await idbOpen(),tx=db.transaction(['projects','meta'],'readwrite');
  tx.objectStore('projects').delete(id);tx.objectStore('meta').delete(id);
  await new Promise(res=>{tx.oncomplete=res;});db.close();}catch(err){}
}
async function loadProject(id){
  const open=docs.findIndex(e=>e.doc.projId===id);
  if(open>=0){switchDoc(open);return;}
  try{
    const db=await idbOpen(),rec=await idbReq(db.transaction('projects').objectStore('projects').get(id));db.close();
    if(!rec){toast('That design was not found');return;}
    startDoc(rec.name,rec.w,rec.h,rec.ppi||72);doc.projId=rec.id;doc.guides=rec.guides||[];
    for(const L of rec.layers){
      const bmp=await createImageBitmap(L.blob),c=mkCanvas(bmp.width,bmp.height);cctx(c).drawImage(bmp,0,0);
      let mk=null;if(L.maskBlob){const mb=await createImageBitmap(L.maskBlob);mk=mkCanvas(mb.width,mb.height);cctx(mk).drawImage(mb,0,0);}
      let og=null;if(L.origBlob){const ob=await createImageBitmap(L.origBlob);og=mkCanvas(ob.width,ob.height);cctx(og).drawImage(ob,0,0);}
      const lay=Object.assign({},L.meta,{canvas:c,ver:0,mask:mk,mver:0,pvv:0,orig:og});if(mk&&L.mkBase&&L.mkP){const mb2=await createImageBitmap(L.mkBase),bc=mkCanvas(mb2.width,mb2.height);cctx(bc).drawImage(mb2,0,0);lay.mk={base:bc,p:Object.assign({dens:100,feather:0},L.mkP),mver:0,shown:mk};}doc.layers.push(lay);
    }
    doc.nextId=rec.nextId;doc.paths=rec.paths||[];doc.ap=doc.paths.length?0:-1;doc.extra=rec.extra||null;doc.comments=rec.comments||[];doc.frames=rec.frames||[];
    finishDoc();doc.active=rec.active;refreshAll();redraw();setTool('move');
  }catch(err){toast('Could not open that design');}
}

window.__openFile=openAnyFile;ACT.openRecent=()=>openRecentDialog();ACT.hideWelcome=()=>hideWelcome();
/* ===== start ===== */
if(isMobile()){S.rulers=false;document.body.classList.add('no-rulers');}
renderToolbox();renderOpts();setSwatches();
setTab('color',false,true);setTab('layers',false,true);
renderTabs();updateUndo();showWelcome();
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{docs.forEach(e=>e.doc.layers.forEach(l=>{if(l.type==='text'&&l.props)renderText(l);}));if(doc)redraw();});
window.addEventListener('resize',()=>{if(doc&&S.autoFit)fitView();else drawRulers();});
if(window.__LK_DEBUG)window.__LK={exportRender,resampleAsync,resampleCanvas,iccBuild,iccFromFile,iccDescribe,iccConvertCanvas,openPhoto,docSizeProblem,openExportAs,addBleed,mkCanvas,view,get vlo(){return VLO;},__redraw:()=>redraw(),loadProject,listProjects,saveAsTemplate,listUserTemplates,openUserTemplate,saveProject,refreshLayers,flatCanvas,renderProps,fa_prep,fa_findText,fa_findShapes,fa_inpaint,fa_textMask,fa_blur,fa_grad,openFontPicker,fontOptionsHtml,FONTS,SHORT,PANEL_ORDER,get doc(){return doc;},S,ACT,docs,openFx,FX,readPSD,buildPSD,buildPSDAsync,makeFile,openPSD,newBlank,commit,active,flatLayer,addLayer,loadTemplate,TEMPLATES,renderText,startDoc,finishDoc,get hist(){return hist;},selFromPathFn,setSelection,selAll,regionMask,mkCanvas,cctx,TOOLS,pickTool,setTool,PANELS,openPanel,curPath,exa,TOOLGROUPS,switchDoc,undo,redo,closeDoc,PLG,qrEncode,plgQR,plgChart,plgFlag,plgRender3D,plgZeus,plgFlare,plgBloom,plgGrade,plgSmartBlur,plgEdges,openPluginGallery,plgThumb,plgPalette,plgEmojiCanvas,FLAGS};
})();
