/* ===== Templates: Business ===== */
TEMPLATES.push(
{name:'Restaurant special',cat:'Business',tags:'restaurant food burger menu promo offer',w:1080,h:1350,build(){
  tGrad('#1a0f08','#0a0603',180);
  tShape('ellipse',.5,.5,1.2,1.2,'#f97316',{name:'Glow'}).opacity=.16;
  tShape('ellipse',.5,.46,.78,.78,'#f59e0b',{name:'Plate'});
  tShape('ellipse',.5,.46,.7,.7,'#7c2d12',{name:'Plate inner'});
  tShape('ellipse',.5,.5,.55,.2,'#92400e',{name:'Bun bottom'});
  tShape('ellipse',.5,.45,.56,.12,'#65a30d',{name:'Lettuce'});
  tShape('ellipse',.5,.42,.5,.1,'#b91c1c',{name:'Patty'});
  tShape('round',.5,.36,.56,.2,'#d97706',{name:'Bun top',p:{radius:200}});
  tText('TASTY',0.5,0.075,{font:'Outfit',size:90,color:'#fbbf24'});
  tText('BURGER NIGHT',0.5,0.17,{font:'Big Shoulders Display',size:180,color:'#ffffff'});
  tShape('ellipse',.84,.64,.22,.22,'#dc2626',{name:'Price badge'});
  tText('2 FOR\nGH₵50',0.84,0.64,{font:'Big Shoulders Display',size:80,color:'#ffffff',lh:.95});
  tText('EVERY THURSDAY  •  5 PM – 11 PM',0.5,0.82,{font:'Outfit',size:52,color:'#fbbf24'});
  tText('Dine in • Takeaway • Delivery\nOrder: 000 000 0000',0.5,0.91,{font:'Outfit',size:42,bold:false,color:'#ffffff',lh:1.5});
}},
{name:'Real estate listing',cat:'Business',tags:'real estate house property for sale listing agent',w:1080,h:1350,build(){
  tSolid('#f8fafc');
  tShape('rect',.5,.3,1,.55,'#0f2a4a',{name:'Sky'});
  tShape('rect',.28,.38,.2,.35,'#1e4a7a',{name:'Tower'});tShape('rect',.5,.33,.22,.5,'#2a5f99',{name:'Tower 2'});tShape('rect',.74,.4,.18,.3,'#1e4a7a',{name:'Tower 3'});
  for(let r=0;r<6;r++)for(let c=0;c<3;c++){tShape('rect',.43+c*.07,.17+r*.065,.035,.04,'#fde68a',{name:'Window'});}
  tShape('rect',.5,.6,1,.02,'#0f2a4a',{name:'Ground'});
  tShape('round',.5,.12,.5,.08,'#ef4444',{name:'Tag',p:{radius:40}});
  tText('JUST LISTED',0.5,0.12,{font:'Outfit',size:56,color:'#ffffff'});
  tText('Modern 4 Bedroom\nFamily Home',0.5,0.69,{font:'Gloock',size:96,bold:false,color:'#0f2a4a',lh:1.05});
  tText('GH₵ 1,250,000',0.5,0.8,{font:'Outfit',size:92,color:'#ef4444'});
  tText('4 BEDS   •   3 BATHS   •   2 CAR GARAGE   •   GARDEN',0.5,0.87,{font:'Outfit',size:36,color:'#475569'});
  tShape('rect',.5,.95,1,.1,'#0f2a4a',{name:'Footer'});
  tText('CALL AGENT  000 000 0000   |   www.yourproperty.com',0.5,0.95,{font:'Outfit',size:36,color:'#ffffff'});
}},
{name:'Gym fitness',cat:'Business',tags:'gym fitness workout training membership',w:1080,h:1350,build(){
  tGrad('#0a0a0a','#1a1a1a',180);
  tShape('rect',.5,.5,.5,2,'#a3e635',{name:'Slash'}).r=.35;
  tText('NO',0.5,0.15,{font:'Big Shoulders Display',size:300,color:'#ffffff'});
  tText('EXCUSES',0.5,0.32,{font:'Big Shoulders Display',size:300,color:'#a3e635',stroke:'#000000',sw:4});
  tText('JOIN THE STRONGEST GYM IN TOWN',0.5,0.5,{font:'Outfit',size:46,color:'#ffffff',shadow:12,shadowColor:'#000000'});
  tShape('rect',.5,.7,.86,.2,'#a3e635',{name:'Offer box'});
  tText('FIRST MONTH',0.5,0.665,{font:'Outfit',size:44,color:'#000000'});
  tText('50% OFF',0.5,0.735,{font:'Big Shoulders Display',size:140,color:'#000000'});
  tText('PERSONAL TRAINING  •  CARDIO  •  WEIGHTS  •  YOGA',0.5,0.85,{font:'Outfit',size:34,bold:false,color:'#ffffff',shadow:10,shadowColor:'#000000'});
  tText('IRON TEMPLE FITNESS  |  000 000 0000',0.5,0.93,{font:'Outfit',size:42,color:'#a3e635',shadow:10,shadowColor:'#000000'});
}},
{name:'Barber shop',cat:'Business',tags:'barber salon hair beauty haircut shop',w:1080,h:1350,build(){
  tGrad('#161616','#050505',180);
  tFrame(.5,.5,.9,1.12,'#c9a227',4);
  tShape('rect',.5,.095,.7,.012,'#c9a227',{name:'Line'});
  tText('EST. 2015',0.5,0.075,{font:'Outfit',size:40,color:'#c9a227'});
  tText('THE',0.5,0.17,{font:'Instrument Serif',size:70,bold:false,italic:true,color:'#ffffff'});
  tText('BARBER',0.5,0.29,{font:'Gloock',size:230,bold:false,color:'#ffffff'});
  tText('SHOP',0.5,0.42,{font:'Gloock',size:180,bold:false,color:'#c9a227'});
  tText('PRICE LIST',0.5,0.62,{font:'Outfit',size:44,color:'#c9a227'});
  tText('HAIRCUT .............. GH₵ 40\nBEARD TRIM .......... GH₵ 25\nHAIRCUT + BEARD ..... GH₵ 60\nKIDS CUT ............ GH₵ 30',0.5,0.75,{font:'JetBrains Mono',size:36,bold:false,color:'#ffffff',lh:1.6});
  tText('WALK-INS WELCOME  •  MON–SAT 8AM–8PM\n000 000 0000',0.5,0.9,{font:'Outfit',size:38,bold:false,color:'#c9a227',lh:1.5});
}},
{name:'We are hiring',cat:'Business',tags:'hiring job vacancy recruitment career work',w:1080,h:1080,build(){
  tSolid('#fde047');
  tShape('ellipse',.9,.1,.6,.6,'#facc15',{name:'Circle'});tShape('ellipse',.05,.95,.5,.5,'#eab308',{name:'Circle 2'});
  tText('WE\'RE',0.3,0.17,{font:'Outfit',size:120,color:'#111111'});
  tText('HIRING!',0.5,0.35,{font:'Erica One',size:250,bold:false,color:'#111111'});
  tShape('round',.5,.55,.84,.11,'#111111',{name:'Role bar',p:{radius:20}});
  tText('SALES ASSISTANT  •  DRIVER  •  CASHIER',0.5,0.55,{font:'Outfit',size:44,color:'#fde047'});
  tText('Full-time & part-time positions\nCompetitive pay • Friendly team • Growth',0.5,0.7,{font:'Outfit',size:48,bold:false,color:'#111111',lh:1.45});
  tText('SEND YOUR CV TO\njobs@yourcompany.com',0.5,0.88,{font:'Outfit',size:54,color:'#111111',lh:1.3});
}},
{name:'Business card',cat:'Business',tags:'business card contact name card',w:1050,h:600,build(){
  tGrad('#0f2a4a','#0a1c33',160);
  tShape('rect',.84,.5,.32,1.2,'#f2b134',{name:'Accent'}).r=.18;
  tShape('ellipse',.14,.22,.09,.09,'#f2b134',{name:'Logo'});
  tText('YC',0.14,0.22,{font:'Outfit',size:44,color:'#0f2a4a'});
  tText('Your Name',0.2,0.22,{font:'Gloock',size:56,bold:false,color:'#ffffff',align:'left'});
  tText('FOUNDER & CEO',0.2,0.32,{font:'Outfit',size:24,color:'#f2b134',align:'left'});
  tText('+233 00 000 0000\nname@yourcompany.com\nwww.yourcompany.com\nAccra, Ghana',0.07,0.7,{font:'Outfit',size:28,bold:false,color:'#ffffff',align:'left',lh:1.5});
}},
{name:'Car wash',cat:'Business',tags:'car wash auto detailing cleaning service',w:1080,h:1350,build(){
  tGrad('#0ea5e9','#0369a1',180);
  tDots(30,'#ffffff',44,[0,0,1,1],.04,.14,.25);
  tShape('round',.5,.7,.62,.12,'#1e293b',{name:'Car body',p:{radius:80}});
  tShape('round',.5,.64,.36,.1,'#334155',{name:'Car roof',p:{radius:70}});
  tShape('ellipse',.3,.77,.1,.1,'#0f172a',{name:'Wheel'});tShape('ellipse',.7,.77,.1,.1,'#0f172a',{name:'Wheel'});
  tShape('ellipse',.3,.77,.05,.05,'#94a3b8',{name:'Hub'});tShape('ellipse',.7,.77,.05,.05,'#94a3b8',{name:'Hub'});
  tText('SHINE &',0.5,0.15,{font:'Outfit',size:100,color:'#ffffff'});
  tText('SPARKLE',0.5,0.27,{font:'Erica One',size:200,bold:false,color:'#fde047',stroke:'#0c4a6e',sw:10});
  tText('CAR WASH',0.5,0.42,{font:'Big Shoulders Display',size:180,color:'#ffffff'});
  tText('INTERIOR  •  EXTERIOR  •  POLISH',0.5,0.52,{font:'Outfit',size:44,color:'#bae6fd'});
  tShape('round',.5,.9,.7,.1,'#fde047',{name:'Offer',p:{radius:50}});
  tText('FULL WASH FROM GH₵ 30',0.5,0.9,{font:'Outfit',size:52,color:'#0c4a6e'});
}},
{name:'Black Friday sale',cat:'Business',tags:'black friday sale discount offer shopping',w:1080,h:1350,build(){
  tGrad('#000000','#14110a',180);
  tCustom('burst',.5,.4,1.2,1.2,'#1c1706',{name:'Burst'});
  tText('BLACK',0.5,0.19,{font:'Big Shoulders Display',size:350,color:'#ffffff'});
  tText('FRIDAY',0.5,0.38,{font:'Big Shoulders Display',size:350,color:'#fbbf24'});
  tShape('rect',.5,.58,.88,.012,'#fbbf24',{name:'Line'});
  tText('UP TO',0.13,0.67,{font:'Outfit',size:64,color:'#ffffff'});
  tText('70%',0.52,0.69,{font:'Erica One',size:200,bold:false,color:'#fbbf24'});
  tText('OFF',0.89,0.7,{font:'Outfit',size:84,color:'#ffffff'});
  tShape('round',.5,.88,.74,.1,'#fbbf24',{name:'Button',p:{radius:20}});
  tText('SHOP NOW  •  26 NOV ONLY',0.5,0.88,{font:'Outfit',size:52,color:'#000000'});
}},
{name:'Coming soon launch',cat:'Business',tags:'coming soon launch product teaser story',w:1080,h:1920,build(){
  tGrad('#312e81','#0f172a',160);
  tShape('ellipse',.5,.4,1.3,1.3,'#6366f1',{name:'Glow'}).opacity=.25;
  tShape('ellipse',.5,.4,.8,.8,'#a5b4fc',{name:'Glow 2'}).opacity=.18;
  tText('SOMETHING\nBIG IS',0.5,0.25,{font:'Outfit',size:140,color:'#ffffff',lh:1});
  tText('COMING',0.5,0.43,{font:'Big Shoulders Display',size:290,color:'#a5b4fc'});
  tText('SOON',0.5,0.56,{font:'Big Shoulders Display',size:290,color:'#ffffff'});
  tShape('round',.5,.74,.72,.09,'#ffffff',{name:'Date pill',p:{radius:60}});
  tText('LAUNCHING 1 DECEMBER',0.5,0.74,{font:'Outfit',size:50,color:'#312e81'});
  tText('Follow us to be the first to know\n@yourbrand',0.5,0.85,{font:'Outfit',size:50,bold:false,color:'#c7d2fe',lh:1.5});
}}
);
