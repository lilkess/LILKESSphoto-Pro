/* ===== Plugin gallery: browse, search, install and open the built-in plugins ===== */
const PLG_INST_KEY='lk_plg_inst';
const plgInstalled=()=>{try{return JSON.parse(localStorage.getItem(PLG_INST_KEY)||'[]');}catch(e){return [];}};
const plgSetInstalled=a=>{try{localStorage.setItem(PLG_INST_KEY,JSON.stringify(a));}catch(e){toast('Could not remember this on the device');}};
const plgUseCount=()=>{try{return JSON.parse(localStorage.getItem('lk_plg_use')||'{}');}catch(e){return {};}};
function plgDemo(w,h){
  const c=mkCanvas(w,h),x=cctx(c),g=x.createLinearGradient(0,0,0,h*.7);g.addColorStop(0,'#16224a');g.addColorStop(.55,'#8a4f7d');g.addColorStop(1,'#ffb36b');x.fillStyle=g;x.fillRect(0,0,w,h);
  const sx=w*.68,sy=h*.55,sg=x.createRadialGradient(sx,sy,0,sx,sy,h*.28);sg.addColorStop(0,'#fffbe0');sg.addColorStop(.25,'#ffe39a');sg.addColorStop(1,'rgba(255,200,120,0)');x.fillStyle=sg;x.fillRect(0,0,w,h);
  x.fillStyle='#fff7d6';x.beginPath();x.arc(sx,sy,h*.055,0,7);x.fill();
  x.fillStyle='#1d1830';x.beginPath();x.moveTo(0,h*.72);[[.12,.52],[.22,.66],[.34,.46],[.48,.7],[.6,.62],[.8,.74],[1,.6]].forEach(p=>x.lineTo(w*p[0],h*p[1]));x.lineTo(w,h);x.lineTo(0,h);x.closePath();x.fill();
  const lg=x.createLinearGradient(0,h*.72,0,h);lg.addColorStop(0,'#2c2447');lg.addColorStop(1,'#0e0c1a');x.fillStyle=lg;x.fillRect(0,h*.74,w,h);
  x.fillStyle='rgba(255,220,150,.55)';x.fillRect(sx-h*.03,h*.76,h*.06,h*.22);
  [[.2,.82,'#ff6b9a'],[.34,.88,'#6bd4ff'],[.52,.84,'#ffd166']].forEach(([a,b,col])=>{x.fillStyle=col;x.beginPath();x.arc(w*a,h*b,h*.018,0,7);x.fill();});
  return c;
}
function plgThumb(def,W,H){
  const out=mkCanvas(W,H),x=cctx(out);x.fillStyle='#22252c';x.fillRect(0,0,W,H);
  const contain=(c,pad)=>{pad=pad||0;const k=Math.min((W-pad*2)/c.width,(H-pad*2)/c.height);x.imageSmoothingQuality='high';x.drawImage(c,(W-c.width*k)/2,(H-c.height*k)/2,c.width*k,c.height*k);};
  try{
    if(def.process&&def.params){const demo=plgDemo(W,H),id=cctx(demo).getImageData(0,0,W,H),v={};def.params.forEach(p=>v[p.id]=p.value);cctx(demo).putImageData(def.process(id,v,{w:W,h:H,scale:W/900})||id,0,0);x.drawImage(demo,0,0);}
    else if(def.render){const v={};def.params.forEach(p=>v[p.id]=p.value);if('size' in v)v.size=Math.min(v.size,320);if('w' in v&&'h' in v){const k=Math.min(1,520/v.w);v.w=Math.round(v.w*k);v.h=Math.round(v.h*k);}if('module' in v)v.module=5;
      const c=def.render(v,true);if(def.id==='flares'||def.id==='zeus'){x.fillStyle='#000';x.fillRect(0,0,W,H);x.globalCompositeOperation='screen';}
      if(def.id==='qr'||def.id==='flags'||def.id==='chart')contain(c,10);else contain(c,def.id==='elements3d'?4:0);x.globalCompositeOperation='source-over';}
    else if(def.id==='lanczos'){const demo=plgDemo(W,H),s=mkCanvas(24,14);cctx(s).drawImage(demo,0,0,24,14);x.imageSmoothingEnabled=false;x.drawImage(s,0,0,W/2,H);x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(demo,W/2,0,W/2,H,W/2,0,W/2,H);x.fillStyle='rgba(0,0,0,.6)';x.fillRect(W/2-1,0,2,H);}
    else if(def.id==='emoji'){x.font=Math.round(H*.34)+'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';x.textAlign='center';x.textBaseline='middle';['😀','😎','🔥','🎉','❤️','⭐'].forEach((e,i)=>x.fillText(e,W*(.2+.3*(i%3)),H*(.3+.4*Math.floor(i/3))));}
    else if(def.id==='palette'){const demo=plgDemo(W,H);x.drawImage(demo,0,0,W,H*.62);const p=plgPalette(demo,6);p.forEach((q,i)=>{x.fillStyle=q.hex;x.fillRect(W*i/p.length,H*.62,W/p.length+1,H*.38);});}
    else if(def.id==='batch'){const demo=plgDemo(W,H);[[.12,.18,-6],[.2,.12,0],[.28,.06,6]].forEach(([a,b,r])=>{x.save();x.translate(W*(a+.25),H*(b+.3));x.rotate(r*Math.PI/180);x.drawImage(demo,-W*.2,-H*.2,W*.4,H*.4);x.strokeStyle='#fff';x.lineWidth=2;x.strokeRect(-W*.2,-H*.2,W*.4,H*.4);x.restore();});x.fillStyle='#fff';x.font='bold '+H*.16+'px sans-serif';x.textAlign='center';x.fillText('ZIP',W*.78,H*.58);}
    else if(def.id==='cameraraw'){x.drawImage(plgDemo(W,H),0,0);x.fillStyle='rgba(15,16,20,.82)';x.fillRect(W*.58,0,W*.42,H);for(let i=0;i<6;i++){const y=H*(.12+i*.14);x.fillStyle='#555';x.fillRect(W*.62,y,W*.32,3);x.fillStyle='#f0f0f0';x.beginPath();x.arc(W*(.64+((i*37)%25)/100),y+1.5,5,0,7);x.fill();}}
    else{x.drawImage(plgDemo(W,H),0,0);x.fillStyle='rgba(255,255,255,.9)';x.font='bold '+H*.3+'px sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('▣',W/2,H/2);}
  }catch(e){console.error('thumb',def.id,e);x.fillStyle='#333';x.fillRect(0,0,W,H);}
  return out;
}
function openPluginGallery(){
  const st={tab:'hot',cat:'All',q:''};
  const inst=()=>new Set(plgInstalled());
  const list=()=>{
    const q=st.q.trim().toLowerCase(),use=plgUseCount();
    let a=PLG.filter(d=>(st.cat==='All'||(st.cat==='Installed'?inst().has(d.id):d.cat===st.cat))&&(!q||(d.name+' '+d.cat+' '+(d.desc||'')).toLowerCase().includes(q)));
    if(st.tab==='new')a=a.slice().sort((x,y)=>y.order-x.order);
    else if(st.tab==='top')a=a.slice().sort((x,y)=>(use[y.id]||0)-(use[x.id]||0)||x.order-y.order);
    return a;
  };
  modalOpen('Plugins','<div class="pg"><div class="pg-top"><div class="pg-tabs" id="pg-tabs"><button data-t="hot">Hot</button><button data-t="new">New</button><button data-t="top">Top</button></div><input type="search" id="pg-q" placeholder="Search plugins"><button id="pg-add" title="Install a plugin file, a web address or pasted code">Add Plugins</button></div>'
    +'<div class="pg-body"><nav class="pg-cats" id="pg-cats"></nav><div class="pg-grid" id="pg-grid"></div></div><div class="muted pg-note">Hot is the featured order, New is the latest additions, Top is what you use most on this device. All plugins here are built in and work offline.</div></div>',
   [{label:'Close'}],root=>{
     const grid=root.querySelector('#pg-grid'),cats=root.querySelector('#pg-cats');let tq=0;
     const drawCats=()=>{const n=c=>PLG.filter(d=>d.cat===c).length;
       cats.innerHTML='<div class="pg-h">CATEGORIES</div>'+['All'].concat(PLG_CATS).filter(c=>c==='All'||n(c)).map(c=>'<button data-c="'+c+'" class="'+(st.cat===c?'on':'')+'">'+c+'<em>'+(c==='All'?PLG.length:n(c))+'</em></button>').join('')+'<div class="pg-h">INSTALLED</div><button data-c="Installed" class="'+(st.cat==='Installed'?'on':'')+'">Installed<em>'+inst().size+'</em></button>';};
     const draw=()=>{
       root.querySelectorAll('#pg-tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===st.tab));drawCats();
       const a=list(),ins=inst();
       grid.innerHTML=a.length?a.map(d=>'<div class="pg-card" data-id="'+d.id+'"><div class="pg-th" data-th="'+d.id+'"></div><b>'+esc(d.name)+'</b><div class="muted pg-by">By '+esc(d.author)+' in '+esc(d.cat)+'</div><div class="muted pg-ds">'+esc(d.desc||'')+'</div><div class="pg-bt"><button class="primary" data-open="'+d.id+'">Open</button><button data-inst="'+d.id+'">'+(ins.has(d.id)?'Remove from menu':'Add to menu')+'</button></div></div>').join(''):'<p class="muted">No plugins match.</p>';
       let i=0;const cards=[...grid.querySelectorAll('[data-th]')];
       const next=()=>{if(!grid.isConnected||i>=cards.length)return;const el=cards[i++],d=PLG.find(x=>x.id===el.dataset.th);if(d&&el.isConnected){const c=plgThumb(d,320,180);c.style.width='100%';c.style.height='auto';el.appendChild(c);}setTimeout(next,12);};
       setTimeout(next,10);
     };
     root.addEventListener('click',e=>{
       const t=e.target.closest('[data-t]');if(t){st.tab=t.dataset.t;draw();return;}
       const c=e.target.closest('[data-c]');if(c){st.cat=c.dataset.c;draw();return;}
       const o=e.target.closest('[data-open]');if(o){const d=PLG.find(x=>x.id===o.dataset.open);closeModal();setTimeout(()=>{try{d.run();}catch(err){console.error(err);toast('Plugin error: '+(err.message||err));}},40);return;}
       const n=e.target.closest('[data-inst]');if(n){const s=inst(),id=n.dataset.inst;if(s.has(id)){s.delete(id);toast('Removed from the Plugins menu');}else{s.add(id);toast('Added. Find it in the Plugins menu.');}plgSetInstalled([...s]);rebuildPluginsMenu();draw();return;}
       if(e.target.id==='pg-add'){closeModal();setTimeout(openPlugins,40);}
     });
     root.querySelector('#pg-q').addEventListener('input',e=>{st.q=e.target.value;clearTimeout(tq);tq=setTimeout(draw,150);});
     draw();
   },{wide:true});
}
ACT.plugGallery=openPluginGallery;
function plgMenuItems(){
  const ins=new Set(plgInstalled()),out=[];
  PLG_CATS.forEach(cat=>{const a=PLG.filter(d=>d.cat===cat&&ins.has(d.id));if(a.length)out.push(sub(cat,a.map(d=>al(d.name+'...','',()=>{try{d.run();}catch(e){console.error(e);toast('Plugin error: '+(e.message||e));}}))));});
  return out;
}
function rebuildPluginsMenu(){}
{
  const st=document.createElement('style');
  st.textContent='.pg{display:flex;flex-direction:column;gap:10px;min-height:60vh}.pg-top{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.pg-tabs{display:flex;gap:2px}.pg-tabs button{background:transparent;border:0;border-bottom:2px solid transparent;border-radius:0;padding:6px 12px;font-size:15px;opacity:.75}.pg-tabs button.on{border-bottom-color:#4b9eff;opacity:1}.pg-top input{flex:1;min-width:140px}.pg-body{display:flex;gap:14px;align-items:flex-start}.pg-cats{width:170px;flex:none;display:flex;flex-direction:column;gap:2px}.pg-h{font-size:11px;letter-spacing:.08em;opacity:.55;margin:10px 4px 4px}.pg-cats button{display:flex;justify-content:space-between;background:transparent;border:0;text-align:left;padding:7px 8px;border-radius:6px;font-size:13px}.pg-cats button.on{background:#ffffff1c}.pg-cats em{font-style:normal;opacity:.55}.pg-grid{flex:1;min-width:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px;max-height:62vh;overflow:auto;padding-right:4px}.pg-card{background:#2a2d35;border-radius:10px;padding:8px;display:flex;flex-direction:column;gap:3px}.pg-th{aspect-ratio:16/9;background:#1c1e23;border-radius:6px;overflow:hidden}.pg-th canvas{display:block}.pg-card b{margin-top:4px}.pg-by{font-size:11px}.pg-ds{font-size:12px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;min-height:48px}.pg-bt{display:flex;gap:6px;margin-top:6px}.pg-bt button{flex:1;font-size:12px;padding:6px 4px}.pg-note{font-size:11px}@media(max-width:700px){.pg-body{flex-direction:column}.pg-cats{width:100%;flex-direction:row;flex-wrap:wrap}.pg-h{display:none}.pg-grid{max-height:none;grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}}';
  document.head.appendChild(st);
}
