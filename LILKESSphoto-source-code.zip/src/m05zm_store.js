/* ===== KESS Store: PNG images, backgrounds, photos, textures, shapes, icons ===== */
const KS={tab:'featured',q:'',sel:null,online:true,gen:{size:2048,c1:'#d4a017',c2:'#1b1b2f'},icon:{color:'#1f2430'},shape:{color:'#f2b134'},busy:0,cache:{}};
const ks$=(s,r)=>(r||document).querySelector(s);
/* ---------- generators (work offline, any size) ---------- */
const ksRGB=c=>hexRGB(c);
const mixc=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];
function genCanvas(w,h,fn){const c=mkCanvas(w,h),x=cctx(c),id=x.createImageData(w,h),d=id.data;fn(d,w,h);x.putImageData(id,0,0);return c;}
const GEN=[
 ['g_linear','Linear gradient','Backgrounds','gradient smooth',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=(x/w+y/h)/2,c=mixc(A,B,t),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_radial','Radial glow','Backgrounds','gradient spotlight studio',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const R=Math.hypot(w,h)/2;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=Math.min(1,Math.hypot(x-w/2,y-h/2)/R*1.15),c=mixc(A,B,fxSS(t)),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_mesh','Mesh gradient','Backgrounds','gradient colorful modern',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const r=fxRnd(s),pts=[];for(let i=0;i<6;i++){const hh=(r()*360),m=i%2?A:B,c=hsl2rgb(hh,0.7,0.55);pts.push({x:r()*w,y:r()*h,c:mixc(m,c,0.45)});}
   for(let y=0;y<h;y++)for(let x=0;x<w;x++){let sr=0,sg=0,sb=0,sw=0;for(const p of pts){const dd=((x-p.x)**2+(y-p.y)**2)/(w*h)+0.002,wt=1/(dd*dd);sr+=p.c[0]*wt;sg+=p.c[1]*wt;sb+=p.c[2]*wt;sw+=wt;}const i=(y*w+x)*4;d[i]=sr/sw;d[i+1]=sg/sw;d[i+2]=sb/sw;d[i+3]=255;}})],
 ['g_burst','Sunburst rays','Backgrounds','rays sunburst retro',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const n=24;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const a=Math.atan2(y-h/2,x-w/2)+Math.PI,k=Math.floor(a/(2*Math.PI)*n)%2,c=k?A:mixc(A,B,0.5),i=(y*w+x)*4,v=1-Math.hypot(x-w/2,y-h/2)/Math.hypot(w,h)*0.35;d[i]=c[0]*v;d[i+1]=c[1]*v;d[i+2]=c[2]*v;d[i+3]=255;}})],
 ['g_bokeh','Bokeh lights','Backgrounds','bokeh lights party glitter blur',(w,h,s,A,B)=>{const c=genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=y/h,cc=mixc(B,[0,0,0],0.4+0.3*t),i=(y*w+x)*4;d[i]=cc[0];d[i+1]=cc[1];d[i+2]=cc[2];d[i+3]=255;}}),x=cctx(c),r=fxRnd(s);x.globalCompositeOperation='lighter';
   for(let i=0;i<70;i++){const rad=(0.02+r()*0.07)*Math.min(w,h),px=r()*w,py=r()*h,cc=mixc(A,[255,240,200],r()*0.6),g=x.createRadialGradient(px,py,0,px,py,rad);g.addColorStop(0,'rgba('+cc.map(Math.round)+','+(0.15+r()*0.35)+')');g.addColorStop(0.85,'rgba('+cc.map(Math.round)+','+(0.1+r()*0.25)+')');g.addColorStop(1,'rgba('+cc.map(Math.round)+',0)');x.fillStyle=g;x.beginPath();x.arc(px,py,rad,0,7);x.fill();}return c;}],
 ['g_stars','Starry night','Backgrounds','stars night sky space',(w,h,s,A,B)=>{const c=genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=y/h,cc=mixc(B,mixc(B,A,0.35),t*t),n=fxFbm(x/(w*0.3),y/(w*0.3),s,4),i=(y*w+x)*4;d[i]=cc[0]*(0.7+n*0.5);d[i+1]=cc[1]*(0.7+n*0.5);d[i+2]=cc[2]*(0.7+n*0.5);d[i+3]=255;}}),x=cctx(c),r=fxRnd(s);
   for(let i=0;i<Math.round(w*h/9000);i++){const px=r()*w,py=r()*h,rad=0.4+r()*r()*2.4*(w/1024),a=0.4+r()*0.6;x.fillStyle='rgba(255,255,255,'+a+')';x.beginPath();x.arc(px,py,rad,0,7);x.fill();if(rad>1.8){x.strokeStyle='rgba(255,255,255,'+a*0.5+')';x.lineWidth=0.6;x.beginPath();x.moveTo(px-rad*4,py);x.lineTo(px+rad*4,py);x.moveTo(px,py-rad*4);x.lineTo(px,py+rad*4);x.stroke();}}return c;}],
 ['g_confetti','Confetti','Backgrounds','confetti party birthday celebration',(w,h,s,A,B)=>{const c=genCanvas(w,h,(d)=>{for(let i=0;i<d.length;i+=4){d[i]=B[0];d[i+1]=B[1];d[i+2]=B[2];d[i+3]=255;}}),x=cctx(c),r=fxRnd(s);
   for(let i=0;i<Math.round(w*h/2600);i++){x.save();x.translate(r()*w,r()*h);x.rotate(r()*7);const cc=hsl2rgb(r()*360,0.8,0.6);x.fillStyle=r()<0.35?'rgb('+A.map(Math.round)+')':'rgb('+cc.map(Math.round)+')';const k=w/1024;if(r()<0.5)x.fillRect(-4*k,-8*k,8*k,16*k);else{x.beginPath();x.arc(0,0,5*k,0,7);x.fill();}x.restore();}return c;}],
 ['g_dots','Polka dots','Backgrounds','dots halftone pattern',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(24,w/22);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const u=((x%k)/k-0.5),v=((y%k)/k-0.5),on=Math.hypot(u,v)<0.22?1:0,c=on?A:B,i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_stripes','Diagonal stripes','Backgrounds','stripes pattern lines',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(30,w/18);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const on=((x+y)%(k*2))<k,c=on?A:B,i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_grid','Blueprint grid','Backgrounds','grid technical blueprint',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(20,w/40);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const major=(x%(k*5)<2||y%(k*5)<2),minor=(x%k<1||y%k<1),c=major?mixc(B,A,0.7):minor?mixc(B,A,0.3):B,i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_chevron','Chevron','Backgrounds','chevron zigzag pattern',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(40,w/12);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=((y+Math.abs((x%(2*k))-k))%(k*1.4))<k*0.7,c=t?A:B,i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_waves','Layered waves','Backgrounds','waves layers ocean',(w,h,s,A,B)=>{const c=mkCanvas(w,h),x=cctx(c);const g=x.createLinearGradient(0,0,0,h);g.addColorStop(0,'rgb('+B.map(Math.round)+')');g.addColorStop(1,'rgb('+mixc(B,A,0.5).map(Math.round)+')');x.fillStyle=g;x.fillRect(0,0,w,h);const r=fxRnd(s);
   for(let l=0;l<6;l++){const y0=h*(0.35+l*0.11),amp=h*(0.05+r()*0.04),ph=r()*6,fr=1.2+r()*1.5;x.beginPath();x.moveTo(0,h);for(let X=0;X<=w;X+=4)x.lineTo(X,y0+Math.sin(X/w*fr*Math.PI*2+ph)*amp+Math.sin(X/w*fr*5+ph)*amp*0.25);x.lineTo(w,h);x.closePath();x.fillStyle='rgba('+mixc(B,A,l/6).map(Math.round)+',0.55)';x.fill();}return c;}],
 ['g_blobs','Abstract blobs','Backgrounds','blobs shapes abstract organic',(w,h,s,A,B)=>{const c=mkCanvas(w,h),x=cctx(c);x.fillStyle='rgb('+B.map(Math.round)+')';x.fillRect(0,0,w,h);const r=fxRnd(s);
   for(let i=0;i<7;i++){const cx=r()*w,cy=r()*h,R=(0.15+r()*0.25)*Math.min(w,h),cc=mixc(A,hsl2rgb(r()*360,0.6,0.6),r()*0.5);x.fillStyle='rgba('+cc.map(Math.round)+','+(0.35+r()*0.4)+')';x.beginPath();for(let a=0;a<=64;a++){const t=a/64*Math.PI*2,rad=R*(1+0.28*Math.sin(t*3+i)+0.18*Math.sin(t*5+i*2));const px=cx+Math.cos(t)*rad,py=cy+Math.sin(t)*rad;a?x.lineTo(px,py):x.moveTo(px,py);}x.closePath();x.fill();}return c;}],
 ['g_aurora','Aurora','Backgrounds','aurora northern lights glow',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.5),y/(h*1.3),s,5),band=Math.exp(-Math.pow((y/h-(0.35+0.25*n))/0.18,2)),c=mixc(B,A,band*0.9+n*0.2),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_glitter','Gold glitter','Backgrounds','glitter sparkle gold shiny',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const r=fxRnd(s);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.2),y/(w*0.2),s,3),sp=fxHash(x>>1,y>>1,s),tw=sp>0.965?(sp-0.965)/0.035:0,base=mixc(B,A,n*0.45),c=mixc(base,[255,244,200],tw),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_spot','Dark spotlight','Backgrounds','spotlight studio dark vignette product',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=Math.hypot((x-w/2)/(w*0.55),(y-h*0.42)/(h*0.6)),k=Math.max(0,1-t),c=mixc([8,8,10],mixc(B,A,0.5),k*k),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['g_memphis','Memphis shapes','Backgrounds','memphis geometric colorful pattern',(w,h,s,A,B)=>{const c=mkCanvas(w,h),x=cctx(c),r=fxRnd(s);x.fillStyle='rgb('+B.map(Math.round)+')';x.fillRect(0,0,w,h);const pal=[A,[255,90,140],[40,190,235],[255,200,40],[30,50,110],[255,255,255]];
   for(let i=0;i<Math.round(w*h/36000);i++){x.save();x.translate(r()*w,r()*h);x.rotate(r()*6.3);const k=(22+r()*38)*(w/1024),col=pal[(r()*pal.length)|0];x.fillStyle=x.strokeStyle='rgb('+col.map(Math.round)+')';x.lineWidth=k*0.14;const t=r()*6|0;x.beginPath();
    if(t===0)x.arc(0,0,k*0.5,0,7);else if(t===1){x.moveTo(0,-k*0.55);x.lineTo(k*0.5,k*0.4);x.lineTo(-k*0.5,k*0.4);x.closePath();}else if(t===2)x.rect(-k/2,-k/2,k,k);else if(t===3){for(let q=0;q<5;q++){x.lineTo(q*k*0.25-k/2,(q%2?k*0.2:-k*0.2));}x.stroke();x.restore();continue;}else if(t===4){x.arc(0,0,k*0.5,0,7);x.stroke();x.restore();continue;}else{x.moveTo(-k/2,0);x.lineTo(k/2,0);x.moveTo(0,-k/2);x.lineTo(0,k/2);x.stroke();x.restore();continue;}
    x.fill();x.restore();}return c;}],
 ['g_checker','Checkerboard','Backgrounds','checker board pattern',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(30,w/16);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const on=((x/k|0)+(y/k|0))%2,c=on?A:B,i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 // textures
 ['t_paper','Paper','Textures','paper white cream',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const base=mixc([250,246,236],A,0.12);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/3,y/3,s,3)*0.5+fxFbm(x/(w*0.15),y/(w*0.15),s+3,3)*0.5,v=0.9+n*0.14,i=(y*w+x)*4;d[i]=base[0]*v;d[i+1]=base[1]*v;d[i+2]=base[2]*v;d[i+3]=255;}})],
 ['t_canvas','Canvas weave','Textures','canvas fabric linen weave',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const base=mixc([225,215,195],A,0.12),k=Math.max(3,w/320);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const a=Math.sin(x/k*Math.PI*2)*0.5+0.5,b=Math.sin(y/k*Math.PI*2)*0.5+0.5,n=fxNoise(x/2,y/2,s),v=0.78+0.14*(a*b+(1-a)*(1-b))+0.12*n,i=(y*w+x)*4;d[i]=base[0]*v;d[i+1]=base[1]*v;d[i+2]=base[2]*v;d[i+3]=255;}})],
 ['t_marble','Marble','Textures','marble stone white luxury',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const dark=mixc([40,40,48],B,0.3);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.25),y/(w*0.25),s,6),v=Math.abs(Math.sin((x/w*3+y/h*2+n*3.2)*Math.PI)),t=Math.pow(1-v,3),c=mixc([240,240,244],dark,t*0.85),m=fxFbm(x/6,y/6,s+9,2)*0.06,i=(y*w+x)*4;d[i]=c[0]*(1-m);d[i+1]=c[1]*(1-m);d[i+2]=c[2]*(1-m);d[i+3]=255;}})],
 ['t_concrete','Concrete','Textures','concrete cement wall grey',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.08),y/(w*0.08),s,6),f=fxNoise(x/1.5,y/1.5,s+4),hole=fxHash(x>>1,y>>1,s)>0.995?0.55:1,v=(150+n*60+f*30-15)*hole,i=(y*w+x)*4;d[i]=v;d[i+1]=v;d[i+2]=v*1.02;d[i+3]=255;}})],
 ['t_wood','Wood grain','Textures','wood planks brown timber',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const light=mixc([205,150,95],A,0.2),dark=mixc([110,65,35],A,0.1),pl=Math.max(80,w/6);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=(x/pl)|0,xx=x%pl,n=fxFbm(y/(h*0.7)+p*3.1,xx/(pl*2),s+p,5),ring=Math.sin((n*14+xx/pl*1.2)*Math.PI),fine=fxNoise(y/1.2,xx/18,s+p+7),t=0.5+0.5*ring,c=mixc(dark,light,t*0.7+fine*0.3),edge=xx<2?0.6:1,i=(y*w+x)*4;d[i]=c[0]*edge;d[i+1]=c[1]*edge;d[i+2]=c[2]*edge;d[i+3]=255;}})],
 ['t_brushed','Brushed metal','Textures','metal steel silver brushed',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxNoise(x/70,y*1.3,s)*0.6+fxNoise(x/20,y*2.5,s+1)*0.4,g=fxNoise(x/(w*0.5),y/(h*0.5),s+2),v=150+n*70+g*40-20,i=(y*w+x)*4;d[i]=v;d[i+1]=v;d[i+2]=v*1.04;d[i+3]=255;}})],
 ['t_foil','Gold foil','Textures','gold foil crumpled shiny metallic',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const gold=mixc([212,160,40],A,0.5);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.06),y/(w*0.06),s,5),nx=fxFbm((x+2)/(w*0.06),y/(w*0.06),s,5)-n,ny=fxFbm(x/(w*0.06),(y+2)/(w*0.06),s,5)-n,l=0.55+(nx*-1.4+ny*-1.0)*28,v=Math.max(0.25,Math.min(1.5,l)),c=mixc([90,55,10],mixc(gold,[255,245,200],Math.max(0,v-1)),Math.min(1,v)),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['t_leather','Leather','Textures','leather skin brown grain',(w,h,s,A,B)=>{const base=mixc([90,50,30],A,0.25);const cells=fxCells(w,h,Math.max(10,w/90),s);return genCanvas(w,h,(d)=>{for(let k=0,i=0;k<w*h;k++,i+=4){const e=cells.dist[k],edge=Math.max(0,1-e/(w/90*0.6)),n=fxNoise((k%w)/2,(k/w|0)/2,s),v=0.55+edge*0.5+n*0.12;d[i]=base[0]*v;d[i+1]=base[1]*v;d[i+2]=base[2]*v;d[i+3]=255;}});}],
 ['t_cardboard','Cardboard','Textures','cardboard kraft brown packaging',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/4,y/4,s,3),f=Math.sin(x/w*140)*0.04+fxNoise(x/40,y/2,s+3)*0.12,v=0.78+n*0.16+f,i=(y*w+x)*4;d[i]=190*v;d[i+1]=150*v;d[i+2]=105*v;d[i+3]=255;}})],
 ['t_grunge','Grunge','Textures','grunge dirty scratched distressed overlay',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.1),y/(w*0.1),s,6),sp=fxHash(x,y,s)>0.992?-60:0,sc2=fxNoise(x/(w*0.4),y*0.9,s+7)>0.78?-40:0,v=clamp(120+n*130-40+sp+sc2,0,255),i=(y*w+x)*4;d[i]=v;d[i+1]=v;d[i+2]=v;d[i+3]=255;}})],
 ['t_sand','Sand','Textures','sand beach desert dunes',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const g=fxHash(x,y,s),dune=fxFbm(x/(w*0.3),y/(w*0.12),s,4),v=0.8+g*0.22+dune*0.25-0.1,i=(y*w+x)*4;d[i]=226*v;d[i+1]=198*v;d[i+2]=150*v;d[i+3]=255;}})],
 ['t_water','Water ripples','Textures','water ripple pool sea',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const deep=mixc([10,70,120],A,0.1),light=[170,230,245];for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=fxFbm(x/(w*0.08),y/(w*0.08),s,4),m=Math.abs(Math.sin((n*6+fxNoise(x/(w*0.04),y/(w*0.04),s+3)*3)*Math.PI)),t=Math.pow(1-m,6),c=mixc(deep,light,t*0.8+n*0.2),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['t_clouds','Clouds','Textures','clouds sky soft',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const n=Math.max(0,Math.min(1,(fxFbm(x/(w*0.3),y/(w*0.2),s,6)-0.35)*2.3)),c=mixc([70,140,225],[255,255,255],n),i=(y*w+x)*4;d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255;}})],
 ['t_carbon','Carbon fiber','Textures','carbon fiber black dark tech',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(6,w/110);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const u=(x%(k*2))/k,v=(y%(k*2))/k,a=((x/(k*2)|0)+(y/(k*2)|0))%2,t=a?(Math.sin(u*Math.PI)*0.5+0.5):(Math.sin(v*Math.PI)*0.5+0.5),val=16+t*30+(((x/k|0)+(y/k|0))%2?10:0),i=(y*w+x)*4;d[i]=val;d[i+1]=val;d[i+2]=val*1.1;d[i+3]=255;}})],
 ['t_stone','Stone tiles','Textures','stone tiles cobble rock',(w,h,s,A,B)=>{const C=fxCells(w,h,Math.max(40,w/12),s);return genCanvas(w,h,(d)=>{const col=new Float32Array(C.n);const r=fxRnd(s);for(let i=0;i<C.n;i++)col[i]=0.65+r()*0.5;for(let k=0,i=0;k<w*h;k++,i+=4){const e=C.dist[k],ed=Math.min(1,e/(w/12*0.55)),n=fxFbm((k%w)/(w*0.05),(k/w|0)/(w*0.05),s,4),v=(col[C.id[k]]*(0.7+n*0.5))*(1-Math.pow(ed,6)*0.55)*150;d[i]=v;d[i+1]=v*0.97;d[i+2]=v*0.92;d[i+3]=255;}});}],
 ['t_grain','Film grain','Textures','noise grain film overlay',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++){const v=128+(fxHash(x,y,s)-0.5)*120,i=(y*w+x)*4;d[i]=d[i+1]=d[i+2]=v;d[i+3]=255;}})],
 ['t_fabric','Denim fabric','Textures','denim jeans fabric blue twill',(w,h,s,A,B)=>genCanvas(w,h,(d)=>{const k=Math.max(2,w/400);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const tw=Math.sin((x+y)/k*Math.PI)*0.5+0.5,n=fxNoise(x/2,y/2,s),v=0.65+tw*0.3+n*0.18,i=(y*w+x)*4;d[i]=60*v;d[i+1]=95*v;d[i+2]=150*v;d[i+3]=255;}})]
].map(g=>({id:g[0],name:g[1],cat:g[2],tags:g[3],fn:g[4],kind:'gen'}));
function genRender(g,size,c1,c2){
  const sz=size==='doc'&&typeof doc!=='undefined'&&doc?[doc.w,doc.h]:[+size,Math.round(+size*0.75)];
  const w=Math.max(64,Math.min(4096,sz[0])),h=Math.max(64,Math.min(4096,sz[1]));
  return g.fn(w,h,7,ksRGB(c1),ksRGB(c2));
}
/* ---------- pack, shapes ---------- */
const PACK=(typeof KESS_PACK!=='undefined'?KESS_PACK:[]).concat(typeof KESS_PACK2!=='undefined'?KESS_PACK2:[],typeof KESS_PACK3!=='undefined'?KESS_PACK3:[],typeof KESS_PACK4!=='undefined'?KESS_PACK4:[],typeof KESS_PACK5!=='undefined'?KESS_PACK5:[],typeof KESS_PACK6!=='undefined'?KESS_PACK6:[],typeof KESS_PACK7!=='undefined'?KESS_PACK7:[],typeof KESS_PACK8!=='undefined'?KESS_PACK8:[],typeof KESS_PACK9!=='undefined'?KESS_PACK9:[],typeof KESS_PACK10!=='undefined'?KESS_PACK10:[],typeof KESS_PACK11!=='undefined'?KESS_PACK11:[]).map(p=>Object.assign({},p,{src:p.file||('data:'+p.mime+';base64,'+p.data),data:null}));
function shapeItems(){return VEC_SHAPES.map(s=>({id:'s_'+s.id,sid:s.id,name:s.name,cat:'Shapes',tags:(SHAPE_CAT[s.id]||'')+' '+s.name,kind:'shape',sub:SHAPE_CAT[s.id]||'Symbols'}));}
/* ---------- helpers ---------- */
function ksImgFrom(src){return new Promise((res,rej)=>{const im=new Image();im.crossOrigin='anonymous';im.onload=()=>res(im);im.onerror=()=>rej(new Error('image load'));im.src=src;});}
async function ksFetchBlob(url,headers){const r=await fetch(url,{mode:'cors',headers});if(!r.ok)throw new Error('http '+r.status);return await r.blob();}
const ksCanvasBlob=(c,type)=>new Promise(r=>c.toBlob(r,type||'image/png'));
function shapeCanvas(sid,color,size){const c=mkCanvas(size,size),x=cctx(c);x.fillStyle=color;x.beginPath();vec_trace(x,vec_transform(vec_shape(sid),[size*0.0096,0,0,size*0.0096,size*0.02,size*0.02]));x.fill('evenodd');return c;}
const iconUrl=(id,color,h)=>'https://api.iconify.design/'+id.replace(':','/')+'.svg?color='+encodeURIComponent(color)+'&height='+(h||256);
/* turn any store item into a canvas at full quality */
async function ksItemCanvas(it,full){
  if(it.kind==='gen')return genRender(it,KS.gen.size,KS.gen.c1,KS.gen.c2);
  if(it.kind==='shape')return shapeCanvas(it.sid,KS.shape.color,1024);
  if(it.kind==='geo')return geoRender(it,1024);
  if(it.kind==='geopat')return geoPatternRender(it,KS.gen.size);
  if(it.kind==='mdi')return mdiCanvas(it.d,KS.icon.color,1024);
  if(it.kind==='icon'){const im=await ksImgFrom(iconUrl(it.id,KS.icon.color,1024));const c=mkCanvas(im.naturalWidth||1024,im.naturalHeight||1024);cctx(c).drawImage(im,0,0,c.width,c.height);return c;}
  if(it.kind==='png'||it.kind==='photo'){const im=await ksImgFrom(it.src);const c=mkCanvas(im.naturalWidth,im.naturalHeight);cctx(c).drawImage(im,0,0);return c;}
  if(it.kind==='online'){
    let url=it.full||it.src;
    if(it.resolve)url=await it.resolve();
    let blob;try{blob=await ksFetchBlob(url);}catch(e){if(it.src&&url!==it.src)blob=await ksFetchBlob(it.src);else throw e;}
    const u=URL.createObjectURL(blob);try{const im=await ksImgFrom(u);const c=mkCanvas(im.naturalWidth,im.naturalHeight);cctx(c).drawImage(im,0,0);return c;}finally{setTimeout(()=>URL.revokeObjectURL(u),5000);}
  }
  throw new Error('unknown item');
}
const ksFileName=it=>(it.name||'kess').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'-').toLowerCase()||'kess';
async function ksAdd(it,mode){
  try{
    toast('Getting '+it.name+'...');const c=await ksItemCanvas(it);
    const blob=await ksCanvasBlob(c,'image/png'),file=new File([blob],ksFileName(it)+'.png',{type:'image/png'});
    closeModal();
    if(mode==='new'||!doc){
      if(it.cat==='Backgrounds'||it.cat==='Textures'||it.kind==='photo'||mode==='new'){await openPhoto(file);}
      else{newBlank('KESS design',1080,1080,72,'#ffffff');await placeImage(file);}
    }else await placeImage(file);
    if(it.kind==='gen'&&doc){const l=active();if(l&&(it.cat==='Backgrounds'||it.cat==='Textures'))toast(it.name+' added. Use the Layers panel to move it behind other layers.');}
  }catch(err){console.error(err);toast('Could not get that item. Check your internet connection, then try again.');}
}
async function ksDownload(it,fmt){
  try{
    toast('Preparing '+it.name+'...');
    if(fmt==='svg'&&(it.kind==='shape'||it.kind==='icon'||it.kind==='mdi')){
      let svg;if(it.kind==='mdi')svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="'+KS.icon.color+'" d="'+it.d+'"/></svg>';else if(it.kind==='icon')svg=await (await fetch(iconUrl(it.id,KS.icon.color,512))).text();
      else{const d=vec_toSVG(vec_shape(it.sid));svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path fill="'+KS.shape.color+'" fill-rule="evenodd" d="'+d+'"/></svg>';}
      await saveBlob(new Blob([svg],{type:'image/svg+xml'}),ksFileName(it)+'.svg');return;}
    const c=await ksItemCanvas(it);
    if(fmt==='jpg'){const f=mkCanvas(c.width,c.height),x=cctx(f);x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(c,0,0);await saveBlob(await ksCanvasBlob(f,'image/jpeg'),ksFileName(it)+'.jpg');}
    else await saveBlob(await ksCanvasBlob(c,'image/png'),ksFileName(it)+'.png');
  }catch(err){console.error(err);if(it.page){toast('Direct download is blocked for this source. Opening its page.');window.open(it.page,'_blank','noopener');}else toast('Could not download that item. Check your internet connection.');}
}
/* ---------- online sources ---------- */
const ONLINE={
 async openverse(q,ext,license){
  const url='https://api.openverse.org/v1/images/?q='+encodeURIComponent(q||'nature')+'&license_type=commercial&page_size=30'+(ext?'&extension='+ext:'')+(license?'&license='+license:'');
  const r=await fetch(url);if(!r.ok)throw new Error('openverse '+r.status);const j=await r.json();
  return (j.results||[]).map(x=>({id:'ov_'+x.id,name:(x.title||'Image').slice(0,60),kind:'online',cat:ext==='png'?'PNG Images':'Photos',src:x.thumbnail||x.url,full:x.url,page:x.foreign_landing_url,lic:(x.license||'').toUpperCase()+(x.license_version?' '+x.license_version:''),by:x.creator||'',srcName:'Openverse',w:x.width,h:x.height}));
 },
 async commons(q,png){
  const url='https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrnamespace=6&gsrlimit=30&gsrsearch='+encodeURIComponent((q||'nature')+(png?' filemime:png':' filemime:jpeg')+' filew:>1200')+'&prop=imageinfo&iiprop=url|size|extmetadata&iiurlwidth=1600';
  const r=await fetch(url);if(!r.ok)throw new Error('commons '+r.status);const j=await r.json();const pages=Object.values((j.query&&j.query.pages)||{});
  return pages.filter(p=>p.imageinfo&&p.imageinfo[0]).map(p=>{const i=p.imageinfo[0],m=i.extmetadata||{};return {id:'wc_'+p.pageid,name:p.title.replace(/^File:/,'').replace(/\.[a-z]+$/i,'').slice(0,60),kind:'online',cat:png?'PNG Images':'Photos',src:i.thumburl||i.url,full:i.thumburl||i.url,page:i.descriptionurl,lic:(m.LicenseShortName&&m.LicenseShortName.value)||'See page',by:((m.Artist&&m.Artist.value)||'').replace(/<[^>]+>/g,'').slice(0,40),srcName:'Wikimedia Commons',w:i.thumbwidth,h:i.thumbheight};});
 },
 async polyhaven(q){
  if(!KS.cache.ph){const r=await fetch('https://api.polyhaven.com/assets?t=textures');if(!r.ok)throw new Error('polyhaven '+r.status);KS.cache.ph=await r.json();}
  const ql=(q||'').toLowerCase();
  return Object.entries(KS.cache.ph).filter(([id,a])=>!ql||id.includes(ql.replace(/\s+/g,'_'))||(a.name||'').toLowerCase().includes(ql)||(a.categories||[]).join(' ').toLowerCase().includes(ql)||(a.tags||[]).join(' ').toLowerCase().includes(ql)).slice(0,60).map(([id,a])=>({id:'ph_'+id,name:a.name||id,kind:'online',cat:'Textures',src:'https://cdn.polyhaven.com/asset_img/thumbs/'+id+'.png?width=320&height=320',lic:'CC0',by:'Poly Haven',srcName:'Poly Haven',page:'https://polyhaven.com/a/'+id,
   resolve:async()=>{const r=await fetch('https://api.polyhaven.com/files/'+id);const f=await r.json();const d=f.Diffuse||f.diff||f.Color||{};const k=['2k','4k','1k','8k'].find(x=>d[x]&&d[x].jpg);if(!k)throw new Error('no map');return d[k].jpg.url;}}));
 },
 async iconify(q){
  const r=await fetch('https://api.iconify.design/search?query='+encodeURIComponent(q||'star')+'&limit=64');if(!r.ok)throw new Error('iconify '+r.status);const j=await r.json();
  return (j.icons||[]).map(id=>({id,name:id.split(':')[1].replace(/-/g,' '),kind:'icon',cat:'Icons',srcName:'Iconify ('+id.split(':')[0]+')',lic:'Open-source icon set'}));
 },
 async picsum(page){
  const r=await fetch('https://picsum.photos/v2/list?page='+page+'&limit=40');if(!r.ok)throw new Error('picsum '+r.status);const j=await r.json();
  return j.map(x=>({id:'ps_'+x.id,name:'Photo by '+x.author,kind:'online',cat:'Photos',src:'https://picsum.photos/id/'+x.id+'/480/320',full:'https://picsum.photos/id/'+x.id+'/'+Math.min(x.width,2400)+'/'+Math.round(Math.min(x.width,2400)*x.height/x.width),page:x.url,lic:'Unsplash licence (free)',by:x.author,srcName:'Unsplash via Picsum'}));
 },
 async pexels(q){const k=PREFS.pexelsKey;if(!k)return null;const r=await fetch('https://api.pexels.com/v1/search?per_page=30&query='+encodeURIComponent(q||'nature'),{headers:{Authorization:k}});if(!r.ok)throw new Error('pexels '+r.status);const j=await r.json();
  return (j.photos||[]).map(p=>({id:'px_'+p.id,name:(p.alt||'Photo by '+p.photographer).slice(0,60),kind:'online',cat:'Photos',src:p.src.medium,full:p.src.large2x||p.src.original,page:p.url,lic:'Pexels licence (free)',by:p.photographer,srcName:'Pexels'}));},
 async pixabay(q){const k=PREFS.pixabayKey;if(!k)return null;const r=await fetch('https://pixabay.com/api/?key='+encodeURIComponent(k)+'&per_page=30&safesearch=true&q='+encodeURIComponent(q||'nature'));if(!r.ok)throw new Error('pixabay '+r.status);const j=await r.json();
  return (j.hits||[]).map(p=>({id:'pb_'+p.id,name:(p.tags||'Photo').slice(0,60),kind:'online',cat:'Photos',src:p.webformatURL,full:p.largeImageURL,page:p.pageURL,lic:'Pixabay licence (free)',by:p.user,srcName:'Pixabay'}));}
};
/* ---------- the store window ---------- */
const KS_TABS=[['featured','Featured'],['png','PNG Images'],['frames','Frames & Badges'],['bg','Backgrounds'],['photos','Stock Photos'],['tex','Textures'],['shapes','Shapes'],['icons','Icons']];
const KS_ICON_CATS=['All','Arrows','Interface','People','Communication','Business','Media','Travel','Food','Weather','Health','Shopping','Education','Sports','Nature','Tools','Tech','Holidays','Shapes','Text','Brands'];
function ksIcons(){const q=KS.q.toLowerCase().trim(),c=KS.iconCat||'All';
  return (typeof KESS_ICONS!=='undefined'?KESS_ICONS:[]).filter(i=>(c==='All'||i[0]===c)&&(!q||i[1].replace(/-/g,' ').includes(q)||i[0].toLowerCase().includes(q)||(i[3]||'').toLowerCase().includes(q))).map(i=>({id:'mdi_'+i[1],name:i[1].replace(/-/g,' '),cat:'Icons',kind:'mdi',d:i[2],tags:i[0],srcName:i[0]==='Brands'?'Simple Icons (CC0)':'Material Design Icons (Pictogrammers)',lic:i[0]==='Brands'?'Brand logo, trademark of its owner':'Free licence'}));}
function mdiCanvas(d,color,size){const c=mkCanvas(size,size),x=cctx(c);x.fillStyle=color;x.scale(size/24,size/24);x.fill(new Path2D(d),'nonzero');return c;}
const KS_ICON_CHIPS=['star','heart','home','user','camera','music','phone','mail','cart','arrow','check','social','food','travel','weather','sport','business','medical','school','love'];
function ksLocal(tab){
  const q=KS.q.toLowerCase(),m=it=>!q||(it.name+' '+(it.tags||'')).toLowerCase().includes(q);
  if(tab==='featured')return PACK.concat(GEN.filter(g=>g.id==='g_mesh'||g.id==='t_marble'||g.id==='t_foil'||g.id==='g_bokeh'),shapeItems().slice(0,10)).filter(m);
  if(tab==='png')return PACK.filter(p=>p.kind==='png'&&p.cat!=='Frames & Badges').filter(m);
  if(tab==='frames')return PACK.filter(p=>p.cat==='Frames & Badges'||p.cat==='Ribbons & Banners').concat(shapeItems().filter(s=>/Badges|Frames|Callouts/.test(s.sub))).filter(m);
  if(tab==='bg')return PACK.filter(p=>p.cat==='Backgrounds').concat(geoPatternItems(),GEN.filter(g=>g.cat==='Backgrounds')).filter(m);
  if(tab==='photos')return PACK.filter(p=>p.kind==='photo'&&p.cat==='Stock Photos').filter(m);
  if(tab==='tex')return PACK.filter(p=>p.cat==='Textures').concat(GEN.filter(g=>g.cat==='Textures')).filter(m);
  if(tab==='icons')return ksIcons();
  if(tab==='shapes')return geoItems().concat(shapeItems()).filter(m);
  return [];
}
function ksThumb(it,el){
  if(it.kind==='png'||it.kind==='photo'||it.kind==='online'){const im=new Image();im.loading='lazy';im.alt=it.name;im.src=it.src;if(it.kind==='online')im.referrerPolicy='no-referrer';im.onerror=()=>{el.innerHTML='<span class="muted">No preview</span>';};el.appendChild(im);}
  else if(it.kind==='shape'){el.appendChild(shapeCanvas(it.sid,'#e3e6ee',96));}
  else if(it.kind==='geo'){el.appendChild(geoRender(it,110));}
  else if(it.kind==='geopat'){setTimeout(()=>{if(!el.isConnected)return;const P=GEO_PAT[it.pi],c=geoPattern(240,180,P[2],Math.max(5,Math.round(P[1]*0.55)),geoPal(),'#ffffff');c.style.width='100%';c.style.height='100%';c.style.objectFit='cover';el.appendChild(c);},0);}
  else if(it.kind==='mdi'){const c=mdiCanvas(it.d,'#e3e6ee',96);c.style.width='64px';c.style.height='64px';el.appendChild(c);}
  else if(it.kind==='icon'){const im=new Image();im.src=iconUrl(it.id,'#e3e6ee',64);im.alt=it.name;el.appendChild(im);}
  else if(it.kind==='gen'){setTimeout(()=>{if(!el.isConnected)return;try{const c=it.fn(160,120,7,ksRGB(KS.gen.c1),ksRGB(KS.gen.c2));c.style.width='100%';c.style.height='100%';c.style.objectFit='cover';el.appendChild(c);}catch(e){}},0);}
}
async function ksOnline(tab){
  const q=KS.q.trim();
  try{
    if(tab==='png'){const [a,b]=await Promise.allSettled([ONLINE.openverse(q||'object','png','cc0,pdm'),ONLINE.commons(q||'object',true)]);return [].concat(a.value||[],b.value||[]);}
    if(tab==='photos'){const jobs=[ONLINE.openverse(q||'nature',null,'cc0,pdm'),ONLINE.commons(q||'landscape',false)];if(PREFS.pexelsKey)jobs.push(ONLINE.pexels(q));if(PREFS.pixabayKey)jobs.push(ONLINE.pixabay(q));if(!q){jobs.unshift(ONLINE.picsum(KS.picPage||1));}const rs=await Promise.allSettled(jobs);const out=[];rs.forEach(r=>{if(r.value)out.push(...r.value);});return out;}
    if(tab==='tex')return await ONLINE.polyhaven(q);
    if(tab==='icons')return await ONLINE.iconify(q||(KS.iconCat&&KS.iconCat!=='All'?KS.iconCat.toLowerCase():'star'));
    if(tab==='bg'){return await ONLINE.openverse((q||'abstract')+' background',null,'cc0,pdm');}
    if(tab==='frames')return await ONLINE.openverse((q||'ornate')+' frame',  'png','cc0,pdm');
  }catch(e){console.error(e);throw e;}
  return [];
}
function openStore(tab){
  if(tab)KS.tab=tab;
  modalOpen('KESS Store','<div class="ks"><nav class="ks-nav" id="ks-nav"></nav><div class="ks-main"><div class="ks-top"><input type="search" id="ks-q" placeholder="Search KESS Store" value="'+esc(KS.q)+'"><span id="ks-opts"></span></div><div id="ks-chips" class="ks-chips"></div><div id="ks-grid" class="ks-grid"></div><div id="ks-more" class="muted ks-note"></div></div><aside class="ks-side" id="ks-side"></aside></div>',[{label:'Close'}],root=>{
    const nav=$('#ks-nav',root),grid=$('#ks-grid',root),side=$('#ks-side',root),note=$('#ks-more',root);let token=0;
    nav.innerHTML=KS_TABS.map(t=>'<button data-ks="'+t[0]+'" class="'+(KS.tab===t[0]?'on':'')+'">'+t[1]+'</button>').join('')+'<div class="muted ks-lic">Free sources are marked with their licence. Check it before you use a picture commercially.</div>';
    const cardHtml=(it,i)=>'<button class="ks-card" data-i="'+i+'" title="'+esc(it.name)+'"><span class="ks-th'+(it.kind==='png'||it.kind==='shape'||it.kind==='icon'||it.kind==='geo'||it.kind==='mdi'?' chk':'')+'"></span><span class="ks-nm">'+esc(it.name)+'</span>'+(it.lic?'<span class="ks-lc">'+esc(it.lic)+'</span>':'')+'</button>';
    let items=[];
    const paint=(list,extra)=>{items=list;grid.innerHTML=list.length?list.map(cardHtml).join(''):'<p class="muted" style="padding:14px">Nothing found. Try another word.</p>';grid.querySelectorAll('.ks-card').forEach((b,i)=>ksThumb(list[i],b.firstChild));note.textContent=extra||'';};
    const showChips=()=>{const c=$('#ks-chips',root);if(KS.tab==='icons'){c.innerHTML=KS_ICON_CATS.map(t=>'<button class="chip'+((KS.iconCat||'All')===t?' on':'')+'" data-chip="'+t+'">'+t+'</button>').join('');}else if(KS.tab==='photos'){c.innerHTML='<button class="chip" data-ksmore="1">More photos (next page)</button><button class="chip" data-keys="1">Add free Pexels / Pixabay key…</button>';}else c.innerHTML='';
      const o=$('#ks-opts',root);o.innerHTML=(KS.tab==='bg'||KS.tab==='tex'||KS.tab==='featured')?'<label class="opt">Size <select id="ks-size"><option value="1024">1024 px</option><option value="2048">2048 px</option><option value="3072">3072 px</option><option value="doc">Design size</option></select></label><label class="opt">Colour 1 <input type="color" id="ks-c1" value="'+KS.gen.c1+'"></label><label class="opt">Colour 2 <input type="color" id="ks-c2" value="'+KS.gen.c2+'"></label>':KS.tab==='shapes'||KS.tab==='frames'?'<label class="opt">Colour <input type="color" id="ks-sc" value="'+KS.shape.color+'"></label>':KS.tab==='icons'?'<label class="opt">Colour <input type="color" id="ks-ic" value="'+KS.icon.color+'"></label>':'';const s=$('#ks-size',root);if(s)s.value=String(KS.gen.size);if(KS.tab==='shapes'||KS.tab==='bg')o.insertAdjacentHTML('beforeend',geoPalHtml());};
    const load=async()=>{
      const my=++token;showChips();[...nav.querySelectorAll('button')].forEach(b=>b.classList.toggle('on',b.dataset.ks===KS.tab));side.innerHTML='<p class="muted">Pick an item to see its options.</p>';
      let local=ksLocal(KS.tab);
      paint(local,'');
      if(KS.tab==='featured'||KS.tab==='shapes')return;
      note.textContent=(KS.tab==='icons'?'Searching icons...':'Loading free images from the web...');
      try{const on=await ksOnline(KS.tab);if(my!==token)return;const all=local.concat(on||[]);paint(all,on&&on.length?'Showing the KESS pack first, then free images from the web.':(KS.tab==='icons'?'':'No web results. You may be offline.'));}
      catch(e){if(my!==token)return;paint(local,'Web sources could not be reached (offline or blocked). Built-in items are still available.');}
    };
    const detail=(it)=>{
      const png=it.kind!=='photo'&&!(it.kind==='online'&&it.cat==='Photos');
      side.innerHTML='<div class="ks-prev" id="ks-prev"></div><b>'+esc(it.name)+'</b><div class="muted">'+esc([it.srcName||'KESS Store',it.by?('by '+it.by):'',it.lic||'',it.w?(it.w+'×'+it.h):''].filter(Boolean).join(' · '))+'</div>'
       +'<div class="row ks-btns"><button class="primary" id="ks-add">Add to design</button><button id="ks-new">Open as new design</button></div><div class="row ks-btns"><button id="ks-dl">Download '+(png?'PNG':'JPG')+'</button>'+((it.kind==='shape'||it.kind==='icon'||it.kind==='mdi')?'<button id="ks-dlsvg">Download SVG</button>':'')+(it.page?'<a class="btnlike" href="'+esc(it.page)+'" target="_blank" rel="noopener">Source page</a>':'')+'</div>'
       +(it.kind==='shape'?'<button id="ks-asshape">Add as editable shape</button>':'')+((it.kind==='geo'||it.kind==='geopat')?'<p class="muted">Drawn on your device, sharp at any size. Change the palette above.</p>':'')+(it.kind==='gen'?'<p class="muted">Made on your device in the size and colours chosen above, so it is sharp at any size.</p>':'');
      const pv=$('#ks-prev',side);ksThumb(it,pv);
      $('#ks-add',side).onclick=()=>ksAdd(it,'add');$('#ks-new',side).onclick=()=>ksAdd(it,'new');$('#ks-dl',side).onclick=()=>ksDownload(it,png?'png':'jpg');
      const sv=$('#ks-dlsvg',side);if(sv)sv.onclick=()=>ksDownload(it,'svg');
      const as=$('#ks-asshape',side);if(as)as.onclick=()=>{closeModal();if(!doc)newBlank('KESS design',1080,1080,72,'#ffffff');S.shape.kind='custom';S.shape.cid=it.sid;const l=addLayer({name:it.name,type:'shape',w:10,h:10,x:doc.w/2,y:doc.h/2,above:true,props:{kind:'custom',fill:KS.shape.color,stroke:'#000000',sw:0,radius:0,sides:6,cid:it.sid,w:Math.round(doc.w*0.3),h:Math.round(doc.w*0.3),flip:false,nofill:false}});renderShape(l);commit(it.name);refreshLayers();renderProps();toast('Shape added. Change its colour, size and stroke in Properties.');};
    };
    root.addEventListener('click',e=>{
      const t=e.target.closest('[data-ks]');if(t){KS.tab=t.dataset.ks;KS.q='';$('#ks-q',root).value='';load();return;}
      const c=e.target.closest('[data-card],.ks-card');if(c){grid.querySelectorAll('.ks-card').forEach(x=>x.classList.toggle('on',x===c));detail(items[+c.dataset.i]);return;}
      const ch=e.target.closest('[data-chip]');if(ch){KS.iconCat=ch.dataset.chip;KS.q='';$('#ks-q',root).value='';load();return;}
      if(e.target.closest("[data-ksmore]")){KS.picPage=((KS.picPage||1)%25)+1;load();return;}
      if(e.target.closest('[data-keys]')){askText('Free photo keys','Optional: paste a free Pexels key, then a comma, then a free Pixabay key (get them free at pexels.com/api and pixabay.com/api/docs). Leave empty to skip.',(PREFS.pexelsKey||'')+(PREFS.pixabayKey?','+PREFS.pixabayKey:''),v=>{const a=(v||'').split(',').map(x=>x.trim());PREFS.pexelsKey=a[0]||'';PREFS.pixabayKey=a[1]||'';savePrefs();toast('Saved. Search again to see more photos.');});}
    });
    let qt=0;$('#ks-q',root).addEventListener('input',e=>{KS.q=e.target.value;clearTimeout(qt);qt=setTimeout(load,KS.tab==='featured'||KS.tab==='shapes'?120:550);});
    root.addEventListener('change',e=>{const t=e.target;if(t.id==='ks-size'){KS.gen.size=t.value==='doc'?'doc':+t.value;}else if(t.id==='ks-c1'){KS.gen.c1=t.value;paint(items);}else if(t.id==='ks-c2'){KS.gen.c2=t.value;paint(items);}else if(t.id==='ks-pal'){KS.geoPal=t.value;paint(items);}else if(t.id==='ks-sc'){KS.shape.color=t.value;paint(items);}else if(t.id==='ks-ic'){KS.icon.color=t.value;paint(items);}});
    load();
  },{wide:true});
}
ACT.store=()=>openStore();
/* menu bar button */
{
  const nav=document.getElementById('menus'),b=document.createElement('button');b.className='kessbtn';b.id='kess-store';b.innerHTML='<span class="kdot"></span>KESS Store';b.title='Pictures, backgrounds, textures, shapes and icons';
  b.addEventListener('click',()=>openStore());nav.appendChild(b);
}
