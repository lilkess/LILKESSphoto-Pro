/* ===== Select Subject bar + mask Properties (Density, Feather, Refine) ===== */
const _setMask=setMask;
setMask=function(kind){
  if(kind==='hsel'){const l=active();if(!l){toast('Select a layer first');return;}if(!S.sel){toast('Make a selection first');return;}if(l.locked){toast('This layer is locked');return;}
    const w=l.canvas.width,h=l.canvas.height,n=mkCanvas(w,h),x=n.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.globalCompositeOperation='destination-out';x.drawImage(selAlphaCanvasLocal(l),0,0);
    if(l.mask){x.globalCompositeOperation='destination-in';x.drawImage(l.mask,0,0,w,h);}
    l.mask=n;l.editMask=true;l.mver++;touch(l);commit('Hide selection');return;}
  if(kind==='sel'&&active()&&active().mask&&S.sel){const l=active();l.mask=null;}  // replace the old mask with the selection
  return _setMask(kind);
};
ACT.maskHideSel=()=>setMask('hsel');
{const L=MENUS.find(m=>m.label==='Layer');if(L){const it=L.items.find(i=>i.label==='Layer mask');if(it&&!it.items.some(i=>i.label==='Hide selection'))it.items.splice(3,0,mi('Hide selection','','maskHideSel'));}}
/* subject bar */
let subjBar=null;
function subjBarShow(){
  subjBarHide();const b=document.createElement('div');b.id='subjbar';b.className='subjbar';
  b.innerHTML='<b>Subject selected</b><button data-s="mask">Add Layer Mask</button><button data-s="hide">Hide Subject</button><button data-s="cut">Cut out to new layer</button><button data-s="feather">Feather edge…</button><button data-s="x" title="Close" aria-label="Close">×</button>';
  document.body.appendChild(b);subjBar=b;
  b.onclick=e=>{const t=e.target.closest('button');if(!t)return;const s=t.dataset.s;
    if(s==='mask'){ACT.maskSel();S.sel=null;if(typeof redraw==='function')redraw();toast('Layer mask added. Paint black to hide, white to bring parts back.');refreshLayers();subjBarHide();}
    else if(s==='hide'){setMask('hsel');S.sel=null;redraw();refreshLayers();toast('Subject hidden with a layer mask');subjBarHide();}
    else if(s==='cut'){try{ACT.layerViaCut&&ACT.layerViaCut();}catch(err){}subjBarHide();}
    else if(s==='feather'){ACT.selFeather&&ACT.selFeather();}
    else subjBarHide();};
}
function subjBarHide(){if(subjBar){subjBar.remove();subjBar=null;}}
const _ss=ACT.selSubject;
ACT.selSubject=function(){_ss();let n=0;const iv=setInterval(()=>{n++;if(S.sel&&!subjBar){subjBarShow();clearInterval(iv);}if(n>60)clearInterval(iv);},200);};
/* ---- mask properties ---- */
const MASKB=new WeakMap();
function maskState(l){let m=MASKB.get(l);if(!m||m.ver!==l.mver||m.mask!==l.mask){m={base:cloneCanvas(l.mask),mask:l.mask,ver:l.mver,p:{dens:100,feather:0,smooth:0,contrast:0,shift:0}};MASKB.set(l,m);}return m;}
function maskRebuild(l,m){
  const w=l.mask.width,h=l.mask.height,p=m.p,src=cctx(m.base).getImageData(0,0,w,h),d=src.data,n=w*h,a=new Uint8ClampedArray(n*4);
  for(let i=0;i<n;i++){const v=d[i*4+3];a[i*4]=a[i*4+1]=a[i*4+2]=v;a[i*4+3]=255;}   // luminance mask
  const alphaMode=false;void alphaMode;
  const R=Math.round(p.feather*(Math.max(w,h)/1000));if(R>=1)boxBlur(a,w,h,R,3);
  const sm=Math.round(p.smooth*(Math.max(w,h)/1000)/3);if(sm>=1){boxBlur(a,w,h,sm,2);const k=1+p.smooth/20;for(let i=0;i<n;i++){const v=a[i*4]/255,s=1/(1+Math.exp(-(v-0.5)*8*k/2)),t=Math.min(1,Math.max(0,s));a[i*4]=a[i*4+1]=a[i*4+2]=t*255;}}
  if(p.shift!==0){const r=Math.max(1,Math.round(Math.abs(p.shift)*(Math.max(w,h)/1000)/2));const t=new Uint8ClampedArray(a);boxBlur(t,w,h,r,2);const th=p.shift>0?0.35:0.65;for(let i=0;i<n;i++){const v=t[i*4]/255,o=Math.min(1,Math.max(0,(v-th)/0.2+0.0)),q=p.shift>0?Math.min(1,Math.max(0,(v-0.15)*3)):Math.min(1,Math.max(0,(v-0.7)*3.3));a[i*4]=a[i*4+1]=a[i*4+2]=q*255;void o;}}
  if(p.contrast!==0){const c=1+p.contrast/50,k=p.contrast>0?c:1/(1-p.contrast/100*0.9);for(let i=0;i<n;i++){const v=a[i*4]/255;let o=(v-0.5)*k+0.5;a[i*4]=a[i*4+1]=a[i*4+2]=Math.min(1,Math.max(0,o))*255;}}
  const dn=p.dens/100;
  for(let i=0;i<n;i++){const v=a[i*4]*dn+255*(1-dn);a[i*4]=a[i*4+1]=a[i*4+2]=255;a[i*4+3]=v;}  // density: 100% = full mask, lower = mask loses effect
  cctx(l.mask).putImageData(new ImageData(a,w,h),0,0);l.mver++;m.ver=l.mver;
}
{const _rp=renderProps;
 renderProps=function(){
  _rp();const l=doc&&active();const root=document.getElementById('tab-props');if(!root)return;
  const old=document.getElementById('p-maskp');if(old)old.remove();
  if(!l||!l.mask)return;const m=maskState(l),p=m.p;
  const sl=(k,lab,min,max)=>'<label class="sl"><span>'+lab+'</span><input type="range" data-mk="'+k+'" min="'+min+'" max="'+max+'" value="'+p[k]+'"><input type="number" class="nv" data-mk="'+k+'" min="'+min+'" max="'+max+'" value="'+p[k]+'"></label>';
  const d=document.createElement('div');d.id='p-maskp';d.className='pgroup';
  d.innerHTML='<h4>Mask</h4>'+sl('dens','Density %',0,100)+sl('feather','Feather',0,100)+'<div class="muted" style="margin:6px 0 2px">Refine edge</div>'+sl('smooth','Smooth',0,100)+sl('contrast','Contrast',-100,100)+sl('shift','Shift edge',-100,100)+'<div class="row"><button id="mk-inv">Invert</button><button id="mk-sel">Load as selection</button><button id="mk-rs">Reset</button></div><p class="muted">Density lowers how strongly the mask hides. Feather softens the edge. Refine smooths, sharpens or moves the edge.</p>';
  root.appendChild(d);
 };
 document.addEventListener('input',e=>{const t=e.target;if(!t.dataset||!t.dataset.mk)return;const l=doc&&active();if(!l||!l.mask)return;const m=maskState(l);const v=+t.value;m.p[t.dataset.mk]=v;
   document.querySelectorAll('[data-mk="'+t.dataset.mk+'"]').forEach(o=>{if(o!==t)o.value=v;});maskRebuild(l,m);redraw();});
 document.addEventListener('change',e=>{const t=e.target;if(t&&t.dataset&&t.dataset.mk){const l=doc&&active();if(l)commit('Mask properties');}});
 document.addEventListener('click',e=>{const t=e.target;if(!t||!t.id||!t.id.startsWith('mk-'))return;const l=doc&&active();if(!l||!l.mask)return;
   if(t.id==='mk-inv'){setMask('invert');renderProps();}
   else if(t.id==='mk-rs'){const m=maskState(l);m.p={dens:100,feather:0,smooth:0,contrast:0,shift:0};maskRebuild(l,m);commit('Reset mask');renderProps();}
   else if(t.id==='mk-sel'){const w=l.mask.width,h=l.mask.height,c=mkCanvas(w,h),x=cctx(c);const src=cctx(l.mask).getImageData(0,0,w,h),o=x.createImageData(w,h);for(let i=0;i<w*h;i++){o.data[i*4+3]=src.data[i*4+3];}x.putImageData(o,0,0);setSelection(layerToDocCanvas(l,c),'new');toast('Mask loaded as a selection');}});
}
