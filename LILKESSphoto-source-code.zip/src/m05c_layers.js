
/* ===== helpers shared by the advanced layer features ===== */
function layerToDocCanvas(l,c){
  const o=mkCanvas(doc.w,doc.h),x=cctx(o);
  x.translate(l.x,l.y);x.rotate(l.r);x.scale(l.s,l.s);x.drawImage(c,-l.canvas.width/2,-l.canvas.height/2,l.canvas.width,l.canvas.height);
  return o;
}
function isPixelLayer(l){return l&&l.type!=='adjust';}
function ensureRaster(l){if(l.type==='text'||l.type==='shape'){rasterize(l);}}
const wrapFn=(name,fn)=>{};

/* ===== clipping masks ===== */
ACT.clipToggle=D(()=>{
  const l=active();if(!l)return;
  const i=doc.layers.indexOf(l);
  if(i===0){toast('There is no layer below to clip to');return;}
  l.clip=!l.clip;commit(l.clip?'Create clipping mask':'Release clipping mask');
  toast(l.clip?'Clipped. The layer now shows only inside the layer below.':'Clipping mask released');
});
ACT.clipPlace=D(()=>{pickFile('clip');});

/* ===== smart objects, rasterize ===== */
ACT.toSmart=D(()=>{
  const l=active();if(!l||!isPixelLayer(l))return;
  if(l.smart){toast('This is already a smart object');return;}
  ensureRaster(l);l.type='image';l.props=null;
  l.smart=true;l.orig=cloneCanvas(l.canvas);l.sf=[];
  commit('Convert to smart object');toast('Smart object. Filters you apply now stay editable in Properties.');renderProps();
});
function smartRebuild(l){
  const w=l.orig.width,h=l.orig.height;
  let img=cctx(l.orig).getImageData(0,0,w,h);
  for(const f of (l.sf||[])){
    if(f.off)continue;
    const fn=f.id==='_adj'?processAdjust:(FX[f.id]&&FX[f.id].fn);if(!fn)continue;
    img=fn(img,f.p,{scale:1});
  }
  l.canvas.width=w;l.canvas.height=h;cctx(l.canvas).putImageData(img,0,0);l.ver++;l.pv=null;l.pvv++;redraw();
}
function smartAdd(l,s){
  l.sf=l.sf||[];l.sf.push({id:s.fxid,p:JSON.parse(JSON.stringify(s.p)),name:s.label});
  smartRebuild(l);
}
ACT.rasterizeLayer=D(()=>{
  const l=active();if(!l)return;
  if(l.smart){l.smart=false;l.orig=null;l.sf=null;commit('Rasterize smart object');toast('Rasterized. The filters are now baked in.');renderProps();return;}
  if(l.type==='text'||l.type==='shape'){rasterize(l);commit('Rasterize layer');renderProps();toast('Layer rasterized to pixels');return;}
  toast('This layer is already pixels');
});
ACT.rasterize=ACT.rasterizeLayer;
{
  const _rp=renderProps;
  renderProps=function(){
    _rp();
    const box=$('#tab-props'),l=doc&&active();if(!box||!l)return;
    let h='';
    if(l.smart){
      h+='<div class="h">Smart object</div><p class="muted" style="margin:0 0 6px">Filters are kept as a list you can switch off or remove. The original pixels are untouched.</p>';
      const sf=l.sf||[];
      h+=sf.length?sf.map((f,i)=>'<div class="row sfrow"><label><input type="checkbox" data-sfon="'+i+'"'+(f.off?'':' checked')+'> '+esc(f.name||'Filter')+'</label><button data-sfdel="'+i+'" aria-label="Remove filter">&#10005;</button></div>').join(''):'<p class="muted">No smart filters yet. Use Filter or Adjust on this layer.</p>';
      h+='<div class="row"><button class="primary" data-act="smartEdit">Edit contents</button><button data-act="rasterizeLayer">Rasterize layer</button></div><p class="muted">Edit contents opens this layer in its own tab. Save there (Ctrl+S) and the layer updates.</p>';
    }else if(isPixelLayer(l)){
      h+='<div class="h">Layer type</div><div class="row"><button data-act="toSmart">Convert to smart object</button>'+(l.type==='text'||l.type==='shape'?'<button data-act="rasterizeLayer">Rasterize</button>':'')+'</div>';
    }
    if(isPixelLayer(l)){
      h+='<div class="h">Quick actions</div><div class="row"><button data-act="removeBg">Remove background</button><button data-act="clipToggle">'+(l.clip?'Release clipping mask':'Create clipping mask')+'</button></div>';
    }
    box.insertAdjacentHTML('beforeend','<div id="p-adv">'+h+'</div>');
  };
  $('#tab-props').addEventListener('click',e=>{
    const d=e.target.closest('[data-sfdel]');
    if(d){const l=active();l.sf.splice(+d.dataset.sfdel,1);smartRebuild(l);commit('Remove smart filter');renderProps();}
  });
  $('#tab-props').addEventListener('change',e=>{
    const o=e.target.closest('[data-sfon]');
    if(o){const l=active();l.sf[+o.dataset.sfon].off=!o.checked;smartRebuild(l);commit('Toggle smart filter');renderProps();}
  });
}

/* ===== adjustment layers (non-destructive) ===== */

function runAdjImg(img,adj,scale){
  if(adj.t==='adj')return processAdjust(img,adj.p);
  const def=FX[adj.id];return def?def.fn(img,adj.p,{scale:scale||1}):img;
}
function drawAdjustOnto(ctx,l){
  if(!l.adj)return;
  const cv=ctx.canvas,w=cv.width,h=cv.height,k=w/doc.w*FX_SCALE;
  const before=ctx.getImageData(0,0,w,h);
  let after=runAdjImg(before,l.adj,k);
  const op=l.opacity;
  let mk=null;
  if(l.mask){const m=mkCanvas(w,h),mx=cctx(m);mx.drawImage(l.mask,0,0,w,h);mk=mx.getImageData(0,0,w,h).data;}
  const a=after.data,b=before.data;
  if(op<1||mk){
    for(let i=0;i<a.length;i+=4){
      const f=op*(mk?mk[i+3]/255:1);
      if(f<1){a[i]=b[i]+(a[i]-b[i])*f;a[i+1]=b[i+1]+(a[i+1]-b[i+1])*f;a[i+2]=b[i+2]+(a[i+2]-b[i+2])*f;}
    }
  }
  ctx.putImageData(after,0,0);
}
function applyAdjustLayer(mx,tmp,m){mx.drawImage(tmp,0,0);drawAdjustOnto(mx,m);}
ACT.adjLayer=(id)=>{
  if(!doc){toast('Create or open a design first');return;}
  flush();
  const def=FX[id];if(!def)return;
  const p={};(def.params||[]).forEach(q=>{p[q.k]=q.def;});
  const l=addLayer({name:def.name,type:'adjust',above:true});
  l.adj={t:'fx',id,p};
  commit('Adjustment layer');refreshLayers();setTab('props');renderProps();redraw();
};
{
  const _rp2=renderProps;
  renderProps=function(){
    _rp2();
    const box=$('#tab-props'),l=doc&&active();if(!box||!l||l.type!=='adjust'||!l.adj)return;
    const def=l.adj.t==='fx'?FX[l.adj.id]:null;
    let h='<div class="h">Adjustment: '+esc(def?def.name:'Adjustments')+'</div>';
    if(def&&def.params&&def.params.length)h+=def.params.map(q=>'<label class="sl"><span>'+esc(q.label)+'</span><input type="range" data-ak="'+q.k+'" min="'+q.min+'" max="'+q.max+'" step="'+q.step+'" value="'+l.adj.p[q.k]+'"><output>'+l.adj.p[q.k]+'</output></label>').join('');
    else h+='<p class="muted">This adjustment has no settings.</p>';
    h+='<div class="row"><button data-act="clipToggle">'+(l.clip?'Release clip to layer below':'Clip to layer below')+'</button></div><p class="muted">Use the mask button in Layers to paint where the adjustment applies.</p>';
    box.insertAdjacentHTML('afterbegin','<div id="p-adj">'+h+'</div>');
  };
  $('#tab-props').addEventListener('input',e=>{
    const k=e.target.dataset&&e.target.dataset.ak;if(!k)return;
    const l=active();if(!l||!l.adj)return;
    l.adj.p[k]=+e.target.value;e.target.nextElementSibling.textContent=e.target.value;pend=true;l.ver++;redraw();
  });
  $('#tab-props').addEventListener('change',e=>{if(e.target.dataset&&e.target.dataset.ak&&pend){pend=false;commit('Adjustment');}});
}
{
  const _rl=refreshLayers;
  refreshLayers=function(){
    _rl();
    if(!doc)return;
    $$('#layerlist .lrow').forEach(row=>{
      const l=doc.layers.find(x=>x.id===+row.dataset.id);if(!l)return;
      row.classList.toggle('clip',!!l.clip);
      if(l.type==='adjust'){const th=row.querySelector('.th');if(th){th.innerHTML='<svg viewBox="0 0 24 24" width="36" height="36" style="background:#3a3a3a;border-radius:3px"><circle cx="12" cy="12" r="7" fill="none" stroke="#ccc" stroke-width="1.6"/><path d="M12 5a7 7 0 0 1 0 14z" fill="#ccc"/></svg>';}}
      const nm=row.querySelector('.nm');
      if(l.smart&&nm&&!nm.querySelector('.sbadge'))nm.insertAdjacentHTML('beforeend',' <em class="fxb sbadge">smart</em>');
    });
  };
}

/* ===== layer style helpers ===== */
let fxClip=null;
ACT.lclearfx=D(()=>{const l=active();if(!l)return;l.fx=null;l.fillOp=1;touch(l);commit('Clear layer style');});
ACT.lcopyfx=D(()=>{const l=active();if(!l)return;fxClip=clone(l.fx);toast('Layer style copied');});
ACT.lpastefx=D(()=>{const l=active();if(!l)return;if(!fxClip){toast('Copy a layer style first');return;}l.fx=clone(fxClip);touch(l);commit('Paste layer style');});
ACT.lsOpen=(k)=>{if(!doc){toast('Create or open a design first');return;}flush();openLayerStyle(k);};

/* ===== remove background and subject selection ===== */
function alphaToLocalMask(alpha,w,h){return cut_alphaToCanvas(alpha,w,h);}
ACT.removeBg=D(()=>{
  const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return;}
  if(l.locked){toast('This layer is locked');return;}
  ensureRaster(l);
  toast('Removing the background...');
  setTimeout(()=>{
    try{
      const r=cut_removeBackground(l.canvas,{});
      const m=alphaToLocalMask(r.alpha,r.w,r.h);
      if(l.mask){const x=cctx(m);x.globalCompositeOperation='destination-in';x.drawImage(l.mask,0,0,m.width,m.height);}
      l.mask=m;l.editMask=false;l.mver++;touch(l);commit('Remove background');refreshLayers();
      toast('Background removed with a layer mask. Paint the mask white or black to refine it.');
    }catch(err){toast('Could not remove the background from this picture');}
  },40);
});
ACT.removeBgApply=D(()=>{const l=active();if(!l||!l.mask){toast('Use Remove background first');return;}setMask('apply');});
ACT.selSubject=D(()=>{
  const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return;}
  toast('Finding the subject...');
  setTimeout(()=>{
    try{
      const r=cut_removeBackground(l.canvas,{}),m=cut_alphaToCanvas(r.alpha,r.w,r.h);
      setSelection(layerToDocCanvas(l,m),'new');toast('Subject selected');
    }catch(err){toast('Could not find a subject');}
  },40);
});
function selectFromRegion(region){
  const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return;}
  const inv=docToLocalM(l);
  const T=(p)=>({x:inv[0]*p.x+inv[2]*p.y+inv[4],y:inv[1]*p.x+inv[3]*p.y+inv[5]});
  const lr=region.rect?(()=>{const a=T({x:region.rect.x,y:region.rect.y}),b=T({x:region.rect.x+region.rect.w,y:region.rect.y+region.rect.h});return {rect:{x:Math.min(a.x,b.x),y:Math.min(a.y,b.y),w:Math.abs(b.x-a.x),h:Math.abs(b.y-a.y)}};})():{poly:region.poly.map(T)};
  toast('Selecting the object...');
  setTimeout(()=>{
    try{const r=cut_objectSelect(l.canvas,lr,{}),m=cut_alphaToCanvas(r.alpha,r.w,r.h);setSelection(layerToDocCanvas(l,m),S.selMode);toast('Object selected');}
    catch(err){toast('Could not select that object');}
  },40);
}
