/* ===== the full Photoshop toolbox, and every panel ===== */
Object.assign(ICONS,{
  artboard:'<path d="M7 3v4M17 3v4M7 17v4M17 17v4M3 7h4M3 17h4M17 7h4M17 17h4"/><rect x="7" y="7" width="10" height="10"/>',
  rowm:'<path d="M3 12h18" stroke-dasharray="3 2"/><path d="M3 9v6M21 9v6"/>',
  colm:'<path d="M12 3v18" stroke-dasharray="3 2"/><path d="M9 3h6M9 21h6"/>',
  maglasso:'<path d="M6 9c0-4 5-6 9-4s4 6-1 8-8 0-8-4z"/><path d="M12 15l1 6M12 15l5 3"/>',
  objsel:'<rect x="4" y="4" width="16" height="16" stroke-dasharray="3 3"/><path d="M9 9l6 3-3 1-1 3z"/>',
  quicksel:'<circle cx="9" cy="9" r="5" stroke-dasharray="3 2"/><path d="M13 13l6 6"/>',
  persp:'<path d="M5 6l14 2-2 10-12 2z"/><path d="M3 3v3M3 3h3"/>',
  slice:'<rect x="4" y="4" width="16" height="16"/><path d="M4 12h16M12 4v16"/>',
  slicesel:'<rect x="4" y="4" width="14" height="14"/><path d="M11 11l9 3-4 1-1 4z"/>',
  frame:'<rect x="4" y="4" width="16" height="16"/><path d="M4 4l16 16M20 4L4 20"/>',
  sampler:'<path d="M12 3v18M3 12h18"/><circle cx="12" cy="12" r="4"/>',
  ruler:'<path d="M3 17L17 3l4 4L7 21z"/><path d="M7 13l2 2M10 10l2 2M13 7l2 2"/>',
  note:'<path d="M5 4h14v12H9l-4 4z"/><path d="M8 8h8M8 12h5"/>',
  count:'<circle cx="12" cy="12" r="8"/><path d="M10 9l2-1v8"/>',
  remove:'<path d="M4 20l9-9 5 5-4 4z"/><path d="M15 3l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/>',
  spot:'<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2" fill="currentColor"/>',
  heal:'<rect x="4" y="9" width="16" height="6" rx="3"/><path d="M12 9v6M9 12h6"/>',
  patch:'<path d="M5 8l7-4 7 4v8l-7 4-7-4z" stroke-dasharray="3 2"/><path d="M9 12h6"/>',
  cam:'<path d="M4 16l4-4 3 3 5-6 4 7"/><path d="M4 20h16"/><path d="M15 4h3v3"/>',
  redeye:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3" fill="currentColor"/>',
  pencil:'<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>',
  colrep:'<path d="M12 3c3 4 5 6 5 9a5 5 0 0 1-10 0c0-3 2-5 5-9z"/><path d="M9 14h6"/>',
  mixer:'<path d="M5 18c3-1 4-4 7-4 2 0 2 2 4 2s3-2 3-4"/><circle cx="8" cy="7" r="2"/><circle cx="15" cy="6" r="2"/>',
  pstamp:'<rect x="8" y="3" width="8" height="5" rx="1"/><path d="M10 8l-2 6h8l-2-6"/><path d="M6 14h12v3H6z"/><circle cx="9" cy="20" r="1"/><circle cx="15" cy="20" r="1"/>',
  histbrush:'<path d="M4 12a8 8 0 1 0 3-6M4 4v4h4"/><path d="M12 8v4l3 2"/>',
  arthist:'<path d="M4 12a8 8 0 1 0 3-6M4 4v4h4"/><path d="M13 8l1 2 2 .5-2 .8-1 2-1-2-2-.8 2-.5z"/>',
  bgerase:'<path d="M5 15l9-9 5 5-9 9H7z" stroke-dasharray="3 2"/><path d="M11 20h9"/>',
  sponge:'<rect x="5" y="8" width="14" height="10" rx="3"/><circle cx="9" cy="12" r="1"/><circle cx="14" cy="14" r="1"/>',
  pen:'<path d="M12 3l6 8-6 10-6-10z"/><circle cx="12" cy="11" r="1.6"/>',
  freeform:'<path d="M4 16c3-9 5 3 8-4s5 3 8-3"/>',
  curv:'<path d="M4 18C8 4 16 4 20 18"/><circle cx="12" cy="8" r="1.5"/>',
  addpt:'<path d="M11 3l6 8-6 10-6-10z"/><path d="M19 3v5M16.5 5.5h5"/>',
  delpt:'<path d="M11 3l6 8-6 10-6-10z"/><path d="M16.5 5.5h5"/>',
  cvpt:'<path d="M5 19l7-14 7 14"/>',
  psel:'<path d="M6 3l12 9-5 1 3 6-3 1-3-6-4 3z" fill="currentColor"/>',
  dsel:'<path d="M6 3l12 9-5 1 3 6-3 1-3-6-4 3z"/>',
  vtext:'<path d="M6 4h10M11 4v12M9 20h4"/><path d="M19 8v8M17 14l2 2 2-2"/>',
  tmask:'<path d="M5 6V4h14v2M12 4v16M9 20h6" stroke-dasharray="3 2"/>',
  vtmask:'<path d="M6 4h10M11 4v12M9 20h4" stroke-dasharray="3 2"/><path d="M19 8v8M17 14l2 2 2-2"/>',
  polygon:'<path d="M12 3l8 6-3 10H7L4 9z"/>',
  custom:'<path d="M12 20C5 15 3 11 3 8a5 5 0 0 1 9-2 5 5 0 0 1 9 2c0 3-2 7-9 12z"/>',
  rotview:'<path d="M20 12a8 8 0 1 1-3-6.200M20 4v5h-5"/>',
  sharpenb:'<path d="M12 4l7 14H5z"/>'
});
const TG=(id,list)=>({id,v:list});
const V=(t,n,k,i,x)=>Object.assign({t,n,k,i},x||{});
TOOLGROUPS.length=0;
TOOLGROUPS.push(
  TG('move',[V('move','Move','V','move'),V('artboard','Artboard','V','artboard')]),
  TG('marquee',[V('marquee','Rectangular Marquee','M','marquee',{kind:'rect'}),V('marquee','Elliptical Marquee','M','ellipse',{kind:'ellipse'}),V('rowmarq','Single Row Marquee','M','rowm'),V('colmarq','Single Column Marquee','M','colm')]),
  TG('lasso',[V('lasso','Lasso','L','lasso',{kind:'free'}),V('lasso','Polygonal Lasso','L','poly',{kind:'poly'}),V('magnetic','Magnetic Lasso','L','maglasso')]),
  TG('wand',[V('objsel','Object Selection','W','objsel'),V('quicksel','Quick Selection','W','quicksel'),V('wand','Magic Wand','W','wand')]),
  TG('crop',[V('crop','Crop','C','crop'),V('persp','Perspective Crop','C','persp'),V('slice','Slice','C','slice'),V('slicesel','Slice Select','C','slicesel')]),
  TG('frame',[V('frame','Frame','K','frame')]),
  TG('pick',[V('pick','Eyedropper','I','pick'),V('sampler','Color Sampler','I','sampler'),V('ruler','Ruler','I','ruler'),V('note','Note','I','note'),V('count','Count','I','count')]),
  TG('heal',[V('remove','Remove Tool','J','remove'),V('spot','Spot Healing Brush','J','spot'),V('heal','Healing Brush','J','heal'),V('patch','Patch','J','patch'),V('cam','Content-Aware Move','J','cam'),V('redeye','Red Eye','J','redeye'),V('retouch','Skin Smoothing Brush','J','smooth',{mode:'smooth'})]),
  TG('brush',[V('brush','Brush','B','brush'),V('pencil','Pencil','B','pencil'),V('colrep','Color Replacement','B','colrep'),V('mixer','Mixer Brush','B','mixer')]),
  TG('stamp',[V('retouch','Clone Stamp','S','clone',{mode:'clone'}),V('pstamp','Pattern Stamp','S','pstamp')]),
  TG('histb',[V('histbrush','History Brush','Y','histbrush'),V('arthist','Art History Brush','Y','arthist')]),
  TG('eraser',[V('eraser','Eraser','E','eraser'),V('bgerase','Background Eraser','E','bgerase'),V('fill','Magic Eraser','E','mageraser',{mode:'erase'})]),
  TG('fill',[V('gradient','Gradient','G','gradient'),V('fill','Paint Bucket','G','fill',{mode:'fill'})]),
  TG('blur',[V('retouch','Blur','R','blur',{mode:'blur'}),V('retouch','Sharpen','R','sharpen',{mode:'sharpen'}),V('retouch','Smudge','R','smudge',{mode:'smudge'})]),
  TG('dodge',[V('retouch','Dodge','O','lighten',{mode:'lighten'}),V('retouch','Burn','O','darken',{mode:'darken'}),V('retouch','Sponge','O','sponge',{mode:'sponge'})]),
  TG('pen',[V('pen','Pen','P','pen'),V('freeform','Freeform Pen','P','freeform'),V('curv','Curvature Pen','P','curv'),V('addpt','Add Anchor Point','P','addpt'),V('delpt','Delete Anchor Point','P','delpt'),V('cvpt','Convert Point','P','cvpt')]),
  TG('text',[V('text','Horizontal Type','T','text'),V('vtext','Vertical Type','T','vtext'),V('tmask','Horizontal Type Mask','T','tmask'),V('vtmask','Vertical Type Mask','T','vtmask')]),
  TG('psel',[V('psel','Path Selection','A','psel'),V('dsel','Direct Selection','A','dsel')]),
  TG('shape',[V('shape','Rectangle','U','rect',{kind:'rect'}),V('shape','Rounded Rectangle','U','round',{kind:'round'}),V('shape','Ellipse','U','circle',{kind:'ellipse'}),V('shape','Triangle','U','triangle',{kind:'triangle'}),V('shape','Polygon','U','polygon',{kind:'polygon'}),V('shape','Line','U','line',{kind:'line'}),V('shape','Custom Shape','U','custom',{kind:'custom'}),V('shape','Star','U','star',{kind:'star'})]),
  TG('hand',[V('hand','Hand','H','hand'),V('rotview','Rotate View','R','rotview')]),
  TG('zoom',[V('zoom','Zoom','Z','zoom')])
);
Object.keys(grpCur).forEach(k=>delete grpCur[k]);TOOLGROUPS.forEach(g=>{grpCur[g.id]=0;});
Object.assign(CURSORS,{pen:'crosshair',hand:'grab',rotview:'grab',text:'text',vtext:'text'});
/* make the keyboard shortcut for Blur/Sharpen/Smudge also reach Rotate View on the same key */
/* the generic setTool lookup and the pickTool bookkeeping for the new variants */
(function(){
  const _pick=pickTool;
  pickTool=function(gid,idx){
    const g=TOOLGROUPS.find(x=>x.id===gid),v=g.v[idx];
    if(v.t==='marquee')S.marq.kind=v.kind;
    if(v.t==='lasso')S.lasso.kind=v.kind;
    if(v.t==='retouch')S.retouch.mode=v.mode;
    if(v.t==='fill')S.fill.mode=v.mode;
    if(v.t==='shape')S.shape.kind=v.kind;
    grpCur[gid]=idx;S.tv=v;setTool(v.t,gid);
  };
})();
/* extra buttons under the colour swatches */
(function(){
  const sw=$('#swatches'),wrap=document.createElement('div');wrap.id='toolextra';
  wrap.innerHTML='<button id="qmbtn" title="Quick Mask Mode (Q)" aria-label="Quick Mask Mode">Q</button><button id="scrbtn" title="Screen mode (F)" aria-label="Screen mode">&#9635;</button><button id="edtb" title="All tools" aria-label="Edit toolbar and more tools">&#8943;</button>';
  sw.parentNode.appendChild(wrap);
  $('#qmbtn').addEventListener('click',()=>ACT.quickMask());
  $('#scrbtn').addEventListener('click',()=>ACT.screenMode());
  $('#edtb').addEventListener('click',()=>ACT.allTools());
})();
ACT.allTools=()=>{
  closeMenus();
  const body='<div class="tgridall">'+TOOLGROUPS.map(g=>'<div class="tgh">'+g.v.map((v,i)=>'<button class="tgb" data-g="'+g.id+'" data-i="'+i+'"><span class="mi">'+svgI(v.i)+'</span>'+esc(v.n)+'<kbd>'+v.k+'</kbd></button>').join('')+'</div>').join('')+'</div>';
  modalOpen('All tools',body,[{label:'Close'}],b=>{b.addEventListener('click',e=>{const t=e.target.closest('.tgb');if(t){pickTool(t.dataset.g,+t.dataset.i);closeModal();}});},{wide:true});
};
ACT.pickToolById=(t)=>{for(const g of TOOLGROUPS){const i=g.v.findIndex(v=>v.t===t);if(i>=0){pickTool(g.id,i);return;}}};

/* ===== panel framework ===== */
const PANELS={};const PANEL_ORDER=[];
function PNL(id,name,dock,render){PANELS[id]={id,name,dock,render};PANEL_ORDER.push(id);}
/* built-in panels that already exist */
[['color','Color','A'],['swatches','Swatches','A'],['adjust','Adjustments','A'],['filters','Looks','A'],['layers','Layers','B'],['history','History','B'],['props','Properties','B']].forEach(a=>{PANELS[a[0]]={id:a[0],name:a[1],dock:a[2],core:true};PANEL_ORDER.push(a[0]);});
const DEFAULT_OPEN={A:['color','swatches','adjust','filters','info'],B:['layers','channels','paths','history','props']};
function buildDockTabs(){
  ['A','B'].forEach(w=>{
    const arr=w==='A'?DOCK_A:DOCK_B;
    $('#dock'+w+' .dtabs').innerHTML=arr.map(id=>'<button data-tab="'+id+'">'+esc(PANELS[id].name.replace('Adjustments','Adjust'))+'</button>').join('')+'<button data-pmenu="'+w+'" title="More panels" aria-label="More panels" style="flex:none;width:26px">&#8943;</button>';
  });
  $$('.dtabs button[data-tab]').forEach(b=>b.classList.toggle('on',b.dataset.tab===S.tabA||b.dataset.tab===S.tabB));
}
function makeSections(){
  PANEL_ORDER.forEach(id=>{
    const p=PANELS[id];if(p.core||$('#tab-'+id))return;
    const sec=document.createElement('section');sec.className='tab';sec.id='tab-'+id;
    $('#dock'+p.dock+' .dbody').appendChild(sec);
  });
}
function openPanel(id){
  const p=PANELS[id];if(!p)return;
  const arr=p.dock==='A'?DOCK_A:DOCK_B;
  if(!arr.includes(id)){arr.push(id);buildDockTabs();}
  flush();setTab(id,false);
}
function panelPicker(){
  closeMenus();
  modalOpen('Panels','<div class="tgridall">'+PANEL_ORDER.map(id=>'<button class="tgb" data-p="'+id+'">'+esc(PANELS[id].name)+'</button>').join('')+'</div>',[{label:'Close'}],b=>{b.addEventListener('click',e=>{const t=e.target.closest('[data-p]');if(t){closeModal();openPanel(t.dataset.p);}});},{wide:true});
}
ACT.panelPicker=panelPicker;
$('#docks').addEventListener('click',e=>{const b=e.target.closest('[data-pmenu]');if(b){e.stopPropagation();panelPicker();}},true);
(function(){const nav=$('#mtabs');if(nav){const b=document.createElement('button');b.textContent='More';b.dataset.pmenu='x';nav.appendChild(b);nav.addEventListener('click',e=>{if(e.target.closest('[data-pmenu]')){e.stopPropagation();panelPicker();}},true);}})();
/* every panel redraws when it becomes visible and when the document changes */
(function(){
  const _st=setTab;
  setTab=function(t,toggle,silent){_st(t,toggle,silent);if(PANELS[t]&&PANELS[t].render)PANELS[t].render();};
  const _rl=refreshLayers;
  refreshLayers=function(){_rl();panelsRefresh();};
  const _render=render;
  render=function(){_render();if(S.chan)applyChannelView();panelTick();};
  const _uci=updateCursorInfo;
  updateCursorInfo=function(p){_uci(p);INFO.cur=p;if(isVisible('info'))infoLive();};
})();
const isVisible=id=>S.tabA===id||S.tabB===id;
function panelsRefresh(){[S.tabA,S.tabB].forEach(id=>{const p=PANELS[id];if(p&&p.render&&!p.live)p.render();});}
let tickT=0;
function panelTick(){
  if(tickT)return;
  tickT=setTimeout(()=>{tickT=0;if(!doc)return;['navigator','histogram'].forEach(id=>{if(isVisible(id)&&PANELS[id].render)PANELS[id].render();});if(isVisible('info'))infoLive();},140);
}
const NODOC='<p class="muted" style="padding:10px">Open or create a design first.</p>';
const pnl=(id,fn)=>()=>{const b=$('#tab-'+id);if(!b)return;if(!doc){b.innerHTML=NODOC;return;}b.innerHTML='<div class="pnl">'+fn()+'</div>';};

/* ---------- Channels ---------- */
S.chan=null;
function applyChannelView(){
  if(!doc)return;const id=vctx.getImageData(0,0,doc.w,doc.h),d=id.data,o={r:0,g:1,b:2}[S.chan];
  for(let i=0;i<d.length;i+=4){const v=d[i+o];d[i]=d[i+1]=d[i+2]=v;}
  vctx.putImageData(id,0,0);
}
let flatCache=null;
function flatDoc(){if(!flatCache){const c=mkCanvas(doc.w,doc.h);compose(cctx(c),1);flatCache=c;setTimeout(()=>{flatCache=null;},50);}return flatCache;}
function chanThumb(ch){
  const c=mkCanvas(32,32),x=cctx(c);x.fillStyle='#000';x.fillRect(0,0,32,32);
  const k=Math.min(32/doc.w,32/doc.h),w=doc.w*k,h=doc.h*k;x.drawImage(flatDoc(),(32-w)/2,(32-h)/2,w,h);
  if(ch){const id=x.getImageData(0,0,32,32),d=id.data,o={r:0,g:1,b:2}[ch];for(let i=0;i<d.length;i+=4){d[i]=d[i+1]=d[i+2]=d[i+o];}x.putImageData(id,0,0);}
  return c.toDataURL();
}
PNL('channels','Channels','B',pnl('channels',()=>{
  const alphas=(doc.extra&&doc.extra.alpha)||[];
  const row=(k,n,img)=>'<button class="prow'+((S.chan||'rgb')===k?' on':'')+'" data-ch="'+k+'"><span class="pth"><img width="30" height="30" src="'+img+'" alt=""></span><span>'+n+'</span></button>';
  return '<div class="plist">'+row('rgb','RGB',chanThumb(null))+row('r','Red',chanThumb('r'))+row('g','Green',chanThumb('g'))+row('b','Blue',chanThumb('b'))
    +alphas.map((a,i)=>'<button class="prow" data-al="'+i+'"><span class="pth"><img width="30" height="30" src="'+a.thumb+'" alt=""></span><span>'+esc(a.name)+'</span></button>').join('')+'</div>'
    +'<div class="pbtns"><button data-act="chanSave">Save selection as channel</button><button data-act="chanLoad">Load channel as selection</button><button data-act="chanDel">Delete channel</button></div>'
    +'<p class="muted">Tap Red, Green or Blue to look at one channel. Tap RGB to go back. Saved channels hold selections.</p>';
}));
document.addEventListener('click',e=>{
  const r=e.target.closest('#tab-channels [data-ch]');if(r&&doc){S.chan=r.dataset.ch==='rgb'?null:r.dataset.ch;PANELS.channels.render();redraw();return;}
  const a=e.target.closest('#tab-channels [data-al]');if(a&&doc){S.alSel=+a.dataset.al;$$('#tab-channels .prow').forEach(x=>x.classList.toggle('on',x===a));}
});
ACT.chanSave=D(()=>{
  if(!S.sel){toast('Make a selection first');return;}
  const c=S.sel.c,t=mkCanvas(32,32),x=cctx(t);x.fillStyle='#000';x.fillRect(0,0,32,32);const k=Math.min(32/c.width,32/c.height);
  const m=mkCanvas(c.width,c.height),mx=cctx(m);mx.fillStyle='#000';mx.fillRect(0,0,c.width,c.height);mx.fillStyle='#fff';mx.globalCompositeOperation='source-over';
  const w=mkCanvas(c.width,c.height),wx=cctx(w);wx.fillStyle='#fff';wx.fillRect(0,0,c.width,c.height);wx.globalCompositeOperation='destination-in';wx.drawImage(c,0,0);mx.drawImage(w,0,0);
  x.drawImage(m,0,0,c.width*k,c.height*k);
  const L=exa('alpha');L.push({name:'Alpha '+(L.length+1),url:c.toDataURL(),thumb:t.toDataURL()});commit('Save selection');PANELS.channels.render();toast('Selection saved as a channel');
});
ACT.chanLoad=D(()=>{
  const L=exa('alpha'),a=L[S.alSel];if(!a){toast('Tap a saved channel first');return;}
  const im=new Image();im.onload=()=>{const c=mkCanvas(doc.w,doc.h);cctx(c).drawImage(im,0,0,doc.w,doc.h);setSelection(c,'new');};im.src=a.url;
});
ACT.chanDel=D(()=>{const L=exa('alpha');if(L[S.alSel]){L.splice(S.alSel,1);S.alSel=-1;commit('Delete channel');PANELS.channels.render();}});

/* ---------- Paths ---------- */
PANELS.paths={id:'paths',name:'Paths',dock:'B',render:renderPathsPanel};PANEL_ORDER.push('paths');

/* Gradients panel and gradient tool live in m05h_pick.js */
/* ---------- Patterns ---------- */
PNL('patterns','Patterns','A',pnl('patterns',()=>'<div class="tilegrid">'+PATTERNS.map(p=>'<button class="gtile'+(S.patId===p[0]?' on':'')+'" data-pt="'+p[0]+'" title="'+p[1]+'"><img width="44" height="44" src="'+PATTERN_TILE(p[0]).toDataURL()+'" alt="'+p[1]+'"></button>').join('')+'</div><div class="pbtns"><button data-act="fillPattern">Fill a new layer with this pattern</button></div><p class="muted">The Pattern Stamp tool paints with the pattern you pick here.</p>'));
document.addEventListener('click',e=>{const t=e.target.closest('#tab-patterns [data-pt]');if(!t)return;S.patId=t.dataset.pt;PANELS.patterns.render();});
ACT.fillPattern=D(()=>{const l=addLayer({name:'Pattern',above:true});cctx(l.canvas).drawImage(patternCanvas(S.patId,doc.w,doc.h,100),0,0);touch(l);restrictCanvasToSel(l);commit('Fill pattern');});

/* ---------- Brushes, Brush Settings, Brush Presets ---------- */
const TIPS=[['round','Round'],['square','Square'],['diamond','Diamond'],['star','Star'],['leaf','Leaf'],['chalk','Chalk'],['splat','Splatter']];
const tipThumb=t=>{const c=mkCanvas(40,40),x=cctx(c);x.fillStyle='#ddd';x.translate(20,20);x.beginPath();tipPath(x,t,14);x.fill();return c.toDataURL();};
PNL('brushes','Brushes','A',pnl('brushes',()=>'<div class="tilegrid">'+TIPS.map(t=>'<button class="gtile'+(S.bs.tip===t[0]?' on':'')+'" data-tip="'+t[0]+'" title="'+t[1]+' tip" style="background:#222"><img width="40" height="40" src="'+tipThumb(t[0])+'" alt="'+t[1]+'"></button>').join('')+'</div>'+rowRange('Size','bsz',1,2500,S.brush.size)+rowRange('Hardness','bhd',0,100,Math.round(S.brush.hard*100))+rowRange('Opacity','bop',1,100,Math.round(S.brush.flow*100))));
PNL('brushset','Brush Settings','A',pnl('brushset',()=>rowRange('Angle','bsa',-180,180,S.bs.angle)+rowRange('Roundness','bsr',5,100,S.bs.round)+rowRange('Spacing %','bss',2,200,S.bs.spacing)+rowRange('Scatter %','bsc',0,100,S.bs.scatter)+rowRange('Size jitter %','bsj',0,100,S.bs.jitter)+'<div class="pbtns"><button data-act="brushReset">Reset</button></div><p class="muted">These shape every brush stroke: tip angle, how squashed the tip is, gaps between dabs and randomness.</p>'));
const BRUSH_PRESETS=[['Soft round',{size:40,hard:0.2,flow:1,tip:'round',spacing:10,scatter:0,jitter:0,angle:0,round:100}],['Hard round',{size:30,hard:1,flow:1,tip:'round',spacing:10,scatter:0,jitter:0,angle:0,round:100}],['Airbrush',{size:90,hard:0,flow:0.25,tip:'round',spacing:6,scatter:0,jitter:0,angle:0,round:100}],['Calligraphy',{size:26,hard:1,flow:1,tip:'round',spacing:4,scatter:0,jitter:0,angle:45,round:18}],['Marker',{size:34,hard:1,flow:0.8,tip:'square',spacing:6,scatter:0,jitter:0,angle:0,round:100}],['Chalk',{size:50,hard:1,flow:0.9,tip:'chalk',spacing:25,scatter:15,jitter:20,angle:0,round:100}],['Stars',{size:40,hard:1,flow:1,tip:'star',spacing:90,scatter:60,jitter:40,angle:0,round:100}],['Leaves',{size:46,hard:1,flow:1,tip:'leaf',spacing:80,scatter:70,jitter:30,angle:30,round:100}],['Splatter',{size:60,hard:1,flow:1,tip:'splat',spacing:60,scatter:30,jitter:50,angle:0,round:100}],['Diamond dust',{size:24,hard:1,flow:0.9,tip:'diamond',spacing:100,scatter:90,jitter:60,angle:0,round:100}]];
PNL('brushpre','Brush Presets','A',pnl('brushpre',()=>'<div class="plist">'+BRUSH_PRESETS.map((b,i)=>'<button class="prow" data-bp="'+i+'"><span>'+b[0]+'</span></button>').join('')+'</div>'));
function rowRange(label,id,min,max,val){return '<label class="prng"><span>'+label+'</span><input type="range" data-rng="'+id+'" min="'+min+'" max="'+max+'" value="'+val+'"><output>'+val+'</output></label>';}
document.addEventListener('input',e=>{
  const t=e.target;if(!t.dataset||!t.dataset.rng)return;const v=+t.value;t.nextElementSibling.textContent=v;
  switch(t.dataset.rng){
    case 'bsz':S.brush.size=v;break;case 'bhd':S.brush.hard=v/100;break;case 'bop':S.brush.flow=v/100;break;
    case 'bsa':S.bs.angle=v;break;case 'bsr':S.bs.round=v;break;case 'bss':S.bs.spacing=v;break;case 'bsc':S.bs.scatter=v;break;case 'bsj':S.bs.jitter=v;break;
  }
  if(typeof renderOpts==='function'&&['bsz','bhd','bop'].includes(t.dataset.rng))renderOpts();
});
document.addEventListener('click',e=>{
  const t=e.target.closest('#tab-brushes [data-tip]');if(t){S.bs.tip=t.dataset.tip;PANELS.brushes.render();return;}
  const b=e.target.closest('#tab-brushpre [data-bp]');if(b){const p=BRUSH_PRESETS[+b.dataset.bp][1];S.brush.size=p.size;S.brush.hard=p.hard;S.brush.flow=p.flow;Object.assign(S.bs,{tip:p.tip,spacing:p.spacing,scatter:p.scatter,jitter:p.jitter,angle:p.angle,round:p.round});toast(BRUSH_PRESETS[+b.dataset.bp][0]+' brush ready');pickTool('brush',0);}
});
ACT.brushReset=()=>{Object.assign(S.bs,{tip:'round',angle:0,round:100,spacing:10,scatter:0,jitter:0});if(doc&&PANELS.brushset)PANELS.brushset.render();};

/* ---------- Character, Paragraph, Glyphs, styles ---------- */
const needText=()=>{const l=active();return l&&l.type==='text'?l:null;};
PNL('character','Character','B',pnl('character',()=>{
  const l=needText();if(!l)return '<p class="muted">Select a text layer to change its letters. Use the Type tool to add one.</p>';
  const p=l.props;
  return '<div class="row"><select data-ch="font" aria-label="Font">'+fontOptionsHtml(p.font)+'</select><button class="fbtn" data-fontpick="ch" title="Browse fonts">Aa</button></div>'
   +rowRange('Size','cs-size',6,600,Math.round(p.size))+rowRange('Leading %','cs-lh',60,300,Math.round(p.lh*100))
   +'<div class="row"><label>Colour <input type="color" data-ch="color" value="'+p.color+'"></label></div>'
   +'<div class="pbtns"><button data-tp="bold"'+(p.bold?' class="on"':'')+'><b>B</b></button><button data-tp="italic"'+(p.italic?' class="on"':'')+'><i>I</i></button><button data-tp="caps"'+(p.caps?' class="on"':'')+'>TT</button><button data-tp="vert"'+(p.vert?' class="on"':'')+'>Vertical</button></div>'
   +'<div class="pbtns"><button data-act="textToShape">Convert to shape</button><button data-act="textToLetters">Letters to shapes</button><button data-act="textToPath">Work path</button></div>';
}));
PNL('paragraph','Paragraph','B',pnl('paragraph',()=>{
  const l=needText();if(!l)return '<p class="muted">Select a text layer first.</p>';const p=l.props;
  return '<div class="pbtns">'+[['left','Left'],['center','Centre'],['right','Right']].map(a=>'<button data-al="'+a[0]+'"'+(p.align===a[0]?' class="on"':'')+'>'+a[1]+'</button>').join('')+'</div>'+rowRange('Line spacing %','ps-lh',60,300,Math.round(p.lh*100))+'<div class="row"><label>Text<br><textarea id="ps-text" rows="4" style="width:100%">'+esc(p.text)+'</textarea></label></div>';
}));
document.addEventListener('input',e=>{
  const t=e.target,l=needText();if(!l||!doc)return;
  if(t.dataset&&t.dataset.rng&&/^(cs-|ps-)/.test(t.dataset.rng)){
    const v=+t.value;if(t.dataset.rng==='cs-size')l.props.size=v;else l.props.lh=v/100;renderText(l);pend=true;t.nextElementSibling.textContent=v;return;
  }
  if(t.dataset&&t.dataset.ch==='color'){l.props.color=t.value;renderText(l);pend=true;}
  if(t.id==='ps-text'){l.props.text=t.value;renderText(l);pend=true;}
});
document.addEventListener('change',e=>{
  const t=e.target,l=needText();if(!l||!doc)return;
  if(t.dataset&&t.dataset.ch==='font'){l.props.font=t.value;renderText(l);commit('Type');}
});
document.addEventListener('click',e=>{
  const b=e.target.closest('#tab-character [data-tp]');if(b){textProp(b.dataset.tp);PANELS.character.render();return;}
  const a=e.target.closest('#tab-paragraph [data-al]');if(a){textProp('align',a.dataset.al);PANELS.paragraph.render();}
});
const GLYPHS=Array.from('©®™€£¥¢§¶†‡•…‰′″‹›«»“”‘’–—·×÷±≠≈≤≥∞√∑∏∫∂∆πΩµ°¹²³¼½¾→←↑↓↔↕⇒⇐♠♣♥♦♪♫☀☁☂★☆✓✔✗✘✦❤☺☻⚡☎✉✂✈♻⚑⚐❖◆◇●○■□▲△▼▽ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÑÒÓÔÕÖØÙÚÛÜÝßàáâãäåæçèéêëìíîïñòóôõöøùúûüýÿŒœ');
PNL('glyphs','Glyphs','B',pnl('glyphs',()=>'<div class="glyphs">'+GLYPHS.map(g=>'<button data-gl="'+g+'">'+g+'</button>').join('')+'</div><p class="muted">Tap a glyph to add it to the selected text layer.</p>'));
document.addEventListener('click',e=>{
  const g=e.target.closest('#tab-glyphs [data-gl]');if(!g||!doc)return;
  const l=needText();
  if(l){l.props.text+=g.dataset.gl;renderText(l);commit('Type');}
  else{const pr=TEXT0();pr.text=g.dataset.gl;pr.size=Math.round(doc.w/6);const n=addLayer({name:'Glyph',type:'text',w:10,h:10,above:true,props:pr});renderText(n);commit('Glyph');}
});
const lsGet=(k,def)=>{try{return JSON.parse(localStorage.getItem(k))||def;}catch(err){return def;}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(err){toast('Could not save that on this device');return false;}};
const CHAR_KEYS=['font','size','bold','italic','caps','color','stroke','sw','shadow','shadowColor'],PARA_KEYS=['align','lh'];
function styleTool(id,name,keys,store){
  PNL(id,name,'B',pnl(id,()=>{
    const L=lsGet(store,[]);
    return '<div class="plist">'+(L.length?L.map((s,i)=>'<div class="prow2"><button data-sa="'+i+'">'+esc(s.name)+'</button><button data-sd="'+i+'" title="Delete" aria-label="Delete style">&#10005;</button></div>').join(''):'<p class="muted" style="padding:8px">No styles yet. Select text you like, then tap Save style.</p>')+'</div><div class="pbtns"><button data-ss="1">Save style from the selected text</button></div>';
  }));
  document.addEventListener('click',e=>{
    const box=e.target.closest('#tab-'+id);if(!box||!doc)return;
    const L=lsGet(store,[]),l=needText();
    if(e.target.closest('[data-ss]')){if(!l){toast('Select a text layer first');return;}askText('New style','Style name',name.replace(' Styles','')+' '+(L.length+1),v=>{const o={name:v||'Style'};keys.forEach(k=>o[k]=l.props[k]);L.push(o);lsSet(store,L);PANELS[id].render();});}
    const a=e.target.closest('[data-sa]');if(a){if(!l){toast('Select a text layer first');return;}const s=L[+a.dataset.sa];keys.forEach(k=>{if(s[k]!==undefined)l.props[k]=s[k];});renderText(l);commit('Apply style');}
    const d=e.target.closest('[data-sd]');if(d){L.splice(+d.dataset.sd,1);lsSet(store,L);PANELS[id].render();}
  });
}
styleTool('cstyles','Character Styles',CHAR_KEYS,'lk_cstyles');styleTool('pstyles','Paragraph Styles',PARA_KEYS,'lk_pstyles');

/* ---------- Libraries ---------- */
PNL('libraries','Libraries','B',pnl('libraries',()=>{
  const L=lsGet('lk_lib',[]);
  return '<div class="tilegrid">'+L.map((a,i)=>a.type==='color'?'<button class="gtile" data-lb="'+i+'" title="'+a.name+'" style="background:'+a.data+'"></button>':'<button class="gtile" data-lb="'+i+'" title="'+esc(a.name)+'" style="background:#222"><img width="44" height="44" style="object-fit:contain" src="'+a.data+'" alt="'+esc(a.name)+'"></button>').join('')+'</div>'
    +(L.length?'':'<p class="muted">Your library keeps things you want to reuse in any design on this device.</p>')
    +'<div class="pbtns"><button data-lbadd="color">Add foreground colour</button><button data-lbadd="layer">Add selected layer</button><button data-lbdel="1">Remove last</button></div>';
}));
document.addEventListener('click',e=>{
  if(!doc)return;const box=e.target.closest('#tab-libraries');if(!box)return;
  const L=lsGet('lk_lib',[]);
  const ad=e.target.closest('[data-lbadd]');
  if(ad){
    if(ad.dataset.lbadd==='color')L.push({type:'color',name:S.fg,data:S.fg});
    else{const l=active();if(!l){toast('Select a layer first');return;}const c=flatLayer(l),b=alphaBBox(c);if(!b){toast('That layer is empty');return;}const k=Math.min(1,480/Math.max(b.w,b.h)),o=mkCanvas(b.w*k,b.h*k);cctx(o).drawImage(c,b.x,b.y,b.w,b.h,0,0,o.width,o.height);L.push({type:'image',name:l.name,data:o.toDataURL()});}
    if(lsSet('lk_lib',L))PANELS.libraries.render();return;
  }
  if(e.target.closest('[data-lbdel]')){L.pop();lsSet('lk_lib',L);PANELS.libraries.render();return;}
  const it=e.target.closest('[data-lb]');
  if(it){const a=L[+it.dataset.lb];if(a.type==='color'){S.fg=a.data;setSwatches();toast('Foreground colour set');}
    else{const im=new Image();im.onload=()=>{const n=addLayer({name:a.name,type:'image',w:im.width,h:im.height,above:true});cctx(n.canvas).drawImage(im,0,0);n.s=Math.min(1,doc.w*0.8/im.width,doc.h*0.8/im.height);commit('Place from library');};im.src=a.data;}}
});

/* ---------- Actions (record and play) ---------- */
S.rec=null;
const ACT_SKIP=['undo','redo','new','open','welcome','actRec','actStop','actPlay','closeDoc','closeAll','saveProject','savePSD','exportAs','panelPicker','allTools','hideWelcome','openRecent'];
Object.keys(ACT).forEach(k=>{
  const f=ACT[k];if(typeof f!=='function'||ACT_SKIP.includes(k))return;
  ACT[k]=function(...a){const r=f.apply(this,a);if(S.rec)S.rec.steps.push(k);return r;};
});
PNL('actions','Actions','B',pnl('actions',()=>{
  const L=lsGet('lk_actions',[]);
  return '<div class="pbtns">'+(S.rec?'<button class="primary" data-act="actStop">Stop recording ('+S.rec.steps.length+' steps)</button>':'<button data-act="actRec">Record new action</button>')+'</div>'
   +'<div class="plist">'+L.map((a,i)=>'<div class="prow2"><button data-ap="'+i+'" title="Play">&#9654; '+esc(a.name)+' <small>('+a.steps.length+')</small></button><button data-ad="'+i+'" aria-label="Delete action">&#10005;</button></div>').join('')+'</div>'
   +'<p class="muted">Record menu commands (Flip, Auto fix, Invert, layer commands and more), then play them again on any picture with one tap.</p>';
}));
ACT.actRec=D(()=>{S.rec={steps:[]};PANELS.actions.render();toast('Recording. Do the steps, then press Stop.');});
ACT.actStop=()=>{
  const r=S.rec;S.rec=null;if(!r)return;
  if(!r.steps.length){toast('Nothing was recorded');PANELS.actions.render();return;}
  askText('Save action','Action name','Action '+(lsGet('lk_actions',[]).length+1),v=>{const L=lsGet('lk_actions',[]);L.push({name:v||'Action',steps:r.steps});lsSet('lk_actions',L);PANELS.actions.render();});
};
document.addEventListener('click',e=>{
  const box=e.target.closest('#tab-actions');if(!box||!doc)return;
  const L=lsGet('lk_actions',[]);
  const p=e.target.closest('[data-ap]');if(p){const a=L[+p.dataset.ap];S.rec=null;(async()=>{for(const s of a.steps){try{if(ACT[s])await ACT[s]();}catch(err){}await new Promise(r=>setTimeout(r,60));}toast('Action finished');})();return;}
  const d=e.target.closest('[data-ad]');if(d){L.splice(+d.dataset.ad,1);lsSet('lk_actions',L);PANELS.actions.render();}
});

/* ---------- Navigator ---------- */
PNL('navigator','Navigator','A',()=>{
  const b=$('#tab-navigator');if(!b)return;
  if(!doc){b.innerHTML=NODOC;return;}
  if(!b.querySelector('canvas')){b.innerHTML='<div class="pnl"><div class="navbox"><canvas id="navc" width="260" height="170"></canvas></div><label class="prng"><span>Zoom</span><input type="range" id="navz" min="2" max="800" value="100"><output id="navzo">100%</output></label></div>';}
  const c=b.querySelector('#navc'),x=c.getContext('2d'),k=Math.min(c.width/doc.w,c.height/doc.h),w=doc.w*k,h=doc.h*k,ox=(c.width-w)/2,oy=(c.height-h)/2;
  x.clearRect(0,0,c.width,c.height);x.fillStyle='#fff';x.fillRect(ox,oy,w,h);x.drawImage(view,ox,oy,w,h);
  const r=vp.getBoundingClientRect(),a=viewToDoc(0,0),z=viewToDoc(r.width,r.height);
  x.strokeStyle='#ff3b30';x.lineWidth=2;x.strokeRect(ox+a.x*k,oy+a.y*k,(z.x-a.x)*k,(z.y-a.y)*k);
  c._m={k,ox,oy};const zs=b.querySelector('#navz');if(zs&&document.activeElement!==zs){zs.value=Math.round(S.zoom*100);b.querySelector('#navzo').textContent=Math.round(S.zoom*100)+'%';}
});
PANELS.navigator.live=true;
(function(){
  let dn=false;
  const go=e=>{const c=e.target.closest&&e.target.closest('#navc');if(!c||!c._m||!doc)return;const rc=c.getBoundingClientRect(),m=c._m,sx=c.width/rc.width,px=((e.clientX-rc.left)*sx-m.ox)/m.k,py=((e.clientY-rc.top)*(c.height/rc.height)-m.oy)/m.k,r=vp.getBoundingClientRect(),z=S.zoom;
    S.px=r.width/2-px*z;S.py=r.height/2-py*z;S.autoFit=false;applyView();};
  document.addEventListener('pointerdown',e=>{if(e.target.closest&&e.target.closest('#navc')){dn=true;go(e);}});
  document.addEventListener('pointermove',e=>{if(dn)go(e);});
  document.addEventListener('pointerup',()=>{dn=false;});
  document.addEventListener('input',e=>{if(e.target.id==='navz'&&doc){const r=vp.getBoundingClientRect();zoomAt(+e.target.value/100,r.width/2,r.height/2);}});
})();

/* ---------- Info ---------- */
const INFO={cur:null};
function infoHTML(){
  const p=INFO.cur,rows=[];
  if(p&&doc&&p.x>=0&&p.y>=0&&p.x<doc.w&&p.y<doc.h){
    const q=vctx.getImageData(Math.floor(p.x),Math.floor(p.y),1,1).data;
    rows.push(['X, Y',Math.round(p.x)+', '+Math.round(p.y)],['R G B',q[0]+', '+q[1]+', '+q[2]],['Hex',rgbHex(q[0],q[1],q[2])],['Alpha',Math.round(q[3]/2.55)+'%']);
  }else rows.push(['X, Y','-']);
  const ex=doc.extra;(ex&&ex.samplers||[]).forEach((s,i)=>{const q=vctx.getImageData(clamp(s.x,0,doc.w-1),clamp(s.y,0,doc.h-1),1,1).data;rows.push(['#'+(i+1),q[0]+', '+q[1]+', '+q[2]+'  ('+s.x+', '+s.y+')']);});
  rows.push(['Document',doc.w+' × '+doc.h+' px']);
  if(S.sel){const b=alphaBBox(S.sel.c);if(b)rows.push(['Selection',b.w+' × '+b.h+' px']);}
  const l=active();if(l)rows.push(['Layer',esc(l.name)+'  '+Math.round(l.canvas.width*l.s)+' × '+Math.round(l.canvas.height*l.s)]);
  return '<table class="itable">'+rows.map(r=>'<tr><th>'+r[0]+'</th><td>'+r[1]+'</td></tr>').join('')+'</table>';
}
PNL('info','Info','A',()=>{const b=$('#tab-info');if(!b)return;b.innerHTML=doc?'<div class="pnl" id="infobox">'+infoHTML()+'</div>':NODOC;});
PANELS.info.live=true;
function infoLive(){const b=$('#infobox');if(b&&doc)b.innerHTML=infoHTML();}
function renderInfo(){if(isVisible('info'))PANELS.info.render();}

/* ---------- Histogram ---------- */
S.histCh='rgb';
PNL('histogram','Histogram','A',()=>{
  const b=$('#tab-histogram');if(!b)return;
  if(!doc){b.innerHTML=NODOC;return;}
  if(!b.querySelector('canvas'))b.innerHTML='<div class="pnl"><div class="row"><select id="histsel" aria-label="Channel"><option value="rgb">RGB</option><option value="lum">Luminosity</option><option value="r">Red</option><option value="g">Green</option><option value="b">Blue</option></select></div><canvas id="histc" width="256" height="120" style="width:100%;background:#1b1b1b;border-radius:4px"></canvas><div id="histinfo" class="muted"></div></div>';
  const sc=b.querySelector('#histsel');if(sc&&document.activeElement!==sc)sc.value=S.histCh;
  const W=Math.min(doc.w,400),H=Math.max(1,Math.round(doc.h*W/doc.w)),t=mkCanvas(W,H);cctx(t).drawImage(view,0,0,W,H);
  const d=cctx(t).getImageData(0,0,W,H).data,hs={r:new Float32Array(256),g:new Float32Array(256),b:new Float32Array(256),l:new Float32Array(256)};let n=0,sum=0;
  for(let i=0;i<d.length;i+=4){if(d[i+3]<8)continue;hs.r[d[i]]++;hs.g[d[i+1]]++;hs.b[d[i+2]]++;const L=Math.round(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]);hs.l[L]++;sum+=L;n++;}
  const c=b.querySelector('#histc'),x=c.getContext('2d');x.clearRect(0,0,256,120);
  const draw=(h,col)=>{let mx=0;for(let i=1;i<255;i++)mx=Math.max(mx,h[i]);mx=mx||1;x.fillStyle=col;for(let i=0;i<256;i++){const v=Math.min(1,h[i]/mx)*116;x.fillRect(i,120-v,1,v);}};
  x.globalCompositeOperation='lighter';
  if(S.histCh==='rgb'){draw(hs.r,'rgba(255,40,40,.75)');draw(hs.g,'rgba(40,255,40,.75)');draw(hs.b,'rgba(60,90,255,.75)');}
  else if(S.histCh==='lum')draw(hs.l,'rgba(230,230,230,.9)');else draw(hs[S.histCh],{r:'rgba(255,60,60,.9)',g:'rgba(60,255,60,.9)',b:'rgba(80,110,255,.9)'}[S.histCh]);
  b.querySelector('#histinfo').textContent=n?'Pixels '+n+'   Average brightness '+Math.round(sum/n):'';
});
PANELS.histogram.live=true;
document.addEventListener('change',e=>{if(e.target.id==='histsel'){S.histCh=e.target.value;PANELS.histogram.render();}});

/* ---------- Measurement Log ---------- */
PNL('mlog','Measurement Log','B',()=>{
  const b=$('#tab-mlog');if(!b)return;
  b.innerHTML='<div class="pnl"><table class="itable"><tr><th>#</th><th>Length</th><th>Angle</th><th>dX / dY</th></tr>'+S.mlog.map(m=>'<tr><td>'+m.n+'</td><td>'+m.len.toFixed(1)+'</td><td>'+m.ang.toFixed(1)+'°</td><td>'+m.dx.toFixed(0)+' / '+m.dy.toFixed(0)+'</td></tr>').join('')+'</table><div class="pbtns"><button data-act="mlogClear">Clear</button><button data-act="mlogCopy">Copy</button></div><p class="muted">Use the Ruler tool. Each measurement is recorded here.</p></div>';
});
function renderMlog(){if(isVisible('mlog'))PANELS.mlog.render();}
ACT.mlogClear=()=>{S.mlog=[];PANELS.mlog.render();};
ACT.mlogCopy=()=>{const t=S.mlog.map(m=>m.n+'\t'+m.len.toFixed(1)+'\t'+m.ang.toFixed(1)).join('\n');try{navigator.clipboard.writeText(t);toast('Copied');}catch(err){toast('Could not copy');}};

/* ---------- Styles (layer style presets) ---------- */
const STYLE_PRESETS=[
  ['Soft shadow',{shadow:{on:true,color:'#000000',op:0.45,angle:120,dist:10,size:16,spread:0}}],
  ['Hard shadow',{shadow:{on:true,color:'#000000',op:0.9,angle:120,dist:12,size:0,spread:0}}],
  ['Outline',{stroke:{on:true,w:6,pos:'outside',color:'#000000',op:1}}],
  ['White border',{stroke:{on:true,w:10,pos:'outside',color:'#ffffff',op:1},shadow:{on:true,color:'#000000',op:0.4,angle:120,dist:6,size:10}}],
  ['Neon glow',{glow:{on:true,color:'#19f0ff',op:0.95,size:28,spread:20},stroke:{on:true,w:3,pos:'outside',color:'#e8ffff',op:1}}],
  ['Pink glow',{glow:{on:true,color:'#ff4fa3',op:0.9,size:30,spread:15}}],
  ['Emboss',{bevel:{on:true,style:'emboss',depth:120,size:8},shadow:{on:true,color:'#000000',op:0.35,angle:120,dist:5,size:8}}],
  ['Bevel',{bevel:{on:true,style:'inner',depth:150,size:10}}],
  ['Gold',{grad:{on:true,style:'linear',angle:90,op:1,stops:[{p:0,c:'#7a4b0a'},{p:0.3,c:'#fff1a6'},{p:0.55,c:'#c98a1a'},{p:0.8,c:'#fff1a6'},{p:1,c:'#8a5a10'}]},bevel:{on:true,style:'inner',depth:120,size:6},stroke:{on:true,w:2,pos:'outside',color:'#5a3a05',op:1}}],
  ['Chrome',{grad:{on:true,style:'linear',angle:90,op:1,stops:[{p:0,c:'#ffffff'},{p:0.45,c:'#6c7a89'},{p:0.5,c:'#1c2833'},{p:0.6,c:'#aab7c4'},{p:1,c:'#ffffff'}]},stroke:{on:true,w:2,pos:'outside',color:'#222222',op:1}}],
  ['Sunset text',{grad:{on:true,style:'linear',angle:90,op:1,stops:[{p:0,c:'#ff512f'},{p:1,c:'#f9d423'}]},shadow:{on:true,color:'#000000',op:0.4,angle:120,dist:8,size:10}}],
  ['Inner shadow',{ishadow:{on:true,color:'#000000',op:0.6,angle:120,dist:8,size:10,choke:0}}],
  ['Satin silk',{satin:{on:true,color:'#000000',op:0.4,angle:19,dist:11,size:14}}],
  ['Candy',{overlay:{on:true,color:'#ff3d81',op:1},bevel:{on:true,style:'inner',depth:200,size:12},shadow:{on:true,color:'#7a0030',op:0.5,angle:120,dist:8,size:8}}]
];
PNL('styles','Styles','A',pnl('styles',()=>'<div class="plist">'+STYLE_PRESETS.map((s,i)=>'<button class="prow" data-st="'+i+'"><span>'+s[0]+'</span></button>').join('')+'</div><div class="pbtns"><button data-act="lclearfx">Clear style</button><button data-act="lsOpen">Edit style...</button></div><p class="muted">Select a layer, then tap a style. Mix them in the Layer Style dialog.</p>'));
document.addEventListener('click',e=>{
  const t=e.target.closest('#tab-styles [data-st]');if(!t||!doc)return;
  const l=active();if(!l){toast('Select a layer first');return;}if(l.type==='adjust'){toast('Styles do not apply to adjustment layers');return;}
  l.fx=lsNormalize(clone(STYLE_PRESETS[+t.dataset.st][1]));touch(l);commit('Apply style');refreshLayers();
});

/* ---------- Tool Presets ---------- */
PNL('toolpre','Tool Presets','A',pnl('toolpre',()=>{
  const L=lsGet('lk_toolpre',[]);
  return '<div class="plist">'+(L.length?L.map((a,i)=>'<div class="prow2"><button data-tp2="'+i+'">'+esc(a.name)+'</button><button data-td2="'+i+'" aria-label="Delete preset">&#10005;</button></div>').join(''):'<p class="muted" style="padding:8px">Set up a tool the way you like it, then save it here.</p>')+'</div><div class="pbtns"><button data-ts2="1">Save current tool</button></div>';
}));
document.addEventListener('click',e=>{
  const box=e.target.closest('#tab-toolpre');if(!box||!doc)return;const L=lsGet('lk_toolpre',[]);
  if(e.target.closest('[data-ts2]')){const nm=(S.tv&&S.tv.n)||S.tool;askText('Save tool preset','Preset name',nm+' '+(L.length+1),v=>{L.push({name:v||nm,gid:S.toolBtn,idx:grpCur[S.toolBtn]||0,brush:clone(S.brush),eraser:clone(S.eraser),retouch:clone(S.retouch),shape:clone(S.shape),aux:clone(S.aux),bs:clone(S.bs),fg:S.fg});lsSet('lk_toolpre',L);PANELS.toolpre.render();});}
  const a=e.target.closest('[data-tp2]');if(a){const p=L[+a.dataset.tp2];['brush','eraser','retouch','shape','aux','bs'].forEach(k=>Object.assign(S[k],p[k]));S.fg=p.fg;setSwatches();pickTool(p.gid,p.idx);}
  const d=e.target.closest('[data-td2]');if(d){L.splice(+d.dataset.td2,1);lsSet('lk_toolpre',L);PANELS.toolpre.render();}
});

/* ---------- Clone Source ---------- */
PNL('clonesrc','Clone Source','A',pnl('clonesrc',()=>'<p>'+(S.srcPt?'Source point: '+Math.round(S.srcPt.x)+', '+Math.round(S.srcPt.y):'No source set yet.')+'</p><div class="pbtns"><button data-act="setSrc">Set source</button><button data-csc="1">Clear source</button></div><p class="muted">Used by the Clone Stamp and Healing Brush. Tap Set source, then tap a clean spot on the picture.</p>'));
document.addEventListener('click',e=>{if(e.target.closest('[data-csc]')){S.srcPt=null;if(doc){PANELS.clonesrc.render();redraw();}}});

/* ---------- Notes ---------- */
PNL('notes','Notes','B',()=>{
  const b=$('#tab-notes');if(!b)return;if(!doc){b.innerHTML=NODOC;return;}
  const L=exa('notes');
  b.innerHTML='<div class="pnl"><div class="plist">'+(L.length?L.map((n,i)=>'<div class="prow2"><button data-nt="'+i+'"><b>'+(i+1)+'.</b> '+esc(n.text.slice(0,70))+'</button><button data-ntd="'+i+'" aria-label="Delete note">&#10005;</button></div>').join(''):'<p class="muted" style="padding:8px">No notes. Use the Note tool and tap the picture.</p>')+'</div></div>';
});
function renderNotes(){if(isVisible('notes'))PANELS.notes.render();}
document.addEventListener('click',e=>{
  if(!doc)return;const box=e.target.closest('#tab-notes');if(!box)return;const L=exa('notes');
  const d=e.target.closest('[data-ntd]');if(d){L.splice(+d.dataset.ntd,1);commit('Delete note');PANELS.notes.render();redraw();return;}
  const n=e.target.closest('[data-nt]');if(n){const q=L[+n.dataset.nt];askText('Note','Note text',q.text,v=>{if(v.trim())q.text=v;else L.splice(+n.dataset.nt,1);commit('Note');PANELS.notes.render();redraw();},true);}
});

/* ---------- Comments ---------- */
PNL('comments','Comments','B',()=>{
  const b=$('#tab-comments');if(!b)return;if(!doc){b.innerHTML=NODOC;return;}
  const L=doc.comments||(doc.comments=[]);
  b.innerHTML='<div class="pnl">'+(L.length?L.map((c,i)=>'<div class="cmt"><div class="muted">'+esc(c.when)+' <button data-cd="'+i+'" aria-label="Delete comment" class="x">&#10005;</button></div><div>'+esc(c.text)+'</div></div>').join(''):'<p class="muted">Leave yourself or a teammate a comment about this design.</p>')+'<div class="row"><textarea id="cmt-in" rows="3" style="width:100%" placeholder="Write a comment"></textarea></div><div class="pbtns"><button class="primary" data-cadd="1">Add comment</button></div></div>';
});
document.addEventListener('click',e=>{
  if(!doc)return;const box=e.target.closest('#tab-comments');if(!box)return;const L=doc.comments||(doc.comments=[]);
  if(e.target.closest('[data-cadd]')){const t=$('#cmt-in').value.trim();if(!t)return;L.push({text:t,when:new Date().toLocaleString()});doc.modified=true;PANELS.comments.render();}
  const d=e.target.closest('[data-cd]');if(d){L.splice(+d.dataset.cd,1);doc.modified=true;PANELS.comments.render();}
});

/* ---------- Timeline (frame animation preview) ---------- */
let tlTimer=0;
PNL('timeline','Timeline','B',()=>{
  const b=$('#tab-timeline');if(!b)return;if(!doc){b.innerHTML=NODOC;return;}
  const F=doc.frames||(doc.frames=[]);
  b.innerHTML='<div class="pnl"><div class="plist">'+(F.length?F.map((f,i)=>'<div class="prow2"><button data-fr="'+i+'"'+(i===S.frSel?' class="on"':'')+'>Frame '+(i+1)+' <small>'+f.delay+' ms</small></button><button data-frd="'+i+'" aria-label="Delete frame">&#10005;</button></div>').join(''):'<p class="muted" style="padding:8px">Show or hide layers, then tap Add frame. Make several frames to build a small animation.</p>')+'</div>'
   +rowRange('Delay ms','tl-delay',40,2000,S.frDelay||200)+'<div class="pbtns"><button data-fradd="1">Add frame</button><button data-frupd="1">Update frame</button><button class="primary" data-frplay="1">'+(tlTimer?'Stop':'Play')+'</button><button data-frexp="1">Save frames</button></div></div>';
});
document.addEventListener('input',e=>{if(e.target.dataset&&e.target.dataset.rng==='tl-delay'){S.frDelay=+e.target.value;e.target.nextElementSibling.textContent=e.target.value;}});
const frCapture=()=>({vis:Object.fromEntries(doc.layers.map(l=>[l.id,l.visible])),delay:S.frDelay||200});
const frApply=f=>{doc.layers.forEach(l=>{if(f.vis[l.id]!==undefined)l.visible=f.vis[l.id];});refreshLayers();redraw();};
document.addEventListener('click',e=>{
  if(!doc)return;const box=e.target.closest('#tab-timeline');if(!box)return;const F=doc.frames||(doc.frames=[]);
  if(e.target.closest('[data-fradd]')){F.push(frCapture());S.frSel=F.length-1;doc.modified=true;PANELS.timeline.render();return;}
  if(e.target.closest('[data-frupd]')){if(F[S.frSel])F[S.frSel]=frCapture();doc.modified=true;PANELS.timeline.render();return;}
  const d=e.target.closest('[data-frd]');if(d){F.splice(+d.dataset.frd,1);S.frSel=-1;PANELS.timeline.render();return;}
  const s=e.target.closest('[data-fr]');if(s){S.frSel=+s.dataset.fr;frApply(F[S.frSel]);PANELS.timeline.render();return;}
  if(e.target.closest('[data-frplay]')){
    if(tlTimer){clearTimeout(tlTimer);tlTimer=0;PANELS.timeline.render();return;}
    if(F.length<2){toast('Add at least two frames');return;}
    let i=0;const step=()=>{frApply(F[i]);S.frSel=i;const dl=F[i].delay;i=(i+1)%F.length;tlTimer=setTimeout(step,dl);};step();PANELS.timeline.render();return;
  }
  if(e.target.closest('[data-frexp]')){
    if(!F.length){toast('Add frames first');return;}
    (async()=>{const keep=doc.layers.map(l=>l.visible);
      for(let i=0;i<F.length;i++){frApply(F[i]);const c=mkCanvas(doc.w,doc.h);compose(cctx(c),1);const bl=await new Promise(r=>c.toBlob(r,'image/png'));await saveBlob(bl,(doc.name||'design')+'_frame'+(i+1)+'.png');}
      doc.layers.forEach((l,i)=>l.visible=keep[i]);refreshLayers();redraw();})();
  }
});

/* ---------- Learn ---------- */
const LESSONS=[
  ['Remove a background with the Pen tool',['Open a photo.','Pick the Pen tool (P). Click around the edge of the object. Drag a little on a point to make a curve.','Click the first point to close the path.','Open the Paths panel and tap "Remove background using this path". The path becomes a mask you can still refine.'],'pen'],
  ['Remove a background automatically',['Select the photo layer.','Open Layer > Remove background.','Paint the layer mask white or black to fix any edges.'],null],
  ['Put a photo inside a shape',['Draw a shape with a Shape tool, or pick Custom Shape.','Choose Layer > Place image into shape and pick the photo.','Drag the photo inside the shape. It stays clipped.'],'shape'],
  ['Edit the letters one by one',['Add text with the Type tool.','Choose Type > Convert letters to shapes.','Pick the Direct Selection tool (A) and drag the points of any letter. Each letter is its own layer.'],'dsel'],
  ['Add a glow or shadow',['Select a layer.','Open Layer > Layer style > Drop Shadow, Outer Glow or Bevel & Emboss.','Or open the Styles panel and tap a ready-made style.'],null],
  ['Fix a blemish',['Pick the Remove tool (J).','Paint over the spot or the unwanted object.','Release. It fills in from the surroundings.'],'remove'],
  ['Cut out with Quick Selection',['Pick Quick Selection (W).','Paint over the object. Hold Alt to take away.','Select > Inverse, then press Delete to remove the background.'],'quicksel'],
  ['Straighten a crooked photo',['Pick the Ruler tool (I).','Drag a line along something that should be level.','Tap Straighten in the options bar.'],'ruler']
];
PNL('learn','Learn','A',()=>{
  const b=$('#tab-learn');if(!b)return;
  b.innerHTML='<div class="pnl">'+LESSONS.map((l,i)=>'<details class="lesson"><summary>'+esc(l[0])+'</summary><ol>'+l[1].map(s=>'<li>'+esc(s)+'</li>').join('')+'</ol>'+(l[2]?'<button data-ls="'+i+'">Pick the tool</button>':'')+'</details>').join('')+'</div>';
});
document.addEventListener('click',e=>{const t=e.target.closest('#tab-learn [data-ls]');if(t)ACT.pickToolById(LESSONS[+t.dataset.ls][2]);});

/* ---------- Discover (search everything) ---------- */
function allCommands(){
  const out=[];
  MENUS.forEach(m=>{const walk=(items,path)=>items.forEach(it=>{if(it.sep)return;if(it.items)walk(it.items,path+' > '+it.label);else out.push({n:it.label,p:path,run:()=>{if(it.dis&&it.dis())return toast('Open a design first');flush();it.fn();}});});walk(m.items,m.label);});
  TOOLGROUPS.forEach(g=>g.v.forEach((v,i)=>out.push({n:v.n,p:'Tool ('+v.k+')',run:()=>pickTool(g.id,i)})));
  PANEL_ORDER.forEach(id=>out.push({n:PANELS[id].name,p:'Panel',run:()=>openPanel(id)}));
  return out;
}
PNL('discover','Discover','A',()=>{
  const b=$('#tab-discover');if(!b)return;
  if(!b.querySelector('input'))b.innerHTML='<div class="pnl"><input type="search" id="disc-in" placeholder="Search tools, menus and panels" style="width:100%"><div class="plist" id="disc-out"></div></div>';
  discoverSearch();
});
PANELS.discover.live=true;
function discoverSearch(){
  const q=($('#disc-in')||{value:''}).value.trim().toLowerCase(),box=$('#disc-out');if(!box)return;
  const all=allCommands();window.__disc=all;
  const hits=(q?all.filter(c=>c.n.toLowerCase().includes(q)||c.p.toLowerCase().includes(q)):all.filter(c=>c.p.startsWith('Tool')||c.p==='Panel')).slice(0,40);
  window.__discHits=hits;
  box.innerHTML=hits.map((c,i)=>'<button class="prow" data-dc="'+i+'"><span>'+esc(c.n)+' <small class="muted">'+esc(c.p)+'</small></span></button>').join('')||'<p class="muted" style="padding:8px">Nothing found.</p>';
}
document.addEventListener('input',e=>{if(e.target.id==='disc-in')discoverSearch();});
document.addEventListener('click',e=>{const t=e.target.closest('#tab-discover [data-dc]');if(t){const c=window.__discHits[+t.dataset.dc];if(c)c.run();}});

/* ---------- start-up: tabs, sections, menus ---------- */
DOCK_A.length=0;DOCK_A.push(...DEFAULT_OPEN.A);DOCK_B.length=0;DOCK_B.push(...DEFAULT_OPEN.B);
makeSections();buildDockTabs();
(function(){
  const M=l=>MENUS.find(m=>m.label===l);
  M('Window').items=[
    sub('Panels',PANEL_ORDER.map(id=>al(PANELS[id].name,'',()=>openPanel(id)))),SEP,
    al('Layers','F7',()=>openPanel('layers')),al('Channels','',()=>openPanel('channels')),al('Paths','',()=>openPanel('paths')),al('History','',()=>openPanel('history')),al('Properties','',()=>openPanel('props')),SEP,
    al('Color','F6',()=>openPanel('color')),al('Swatches','',()=>openPanel('swatches')),al('Gradients','',()=>openPanel('gradients')),al('Patterns','',()=>openPanel('patterns')),al('Adjustments','',()=>openPanel('adjust')),al('Styles','',()=>openPanel('styles')),SEP,
    al('Brushes','',()=>openPanel('brushes')),al('Brush Settings','F5',()=>openPanel('brushset')),al('Brush Presets','',()=>openPanel('brushpre')),al('Tool Presets','',()=>openPanel('toolpre')),al('Clone Source','',()=>openPanel('clonesrc')),SEP,
    al('Character','',()=>openPanel('character')),al('Paragraph','',()=>openPanel('paragraph')),al('Glyphs','',()=>openPanel('glyphs')),al('Character Styles','',()=>openPanel('cstyles')),al('Paragraph Styles','',()=>openPanel('pstyles')),SEP,
    al('Navigator','',()=>openPanel('navigator')),al('Info','F8',()=>openPanel('info')),al('Histogram','',()=>openPanel('histogram')),al('Measurement Log','',()=>openPanel('mlog')),al('Notes','',()=>openPanel('notes')),al('Comments','',()=>openPanel('comments')),al('Timeline','',()=>openPanel('timeline')),SEP,
    al('Libraries','',()=>openPanel('libraries')),al('Actions','Alt+F9',()=>openPanel('actions')),al('Learn','',()=>openPanel('learn')),al('Discover','',()=>openPanel('discover')),SEP,
    al('Tools...','',()=>ACT.allTools()),al('Hide or show panels','Tab',()=>togglePanels())];
  M('Type').items=[
    mi('Add text','',()=>setTool('text')),mi('Add vertical text','',()=>ACT.pickToolById('vtext')),SEP,
    mi('Convert text to shape','','textToShape'),mi('Convert letters to shapes (one layer each)','','textToLetters'),mi('Create work path from text','','textToPath'),SEP,
    mi('Bold','','boldToggle'),mi('Italic','','italicToggle'),mi('All caps','','capsToggle'),mi('Vertical or horizontal','','vertToggle'),SEP,
    mi('Align left','','txtL'),mi('Align centre','','txtC'),mi('Align right','','txtR'),SEP,mi('Rasterize type layer','','rasterize')];
  const sel=M('Select').items;
  sel.push(SEP,mi('Quick Mask Mode','Q','quickMask',{dis:()=>!doc}),mi('Make selection from path','','pathSel'),mi('Make work path from selection','','selToPath'),mi('Save selection as channel','','chanSave'));
  const lay=M('Layer').items;
  lay.push(SEP,sub('Path',[mi('Fill path','','pathFill'),mi('Stroke path','','pathStroke'),mi('Vector mask from path','','pathMask'),mi('Remove background using path','','pathCut'),mi('Remove area inside path','','pathCutInside'),mi('Shape from path','','pathShape')],{dis:()=>!doc}));
})();
document.addEventListener('keydown',e=>{
  if(!doc||e.ctrlKey||e.metaKey||e.altKey)return;
  const tg=e.target,typing=tg.tagName==='TEXTAREA'||tg.tagName==='SELECT'||(tg.tagName==='INPUT'&&/text|number|search/.test(tg.type));
  if(typing||!$('#modal').hidden)return;
  if(e.key==='q'||e.key==='Q'){e.preventDefault();ACT.quickMask();e.stopImmediatePropagation();}
  else if(e.key==='f'||e.key==='F'){e.preventDefault();ACT.screenMode();e.stopImmediatePropagation();}
},true);
