/* ===== Colour profiles (ICC), full-resolution Export As, Image Size, print setup (bleed, safe margin, crop marks, CMYK PDF) ===== */

/* ---------- ICC profiles: write, read, convert, embed ---------- */
const ICC_P={
  'sRGB':{name:'sRGB IEC61966-2.1',xyz:[[0.4360747,0.2225045,0.0139322],[0.3850649,0.7168786,0.0971045],[0.1430804,0.0606169,0.7141733]],trc:'srgb'},
  'Display P3':{name:'Display P3',xyz:[[0.5151140,0.2411970,-0.0010500],[0.2919540,0.6922440,0.0418790],[0.1571320,0.0665580,0.7840780]],trc:'srgb'},
  'Adobe RGB (1998)':{name:'Adobe RGB (1998)',xyz:[[0.6097559,0.3111242,0.0194811],[0.2052401,0.6256560,0.0608902],[0.1492240,0.0632197,0.7448387]],trc:2.19921875},
  'ProPhoto RGB':{name:'ProPhoto RGB',xyz:[[0.7976749,0.2880402,0],[0.1351917,0.7118741,0],[0.0313534,0.0000857,0.8252100]],trc:1.8}
};
const srgbDec=v=>v<=0.04045?v/12.92:Math.pow((v+0.055)/1.055,2.4);
const srgbEnc=v=>v<=0.0031308?v*12.92:1.055*Math.pow(v,1/2.4)-0.055;
const trcDec=(t,v)=>t==='srgb'?srgbDec(v):Math.pow(v,t);
const trcEnc=(t,v)=>t==='srgb'?srgbEnc(v):Math.pow(v,1/t);
const ICC_CACHE={};
function iccBuild(key){
  if(ICC_CACHE[key])return ICC_CACHE[key];
  const P=ICC_P[key];if(!P)return null;
  const s15=v=>Math.round(v*65536),pad4=n=>(n+3)&~3;
  const tags=[];
  const desc=(()=>{const t=P.name,n=t.length+1,sz=pad4(90+n),b=new Uint8Array(sz),dv=new DataView(b.buffer);b.set([100,101,115,99],0);dv.setUint32(8,n);for(let i=0;i<t.length;i++)b[12+i]=t.charCodeAt(i);return b;})();
  const text=(()=>{const t='Public Domain. Made by LILKESSphoto Pro.',b=new Uint8Array(pad4(8+t.length+1));b.set([116,101,120,116],0);for(let i=0;i<t.length;i++)b[8+i]=t.charCodeAt(i);return b;})();
  const xyz=v=>{const b=new Uint8Array(20),dv=new DataView(b.buffer);b.set([88,89,90,32],0);dv.setInt32(8,s15(v[0]));dv.setInt32(12,s15(v[1]));dv.setInt32(16,s15(v[2]));return b;};
  const curv=(()=>{
    if(P.trc==='srgb'){const n=1024,b=new Uint8Array(12+n*2),dv=new DataView(b.buffer);b.set([99,117,114,118],0);dv.setUint32(8,n);for(let i=0;i<n;i++)dv.setUint16(12+i*2,Math.round(srgbDec(i/(n-1))*65535));return b;}
    const b=new Uint8Array(16),dv=new DataView(b.buffer);b.set([99,117,114,118],0);dv.setUint32(8,1);dv.setUint16(12,Math.round(P.trc*256));return b;
  })();
  const D50=[0.9642,1,0.8249];
  const items=[['desc',desc],['wtpt',xyz(D50)],['cprt',text],['rXYZ',xyz(P.xyz[0])],['gXYZ',xyz(P.xyz[1])],['bXYZ',xyz(P.xyz[2])],['rTRC',curv],['gTRC',null],['bTRC',null]];
  const n=items.length;let off=128+4+n*12;const offs=[],sizes=[];let curvOff=0;
  for(const [sig,b] of items){
    if(b===null){offs.push(curvOff);sizes.push(curv.length);continue;}
    offs.push(off);sizes.push(b.length);if(sig==='rTRC')curvOff=off;off+=pad4(b.length);
  }
  const out=new Uint8Array(off),dv=new DataView(out.buffer);
  dv.setUint32(0,off);dv.setUint32(8,0x02100000);
  out.set([109,110,116,114],12);out.set([82,71,66,32],16);out.set([88,89,90,32],20);        /* mntr RGB XYZ */
  dv.setUint16(24,2026);dv.setUint16(26,1);dv.setUint16(28,1);
  out.set([97,99,115,112],36);dv.setUint32(64,0);                                          /* acsp, perceptual */
  dv.setInt32(68,s15(D50[0]));dv.setInt32(72,s15(D50[1]));dv.setInt32(76,s15(D50[2]));
  dv.setUint32(128,n);
  items.forEach(([sig,b],i)=>{const p=132+i*12;for(let k=0;k<4;k++)out[p+k]=sig.charCodeAt(k);dv.setUint32(p+4,offs[i]);dv.setUint32(p+8,sizes[i]);if(b)out.set(b,offs[i]);});
  return ICC_CACHE[key]=out;
}
/* sRGB pixels -> another RGB space (the canvas always works in sRGB) */
function iccConvertCanvas(c,key){
  const P=ICC_P[key];if(!P||key==='sRGB')return c;
  const S0=ICC_P.sRGB.xyz,mat=(t)=>[[t[0][0],t[1][0],t[2][0]],[t[0][1],t[1][1],t[2][1]],[t[0][2],t[1][2],t[2][2]]];
  const A=mat(S0),B=mat(P.xyz),det=m=>m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]);
  const inv=m=>{const d=det(m);return [[(m[1][1]*m[2][2]-m[1][2]*m[2][1])/d,(m[0][2]*m[2][1]-m[0][1]*m[2][2])/d,(m[0][1]*m[1][2]-m[0][2]*m[1][1])/d],[(m[1][2]*m[2][0]-m[1][0]*m[2][2])/d,(m[0][0]*m[2][2]-m[0][2]*m[2][0])/d,(m[0][2]*m[1][0]-m[0][0]*m[1][2])/d],[(m[1][0]*m[2][1]-m[1][1]*m[2][0])/d,(m[0][1]*m[2][0]-m[0][0]*m[2][1])/d,(m[0][0]*m[1][1]-m[0][1]*m[1][0])/d]];};
  const Bi=inv(B),M=[0,1,2].map(i=>[0,1,2].map(j=>Bi[i][0]*A[0][j]+Bi[i][1]*A[1][j]+Bi[i][2]*A[2][j]));
  const dec=new Float32Array(256);for(let i=0;i<256;i++)dec[i]=srgbDec(i/255);
  const N=8192,enc=new Uint8Array(N+1);for(let i=0;i<=N;i++)enc[i]=Math.round(Math.max(0,Math.min(1,trcEnc(P.trc,i/N)))*255);
  const w=c.width,h=c.height,x=cctx(c),id=x.getImageData(0,0,w,h),d=id.data;
  const m00=M[0][0],m01=M[0][1],m02=M[0][2],m10=M[1][0],m11=M[1][1],m12=M[1][2],m20=M[2][0],m21=M[2][1],m22=M[2][2];
  for(let i=0;i<d.length;i+=4){
    const r=dec[d[i]],g=dec[d[i+1]],b=dec[d[i+2]];
    let R=m00*r+m01*g+m02*b,G=m10*r+m11*g+m12*b,Bl=m20*r+m21*g+m22*b;
    R=R<0?0:R>1?1:R;G=G<0?0:G>1?1:G;Bl=Bl<0?0:Bl>1?1:Bl;
    d[i]=enc[(R*N+0.5)|0];d[i+1]=enc[(G*N+0.5)|0];d[i+2]=enc[(Bl*N+0.5)|0];
  }
  const o=mkCanvas(w,h);cctx(o).putImageData(id,0,0);return o;
}
/* read the profile that a JPEG or PNG carries, and describe it */
async function iccFromFile(file){
  try{
    const u=new Uint8Array(await file.arrayBuffer());
    if(u[0]===0xFF&&u[1]===0xD8){
      let p=2;const parts=[];
      while(p+4<u.length&&u[p]===0xFF){
        const m=u[p+1];if(m===0xDA||m===0xD9)break;const len=(u[p+2]<<8)|u[p+3];
        if(m===0xE2&&String.fromCharCode(...u.subarray(p+4,p+16))==='ICC_PROFILE\0')parts.push({seq:u[p+16],d:u.subarray(p+18,p+2+len)});
        p+=2+len;
      }
      if(!parts.length)return null;parts.sort((a,b)=>a.seq-b.seq);let n=0;parts.forEach(q=>n+=q.d.length);const o=new Uint8Array(n);let k=0;parts.forEach(q=>{o.set(q.d,k);k+=q.d.length;});return o;
    }
    if(u[0]===0x89&&u[1]===0x50){
      let p=8;
      while(p+12<=u.length){
        const len=(u[p]<<24|u[p+1]<<16|u[p+2]<<8|u[p+3])>>>0,t=String.fromCharCode(u[p+4],u[p+5],u[p+6],u[p+7]);
        if(t==='iCCP'){let z=p+8;while(u[z])z++;const body=u.subarray(z+2,p+8+len);
          const ds=new DecompressionStream('deflate'),wr=ds.writable.getWriter();wr.write(body);wr.close();return new Uint8Array(await new Response(ds.readable).arrayBuffer());}
        if(t==='IDAT'||t==='IEND')break;p+=12+len;
      }
    }
  }catch(e){}
  return null;
}
function iccDescribe(u){
  try{
    const dv=new DataView(u.buffer,u.byteOffset,u.byteLength),sp=String.fromCharCode(u[16],u[17],u[18],u[19]).trim(),n=dv.getUint32(128);let name='',hasMat=false,hasLut=false;
    for(let i=0;i<n;i++){const p=132+i*12,sig=String.fromCharCode(u[p],u[p+1],u[p+2],u[p+3]),o=dv.getUint32(p+4),sz=dv.getUint32(p+8);
      if(sig==='desc'){const t=String.fromCharCode(u[o],u[o+1],u[o+2],u[o+3]);if(t==='desc'){const c=dv.getUint32(o+8);name=String.fromCharCode(...u.subarray(o+12,o+12+c-1));}else if(t==='mluc'){const l=dv.getUint32(o+20),so=dv.getUint32(o+24);let s='';for(let k=0;k<l/2;k++)s+=String.fromCharCode(dv.getUint16(o+so+k*2));name=s;}}
      if(sig==='rXYZ')hasMat=true;if(sig==='A2B0')hasLut=true;}
    return {space:sp,name:name||'unnamed profile',matrix:hasMat&&sp==='RGB',lut:hasLut};
  }catch(e){return null;}
}
/* tell the person what happened to the colours of a file they opened */
async function iccReport(file){
  const u=await iccFromFile(file);if(!u)return;
  const d=iccDescribe(u);if(!d)return;
  if(/^sRGB/i.test(d.name)){doc.profileNote='sRGB';return;}
  doc.profileNote=d.name;
  if(d.space==='RGB'){setTimeout(()=>toast('This file uses the colour profile "'+d.name+'". Its colours were converted to sRGB so they look right here. Export lets you choose a profile again.'),1500);}
  else setTimeout(()=>toast('This file uses a '+d.space+' colour profile ("'+d.name+'") that this editor cannot read. The picture is shown as sRGB, so colours may differ. For accurate colour, convert it to sRGB in the program that made it.'),1500);
}
{const _op=openPhoto;openPhoto=async function(file){await _op(file);if(doc&&doc.layers.length===1)iccReport(file);};}
/* photos open at their real size; they are only reduced when the device really cannot hold them */
fileToCanvas=function(file,max){
  return new Promise((res,rej)=>{
    const url=URL.createObjectURL(file),img=new Image();
    img.onload=()=>{
      let w=img.naturalWidth,h=img.naturalHeight;const w0=w,h0=h;
      let k=1;
      for(let i=0;i<8&&docSizeProblem(Math.round(w0*k),Math.round(h0*k),3,'picture');i++)k*=0.8;
      if(docSizeProblem(Math.round(w0*k),Math.round(h0*k),3,'picture')){URL.revokeObjectURL(url);rej(new Error('too big'));return;}
      w=Math.round(w0*k);h=Math.round(h0*k);
      const c=mkCanvas(w,h),x=cctx(c);x.imageSmoothingQuality='high';x.drawImage(img,0,0,w,h);URL.revokeObjectURL(url);
      if(k<1)setTimeout(()=>toast('This picture is '+w0+' x '+h0+' px. This device cannot hold that much, so it was opened at '+w+' x '+h+' px.'),800);
      res(c);
    };
    img.onerror=()=>{URL.revokeObjectURL(url);rej(new Error('decode'));};img.src=url;
  });
};
async function iccEmbed(blob,icc){
  if(!icc||!blob)return blob;
  try{
    const u=new Uint8Array(await blob.arrayBuffer());
    if(blob.type==='image/png'){
      const z=await deflateBytes(icc);if(!z)return blob;
      const name=[73,67,67,32,80,114,111,102,105,108,101,0,0],body=new Uint8Array(name.length+z.length);body.set(name);body.set(z,name.length);
      const ch=new Uint8Array(12+body.length),dv=new DataView(ch.buffer);dv.setUint32(0,body.length);ch.set([105,67,67,80],4);ch.set(body,8);dv.setUint32(8+body.length,crc32(ch.subarray(4,8+body.length))>>>0);
      const at=33,out=new Uint8Array(u.length+ch.length);out.set(u.subarray(0,at));out.set(ch,at);out.set(u.subarray(at),at+ch.length);return new Blob([out],{type:'image/png'});
    }
    if(blob.type==='image/jpeg'){
      let at=2;if(u[2]===0xFF&&u[3]===0xE0)at=4+((u[4]<<8)|u[5]);
      const per=65519-14,total=Math.ceil(icc.length/per),segs=[];
      for(let i=0;i<total;i++){const part=icc.subarray(i*per,(i+1)*per),len=part.length+16,s=new Uint8Array(len+2);s[0]=0xFF;s[1]=0xE2;s[2]=len>>8;s[3]=len&255;s.set([73,67,67,95,80,82,79,70,73,76,69,0],4);s[16]=i+1;s[17]=total;s.set(part,18);segs.push(s);}
      let sl=0;segs.forEach(s=>sl+=s.length);const out=new Uint8Array(u.length+sl);out.set(u.subarray(0,at));let k=at;segs.forEach(s=>{out.set(s,k);k+=s.length;});out.set(u.subarray(at),k);return new Blob([out],{type:'image/jpeg'});
    }
  }catch(e){console.error(e);}
  return blob;
}
function encodeTIFFicc(c,dpi,icc){
  const w=c.width,h=c.height,d=cctx(c).getImageData(0,0,w,h).data,n=icc?14:13,ifdOff=8,ifdLen=2+n*12+4,bpsOff=ifdOff+ifdLen,resOff=bpsOff+8,iccOff=resOff+16,dataOff=iccOff+(icc?((icc.length+3)&~3):0),total=dataOff+w*h*4;
  const out=new Uint8Array(total),dv=new DataView(out.buffer);
  out[0]=0x49;out[1]=0x49;dv.setUint16(2,42,true);dv.setUint32(4,ifdOff,true);
  let p=ifdOff;dv.setUint16(p,n,true);p+=2;
  const ent=(tag,type,cnt,val)=>{dv.setUint16(p,tag,true);dv.setUint16(p+2,type,true);dv.setUint32(p+4,cnt,true);if(type===3&&cnt===1)dv.setUint16(p+8,val,true);else dv.setUint32(p+8,val,true);p+=12;};
  ent(256,4,1,w);ent(257,4,1,h);ent(258,3,4,bpsOff);ent(259,3,1,1);ent(262,3,1,2);ent(273,4,1,dataOff);ent(277,3,1,4);ent(278,4,1,h);ent(279,4,1,w*h*4);
  ent(282,5,1,resOff);ent(283,5,1,resOff+8);ent(296,3,1,2);ent(338,3,1,2);if(icc)ent(34675,7,icc.length,iccOff);
  dv.setUint32(p,0,true);
  for(let i=0;i<4;i++)dv.setUint16(bpsOff+i*2,8,true);
  dv.setUint32(resOff,dpi||72,true);dv.setUint32(resOff+4,1,true);dv.setUint32(resOff+8,dpi||72,true);dv.setUint32(resOff+12,1,true);
  if(icc)out.set(icc,iccOff);out.set(d,dataOff);
  return new Blob([out],{type:'image/tiff'});
}

/* ---------- print setup: bleed, safe margin, crop marks (stored in the design) ---------- */
const mmToPx=(mm,ppi)=>mm/25.4*ppi;
function printOf(){const e=doc.extra=doc.extra||{};e.print=e.print||{bleed:3,safe:5,marks:true};return e.print;}
function addBleed(c,bleedPx){
  const b=Math.round(bleedPx);if(b<=0)return c;
  const w=c.width,h=c.height,o=mkCanvas(w+2*b,h+2*b),x=cctx(o);
  x.drawImage(c,b,b);
  /* the extra edge repeats the outer row of pixels. For a real bleed, design the background past the edge and use a larger canvas. */
  x.drawImage(c,0,0,w,1,b,0,w,b);x.drawImage(c,0,h-1,w,1,b,b+h,w,b);x.drawImage(c,0,0,1,h,0,b,b,h);x.drawImage(c,w-1,0,1,h,b+w,b,b,h);
  x.drawImage(c,0,0,1,1,0,0,b,b);x.drawImage(c,w-1,0,1,1,b+w,0,b,b);x.drawImage(c,0,h-1,1,1,0,b+h,b,b);x.drawImage(c,w-1,h-1,1,1,b+w,b+h,b,b);
  return o;
}
function drawMarksRaster(c,trim,bleedPx,ppi){
  const gap=bleedPx+mmToPx(1,ppi),L=mmToPx(4,ppi),x=cctx(c);x.fillStyle='#000';const t=Math.max(1,Math.round(ppi/150));
  const {x0,y0,x1,y1}=trim,hl=(a,b2,len)=>x.fillRect(a,b2-t/2,len,t),vl=(a,b2,len)=>x.fillRect(a-t/2,b2,t,len);
  hl(x0-gap-L,y0,L);hl(x1+gap,y0,L);hl(x0-gap-L,y1,L);hl(x1+gap,y1,L);vl(x0,y0-gap-L,L);vl(x1,y0-gap-L,L);vl(x0,y1+gap,L);vl(x1,y1+gap,L);
}
const printMargin=(o,ppi)=>o.marks?Math.round(mmToPx(o.bleed+7,ppi)):0;

/* ---------- Export As: render the real final size from the sources ---------- */
const XFMT=[['png','PNG - lossless, keeps transparency'],['jpeg','JPEG - smaller file, lossy'],['webp','WebP'],['pdf','PDF - print and documents'],['tiff','TIFF - lossless']];
async function exportRender(o){
  flush();
  const W=Math.round(o.W),H=Math.round(o.H),layers=doc.layers.length;
  const pr=docSizeProblem(W,H,Math.min(layers+1,6),'export');if(pr)throw new Error(pr);
  const kx=W/doc.w,ky=H/doc.h,uni=Math.abs(kx/ky-1)<0.005;
  S.exportRs=o.resample&&o.resample!=='render'?o.resample:'auto';
  let matte=o.fmt==='jpeg'||o.fmt==='pdf'||o.fmt==='bmp'?(o.matte||'#ffffff'):(o.transparent===false?(o.matte||'#ffffff'):null);
  let c;
  try{c=flatCanvas(uni?kx:Math.max(kx,ky),matte);}finally{S.exportRs=null;}
  if(c.width!==W||c.height!==H)c=await resampleAsync(c,W,H,o.resample&&o.resample!=='render'?o.resample:'auto');
  const dpi=o.dpi||(doc.ppi||doc.dpi||72);let page=c,marks=null;
  const pc=o.fmt==='pdf'||o.fmt==='png'||o.fmt==='jpeg'||o.fmt==='tiff';
  if(pc&&(o.bleed>0||o.marks)){
    const bpx=mmToPx(o.bleed||0,dpi);
    page=addBleed(c,bpx);
    if(o.fmt==='pdf'){marks={marginPt:o.marks?(o.bleed+7)/25.4*72:0,bleedPt:(o.bleed||0)/25.4*72,crop:!!o.marks};}
    else if(o.marks){
      const m=printMargin(o,dpi),big=mkCanvas(page.width+2*m,page.height+2*m),x=cctx(big);x.fillStyle='#fff';x.fillRect(0,0,big.width,big.height);x.drawImage(page,m,m);
      const b=Math.round(bpx);drawMarksRaster(big,{x0:m+b,y0:m+b,x1:m+b+W,y1:m+b+H},b,dpi);page=big;
    }
  }
  const prof=o.fmt==='webp'||o.fmt==='bmp'||o.fmt==='gif'?'sRGB':(o.profile||'sRGB');
  if(prof!=='sRGB'&&!o.cmyk)page=iccConvertCanvas(page,prof);
  const icc=(!o.cmyk&&(o.embed!==false))?iccBuild(prof):null;
  let blob;
  if(o.fmt==='png')blob=await iccEmbed(await setDpiBlob(await canvasBlob(page,'image/png'),dpi),icc);
  else if(o.fmt==='jpeg')blob=await iccEmbed(await setDpiBlob(await canvasBlob(page,'image/jpeg',(o.quality||92)/100),dpi),icc);
  else if(o.fmt==='webp')blob=await canvasBlob(page,'image/webp',(o.quality||92)/100);
  else if(o.fmt==='tiff')blob=encodeTIFFicc(page,dpi,icc);
  else if(o.fmt==='pdf')blob=await buildPDF({pages:[{name:doc.name,canvas:page,marks}],quality:o.quality||92,lossless:o.lossless,dpi,icc,cmyk:!!o.cmyk});
  else throw new Error('Unknown format');
  return {blob,w:page.width,h:page.height,trimW:W,trimH:H,profile:prof,dpi};
}
function openExportAs(){
  if(!doc){toast('Create or open a design first');return;}
  const P=printOf(),dpi0=(doc.ppi||doc.dpi||72);
  modalOpen('Export As',
   '<div class="xa"><div class="row"><label>Format <select id="xa-f">'+XFMT.map(f=>'<option value="'+f[0]+'">'+f[1]+'</option>').join('')+'</select></label></div>'
   +'<div class="h">Size (the design is drawn again at this size, not enlarged)</div>'
   +'<div class="fld2"><label>Width px<input type="number" id="xa-w" min="1" value="'+doc.w+'"></label><label>Height px<input type="number" id="xa-h" min="1" value="'+doc.h+'"></label><label>Scale<select id="xa-s"><option value="">Custom</option><option value="0.5">0.5x</option><option value="1" selected>1x (design size)</option><option value="2">2x</option><option value="3">3x</option><option value="4">4x</option></select></label></div>'
   +'<label class="row"><input type="checkbox" id="xa-lock" checked> Keep proportions</label>'
   +'<label class="row">Resampling of photos <select id="xa-rs"><option value="auto">Automatic (Lanczos to shrink, bicubic to enlarge)</option><option value="lanczos">Lanczos (sharpest when shrinking)</option><option value="bicubic">Bicubic</option><option value="bilinear">Bilinear (fast)</option><option value="nearest">Nearest neighbour (pixel art)</option></select></label>'
   +'<div id="xa-q" class="row">Quality <input type="range" id="xa-qs" min="30" max="100" value="92" style="width:140px"><output id="xa-qv">92</output> <span class="muted" id="xa-qn"></span></div>'
   +'<div id="xa-t" class="row"><label><input type="checkbox" id="xa-tr" checked> Transparent background</label><label>Fill colour <input type="color" id="xa-mc" value="#ffffff"></label></div>'
   +'<div class="fld2"><label>Resolution (metadata)<select id="xa-d"><option value="72">72 ppi</option><option value="150">150 ppi</option><option value="300">300 ppi</option><option value="600">600 ppi</option></select></label>'
   +'<label>Colour profile<select id="xa-p"><option>sRGB</option><option>Display P3</option><option>Adobe RGB (1998)</option><option>ProPhoto RGB</option></select></label><label>Colour mode<select id="xa-c"><option value="rgb">RGB</option><option value="cmyk">CMYK (PDF only)</option></select></label></div>'
   +'<div class="h">Print</div><div class="fld2"><label>Bleed (mm)<select id="xa-b"><option value="0">None</option><option value="3">3 mm</option><option value="5">5 mm</option></select></label><label class="row"><input type="checkbox" id="xa-m"> Crop marks</label><span></span></div>'
   +'<p class="muted" id="xa-info"></p><p class="err" id="xa-err" role="alert"></p></div>',
   [{label:'Cancel'},{label:'Export',primary:true,close:false,cb:()=>{xaGo();return false;}}],root=>{
     const q=id=>root.querySelector(id);
     q('#xa-d').value=[72,150,300,600].includes(dpi0)?dpi0:72;q('#xa-b').value=String(P.bleed>=5?5:P.bleed>=3?3:0);q('#xa-m').checked=!!P.marks&&+q('#xa-b').value>0;
     let busy=false;
     const info=()=>{
       const f=q('#xa-f').value,W=+q('#xa-w').value,H=+q('#xa-h').value,d=+q('#xa-d').value;
       q('#xa-q').style.display=(f==='jpeg'||f==='webp')?'':'none';q('#xa-qn').textContent=f==='jpeg'||f==='webp'?'Lossy: lower quality makes a smaller file and loses fine detail.':'';
       q('#xa-t').style.display=(f==='png'||f==='webp'||f==='tiff')?'':'none';
       const web=f==='webp';q('#xa-p').disabled=web;q('#xa-c').disabled=f!=='pdf';if(f!=='pdf')q('#xa-c').value='rgb';
       const pr=f==='pdf'||f==='png'||f==='jpeg'||f==='tiff';q('#xa-b').disabled=!pr;q('#xa-m').disabled=!pr;
       q('#xa-info').textContent=W+' x '+H+' px ('+(W*H/1e6).toFixed(1)+' MP). At '+d+' ppi that prints '+(W/d*25.4).toFixed(0)+' x '+(H/d*25.4).toFixed(0)+' mm. The ppi number does not add detail: only the pixel size does.'+(web?' WebP is saved as sRGB.':'');
       q('#xa-err').textContent=docSizeProblem(W,H,Math.min(doc.layers.length+1,6),'export');
     };
     root.addEventListener('input',e=>{
       const t=e.target;
       if(t.id==='xa-w'&&q('#xa-lock').checked)q('#xa-h').value=Math.max(1,Math.round(+t.value*doc.h/doc.w));
       if(t.id==='xa-h'&&q('#xa-lock').checked)q('#xa-w').value=Math.max(1,Math.round(+t.value*doc.w/doc.h));
       if(t.id==='xa-w'||t.id==='xa-h')q('#xa-s').value='';
       if(t.id==='xa-qs')q('#xa-qv').textContent=t.value;
       info();
     });
     root.addEventListener('change',e=>{
       if(e.target.id==='xa-s'&&e.target.value){const k=+e.target.value;q('#xa-w').value=Math.round(doc.w*k);q('#xa-h').value=Math.round(doc.h*k);}
       if(e.target.id==='xa-b'&&+e.target.value>0)q('#xa-m').checked=true;
       info();
     });
     window.xaGo=async()=>{
       if(busy)return;const f=q('#xa-f').value,W=Math.round(+q('#xa-w').value),H=Math.round(+q('#xa-h').value);
       const pr=docSizeProblem(W,H,Math.min(doc.layers.length+1,6),'export');if(pr){q('#xa-err').textContent=pr;return;}
       busy=true;q('#xa-err').textContent='Rendering '+W+' x '+H+' px from your layers...';
       const o={fmt:f,W,H,quality:+q('#xa-qs').value,transparent:q('#xa-tr').checked,matte:q('#xa-mc').value,dpi:+q('#xa-d').value,profile:q('#xa-p').value,cmyk:q('#xa-c').value==='cmyk',resample:q('#xa-rs').value,bleed:+q('#xa-b').value,marks:q('#xa-m').checked&&+q('#xa-b').value>=0};
       const pp=printOf();pp.bleed=o.bleed||pp.bleed;pp.marks=o.marks;
       setTimeout(async()=>{
         try{
           const r=await exportRender(o),name=(fileBase?fileBase():'design')+(W!==doc.w?'_'+W+'x'+H:'')+'.'+(f==='jpeg'?'jpg':f==='tiff'?'tif':f);
           await saveBlob(r.blob,name);closeModal();
           toast('Exported '+name+': '+r.w+' x '+r.h+' px, '+(r.blob.size/1048576).toFixed(2)+' MB'+(o.cmyk?'. CMYK uses a simple conversion without a press profile.':''));
         }catch(err){console.error(err);busy=false;q('#xa-err').textContent='Could not export: '+(err&&err.message?err.message:err);}
       },30);
     };
     info();
   },{wide:true});
}
ACT.exportAs=openExportAs;

/* ---------- Image Size: pixels, units, resolution, and the resampling method ---------- */
function openImageSize(){
  const ar=doc.w/doc.h,ppi0=(doc.ppi||doc.dpi||72);
  modalOpen('Image size',
   '<p class="muted" style="margin-top:0" id="is-cur">Current: '+doc.w+' x '+doc.h+' px at '+ppi0+' ppi</p>'
   +'<div class="fld2"><label>Width<input type="number" id="is-w" min="0.01" step="any" value="'+doc.w+'"></label><label>Height<input type="number" id="is-h" min="0.01" step="any" value="'+doc.h+'"></label><label>Unit<select id="is-u"><option value="px">Pixels</option><option value="mm">Millimetres</option><option value="cm">Centimetres</option><option value="in">Inches</option></select></label></div>'
   +'<div class="fld2"><label>Resolution (ppi)<input type="number" id="is-d" min="1" max="2400" value="'+ppi0+'"></label><span></span><span></span></div>'
   +'<label class="row"><input type="checkbox" id="is-lock" checked> Keep proportions</label>'
   +'<label class="row"><input type="checkbox" id="is-rs" checked> Resample (change the number of pixels)</label>'
   +'<label class="row">Method <select id="is-mode"><option value="auto">Automatic (Lanczos to shrink, bicubic to enlarge)</option><option value="lanczos">Lanczos</option><option value="bicubic">Bicubic</option><option value="smooth">Browser smooth (fast)</option><option value="detail">Preserve details (enlarge + sharpen)</option><option value="bilinear">Bilinear (fast preview)</option><option value="nearest">Nearest neighbour (pixel art)</option></select></label>'
   +'<p class="muted" id="is-note"></p><p class="err" id="is-err" role="alert"></p>',
   [{label:'Cancel'},{label:'OK',primary:true,close:false,cb:()=>{isGo();return false;}}],root=>{
     const q=id=>root.querySelector(id),UN={px:null,mm:25.4,cm:2.54,in:1};
     let unit='px';
     const toPx=v=>unit==='px'?v:v/UN[unit]*(+q('#is-d').value||ppi0);
     const fromPx=v=>unit==='px'?v:v*UN[unit]/(+q('#is-d').value||ppi0);
     const pxs=()=>({W:Math.max(1,Math.round(toPx(+q('#is-w').value))),H:Math.max(1,Math.round(toPx(+q('#is-h').value)))});
     const note=()=>{
       const {W,H}=pxs(),rs=q('#is-rs').checked,d=+q('#is-d').value;
       q('#is-note').textContent=rs?(W+' x '+H+' px ('+(W*H/1e6).toFixed(1)+' MP). '+(W>doc.w?'Enlarging cannot create real detail: new pixels are estimated from the old ones.':W<doc.w?'Shrinking keeps the picture sharp with Lanczos.':'')):
         'Resample is off: the pixels stay '+doc.w+' x '+doc.h+'. Changing the ppi only changes the printed size ('+(doc.w/d*25.4).toFixed(0)+' x '+(doc.h/d*25.4).toFixed(0)+' mm). It adds no detail.';
       q('#is-err').textContent=rs?docSizeProblem(W,H,doc.layers.length+1):'';
     };
     root.addEventListener('input',e=>{
       const t=e.target,rs=q('#is-rs').checked;
       if(t.id==='is-w'&&q('#is-lock').checked)q('#is-h').value=+(+t.value/ar).toFixed(unit==='px'?0:3);
       if(t.id==='is-h'&&q('#is-lock').checked)q('#is-w').value=+(+t.value*ar).toFixed(unit==='px'?0:3);
       if(t.id==='is-d'&&!rs){/* pixels stay, the printed size follows */const d=+t.value||ppi0;if(unit!=='px'){q('#is-w').value=+(doc.w/d*UN[unit]).toFixed(3);q('#is-h').value=+(doc.h/d*UN[unit]).toFixed(3);}}
       else if(t.id==='is-d'&&rs&&unit!=='px'){/* physical size kept, pixels follow */}
       note();
     });
     q('#is-u').onchange=e=>{const {W,H}=pxs();unit=e.target.value;q('#is-w').value=+fromPx(W).toFixed(unit==='px'?0:3);q('#is-h').value=+fromPx(H).toFixed(unit==='px'?0:3);note();};
     q('#is-rs').onchange=()=>{if(!q('#is-rs').checked){unit=q('#is-u').value;const d=+q('#is-d').value||ppi0;q('#is-w').value=unit==='px'?doc.w:+(doc.w/d*UN[unit]).toFixed(3);q('#is-h').value=unit==='px'?doc.h:+(doc.h/d*UN[unit]).toFixed(3);}note();};
     window.isGo=async()=>{
       const rs=q('#is-rs').checked,d=Math.round(+q('#is-d').value)||ppi0,{W,H}=pxs();
       if(!rs){doc.dpi=d;doc.ppi=d;commit('Resolution '+d+' ppi');closeModal();toast('Resolution set to '+d+' ppi. The pixels did not change.');return;}
       const pr=docSizeProblem(W,H,doc.layers.length+1);if(pr){q('#is-err').textContent=pr;return;}
       if(W===doc.w&&H===doc.h){doc.dpi=d;doc.ppi=d;closeModal();return;}
       const mode=q('#is-mode').value;S.resampleMode=mode;
       q('#is-err').textContent='Resizing...';
       try{
         const kx=W/doc.w,ky=H/doc.h,jobs=[];
         for(const l of doc.layers){
           if(l.type==='adjust')continue;
           const uni=Math.abs(kx-ky)<1e-3;if(uni&&(l.type==='text'||l.type==='shape'))continue;
           for(const key of ['canvas','mask']){const c=l[key];if(c&&['lanczos','bicubic','auto'].includes(mode)){jobs.push({c,w:Math.round(c.width*kx),h:Math.round(c.height*ky),key});}}
         }
         let i=0;
         for(const j of jobs){q('#is-err').textContent='Resizing '+(++i)+' of '+jobs.length+'...';const res=await resampleAsync(j.c,j.w,j.h,mode);if(!res)throw new Error('cancelled');RS_PRE.set(j.c,{w:j.w,h:j.h,mode,res});}
         resizeImage(W,H);doc.dpi=d;doc.ppi=d;commit('Image size');S.autoFit=true;fitView();closeModal();
         toast('Resized to '+W+' x '+H+' px with '+mode+' resampling');
       }catch(err){console.error(err);q('#is-err').textContent='Could not resize: '+(err&&err.message||err);}
     };
     note();
   });
}

/* ---------- print setup + checklist ---------- */
function openPrintSetup(){
  if(!doc){toast('Create or open a design first');return;}
  const P=printOf(),ppi=(doc.ppi||doc.dpi||72);
  const imgs=doc.layers.filter(l=>l.type==='image'&&l.canvas&&l.visible).map(l=>({n:l.name,eff:ppi/Math.max(0.01,l.s||1)})).sort((a,b)=>a.eff-b.eff);
  const low=imgs.filter(i=>i.eff<150);
  modalOpen('Print setup',
   '<div class="fld2"><label>Bleed (mm)<select id="ps-b"><option value="0">None</option><option value="3">3 mm</option><option value="5">5 mm</option></select></label><label>Safe margin (mm)<input type="number" id="ps-s" min="0" max="50" value="'+P.safe+'"></label><label class="row"><input type="checkbox" id="ps-m"> Crop marks</label></div>'
   +'<label class="row"><input type="checkbox" id="ps-show" '+(P.showSafe!==false?'checked':'')+'> Show the safe margin on the canvas</label>'
   +'<div class="h">Print check</div><ul class="muted" style="margin:4px 0 0 16px">'
   +'<li>Size: '+doc.w+' x '+doc.h+' px at '+ppi+' ppi prints '+(doc.w/ppi*25.4).toFixed(0)+' x '+(doc.h/ppi*25.4).toFixed(0)+' mm.'+(ppi<150?' <b>This is below 150 ppi, which looks soft in print.</b>':'')+'</li>'
   +'<li>'+(low.length?'<b>'+low.length+' picture layer'+(low.length>1?'s are':' is')+' below 150 ppi when printed at this size:</b> '+low.slice(0,4).map(i=>esc(i.n)+' ('+Math.round(i.eff)+' ppi)').join(', ')+'.':'Picture layers look sharp enough at this size.')+'</li>'
   +'<li>Colour: the design is RGB. CMYK PDF export uses a simple conversion without a press profile, so colours can shift. Ask your printer which profile they want.</li>'
   +'<li>Text and shapes are exported as sharp pixels at the export size, not as vector in the PDF.</li>'
   +'<li>Bleed is made by repeating the outer pixels. For artwork that runs to the edge, make the canvas bigger and design past the trim line.</li></ul>'
   +'<p class="muted">300 ppi is a label. A design is print ready only when its pixels, pictures, colours and bleed also suit the printer.</p>',
   [{label:'Cancel'},{label:'Save',primary:true,cb:()=>{P.bleed=+$('#ps-b').value;P.safe=+$('#ps-s').value||0;P.marks=$('#ps-m').checked;P.showSafe=$('#ps-show').checked;doc.modified=true;redraw();toast('Print setup saved with the design');}}],root=>{
     root.querySelector('#ps-b').value=String(P.bleed>=5?5:P.bleed>=3?3:0);root.querySelector('#ps-m').checked=!!P.marks;
   },{wide:true});
}
ACT.printSetup=openPrintSetup;
{
  const _do=drawOver;
  drawOver=function(){
    _do();
    if(!doc||!doc.extra||!doc.extra.print||doc.extra.print.showSafe===false||!(doc.extra.print.safe>0)||SM.on)return;
    const P=doc.extra.print,m=mmToPx(P.safe,(doc.ppi||doc.dpi||72));if(m*2>=Math.min(doc.w,doc.h))return;
    const o=octx;o.save();o.strokeStyle='rgba(0,200,255,.9)';o.lineWidth=1.5/S.zoom;o.setLineDash([8/S.zoom,6/S.zoom]);o.strokeRect(m,m,doc.w-2*m,doc.h-2*m);o.restore();
  };
}
(()=>{
  const M=MENUS.find(m=>m.label==='File');if(!M)return;
  const i=M.items.findIndex(it=>it.label==='Save a Copy...');
  M.items.splice(i>=0?i+1:3,0,mi('Print setup (bleed, safe margin, check)...','','printSetup'));
})();
