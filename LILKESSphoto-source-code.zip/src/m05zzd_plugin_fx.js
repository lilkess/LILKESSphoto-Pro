/* ===== Built-in plugins, part 1: the registry and the effect plugins (with live preview) ===== */
const PLG=[];                                   /* every built-in plugin: {id,name,cat,desc,ver,order,run,thumb} */
const PLG_CATS=['Resources','Image Elements','Effects','Filters','Combine Elements','Generate Content','Other Plugins'];
function plgReg(d){d.author=d.author||'LILKESSphoto';d.ver=d.ver||'1.0';d.order=PLG.length;PLG.push(d);return d;}
const plgClamp=(v,a,b)=>v<a?a:v>b?b:v;
function plgPlanes(img){const d=img.data,n=img.width*img.height,P=[0,1,2,3].map(()=>new Float32Array(n));
  for(let i=0;i<n;i++){const a=d[i*4+3]/255;P[0][i]=d[i*4]/255*a;P[1][i]=d[i*4+1]/255*a;P[2][i]=d[i*4+2]/255*a;P[3][i]=a;}return P;}
function plgFromPlanes(P,img){const d=img.data,n=img.width*img.height;
  for(let i=0;i<n;i++){const a=plgClamp(P[3][i],0,1);d[i*4+3]=Math.round(a*255);if(a>1e-4){d[i*4]=Math.round(plgClamp(P[0][i]/a,0,1)*255);d[i*4+1]=Math.round(plgClamp(P[1][i]/a,0,1)*255);d[i*4+2]=Math.round(plgClamp(P[2][i]/a,0,1)*255);}else{d[i*4]=d[i*4+1]=d[i*4+2]=0;}}return img;}
const plgBlur=(P,w,h,sigma)=>P.map(q=>fthGauss(q,w,h,Math.max(0.3,sigma)));
function plgTarget(){
  if(!doc){toast('Open a design first');return null;}
  const l=active();if(!l||l.type==='adjust'){toast('Select a picture layer first');return null;}
  if(l.locked||pxLocked(l)){toast('This layer is locked');return null;}
  ensureRaster(l);return l;
}
/* a dialog with a live preview. def.params: [{id,label,type:'range'|'select'|'check',min,max,step,value,options,unit}], def.process(img,v,{w,h,scale}) */
function plgEffectDialog(def,o){
  const l=plgTarget();if(!l)return;
  const full=l.canvas,fw=full.width,fh=full.height,k=Math.min(1,460/Math.max(fw,fh)),pw=Math.max(1,Math.round(fw*k)),ph=Math.max(1,Math.round(fh*k));
  const pc=mkCanvas(pw,ph);cctx(pc).drawImage(full,0,0,pw,ph);const base=cctx(pc).getImageData(0,0,pw,ph);
  const vals={};(def.params||[]).forEach(p=>vals[p.id]=p.value);
  const ctl=(def.params||[]).map(p=>{
    if(p.type==='select')return '<label class="plg-r"><span>'+esc(p.label)+'</span><select data-pp="'+p.id+'">'+p.options.map(op=>'<option value="'+esc(op[0])+'"'+(op[0]===p.value?' selected':'')+'>'+esc(op[1])+'</option>').join('')+'</select></label>';
    if(p.type==='check')return '<label class="plg-r"><span></span><label class="opt"><input type="checkbox" data-pp="'+p.id+'"'+(p.value?' checked':'')+'> '+esc(p.label)+'</label></label>';
    return '<label class="plg-r"><span>'+esc(p.label)+'</span><input type="range" data-pp="'+p.id+'" min="'+p.min+'" max="'+p.max+'" step="'+(p.step||1)+'" value="'+p.value+'"><input type="number" class="nv" data-pn="'+p.id+'" min="'+p.min+'" max="'+p.max+'" step="'+(p.step||1)+'" value="'+p.value+'"><em>'+(p.unit||'')+'</em></label>';}).join('');
  modalOpen(def.name,'<div class="plg-dlg"><div class="plg-pv"><canvas id="plg-pv" width="'+pw+'" height="'+ph+'"></canvas><label class="opt"><input type="checkbox" id="plg-orig"> Show original</label><div class="muted" id="plg-ms"></div></div><div class="plg-ct">'+(def.desc?'<p class="muted">'+esc(def.desc)+'</p>':'')+ctl+'</div></div>',
   [{label:'Cancel'},{label:'Apply',primary:true,cb:()=>{
      const lay=active();if(!lay||lay!==l){toast('The layer changed. Open the plugin again.');return;}
      toast('Applying...');setTimeout(()=>{
        try{
          const img=cctx(l.canvas).getImageData(0,0,l.canvas.width,l.canvas.height),b0=new ImageData(new Uint8ClampedArray(img.data),img.width,img.height);
          let out=def.process(img,Object.assign({},vals),{w:img.width,h:img.height,scale:1})||img;
          const sel=S.sel?selAlphaLocal(l):null;if(sel)out=mixSel(b0,out,sel);
          if(out.width!==l.canvas.width||out.height!==l.canvas.height){l.canvas.width=out.width;l.canvas.height=out.height;}
          cctx(l.canvas).putImageData(out,0,0);l.pv=null;l.pvv++;l.ver++;
          plgUsed(def.id);commit(def.name);renderProps();redraw();toast(def.name+' applied');
        }catch(e){console.error(e);toast('The plugin could not finish: '+(e.message||e));}
      },30);}}],
   root=>{
     const cv=root.querySelector('#plg-pv'),cx=cctx(cv),ms=root.querySelector('#plg-ms');let t=0;
     const draw=()=>{
       const t0=performance.now();
       try{const src=new ImageData(new Uint8ClampedArray(base.data),pw,ph);const out=root.querySelector('#plg-orig').checked?src:(def.process(src,Object.assign({},vals),{w:pw,h:ph,scale:k})||src);
         cv.width=out.width;cv.height=out.height;cctx(cv).putImageData(out,0,0);ms.textContent='Preview '+Math.round(performance.now()-t0)+' ms';}
       catch(e){console.error(e);ms.textContent='Preview failed: '+(e.message||e);}
     };
     const sched=()=>{clearTimeout(t);t=setTimeout(draw,70);};
     root.addEventListener('input',e=>{const x=e.target,id=x.dataset.pp||x.dataset.pn;if(!id)return;
       if(x.type==='checkbox')vals[id]=x.checked;else if(x.tagName==='SELECT')vals[id]=x.value;else{vals[id]=+x.value;const o=root.querySelector('[data-pp="'+id+'"][type=range]'),n=root.querySelector('[data-pn="'+id+'"]');if(o&&x!==o)o.value=x.value;if(n&&x!==n)n.value=x.value;}
       sched();});
     root.querySelector('#plg-orig').addEventListener('change',sched);
     draw();
   },{wide:true});
}
function plgUsed(id){try{const u=JSON.parse(localStorage.getItem('lk_plg_use')||'{}');u[id]=(u[id]||0)+1;localStorage.setItem('lk_plg_use',JSON.stringify(u));}catch(e){}}
{const st=document.createElement('style');
 st.textContent='.plg-dlg{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:14px}@media(max-width:700px){.plg-dlg{grid-template-columns:1fr}}.plg-pv{display:flex;flex-direction:column;gap:6px;align-items:center}.plg-pv canvas{max-width:100%;max-height:46vh;background:conic-gradient(#555 25%,#3a3a3a 0 50%,#555 0 75%,#3a3a3a 0) 0 0/14px 14px;border:1px solid #444;border-radius:4px}.plg-r{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:13px}.plg-r>span{width:104px;flex:none;opacity:.85}.plg-r input[type=range]{flex:1;min-width:0}.plg-r select{flex:1;min-width:0}.plg-r .nv{width:64px}.plg-r em{font-style:normal;opacity:.6;width:18px;font-size:11px}';
 document.head.appendChild(st);}

/* ---------- Superbloom: glow from the bright parts ---------- */
const PLG_TINT={none:[1,1,1],warm:[1,.82,.55],cool:[.6,.8,1],pink:[1,.55,.85],gold:[1,.9,.5]};
function plgBloom(img,v,c){
  const w=img.width,h=img.height,P=plgPlanes(img),n=w*h,th=v.threshold/255,tn=PLG_TINT[v.tint]||PLG_TINT.none,B=[0,1,2,3].map(()=>new Float32Array(n));
  for(let i=0;i<n;i++){const a=P[3][i];if(a<=0)continue;const lum=(0.299*P[0][i]+0.587*P[1][i]+0.114*P[2][i])/a,t=plgClamp((lum-th)/Math.max(0.02,1-th),0,1);
    if(t>0){B[0][i]=P[0][i]*t;B[1][i]=P[1][i]*t;B[2][i]=P[2][i]*t;B[3][i]=a*t;}}
  const r=Math.max(0.5,v.radius*c.scale),b1=plgBlur(B,w,h,r/2),b2=plgBlur(B,w,h,r*1.2),I=v.intensity/100;
  for(let i=0;i<n;i++){
    for(let q=0;q<4;q++){const bl=(0.6*b1[q][i]+0.4*b2[q][i])*I*(q<3?tn[q]:1),s=Math.min(1,bl);P[q][i]=P[q][i]+s-P[q][i]*s;}
  }
  return plgFromPlanes(P,img);
}
plgReg({id:'superbloom',name:'Superbloom',cat:'Effects',desc:'Beautiful blooms and glows. The bright parts of the picture spill a soft light around them.',
  params:[{id:'threshold',label:'Threshold',min:0,max:250,value:150,type:'range'},{id:'radius',label:'Radius',min:1,max:300,value:40,unit:'px',type:'range'},{id:'intensity',label:'Intensity',min:0,max:300,value:110,unit:'%',type:'range'},{id:'tint',label:'Glow colour',type:'select',value:'none',options:[['none','Natural'],['warm','Warm'],['gold','Golden'],['cool','Cool'],['pink','Pink']]}],
  process:plgBloom,run(){plgEffectDialog(this);}});

/* ---------- Color Theater: film looks ---------- */
const PLG_LOOKS={
 teal:{n:'Teal and orange',sat:1.12,con:1.1,sh:[-.07,.02,.08],hi:[.09,.035,-.08],fade:0},
 bleach:{n:'Bleach bypass',sat:.5,con:1.4,sh:[0,0,0],hi:[0,0,0],fade:0},
 vintage:{n:'Vintage fade',sat:.8,con:.95,sh:[.02,.035,.0],hi:[.09,.05,-.04],fade:.12},
 noir:{n:'Noir',sat:0,con:1.4,sh:[0,0,0],hi:[0,0,0],fade:0},
 cyber:{n:'Cyberpunk',sat:1.3,con:1.15,sh:[.09,-.03,.13],hi:[-.03,.09,.11],fade:0},
 golden:{n:'Golden hour',sat:1.15,con:1.05,sh:[.03,0,-.03],hi:[.12,.06,-.07],fade:0},
 steel:{n:'Cold steel',sat:.78,con:1.12,sh:[-.03,0,.06],hi:[-.03,.01,.07],fade:0},
 matte:{n:'Matte film',sat:.9,con:.9,sh:[.01,.01,.02],hi:[.02,.01,-.01],fade:.18},
 moody:{n:'Moody green',sat:.85,con:1.18,sh:[-.03,.06,.02],hi:[-.05,.02,-.03],fade:.03},
 pastel:{n:'Pastel dream',sat:.85,con:.85,sh:[.03,.0,.05],hi:[.04,.02,.06],fade:.1}};
function plgGrade(img,v,c){
  const L=PLG_LOOKS[v.look]||PLG_LOOKS.teal,d=img.data,w=img.width,h=img.height,k=v.strength/100,cx=w/2,cy=h/2,Rm=Math.hypot(cx,cy),extra=1+v.contrast/100,vg=v.vignette/100;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4;let r=d[i]/255,g=d[i+1]/255,b=d[i+2]/255;const o0=r,o1=g,o2=b;
    const con=L.con*extra;r=(r-.5)*con+.5;g=(g-.5)*con+.5;b=(b-.5)*con+.5;
    let lum=.299*r+.587*g+.114*b;r=lum+(r-lum)*L.sat;g=lum+(g-lum)*L.sat;b=lum+(b-lum)*L.sat;
    lum=plgClamp(.299*r+.587*g+.114*b,0,1);const hw=lum*lum*(3-2*lum),sw=1-hw;
    r+=L.sh[0]*sw+L.hi[0]*hw;g+=L.sh[1]*sw+L.hi[1]*hw;b+=L.sh[2]*sw+L.hi[2]*hw;
    if(L.fade){r=r*(1-L.fade)+L.fade;g=g*(1-L.fade)+L.fade;b=b*(1-L.fade)+L.fade;}
    if(vg>0){const t=Math.hypot(x-cx,y-cy)/Rm,m=1-vg*Math.max(0,t-.35)*1.5;r*=m;g*=m;b*=m;}
    d[i]=plgClamp(o0+(r-o0)*k,0,1)*255;d[i+1]=plgClamp(o1+(g-o1)*k,0,1)*255;d[i+2]=plgClamp(o2+(b-o2)*k,0,1)*255;
  }
  return img;
}
plgReg({id:'colortheater',name:'Color Theater',cat:'Filters',desc:'Quick and effective colour grading. Ten film looks with a strength slider.',
  params:[{id:'look',label:'Look',type:'select',value:'teal',options:Object.keys(PLG_LOOKS).map(k=>[k,PLG_LOOKS[k].n])},{id:'strength',label:'Strength',min:0,max:100,value:100,unit:'%',type:'range'},{id:'contrast',label:'Extra contrast',min:-50,max:50,value:0,type:'range'},{id:'vignette',label:'Vignette',min:0,max:100,value:0,type:'range'}],
  process:plgGrade,run(){plgEffectDialog(this);}});

/* ---------- Smart Blur: blurs flat areas, keeps the edges ---------- */
function plgSmartBlur(img,v,c){
  const w=img.width,h=img.height,d=img.data,R=Math.max(1,Math.round(v.radius*c.scale)),sr=Math.max(1,v.threshold),inv=-1/(2*sr*sr);
  const t=new Float32Array(w*h*3);
  const pass=(src,dst,horiz,srcF)=>{
    const len=horiz?w:h,lines=horiz?h:w;
    for(let ln=0;ln<lines;ln++)for(let p=0;p<len;p++){
      const idx=horiz?ln*w+p:p*w+ln,cr=srcF?src[idx*3]:src[idx*4],cg=srcF?src[idx*3+1]:src[idx*4+1],cb=srcF?src[idx*3+2]:src[idx*4+2];
      let sr_=0,sg=0,sb=0,sw=0;
      for(let q=-R;q<=R;q++){const pp=p+q;if(pp<0||pp>=len)continue;const j=horiz?ln*w+pp:pp*w+ln,r=srcF?src[j*3]:src[j*4],g=srcF?src[j*3+1]:src[j*4+1],b=srcF?src[j*3+2]:src[j*4+2];
        const dd=(r-cr)*(r-cr)+(g-cg)*(g-cg)+(b-cb)*(b-cb),wt=Math.exp(dd*inv/3);sr_+=r*wt;sg+=g*wt;sb+=b*wt;sw+=wt;}
      dst[idx*3]=sr_/sw;dst[idx*3+1]=sg/sw;dst[idx*3+2]=sb/sw;}
  };
  pass(d,t,true,false);const u=new Float32Array(w*h*3);pass(t,u,false,true);
  const q=v.passes||1;let cur=u;
  for(let i=1;i<q;i++){const a=new Float32Array(w*h*3),b2=new Float32Array(w*h*3);pass(cur,a,true,true);pass(a,b2,false,true);cur=b2;}
  for(let i=0;i<w*h;i++){d[i*4]=cur[i*3];d[i*4+1]=cur[i*3+1];d[i*4+2]=cur[i*3+2];}
  return img;
}
plgReg({id:'smartblur',name:'Smart Blur',cat:'Filters',desc:'Smooths skin, sky and flat areas but keeps the sharp edges. A larger threshold smooths more.',
  params:[{id:'radius',label:'Radius',min:1,max:40,value:8,unit:'px',type:'range'},{id:'threshold',label:'Threshold',min:2,max:120,value:25,type:'range'},{id:'passes',label:'Passes',min:1,max:3,value:1,type:'range'}],
  process:plgSmartBlur,run(){plgEffectDialog(this);}});

/* ---------- Find Edges ---------- */
function plgEdges(img,v){
  const w=img.width,h=img.height,d=img.data,lum=new Float32Array(w*h);
  for(let i=0;i<w*h;i++)lum[i]=(.299*d[i*4]+.587*d[i*4+1]+.114*d[i*4+2])/255;
  const g=(x,y)=>lum[plgClamp(y,0,h-1)*w+plgClamp(x,0,w-1)],st=v.strength/100*2.2,out=new Uint8ClampedArray(d.length);
  const src=new Uint8ClampedArray(d);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const gx=-g(x-1,y-1)-2*g(x-1,y)-g(x-1,y+1)+g(x+1,y-1)+2*g(x+1,y)+g(x+1,y+1),gy=-g(x-1,y-1)-2*g(x,y-1)-g(x+1,y-1)+g(x-1,y+1)+2*g(x,y+1)+g(x+1,y+1);
    const e=plgClamp(Math.hypot(gx,gy)*st,0,1),i=(y*w+x)*4;
    if(v.mode==='white'){const q=255-e*255;out[i]=out[i+1]=out[i+2]=q;}
    else if(v.mode==='black'){const q=e*255;out[i]=out[i+1]=out[i+2]=q;}
    else{out[i]=src[i]*e;out[i+1]=src[i+1]*e;out[i+2]=src[i+2]*e;}
    out[i+3]=src[i+3];
  }
  img.data.set(out);return img;
}
plgReg({id:'findedges',name:'Find+ Edges',cat:'Filters',desc:'Draws the outlines found in the picture: dark lines on white, light lines on black, or the original colours along the edges.',
  params:[{id:'strength',label:'Strength',min:10,max:400,value:100,unit:'%',type:'range'},{id:'mode',label:'Style',type:'select',value:'white',options:[['white','Dark lines on white'],['black','Light lines on black'],['colour','Colour edges']]}],
  process:plgEdges,run(){plgEffectDialog(this);}});

/* ---------- Lanczos Upscale: real resampling of the layer, no stretch blur ---------- */
plgReg({id:'lanczos',name:'Lanczos Upscale',cat:'Resources',desc:'Enlarges the active layer 2x, 3x or 4x with Lanczos resampling and a light sharpen. The layer keeps its size on the canvas and gains pixels, so you can scale it up later without going soft.',
  run(){
    const l=plgTarget();if(!l)return;
    const cap=Math.max(l.canvas.width,l.canvas.height);
    modalOpen('Lanczos Upscale','<p class="muted">The layer is now '+l.canvas.width+' x '+l.canvas.height+' px.</p><label class="plg-r"><span>Enlarge</span><select id="lz-f"><option value="2">2x</option><option value="3">3x</option><option value="4">4x</option></select></label><label class="plg-r"><span>Sharpen</span><input type="range" id="lz-s" min="0" max="100" value="25"><em>%</em></label><p class="muted">This adds real pixels with a high quality filter. It cannot invent detail that is not in the picture.</p>',
     [{label:'Cancel'},{label:'Upscale',primary:true,cb:async()=>{
        const f=+$('#lz-f').value,sh=+$('#lz-s').value/100,nw=l.canvas.width*f,nh=l.canvas.height*f;
        const pr=docSizeProblem(nw,nh,1,'This layer');if(pr){toast(pr);return;}
        toast('Upscaling...');
        try{
          let c=await resampleAsync(l.canvas,nw,nh,'lanczos');
          if(sh>0){const x=cctx(c),id=x.getImageData(0,0,c.width,c.height),P=plgPlanes(id),B=plgBlur(P,c.width,c.height,1.2);for(let q=0;q<3;q++)for(let i=0;i<P[q].length;i++)P[q][i]=P[q][i]+(P[q][i]-B[q][i])*sh*1.2;plgFromPlanes(P,id);x.putImageData(id,0,0);}
          const m=l.mask?await resampleAsync(l.mask,nw,nh,'lanczos'):null;
          if(l.smart&&l.orig)l.orig=c;
          l.canvas=c;if(m){l.mask=m;l.mver++;l._mc=null;if(l.mk)l.mk=null;}
          l.s=l.s/f;l.ver++;l.pv=null;l.pvv++;plgUsed('lanczos');commit('Lanczos upscale '+f+'x');renderProps();redraw();toast('Layer enlarged to '+c.width+' x '+c.height+' px');
        }catch(e){console.error(e);toast('Upscale failed: '+(e.message||e));}
      }}]);
  }});
