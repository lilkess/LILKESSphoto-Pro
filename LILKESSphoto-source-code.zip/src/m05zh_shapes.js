/* ===== Shape library, shape properties (corners, stroke, pathfinder), pen right-click menu ===== */
const SHAPE_CAT={};
['heart','star5','star6','burst','bubble','bubbleR','cloud','bolt'].forEach(i=>SHAPE_CAT[i]='Basic');
['arrowR','arrowL','arrowU','arrowD','arrow2','chevron'].forEach(i=>SHAPE_CAT[i]='Arrows');
['check','plus','minus','cross','crown','sun','moon','leaf','drop','flower','shield','banner','ticket','diamond','hexagon','octagon','pentagon','trapezoid','parallelogram','gear','home','pin','note','envelope','bookmark','tag','flag','ring','frame','seal','wave','smiley'].forEach(i=>{if(!SHAPE_CAT[i])SHAPE_CAT[i]='Symbols';});
['leaf','drop','flower','sun','moon','cloud'].forEach(i=>SHAPE_CAT[i]='Nature');['banner','ticket','seal','bookmark','tag','flag','shield','crown'].forEach(i=>SHAPE_CAT[i]='Badges & Banners');['bubble','bubbleR'].forEach(i=>SHAPE_CAT[i]='Callouts');['diamond','hexagon','octagon','pentagon','trapezoid','parallelogram','ring','frame'].forEach(i=>SHAPE_CAT[i]='Geometric');
const f1=n=>Math.round(n*100)/100;
function gStar(n,ri,rot){let d='';for(let i=0;i<n*2;i++){const a=-Math.PI/2+i*Math.PI/n+(rot||0),r=i%2?ri*48:48;d+=(i?'L':'M')+f1(50+Math.cos(a)*r)+' '+f1(50+Math.sin(a)*r);}return d+'Z';}
function gPoly(n,rot){let d='';for(let i=0;i<n;i++){const a=-Math.PI/2+i*2*Math.PI/n+(rot||0);d+=(i?'L':'M')+f1(50+Math.cos(a)*48)+' '+f1(50+Math.sin(a)*48);}return d+'Z';}
function gGear(n,ri){let d='';const step=Math.PI*2/n;for(let i=0;i<n;i++){const a=i*step-Math.PI/2,pts=[[a-step*0.28,ri],[a-step*0.18,48],[a+step*0.18,48],[a+step*0.28,ri]];pts.forEach((q,k)=>{d+=(i||k?'L':'M')+f1(50+Math.cos(q[0])*q[1])+' '+f1(50+Math.sin(q[0])*q[1]);});}return d+'ZM50 32A18 18 0 1 0 50 68A18 18 0 1 0 50 32Z';}
function gPie(a0,a1){const p=a=>[f1(50+Math.cos(a)*48),f1(50+Math.sin(a)*48)],A=p(a0),B=p(a1),big=(a1-a0)>Math.PI?1:0;return 'M50 50L'+A[0]+' '+A[1]+'A48 48 0 '+big+' 1 '+B[0]+' '+B[1]+'Z';}
function gArcBand(a0,a1,t){const R=48,r=R-t,p=(a,q)=>[f1(50+Math.cos(a)*q),f1(50+Math.sin(a)*q)],A=p(a0,R),B=p(a1,R),C=p(a1,r),D=p(a0,r),big=(a1-a0)>Math.PI?1:0;return 'M'+A[0]+' '+A[1]+'A'+R+' '+R+' 0 '+big+' 1 '+B[0]+' '+B[1]+'L'+C[0]+' '+C[1]+'A'+r+' '+r+' 0 '+big+' 0 '+D[0]+' '+D[1]+'Z';}
function gSnow(){let d='';for(let i=0;i<6;i++){const a=i*Math.PI/3,c=Math.cos(a),s=Math.sin(a),px=-s,py=c,pt=(r,w)=>f1(50+c*r+px*w)+' '+f1(50+s*r+py*w);d+='M'+pt(0,-3)+'L'+pt(46,-3)+'L'+pt(46,3)+'L'+pt(0,3)+'ZM'+pt(30,-3)+'L'+pt(40,-15)+'L'+pt(44,-12)+'L'+pt(34,0)+'ZM'+pt(30,3)+'L'+pt(40,15)+'L'+pt(44,12)+'L'+pt(34,0)+'Z';}return d;}
const NEWSHAPES=[
 // Geometric
 ['star4','4-point star','Geometric',gStar(4,0.38)],['star8','8-point star','Geometric',gStar(8,0.6)],['star12','12-point star','Geometric',gStar(12,0.78)],['star16','Sunburst','Geometric',gStar(16,0.82)],['star24','Scallop burst','Geometric',gStar(24,0.9)],
 ['tri','Triangle','Geometric',gPoly(3)],['rtri','Right triangle','Geometric','M6 94V6L94 94Z'],['pent','Pentagon (regular)','Geometric',gPoly(5)],['hex2','Hexagon (regular)','Geometric',gPoly(6,Math.PI/6)],['hept','Heptagon','Geometric',gPoly(7)],['dec','Decagon','Geometric',gPoly(10)],
 ['squircle','Squircle','Geometric','M50 2C88 2 98 12 98 50S88 98 50 98S2 88 2 50S12 2 50 2Z'],['rrect','Rounded square','Geometric','M22 4H78A18 18 0 0 1 96 22V78A18 18 0 0 1 78 96H22A18 18 0 0 1 4 78V22A18 18 0 0 1 22 4Z'],
 ['semi','Semicircle','Geometric','M2 70A48 48 0 0 1 98 70Z'],['quarter','Quarter circle','Geometric','M4 96V4A92 92 0 0 1 96 96Z'],['pie75','Pie','Geometric',gPie(-Math.PI/2,Math.PI)],['pie25','Pie slice','Geometric',gPie(-Math.PI/2,0)],['band','Arc band','Geometric',gArcBand(Math.PI,Math.PI*2,16)],['band3','Ring segment','Geometric',gArcBand(-Math.PI*0.2,Math.PI*1.2,14)],
 ['egg','Egg','Geometric','M50 4C74 4 90 40 90 62A40 36 0 0 1 10 62C10 40 26 4 50 4Z'],['oval','Oval','Geometric','M50 12A48 38 0 1 0 50 88A48 38 0 1 0 50 12Z'],['kite','Kite','Geometric','M50 2L90 36L50 98L10 36Z'],['rhomb','Rhombus','Geometric','M50 12L94 50L50 88L6 50Z'],['cross2','Cross (thin)','Geometric','M42 4H58V42H96V58H58V96H42V58H4V42H42Z'],['lshape','L shape','Geometric','M12 4H40V62H88V90H12Z'],['tshape','T shape','Geometric','M4 10H96V36H64V92H36V36H4Z'],['ushape','U shape','Geometric','M10 6H36V64H64V6H90V94H10Z'],['zig','Zig-zag','Geometric','M2 70L22 30L42 70L62 30L82 70L98 38V62L82 94L62 54L42 94L22 54L2 94Z'],
 // Arrows
 ['arrowBent','Bent arrow','Arrows','M6 94V50A40 40 0 0 1 46 10H62V0L96 22L62 44V34H46A16 16 0 0 0 30 50V94Z'],['arrowUturn','U-turn arrow','Arrows','M6 94V40A32 32 0 0 1 70 40V58H86L58 94L30 58H46V40A8 8 0 0 0 30 40V94Z'],['arrowNotch','Notched arrow','Arrows','M2 34H62V8L98 50L62 92V66H2L18 50Z'],['arrowBlock','Block arrow up','Arrows','M30 96V48H8L50 4L92 48H70V96Z'],['arrowStripe','Striped arrow','Arrows','M4 38H18V62H4ZM24 38H38V62H24ZM44 38H62V14L98 50L62 86V62H44Z'],['arrowCirc','Circular arrow','Arrows','M50 10A40 40 0 1 0 90 50H74A24 24 0 1 1 50 26V42L84 20L50 -2Z'],['arrowLR','Left-right arrow','Arrows','M2 50L26 22V38H74V22L98 50L74 78V62H26V78Z'],['arrow4','4-way arrow','Arrows','M50 2L68 24H56V44H76V32L98 50L76 68V56H56V76H68L50 98L32 76H44V56H24V68L2 50L24 32V44H44V24H32Z'],['arrowTri','Triangle arrow','Arrows','M10 10L96 50L10 90L28 50Z'],['arrowFat','Fat arrow','Arrows','M2 28H54V6L98 50L54 94V72H2Z'],['arrowCurve','Curved arrow','Arrows','M6 90C6 40 36 18 74 22V6L98 30L74 54V38C48 36 28 52 22 90Z'],['chevron2','Chevron small','Arrows','M20 6L72 50L20 94L8 82L48 50L8 18Z'],['caretD','Caret down','Arrows','M6 28H94L50 80Z'],
 // Symbols
 ['play','Play','Symbols','M18 6L92 50L18 94Z'],['pause','Pause','Symbols','M14 6H40V94H14ZM60 6H86V94H60Z'],['stop','Stop','Symbols','M10 10H90V90H10Z'],['next','Next','Symbols','M6 8L66 50L6 92ZM72 8H94V92H72Z'],['rec','Record','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4Z'],['eject','Eject','Symbols','M50 8L94 56H6ZM6 70H94V92H6Z'],
 ['target','Target','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM50 16A34 34 0 1 1 50 84A34 34 0 1 1 50 16ZM50 30A20 20 0 1 0 50 70A20 20 0 1 0 50 30ZM50 42A8 8 0 1 1 50 58A8 8 0 1 1 50 42Z'],['ban','No sign','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM50 16A34 34 0 0 1 77 27L27 77A34 34 0 0 1 50 16ZM73 23L23 73A34 34 0 0 0 73 23Z'],['infinity','Infinity','Symbols','M26 30C4 30 4 70 26 70C44 70 56 30 74 30C96 30 96 70 74 70C56 70 44 30 26 30ZM26 40C14 40 14 60 26 60C36 60 46 40 56 50C46 40 36 40 26 40Z'],
 ['plusC','Plus in circle','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM44 24H56V44H76V56H56V76H44V56H24V44H44Z'],['checkC','Check in circle','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM22 50L32 40L44 52L68 28L78 38L44 72Z'],['xC','Close in circle','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM30 38L38 30L50 42L62 30L70 38L58 50L70 62L62 70L50 58L38 70L30 62L42 50Z'],['info','Info','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM43 22H57V36H43ZM43 44H57V78H43Z'],['excl','Exclamation','Symbols','M38 6H62L58 62H42ZM40 74H60V94H40Z'],['quest','Question mark','Symbols','M26 30C26 10 74 6 74 32C74 52 52 52 52 62V66H40V58C40 40 62 40 62 32C62 24 38 22 38 32ZM40 76H54V92H40Z'],
 ['power','Power','Symbols','M44 4H56V48H44ZM28 18L36 26A32 32 0 1 0 64 26L72 18A44 44 0 1 1 28 18Z'],['lock','Lock','Symbols','M30 40V28A20 20 0 0 1 70 28V40H80V94H20V40ZM42 40H58V28A8 8 0 0 0 42 28Z'],['magn','Magnifier','Symbols','M40 6A34 34 0 1 0 40 74A34 34 0 1 0 40 6ZM40 20A20 20 0 1 1 40 60A20 20 0 1 1 40 20ZM62 66L72 56L96 80L86 90Z'],['bell','Bell','Symbols','M50 4C58 4 60 8 60 12C78 16 86 32 86 52V70L96 82V88H4V82L14 70V52C14 32 22 16 40 12C40 8 42 4 50 4ZM38 92H62A12 8 0 0 1 38 92Z'],['bulb','Light bulb','Symbols','M50 2A32 32 0 0 1 72 56C66 64 66 70 66 74H34C34 70 34 64 28 56A32 32 0 0 1 50 2ZM34 80H66V86H34ZM40 90H60V96H40Z'],['cup','Cup','Symbols','M8 20H72V60A28 28 0 0 1 44 88H36A28 28 0 0 1 8 60ZM72 28H86A10 10 0 0 1 96 38V46A10 10 0 0 1 86 56H70V48H84V34H72Z'],['trophy','Trophy','Symbols','M24 6H76V34A26 26 0 0 1 56 58V72H72V82H28V72H44V58A26 26 0 0 1 24 34ZM24 12H8V30A14 14 0 0 0 26 44V36A8 8 0 0 1 14 30V18H24ZM76 12H92V30A14 14 0 0 1 74 44V36A8 8 0 0 0 86 30V18H76ZM24 88H76V96H24Z'],['camera','Camera','Symbols','M30 18H70L76 30H92V84H8V30H24ZM50 36A20 20 0 1 0 50 76A20 20 0 1 0 50 36ZM50 46A10 10 0 1 1 50 66A10 10 0 1 1 50 46Z'],['phone','Phone','Symbols','M18 4H62V96H18ZM26 14V76H54V14ZM36 84H44V90H36Z'],['clock','Clock','Symbols','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM46 18H54V48L74 60L70 68L46 54Z'],['cal','Calendar','Symbols','M10 14H90V92H10ZM10 14V30H90V14ZM26 4H34V22H26ZM66 4H74V22H66ZM20 40H34V52H20ZM44 40H58V52H44ZM68 40H82V52H68ZM20 62H34V74H20ZM44 62H58V74H44Z'],['eye','Eye','Symbols','M2 50C20 20 80 20 98 50C80 80 20 80 2 50ZM50 34A16 16 0 1 0 50 66A16 16 0 1 0 50 34Z'],['hand','Thumbs up','Symbols','M8 44H28V94H8ZM34 46L52 8C64 8 66 20 62 32H90C96 32 98 40 94 48L84 88C82 92 80 94 76 94H34Z'],['paw','Paw print','Symbols','M50 48C70 48 80 74 72 84C66 92 56 84 50 84C44 84 34 92 28 84C20 74 30 48 50 48ZM18 36A10 14 0 1 0 18 64ZM82 36A10 14 0 1 1 82 64ZM36 10A10 14 0 1 0 36 38ZM64 10A10 14 0 1 1 64 38Z'],
 // Nature
 ['tree','Pine tree','Nature','M50 2L76 38H64L88 70H66L82 90H18L34 70H12L36 38H24ZM44 90H56V98H44Z'],['tree2','Round tree','Nature','M50 4A30 30 0 0 1 80 34A26 26 0 0 1 66 58H56V80H66V94H34V80H44V58H34A26 26 0 0 1 20 34A30 30 0 0 1 50 4Z'],['mount','Mountains','Nature','M2 92L34 30L50 56L68 22L98 92Z'],['snow','Snowflake','Nature',gSnow()],['sunS','Sun rays','Nature',gStar(12,0.7)],['cloud2','Cloud (round)','Nature','M24 80A18 18 0 0 1 22 44A22 22 0 0 1 62 30A24 24 0 0 1 90 54A14 14 0 0 1 80 80Z'],['rain','Rain cloud','Nature','M26 58A16 16 0 0 1 24 28A20 20 0 0 1 62 16A20 20 0 0 1 84 38A12 12 0 0 1 76 58ZM28 68L22 84H30L36 68ZM48 68L42 84H50L56 68ZM68 68L62 84H70L76 68Z'],['fish','Fish','Nature','M4 50C24 18 56 14 76 40L96 20V80L76 60C56 86 24 82 4 50ZM24 44A5 5 0 1 0 24 54Z'],['bird','Bird','Nature','M4 66C24 70 40 60 46 44C52 28 70 26 82 36L96 34L88 44C88 70 66 92 38 88C20 86 8 78 4 66Z'],['butter','Butterfly','Nature','M50 30C50 10 20 2 10 14C0 28 14 50 36 50C14 52 6 74 22 88C36 98 50 80 50 62ZM50 30C50 10 80 2 90 14C100 28 86 50 64 50C86 52 94 74 78 88C64 98 50 80 50 62Z'],['feather','Feather','Nature','M92 6C60 6 24 24 16 64L8 92L20 84C26 80 32 76 38 74C70 70 90 44 92 6ZM20 80L58 40'],['petal','Petal','Nature','M50 2C80 28 80 72 50 98C20 72 20 28 50 2Z'],['clover','Clover','Nature','M50 50A20 20 0 1 1 50 8A20 20 0 1 1 50 50A20 20 0 1 1 92 50A20 20 0 1 1 50 92A20 20 0 1 1 8 50A20 20 0 1 1 50 8Z'],
 // Callouts
 ['callSq','Square callout','Callouts','M6 8H94V66H64L50 92L36 66H6Z'],['callRd','Round callout','Callouts','M50 6C26 6 6 22 6 42C6 62 26 78 50 78C54 78 56 78 60 78L82 94L76 70C90 62 94 52 94 42C94 22 74 6 50 6Z'],['callL','Left tail bubble','Callouts','M94 8H6V66H36L50 92L64 66H94Z'],['thought','Thought bubble','Callouts','M26 60A20 20 0 0 1 22 22A24 24 0 0 1 64 12A20 20 0 0 1 88 34A18 18 0 0 1 82 62A20 18 0 0 1 56 68A22 18 0 0 1 26 60ZM20 78A8 7 0 1 0 20 92A8 7 0 1 0 20 78ZM8 94A4 4 0 1 0 8 100Z'],['callBox','Rounded callout','Callouts','M16 6H84A12 12 0 0 1 96 18V56A12 12 0 0 1 84 68H56L40 92V68H16A12 12 0 0 1 4 56V18A12 12 0 0 1 16 6Z'],['shout','Shout bubble','Callouts','M50 4L60 20L80 8L80 28L98 34L84 48L98 62L78 66L82 86L60 78L50 96L40 78L18 86L22 66L2 62L16 48L2 34L20 28L20 8L40 20Z'],
 // Badges & banners
 ['rib','Ribbon','Badges & Banners','M2 22H98L88 50L98 78H2L12 50ZM18 78H82V94H18Z'],['rib2','Ribbon curved','Badges & Banners','M2 30C30 10 70 10 98 30V74C70 54 30 54 2 74Z'],['scroll','Scroll','Badges & Banners','M16 8H86A10 10 0 0 1 86 28H22V72H86A10 10 0 0 1 86 92H14A10 10 0 0 1 14 72V28A10 10 0 0 1 16 8Z'],['badge','Badge','Badges & Banners',gStar(20,0.88)],['medal','Medal','Badges & Banners','M30 2H46L56 32H44ZM70 2H54L44 32H56ZM50 36A30 30 0 1 0 50 96A30 30 0 1 0 50 36ZM50 50A16 16 0 1 1 50 82A16 16 0 1 1 50 50Z'],['label','Label','Badges & Banners','M2 22H78L98 50L78 78H2Z'],['stamp','Stamp frame','Badges & Banners','M4 4H12A6 6 0 0 0 24 4H36A6 6 0 0 0 48 4H60A6 6 0 0 0 72 4H84A6 6 0 0 0 96 4V12A6 6 0 0 0 96 24V36A6 6 0 0 0 96 48V60A6 6 0 0 0 96 72V84A6 6 0 0 0 96 96H88A6 6 0 0 0 76 96H64A6 6 0 0 0 52 96H40A6 6 0 0 0 28 96H16A6 6 0 0 0 4 96V88A6 6 0 0 0 4 76V64A6 6 0 0 0 4 52V40A6 6 0 0 0 4 28V16A6 6 0 0 0 4 4Z'],
 // Frames & ornaments
 ['frameR','Rounded frame','Frames & Ornaments','M20 4H80A16 16 0 0 1 96 20V80A16 16 0 0 1 80 96H20A16 16 0 0 1 4 80V20A16 16 0 0 1 20 4ZM22 16A6 6 0 0 0 16 22V78A6 6 0 0 0 22 84H78A6 6 0 0 0 84 78V22A6 6 0 0 0 78 16Z'],['frame2','Double frame','Frames & Ornaments','M4 4H96V96H4ZM12 12V88H88V12ZM20 20H80V80H20Z'],['frameC','Circle frame','Frames & Ornaments','M50 4A46 46 0 1 0 50 96A46 46 0 1 0 50 4ZM50 16A34 34 0 1 1 50 84A34 34 0 1 1 50 16Z'],['cornerO','Corner bracket','Frames & Ornaments','M4 4H46V14H14V46H4Z'],['divider','Divider','Frames & Ornaments','M2 46H38L44 38L50 46L56 38L62 46H98V54H62L56 62L50 54L44 62L38 54H2Z'],['fleur','Fleur','Frames & Ornaments','M50 4C60 22 60 34 50 50C40 34 40 22 50 4ZM50 50C36 46 18 52 8 70C28 66 40 70 46 84L50 96L54 84C60 70 72 66 92 70C82 52 64 46 50 50Z'],['brace','Curly brace','Frames & Ornaments','M60 4C40 4 40 14 40 28C40 40 38 44 28 50C38 56 40 60 40 72C40 86 40 96 60 96V90C48 90 46 84 46 72C46 58 42 54 34 50C42 46 46 42 46 28C46 16 48 10 60 10Z'],['quoteL','Open quote','Frames & Ornaments','M6 56C6 28 18 12 38 8V22C26 26 24 34 24 40H40V80H6ZM52 56C52 28 64 12 84 8V22C72 26 70 34 70 40H86V80H52Z'],['dots','Dots','Frames & Ornaments','M16 16A10 10 0 1 0 16 36A10 10 0 1 0 16 16ZM50 16A10 10 0 1 0 50 36A10 10 0 1 0 50 16ZM84 16A10 10 0 1 0 84 36A10 10 0 1 0 84 16ZM16 64A10 10 0 1 0 16 84A10 10 0 1 0 16 64ZM50 64A10 10 0 1 0 50 84A10 10 0 1 0 50 64ZM84 64A10 10 0 1 0 84 84A10 10 0 1 0 84 64Z'],
 ['wave2','Wave band','Frames & Ornaments','M2 44C18 24 34 24 50 44S82 64 98 44V64C82 84 66 84 50 64S18 44 2 64Z'],['drip','Drip','Frames & Ornaments','M2 4H98V32C98 40 90 40 90 32V30C90 52 78 52 78 30C78 62 66 62 66 30V28C66 36 58 36 58 28V26C58 76 42 76 42 26V24C42 32 34 32 34 24C34 48 22 48 22 22C22 36 14 36 14 22C14 36 2 36 2 28Z']
];
NEWSHAPES.forEach(s=>{if(!VEC_SHAPES.some(q=>q.id===s[0])){VEC_SHAPES.push({id:s[0],name:s[1],d:s[3]});SHAPE_CAT[s[0]]=s[2];}});
/* custom shapes saved by the user */
function vec_toSVG(path){let d='';for(const s of path.subs){const n=s.pts.length;s.pts.forEach((q,i)=>{if(!i){d+='M'+f1(q.x)+' '+f1(q.y);return;}const a=s.pts[i-1];d+=(vec_hasH(a)||vec_hasH(q))?'C'+f1(a.ox)+' '+f1(a.oy)+' '+f1(q.ix)+' '+f1(q.iy)+' '+f1(q.x)+' '+f1(q.y):'L'+f1(q.x)+' '+f1(q.y);});
  if(s.closed&&n>1){const a=s.pts[n-1],q=s.pts[0];if(vec_hasH(a)||vec_hasH(q))d+='C'+f1(a.ox)+' '+f1(a.oy)+' '+f1(q.ix)+' '+f1(q.iy)+' '+f1(q.x)+' '+f1(q.y);d+='Z';}}return d;}
function loadMyShapes(){try{const a=JSON.parse(localStorage.getItem('lk_my_shapes')||'[]');a.forEach(s=>{if(!VEC_SHAPES.some(q=>q.id===s.id)){VEC_SHAPES.push({id:s.id,name:s.name,d:s.d});SHAPE_CAT[s.id]='My Shapes';}});}catch(e){}}
loadMyShapes();
function saveMyShape(name,path){
  const fit=vec_fit(path,2,2,96,96,true),d=vec_toSVG(fit),id='my'+Date.now();
  VEC_SHAPES.push({id,name,d});SHAPE_CAT[id]='My Shapes';
  try{const a=JSON.parse(localStorage.getItem('lk_my_shapes')||'[]');a.push({id,name,d});localStorage.setItem('lk_my_shapes',JSON.stringify(a));}catch(e){}
  return id;
}
/* ---- shape library dialog ---- */
const SHAPE_CATS=['All','Basic','Geometric','Arrows','Symbols','Nature','Callouts','Badges & Banners','Frames & Ornaments','My Shapes'];
function shapeThumb(id,sz){const c=mkCanvas(sz,sz),x=cctx(c);x.fillStyle='#d8dde6';x.beginPath();vec_trace(x,vec_transform(vec_shape(id),[sz*0.0084,0,0,sz*0.0084,sz*0.08,sz*0.08]));x.fill('evenodd');return c;}
ACT.shapeLibrary=function(){
  if(!doc){toast('Create or open a design first');return;}
  const l=active(),canReplace=l&&l.type==='shape';let cat='All',q='';
  const grid=()=>VEC_SHAPES.filter(s=>(cat==='All'||(SHAPE_CAT[s.id]||'Symbols')===cat)&&(!q||s.name.toLowerCase().includes(q))).map(s=>'<button class="shp" data-sid="'+s.id+'" title="'+esc(s.name)+'"><span data-th="'+s.id+'"></span></button>').join('')||'<p class="muted">Nothing found.</p>';
  modalOpen('Shape library','<div class="shl"><div class="shl-top"><input type="search" id="shl-q" placeholder="Search shapes" style="flex:1"><span class="muted" id="shl-n"></span></div><div class="shl-cats">'+SHAPE_CATS.map(c=>'<button data-cat="'+c+'" class="'+(c===cat?'on':'')+'">'+c+'</button>').join('')+'</div><div class="shl-grid" id="shl-g"></div><p class="muted">Click a shape to draw it with the Custom Shape tool'+(canReplace?', or press <b>Replace selected</b> to swap the selected shape.':'.')+' Make your own with the Pen tool, then right-click and choose <b>Define Custom Shape</b>.</p></div>',
   [{label:'Close'},...(canReplace?[{label:'Replace selected',cb:()=>{const id=S.shape.cid;const l2=active();if(l2&&l2.type==='shape'){l2.props.kind='custom';l2.props.cid=id;l2.props.np=null;l2.name=(VEC_SHAPES.find(s=>s.id===id)||{}).name||'Shape';renderShape(l2);commit('Replace shape');renderProps();}}}]:[])],
   body=>{
    const g=body.querySelector('#shl-g');let pick=S.shape.cid;
    const fill=()=>{g.innerHTML=grid();body.querySelector('#shl-n').textContent=g.querySelectorAll('.shp').length+' shapes';g.querySelectorAll('[data-th]').forEach((e,i)=>{const cv=shapeThumb(e.dataset.th,56);e.appendChild(cv);});g.querySelectorAll('.shp').forEach(b=>b.classList.toggle('on',b.dataset.sid===pick));};
    fill();
    body.addEventListener('click',e=>{const c=e.target.closest('[data-cat]');if(c){cat=c.dataset.cat;body.querySelectorAll('[data-cat]').forEach(b=>b.classList.toggle('on',b===c));fill();return;}
      const s=e.target.closest('.shp');if(s){pick=s.dataset.sid;S.shape.cid=pick;S.shape.kind='custom';g.querySelectorAll('.shp').forEach(b=>b.classList.toggle('on',b===s));if(!canReplace){closeModal();setTool('shape');S.shape.kind='custom';S.shape.cid=pick;renderOpts&&renderOpts();toast((VEC_SHAPES.find(v=>v.id===pick)||{}).name+' selected: drag on the canvas to draw it.');}}});
    body.querySelector('#shl-q').oninput=e=>{q=e.target.value.toLowerCase();fill();};
   },{wide:true});
};
{const W=MENUS.find(m=>m.label==='Window');if(W)W.items.splice(Math.max(0,W.items.findIndex(i=>i.label==='Layers')),0,al('Shapes','',()=>ACT.shapeLibrary()));
 const Ly=MENUS.find(m=>m.label==='Layer');if(Ly)Ly.items.push(SEP,mi('Shape library...','','shapeLibrary'));}
const _seo=shapeExtraOpts;
shapeExtraOpts=function(){return _seo()+(S.shape.kind==='custom'?'<button data-act="shapeLibrary">Browse '+VEC_SHAPES.length+' shapes...</button>':'');};
/* ===== shape rendering with corner radii, stroke options ===== */
function shapeDims(p){const so=p.salign==='outside'?p.sw:p.sw/2;return {pad:Math.ceil(so)+3,w:Math.max(2,Math.round(p.w)),h:Math.max(2,Math.round(p.h))};}
function shapePathCtx(ctx,p,w,h){
  ctx.beginPath();
  switch(p.kind){
    case 'round':case 'rect':{const cr=p.cr&&p.cr.length===4?p.cr:null;
      if(p.kind==='round'||cr){const r=cr||[p.radius,p.radius,p.radius,p.radius],m=Math.min(w,h)/2,[a,b,c,d]=r.map(v=>Math.max(0,Math.min(m,+v||0))),cs=p.cs||'round';
        const cor=(r_,x0,y0,x1,y1,cx,cy,a0,a1)=>{if(!r_)return ctx.lineTo(cx,cy);if(cs==='cut')ctx.lineTo(x1,y1);else if(cs==='inv')ctx.arc(cx,cy,r_,a0,a1,true);else ctx.arcTo(cx,cy,x1,y1,r_);};
        ctx.moveTo(a,0);ctx.lineTo(w-b,0);cor(b,w-b,0,w,b,w,0,Math.PI,Math.PI/2);
        ctx.lineTo(w,h-c);cor(c,w,h-c,w-c,h,w,h,Math.PI*1.5,Math.PI);
        ctx.lineTo(d,h);cor(d,d,h,0,h-d,0,h,0,-Math.PI/2);
        ctx.lineTo(0,a);cor(a,0,a,a,0,0,0,Math.PI/2,0);ctx.closePath();}
      else ctx.rect(0,0,w,h);break;}
    case 'ellipse':ctx.ellipse(w/2,h/2,w/2,h/2,0,0,Math.PI*2);break;
    case 'triangle':roundPoly(ctx,[[w/2,0],[w,h],[0,h]],p.vr||0,p.cs);break;
    case 'star':{const n=Math.max(3,(p.pts|0)||5),ri=p.inner==null?0.42:p.inner;const q=[];for(let i=0;i<n*2;i++){const a=-Math.PI/2+i*Math.PI/n,k=i%2?ri:1;q.push([w/2+Math.cos(a)*k*w/2,h/2+Math.sin(a)*k*h/2]);}roundPoly(ctx,q,p.vr||0,p.cs);break;}
    case 'line':ctx.moveTo(0,p.flip?h:0);ctx.lineTo(w,p.flip?0:h);break;
    case 'polygon':{const n=Math.max(3,p.sides|0||6);const q=[];for(let i=0;i<n;i++){const a=-Math.PI/2+i*2*Math.PI/n;q.push([w/2+Math.cos(a)*w/2,h/2+Math.sin(a)*h/2]);}roundPoly(ctx,q,p.vr||0,p.cs);break;}
    case 'custom':case 'path':{const np=shapeNorm(p);if(np)vec_trace(ctx,np,[w,0,0,h,0,0]);break;}
    default:ctx.rect(0,0,w,h);
  }
}
/* polygon with rounded / cut vertices (radius limited so neighbouring corners never overlap) */
function roundPoly(ctx,pts,r,style){
  const n=pts.length;if(!r||r<=0){pts.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.closePath();return;}
  const seg=[];
  for(let i=0;i<n;i++){const P=pts[(i+n-1)%n],C=pts[i],N=pts[(i+1)%n],
    v1=[P[0]-C[0],P[1]-C[1]],v2=[N[0]-C[0],N[1]-C[1]],l1=Math.hypot(v1[0],v1[1])||1,l2=Math.hypot(v2[0],v2[1])||1,
    cos=Math.max(-1,Math.min(1,(v1[0]*v2[0]+v1[1]*v2[1])/(l1*l2))),th=Math.acos(cos),tn=Math.tan(th/2)||1e-6;
    let t=Math.min(r/tn,l1/2,l2/2);
    seg.push({C,a:[C[0]+v1[0]/l1*t,C[1]+v1[1]/l1*t],b:[C[0]+v2[0]/l2*t,C[1]+v2[1]/l2*t],t,th});}
  seg.forEach((s,i)=>{i?ctx.lineTo(s.a[0],s.a[1]):ctx.moveTo(s.a[0],s.a[1]);
    if(s.t<0.01){ctx.lineTo(s.C[0],s.C[1]);return;}
    if(style==='cut')ctx.lineTo(s.b[0],s.b[1]);
    else if(style==='inv'){const mx=(s.a[0]+s.b[0])/2,my=(s.a[1]+s.b[1])/2;ctx.quadraticCurveTo(2*mx-s.C[0],2*my-s.C[1],s.b[0],s.b[1]);}
    else ctx.arcTo(s.C[0],s.C[1],s.b[0],s.b[1],s.t*Math.tan(s.th/2));});
  ctx.closePath();
}
function renderShape(l){
  const p=l.props,d=shapeDims(p),pad=d.pad,w=d.w,h=d.h,c=l.canvas,oldMask=l.mask,ow=c.width,oh=c.height;
  c.width=w+pad*2;c.height=h+pad*2;
  const ctx=cctx(c);ctx.translate(pad,pad);shapePathCtx(ctx,p,w,h);
  const fo=p.fo==null?1:p.fo;
  if(p.kind!=='line'&&!p.nofill&&(p.grad||p.fill)){ctx.save();ctx.globalAlpha=fo;ctx.fillStyle=p.grad?shapeGradient(ctx,p.grad,w,h):p.fill;ctx.fill('evenodd');ctx.restore();}
  if(p.sw>0){
    ctx.save();ctx.strokeStyle=p.stroke;ctx.lineJoin=p.join||'round';ctx.lineCap=p.cap||'round';ctx.globalAlpha=p.so==null?1:p.so;
    const dash=p.dash==='dashed'?[p.sw*3,p.sw*2]:p.dash==='dotted'?[0.01,p.sw*1.8]:[];ctx.setLineDash(dash);if(p.dash==='dotted')ctx.lineCap='round';
    if(p.salign==='inside'&&p.kind!=='line'){ctx.clip('evenodd');ctx.lineWidth=p.sw*2;ctx.stroke();}
    else if(p.salign==='outside'&&p.kind!=='line'){const tmp=mkCanvas(c.width,c.height),t=cctx(tmp);t.translate(pad,pad);shapePathCtx(t,p,w,h);t.strokeStyle=p.stroke;t.lineJoin=p.join||'round';t.lineCap=p.cap||'round';t.lineWidth=p.sw*2;t.setLineDash(dash);t.stroke();t.globalCompositeOperation='destination-out';t.fillStyle='#000';t.fill('evenodd');ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(tmp,0,0);}
    else{ctx.lineWidth=p.sw;ctx.stroke();}
    ctx.restore();}
  if(oldMask){if(oldMask.width===c.width&&oldMask.height===c.height)l.mask=oldMask;else{const m=mkCanvas(c.width,c.height);cctx(m).drawImage(oldMask,0,0,c.width,c.height);l.mask=m;l.mver++;}}else l.mask=null;
  touch(l);
}
/* keep masks when text is edited too */
{const _rt=renderText;renderText=function(l){const m=l.mask,ow=l.canvas.width,oh=l.canvas.height;_rt(l);if(m){if(m.width===l.canvas.width&&m.height===l.canvas.height)l.mask=m;else{const n=mkCanvas(l.canvas.width,l.canvas.height);cctx(n).drawImage(m,0,0,n.width,n.height);l.mask=n;l.mver++;}touch(l);}};}
/* ---- corner radius panel ---- */
const CORNER_KINDS=['rect','round','triangle','star','polygon'];
function cornerMax(p){return Math.max(1,Math.floor(Math.min(p.w,p.h)/2));}
function cornerPanel(p){
  if(!CORNER_KINDS.includes(p.kind))return '';
  const max=cornerMax(p),cs=p.cs||'round',poly=p.kind!=='rect'&&p.kind!=='round',link=p.crl!==false;
  const cr=(p.cr&&p.cr.length===4?p.cr:[p.radius||0,p.radius||0,p.radius||0,p.radius||0]).map(v=>Math.min(max,Math.round(v))),mst=poly?Math.min(max,Math.round(p.vr||0)):Math.max(...cr);
  let h='<div class="crx"><div class="crx-h"><b>Corners</b><span class="crx-sp"></span>'
   +(poly?'':'<button class="crx-lk'+(link?' on':'')+'" data-crlink="1" title="'+(link?'Corners are linked. Click to edit them one by one':'Corners are independent. Click to link them')+'">'+(link?'&#128279; Linked':'&#9986; Separate')+'</button>')
   +'<button class="crx-rs" data-crreset="1" title="Reset corners to square">Reset</button></div>';
  if(!poly){
    const fld=(i,pos)=>'<input type="number" class="crx-n '+pos+'" data-crx="'+i+'" min="0" max="'+max+'" value="'+cr[i]+'" title="'+({tl:'Top left',tr:'Top right',bl:'Bottom left',br:'Bottom right'})[pos]+' radius"'+(link&&i>0?' tabindex="-1"':'')+'>';
    const rr=Math.min(100,100*Math.min(...cr)/max*0.5);
    h+='<div class="crx-box"><div class="crx-prev" style="border-radius:'+cr.map(v=>(max?v/max*50:0)+'%').join(' ')+'/'+cr.map(v=>(max?v/max*50:0)+'%').join(' ')+'"></div>'+fld(0,'tl')+fld(1,'tr')+fld(3,'bl')+fld(2,'br')+'</div>';
  }
  h+='<div class="crx-ms"><input type="range" data-crm="1" min="0" max="'+max+'" step="1" value="'+mst+'"><input type="number" class="crx-n crx-mn" data-crm="1" min="0" max="'+max+'" value="'+mst+'"><span class="muted">px</span></div>'
   +'<div class="crx-st"><span class="muted">Style</span><select id="sp-cs">'+[['round','Round'],['cut','Chamfer'],['inv','Scoop']].map(a=>'<option value="'+a[0]+'"'+(cs===a[0]?' selected':'')+'>'+a[1]+'</option>').join('')+'</select></div></div>';
  return h;
}
function setCorners(l,t){
  const p=l.props,max=cornerMax(p);let v=Math.max(0,Math.min(max,+t.value||0));
  const poly=p.kind!=='rect'&&p.kind!=='round';
  if(poly){p.vr=v;}
  else{let cr=p.cr&&p.cr.length===4?p.cr.slice():[p.radius||0,p.radius||0,p.radius||0,p.radius||0];
    if(t.dataset.crm!==undefined||p.crl!==false)cr=[v,v,v,v];else cr[+t.dataset.crx]=v;
    p.cr=cr;p.radius=cr[0];if(p.kind==='rect'&&cr.some(x=>x>0))p.kind='round';}
  const box=$('#tab-props');
  box.querySelectorAll('[data-crm]').forEach(o=>{if(o!==t)o.value=v;});
  if(!poly){const cr=p.cr;box.querySelectorAll('[data-crx]').forEach(o=>{if(o!==t)o.value=Math.round(cr[+o.dataset.crx]);});
    const pv=box.querySelector('.crx-prev');if(pv){const r=cr.map(x=>(max?x/max*50:0)+'%').join(' ');pv.style.borderRadius=r;}}
  renderShape(l);pend=true;redraw();
}
/* ---- shape Properties ---- */
{
  const _rp=renderProps;
  renderProps=function(){
    _rp();const l=doc&&active();if(!l||l.type!=='shape')return;
    const box=$('#tab-props');{const o=box.querySelector('#p-sradius');if(o){const lb=o.closest('label');if(lb)lb.remove();}}
    const p=l.props,h=box.innerHTML,idx=h.indexOf('<div class="h">Mask and style</div>');if(idx<0)return;
    const sl=(k,lab,min,max,val,step)=>'<label class="sl"><span>'+lab+'</span><input type="range" data-sp="'+k+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+val+'"><input type="number" class="nv" data-sp="'+k+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+val+'"></label>';
    const cr=p.cr&&p.cr.length===4?p.cr:[p.radius||0,p.radius||0,p.radius||0,p.radius||0],link=p.crl!==false;
    let x='<details class="tpanel" open><summary>Appearance</summary>';
    x+=cornerPanel(p);
    if(p.kind==='star')x+=sl('pts','Points',3,40,p.pts||5)+sl('inner','Inner radius %',5,95,Math.round((p.inner==null?0.42:p.inner)*100));
    if(p.kind==='polygon')x+=sl('sides','Sides',3,40,p.sides||6);
    x+=sl('fo','Fill opacity %',0,100,Math.round((p.fo==null?1:p.fo)*100));
    x+='<div class="h">Stroke</div>'+sl('so','Stroke opacity %',0,100,Math.round((p.so==null?1:p.so)*100))
     +'<div class="row"><label class="opt">Align <select id="sp-salign">'+[['center','Center'],['inside','Inside'],['outside','Outside']].map(a=>'<option value="'+a[0]+'"'+((p.salign||'center')===a[0]?' selected':'')+'>'+a[1]+'</option>').join('')+'</select></label><label class="opt">Line <select id="sp-dash">'+[['solid','Solid'],['dashed','Dashed'],['dotted','Dotted']].map(a=>'<option value="'+a[0]+'"'+((p.dash||'solid')===a[0]?' selected':'')+'>'+a[1]+'</option>').join('')+'</select></label></div>'
     +'<div class="row"><label class="opt">Caps <select id="sp-cap">'+[['round','Round'],['butt','Butt'],['square','Square']].map(a=>'<option value="'+a[0]+'"'+((p.cap||'round')===a[0]?' selected':'')+'>'+a[1]+'</option>').join('')+'</select></label><label class="opt">Corners <select id="sp-join">'+[['round','Round'],['miter','Miter'],['bevel','Bevel']].map(a=>'<option value="'+a[0]+'"'+((p.join||'round')===a[0]?' selected':'')+'>'+a[1]+'</option>').join('')+'</select></label></div></details>';
    const n=grpSelShapes().length;
    x+='<details class="tpanel" open><summary>Pathfinder</summary><div class="pfgrid"><button data-pf="unite" title="Unite">Unite</button><button data-pf="subtract" title="Subtract front shapes from the back one">Subtract</button><button data-pf="intersect" title="Intersect">Intersect</button><button data-pf="exclude" title="Exclude overlap">Exclude</button></div><div class="row"><button data-pf="path" title="Turn this shape into an editable path">Convert to editable path</button><button data-act="shapeLibrary">Shapes...</button></div><p class="muted">'+(n>1?n+' shapes selected. The lowest one keeps its colour.':'Select two or more shapes (Ctrl/Shift-click in Layers) to combine them.')+'</p></details>';
    box.innerHTML=h.slice(0,idx)+x+h.slice(idx);
  };
  const box=$('#tab-props');
  const grpSelShapes=()=>{const s=new Set(doc.msel||[]);if(doc.active)s.add(doc.active);return [...s].map(id=>doc.layers.find(l=>l.id===id)).filter(l=>l&&l.type==='shape');};
  window.grpSelShapes=grpSelShapes;
  box.addEventListener('input',e=>{const t=e.target,l=active();if(!l||l.type!=='shape')return;
    if(t.dataset.sp){let v=+t.value;const k=t.dataset.sp;if(k==='fo'||k==='so')v/=100;if(k==='inner')v/=100;l.props[k]=v;box.querySelectorAll('[data-sp="'+k+'"]').forEach(o=>{if(o!==t)o.value=t.value;});renderShape(l);pend=true;redraw();}
    else if(t.dataset.crx!==undefined||t.dataset.crm!==undefined)setCorners(l,t);
  });
  box.addEventListener('change',e=>{const t=e.target,l=active();if(!l||l.type!=='shape')return;
    if(t.dataset.crx!==undefined||t.dataset.crm!==undefined){commit('Corner radius');return;}
    if(t.id==='p-kind'){setTimeout(()=>{renderShape(l);renderProps();},30);return;}
    if(t.id==='sp-cs'){l.props.cs=t.value;renderShape(l);commit('Corner style');redraw();renderProps();return;}
    const m={'sp-salign':'salign','sp-dash':'dash','sp-cap':'cap','sp-join':'join'}[t.id];if(m){l.props[m]=t.value;renderShape(l);commit('Shape stroke');renderProps();}
  });
  box.addEventListener('click',e=>{
    const lk=e.target.closest('[data-crlink]'),l=active();
    if(lk&&l&&l.props){const p=l.props;p.crl=p.crl===false;const cr=p.cr&&p.cr.length===4?p.cr:[p.radius||0,p.radius||0,p.radius||0,p.radius||0];if(p.crl){const v=Math.max(...cr);p.cr=[v,v,v,v];p.radius=v;renderShape(l);redraw();}commit('Link corners');renderProps();return;}
    const rs=e.target.closest('[data-crreset]');if(rs&&l){const p=l.props;p.cr=[0,0,0,0];p.radius=0;p.vr=0;renderShape(l);commit('Reset corners');redraw();renderProps();return;}
    const b=e.target.closest('[data-pf]');if(!b)return;pathfinder(b.dataset.pf);});
  function pathfinder(op){
    flush();const list=grpSelShapes();
    if(op==='path'){const l=active();if(!l||l.type!=='shape'){toast('Select a shape');return;}if(l.props.kind==='path'||l.props.kind==='custom'){toast('Already an editable path');return;}
      const c=cloneCanvas(l.canvas);const tr=vec_traceAlpha(c,{tol:0.5});const dm=layerToDocM(l),path=vec_transform(tr,dm);const nl=pathToShapeLayer(path,{name:l.name+' path',fill:l.props.fill,stroke:l.props.stroke,sw:0});
      nl.props.grad=l.props.grad||null;renderShape(nl);doc.layers.splice(doc.layers.indexOf(l),1);commit('Convert to path');refreshLayers();redraw();renderProps();toast('Now an editable path. Use the Direct Selection tool to reshape it.');return;}
    if(list.length<2){toast('Select two or more shapes first (Ctrl or Shift-click them in the Layers panel)');return;}
    list.sort((a,b)=>doc.layers.indexOf(a)-doc.layers.indexOf(b));
    const W=doc.w,H=doc.h,res=mkCanvas(W,H),x=cctx(res);
    const draw=(ctx,l)=>{ctx.save();ctx.setTransform.apply(ctx,layerToDocM(l));ctx.drawImage(l.canvas,0,0);ctx.restore();};
    const solid=(l)=>{const c=mkCanvas(W,H),t=cctx(c);t.save();t.setTransform.apply(t,layerToDocM(l));const p=Object.assign({},l.props,{sw:0,fill:'#000',grad:null,nofill:false,fo:1});const d=shapeDims(p);t.translate(d.pad,d.pad);shapePathCtx(t,p,d.w,d.h);t.fillStyle='#000';t.fill('evenodd');t.restore();return c;};
    const base=solid(list[0]);x.drawImage(base,0,0);
    for(let i=1;i<list.length;i++){const s=solid(list[i]);
      if(op==='unite'){x.globalCompositeOperation='source-over';x.drawImage(s,0,0);}
      else if(op==='subtract'){x.globalCompositeOperation='destination-out';x.drawImage(s,0,0);}
      else if(op==='intersect'){x.globalCompositeOperation='destination-in';x.drawImage(s,0,0);}
      else if(op==='exclude'){const a=cloneCanvas(res),inter=cloneCanvas(res),ix=cctx(inter);ix.globalCompositeOperation='destination-in';ix.drawImage(s,0,0);x.globalCompositeOperation='source-over';x.drawImage(s,0,0);x.globalCompositeOperation='destination-out';x.drawImage(inter,0,0);}
      x.globalCompositeOperation='source-over';}
    const path=vec_traceAlpha(res,{tol:0.6,minArea:4});
    if(!path.subs.length){toast('The result is empty');return;}
    const b=list[0].props,nl=pathToShapeLayer(path,{name:({unite:'Unite',subtract:'Subtract',intersect:'Intersect',exclude:'Exclude'})[op],fill:b.fill,stroke:b.stroke,sw:b.sw||0});nl.props.grad=b.grad||null;renderShape(nl);
    list.forEach(l=>{const i=doc.layers.indexOf(l);if(i>=0)doc.layers.splice(i,1);});doc.msel=[];
    commit('Pathfinder: '+op);refreshLayers();redraw();renderProps();toast('Combined into one editable shape (traced, so curves are approximated).');
  }
  ACT.pfUnite=()=>pathfinder('unite');ACT.pfSubtract=()=>pathfinder('subtract');ACT.pfIntersect=()=>pathfinder('intersect');ACT.pfExclude=()=>pathfinder('exclude');
  const Ly=MENUS.find(m=>m.label==='Layer');if(Ly)Ly.items.push(sub('Combine shapes',[mi('Unite','','pfUnite'),mi('Subtract','','pfSubtract'),mi('Intersect','','pfIntersect'),mi('Exclude overlap','','pfExclude')],{dis:()=>!doc}));
}
/* ===== Pen right-click menu ===== */
{
  const vp2=document.getElementById('view');let menu=null;
  const hide=()=>{if(menu){menu.remove();menu=null;}};
  document.addEventListener('pointerdown',e=>{if(menu&&!menu.contains(e.target))hide();},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')hide();});
  const tol=()=>[10/S.zoom,8/S.zoom,8/S.zoom];
  const target=()=>editTarget();
  function defineCustom(){
    const T=target();let path=T?T.get():null;if(!path||!path.subs.some(s=>s.pts.length>1)){toast('Draw a closed path first');return;}
    askText('Define custom shape','Shape name','My shape '+(VEC_SHAPES.filter(s=>SHAPE_CAT[s.id]==='My Shapes').length+1),name=>{const id=saveMyShape(name||'My shape',path);S.shape.kind='custom';S.shape.cid=id;toast('Saved "'+(name||'My shape')+'". Find it in the Shape library under My Shapes.');});
  }
  function items(p,hit){
    const ph=curPath(false),drawing=penCur(ph),has=ph&&ph.path.subs.some(s=>s.pts.length>1),shapeL=shapeEditable(active())&&!S.pen.usePath,T=target(),it=[];
    const add=(label,fn,dis)=>it.push({label,fn,dis});const sep=()=>it.push(null);
    const onSeg=hit&&hit.type==='segment',onPt=hit&&(hit.type==='anchor');
    add('Add Anchor Point',()=>{if(!T||!onSeg)return;const path=T.get();vec_insertPointAt(path.subs[hit.sub],hit.pt,hit.t);T.set(path);S.pen.sel={sub:hit.sub,pt:hit.pt+1};commit('Add anchor point');redraw();},!onSeg);
    add('Delete Anchor Point',()=>{const path=T.get(),s=path.subs[hit.sub];if(vec_deletePoint(s,hit.pt))path.subs.splice(hit.sub,1);T.set(path);commit('Delete anchor point');redraw();},!onPt);
    add('Convert Point (smooth / corner)',()=>{const path=T.get();vec_convertPoint(path.subs[hit.sub],hit.pt);T.set(path);commit('Convert point');redraw();},!onPt);
    sep();
    add('Close Path',()=>{const s=penCur(curPath(false));if(s&&s.pts.length>2){s.closed=true;S.pen.sub=null;commit('Close path');redraw();}},!(drawing&&drawing.pts.length>2));
    add('Finish Path (open)',()=>{penFinish(false);commit('Finish path');},!drawing);
    add('Delete Last Point',()=>{const s=penCur(curPath(false));if(s){s.pts.pop();if(!s.pts.length){const P=curPath(false);P.path.subs.splice(P.path.subs.indexOf(s),1);S.pen.sub=null;}redraw();}},!drawing);
    sep();
    add('Make Selection...',()=>penSelDialog(),!has);
    add('Make Selection (quick)',()=>{pathAsSelection(S.selMode);toast('Selection made from the path');},!has);
    add('Make Layer Mask',()=>ACT.pathMask(),!has);
    add('Make Shape',()=>ACT.pathShape(),!has||shapeL);
    add('Fill Path',()=>ACT.pathFill(),!has);
    add('Stroke Path',()=>ACT.pathStroke(),!has);
    sep();
    add('Define Custom Shape...',defineCustom,!has&&!shapeL);
    add('Free Transform Path',()=>{S.pen.ftp=true;toast('Use the Path Selection tool to move the whole path. Scale with Edit > Transform on a shape layer.');setTool('psel');},!has);
    add('Delete Path',()=>{if(shapeL){toast('Delete the shape layer to remove it');return;}ACT.pathDel();},!has);
    return it;
  }
  function show(x,y,p){
    hide();const T=target();let hit=null;if(T){const [a,h,s]=tol();try{hit=vec_hitTest(T.get(),p.x,p.y,a,h,s);}catch(e){}}
    const its=items(p,hit);menu=document.createElement('div');menu.className='pctx';
    menu.innerHTML=its.map((i,n)=>i?'<button data-n="'+n+'"'+(i.dis?' disabled':'')+'>'+esc(i.label)+'</button>':'<hr>').join('');
    document.body.appendChild(menu);
    const r=menu.getBoundingClientRect();menu.style.left=Math.min(x,innerWidth-r.width-6)+'px';menu.style.top=Math.min(y,innerHeight-r.height-6)+'px';
    menu.onclick=e=>{const b=e.target.closest('button');if(!b||b.disabled)return;const i=its[+b.dataset.n];hide();try{i.fn();}catch(err){console.error(err);toast('Could not do that');}};
  }
  document.getElementById('vp').addEventListener('contextmenu',e=>{
    if(!doc||!(PEN_TOOLS.includes(S.tool)))return;
    e.preventDefault();show(e.clientX,e.clientY,toDoc(e));
  });
}
