/* ===== Camera Raw Filter: full-screen develop window ===== */
const CRPAGE='<div id="cr" hidden><div class="crtop"></div><div class="crmain"><div class="crstage"><canvas id="crc"></canvas><div class="crhint" id="crhint"></div></div><div class="crside"><div class="crhist"><canvas id="crh" width="300" height="96"></canvas><div class="crrgb" id="crrgb">R — G — B —</div><div class="crsamp" id="crsamp"></div></div><div class="crtabs" id="crtabs"></div><div class="crpanel" id="crpanel"></div></div></div><div class="crbot"></div></div>';
let CR=null;
const CRSEC=[['edit','Edit','M4 6h16M4 12h16M4 18h16'],['heal','Heal','M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z'],['mask','Masking','M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 3a6 6 0 0 1 0 12z'],['red','Red Eye','M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zm10-3a3 3 0 1 0 0 6 3 3 0 0 0 0-6z'],['snap','Snapshots','M4 7h3l2-2h6l2 2h3v12H4zm8 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z'],['pre','Presets','M4 4h7v7H4zm9 0h7v7h-7zM4 13h7v7H4zm9 0h7v7h-7z']];
function crEnsureDom(){
  if($('#cr'))return;
  document.body.insertAdjacentHTML('beforeend',CRPAGE);
  const top=$('#cr .crtop');
  const tb=(id,t,k,svg)=>'<button class="crt" data-tool="'+id+'" title="'+t+' ('+k+')"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="'+svg+'"/></svg></button>';
  top.innerHTML=
   tb('hand','Hand','H','M8 12V5a1.5 1.5 0 0 1 3 0v6m0-1V4a1.5 1.5 0 0 1 3 0v6m0-4a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-1a6 6 0 0 1-5-3l-2-4a1.5 1.5 0 0 1 2.5-1.5L8 14')+
   tb('zoom','Zoom','Z','M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zm10 17-5-5M8 11h6M11 8v6')+
   tb('wb','White balance','I','M4 20l9-9m0 0 3-3 4 4-3 3zM14 7l3 3')+
   tb('samp','Color sampler','S','M12 3v6m0 6v6M3 12h6m6 0h6M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z')+
   tb('tai','Targeted adjustment','T','M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 5v8M8 12h8')+
   '<span class="crsep"></span>'+
   '<select id="cr-tai" title="Targeted adjustment mode"><option value="h">Hue</option><option value="s">Saturation</option><option value="l">Luminance</option><option value="c">Point curve</option></select>'+
   '<span class="crsep"></span>'+
   '<button id="cr-view" title="Switch view (Q)">Single view</button><button id="cr-bef" title="Hold to see the original (\\)">Before</button>'+
   '<button id="cr-fit" title="Fit in view (Ctrl+0)">Fit</button><select id="cr-zoom"><option value="0">Fit</option><option value=".25">25%</option><option value=".5">50%</option><option value="1">100%</option><option value="2">200%</option><option value="4">400%</option></select>'+
   '<button id="cr-clipS" title="Shadow clipping (U)">&#9698; Shadows</button><button id="cr-clipH" title="Highlight clipping (O)">Highlights &#9700;</button>'+
   '<span style="flex:1"></span><button id="cr-undo" title="Undo (Ctrl+Z)">Undo</button><button id="cr-redo" title="Redo (Ctrl+Shift+Z)">Redo</button>';
  $('#cr .crbot').innerHTML='<label class="opt"><input type="checkbox" id="cr-nd"> Non-destructive (Camera Raw adjustment layer)</label><label class="opt"><input type="checkbox" id="cr-prev" checked> Preview</label><span id="cr-info" class="muted"></span><span style="flex:1"></span><button id="cr-reset">Reset</button><button id="cr-auto">Auto</button><button id="cr-cancel">Cancel</button><button id="cr-ok" class="primary">OK</button>';
  $('#crtabs').innerHTML=CRSEC.map(s=>'<button data-sec="'+s[0]+'" title="'+s[1]+'"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="'+s[2]+'"/></svg><small>'+s[1]+'</small></button>').join('');
  crWire();
}
function crSl(lbl,key,min,max,step,cls){return '<label class="crs '+(cls||'')+'"><span data-reset="'+key+'" title="Double-click to reset">'+lbl+'</span><input type="range" data-p="'+key+'" min="'+min+'" max="'+max+'" step="'+step+'"><input type="number" class="crn" data-p="'+key+'" min="'+min+'" max="'+max+'" step="'+step+'"></label>';}
function crGet(key){const i=key.indexOf(':'),sc=key.slice(0,i),k=key.slice(i+1);
  if(sc==='p')return raw_getParam(CR.st.p,k);if(sc==='para')return CR.st.para[k];if(sc==='o')return CR.opt[k];
  if(sc==='m'){const m=crSel();return m?(k==='amount'?m.amount:m.L[k]):0;}if(sc==='s'){const s=CR.sel&&CR.sel.kind==='spot'?CR.st.spots[CR.sel.i]:null;return s?s[k]:0;}if(sc==='e'){return CR.redOpt[k];}return 0;}
function crSet(key,v){const i=key.indexOf(':'),sc=key.slice(0,i),k=key.slice(i+1);
  if(sc==='p')raw_setParam(CR.st.p,k,v);else if(sc==='para')CR.st.para[k]=v;else if(sc==='o')CR.opt[k]=v;
  else if(sc==='m'){const m=crSel();if(m){if(k==='amount')m.amount=v;else m.L[k]=v;CR.maskDirty=true;}}
  else if(sc==='s'){const s=CR.sel&&CR.sel.kind==='spot'?CR.st.spots[CR.sel.i]:null;if(s)s[k]=v;}else if(sc==='e')CR.redOpt[k]=v;}
function crSel(){return CR&&CR.selMask!=null?CR.st.masks[CR.selMask]:null;}
function crDefault(key){const i=key.indexOf(':'),sc=key.slice(0,i),k=key.slice(i+1);if(sc==='p')return raw_getParam(raw_mkDefaults(),k);if(sc==='m')return k==='amount'?100:0;if(sc==='para')return 0;return undefined;}
/* ---------- panels ---------- */
function crPanelEdit(){
  const P=CR.st.p,o=CR.open;
  const det=(id,t,body)=>'<details data-d="'+id+'"'+(o[id]?' open':'')+'><summary>'+t+'</summary><div class="crbody">'+body+'</div></details>';
  const bands=RAW_BANDS,mode=CR.hslMode;
  const hsl=(k,lab)=>bands.map(b=>crSl(b[0].toUpperCase()+b.slice(1),'p:hsl.'+b+'.'+k,-100,100,1,'band-'+b)).join('');
  return '<div class="crcols">'+
   det('basic','Basic','<div class="crrow"><b>Treatment</b><label><input type="radio" name="crtr" value="c"'+(P.bw?'':' checked')+'> Color</label><label><input type="radio" name="crtr" value="b"'+(P.bw?' checked':'')+'> Black &amp; White</label></div>'+
     '<div class="crrow"><b>Profile</b><select id="cr-prof">'+Object.keys(CR_PROFILES).map(k=>'<option'+(CR.st.profile===k?' selected':'')+'>'+k+'</option>').join('')+'</select></div>'+
     '<div class="crrow"><b>WB</b><select id="cr-wb">'+Object.keys(CR_WB).concat(['Custom']).map(k=>'<option'+(CR.st.wb===k?' selected':'')+'>'+k+'</option>').join('')+'</select><button id="cr-wbpick" title="White balance tool">Pick</button></div>'+
     crSl('Temp','p:temp',-100,100,1,'tmp')+crSl('Tint','p:tint',-100,100,1,'tnt')+'<div class="crhr"></div>'+
     crSl('Exposure','p:exposure',-5,5,0.05)+crSl('Contrast','p:contrast',-100,100,1)+crSl('Highlights','p:highlights',-100,100,1)+crSl('Shadows','p:shadows',-100,100,1)+crSl('Whites','p:whites',-100,100,1)+crSl('Blacks','p:blacks',-100,100,1)+'<div class="crhr"></div>'+
     crSl('Texture','p:texture',-100,100,1)+crSl('Clarity','p:clarity',-100,100,1)+crSl('Dehaze','p:dehaze',-100,100,1)+crSl('Vibrance','p:vibrance',-100,100,1)+crSl('Saturation','p:saturation',-100,100,1))+
   det('curve','Tone Curve','<div class="crrow"><b>Curve</b><select id="cr-cch"><option value="curve">RGB</option><option value="curveR">Red</option><option value="curveG">Green</option><option value="curveB">Blue</option></select><button id="cr-creset">Reset curve</button></div><canvas id="cr-curve" width="260" height="260"></canvas><div class="crhr"></div><b class="muted">Parametric</b>'+
     crSl('Highlights','para:hi',-100,100,1)+crSl('Lights','para:li',-100,100,1)+crSl('Darks','para:da',-100,100,1)+crSl('Shadows','para:sh',-100,100,1))+
   det('detail','Detail','<b>Sharpening</b>'+crSl('Amount','p:sharpen',0,150,1)+crSl('Radius','p:sharpenRadius',5,30,1)+crSl('Masking','p:masking',0,100,1)+'<div class="crhr"></div><b>Noise reduction</b>'+crSl('Luminance','p:nrLum',0,100,1)+crSl('Color','p:nrColor',0,100,1))+
   det('mixer','Color Mixer','<div class="crtabs2" id="cr-hm">'+[['h','Hue'],['s','Saturation'],['l','Luminance']].map(a=>'<button data-hm="'+a[0]+'"'+(mode===a[0]?' class="on"':'')+'>'+a[1]+'</button>').join('')+'<button data-hm="a"'+(mode==='a'?' class="on"':'')+'>All</button></div>'+
     (mode==='a'?'<b class="muted">Hue</b>'+hsl('h')+'<b class="muted">Saturation</b>'+hsl('s')+'<b class="muted">Luminance</b>'+hsl('l'):hsl(mode)))+
   det('grade','Color Grading','<div class="crwheels">'+['shadows','mids','highs'].map(z=>'<div><canvas class="crwheel" data-z="'+z+'" width="100" height="100"></canvas><small>'+({shadows:'Shadows',mids:'Midtones',highs:'Highlights'})[z]+'</small></div>').join('')+'</div>'+
     ['shadows','mids','highs'].map(z=>crSl(({shadows:'Shadow lum',mids:'Mid lum',highs:'Highlight lum'})[z],'p:grade.'+z+'.l',-100,100,1)).join('')+crSl('Blending','p:grade.blend',0,100,1)+crSl('Balance','p:grade.balance',-100,100,1))+
   det('optics','Optics','<label class="opt"><input type="checkbox" id="cr-ca"'+(P.caFix?' checked':'')+'> Remove chromatic aberration</label>'+crSl('Distortion','p:lensCorr',-100,100,1)+'<p class="muted">Lens profiles are not included, so distortion is a manual slider.</p>')+
   det('fx','Effects','<b>Grain</b>'+crSl('Amount','p:grain',0,100,1)+crSl('Size','p:grainSize',0,100,1)+'<div class="crhr"></div><b>Post-crop vignetting</b>'+crSl('Amount','p:vignette',-100,100,1)+crSl('Midpoint','p:vigMid',0,100,1)+crSl('Feather','p:vigFeather',0,100,1))+
   '</div>';
}
function crPanelMask(){
  const m=crSel(),o=CR.opt;
  let h='<div class="crrow crtools2">'+[['brush','Brush'],['linear','Linear Gradient'],['radial','Radial Gradient']].map(t=>'<button data-mt="'+t[0]+'"'+(CR.tool===t[0]?' class="on"':'')+'>'+t[1]+'</button>').join('')+'</div>';
  if(CR.tool==='brush'||(m&&m.type==='brush'))h+='<div class="crbody">'+crSl('Size','o:size',1,50,0.5)+crSl('Feather','o:feather',0,100,1)+crSl('Flow','o:flow',1,100,1)+'<label class="opt"><input type="checkbox" id="cr-auto2"'+(o.auto?' checked':'')+'> Auto mask</label><label class="opt"><input type="checkbox" id="cr-erase"'+(o.erase?' checked':'')+'> Erase</label></div>';
  h+='<div class="crhr"></div><b>Masks</b><div class="crmasks">'+(CR.st.masks.length?CR.st.masks.map((mk,i)=>'<div class="crmk'+(i===CR.selMask?' on':'')+'" data-mk="'+i+'"><span>'+esc(mk.name||('Mask '+(i+1)))+' <small class="muted">'+mk.type+'</small></span><button data-mkov="'+i+'" title="Show overlay">&#9681;</button><button data-mkinv="'+i+'" title="Invert">&#8644;</button><button data-mkdel="'+i+'" title="Delete">&times;</button></div>').join(''):'<p class="muted">No masks yet. Pick a tool, then drag on the picture.</p>')+'</div>';
  if(m)h+='<div class="crhr"></div><div class="crrow"><label class="opt"><input type="checkbox" id="cr-ov"'+(CR.overlay?' checked':'')+'> Show overlay</label></div>'+crSl('Amount','m:amount',0,100,1)+'<div class="crhr"></div>'+CR_LOCAL_KEYS.map(k=>crSl(k[1],'m:'+k[0],k[2],k[3],k[4])).join('');
  return h;
}
function crPanelHeal(){
  const o=CR.opt,s=CR.sel&&CR.sel.kind==='spot'?CR.st.spots[CR.sel.i]:null;
  return '<div class="crrow"><button data-hmode="heal"'+(o.hmode==='heal'?' class="on"':'')+'>Heal</button><button data-hmode="clone"'+(o.hmode==='clone'?' class="on"':'')+'>Clone</button></div>'+
   crSl('Size','o:hsize',0.3,8,0.1)+crSl('Feather','o:hfeather',0,100,1)+crSl('Opacity','o:hop',1,100,1)+
   '<p class="muted">Click a blemish to remove it. A source circle is chosen for you; drag it to pick another spot.</p><div class="crrow"><button id="cr-delspot"'+(s?'':' disabled')+'>Delete selected</button><button id="cr-clrspots"'+(CR.st.spots.length?'':' disabled')+'>Clear all ('+CR.st.spots.length+')</button></div>';
}
function crPanelRed(){return crSl('Pupil size','e:size',0.3,6,0.1)+crSl('Darken','e:dark',0,100,1)+'<p class="muted">Click on a red pupil.</p><div class="crrow"><button id="cr-clrred"'+(CR.st.reds.length?'':' disabled')+'>Clear all ('+CR.st.reds.length+')</button></div>';}
function crPanelSnap(){return '<div class="crrow"><button id="cr-snapnew" class="primary">New snapshot</button></div><div class="crmasks">'+(CR.st.snaps.length?CR.st.snaps.map((s,i)=>'<div class="crmk" data-snap="'+i+'"><span>'+esc(s.name)+'</span><button data-snapdel="'+i+'">&times;</button></div>').join(''):'<p class="muted">Snapshots save the current settings so you can come back to them.</p>')+'</div>';}
function crPanelPre(){
  const up=crUserPresets();
  const card=(id,n,u)=>'<div class="crpre" data-pre="'+id+'"><canvas width="96" height="72"></canvas><span>'+esc(n)+'</span>'+(u?'<button data-predel="'+id+'">&times;</button>':'')+'</div>';
  return crSl('Amount','o:pamt',0,150,1)+'<div class="crrow"><button id="cr-presave">Save current as preset...</button></div><div class="crgrid">'+RAW_PRESETS.map(p=>card('b:'+p.id,p.name)).join('')+up.map((p,i)=>card('u:'+i,p.name,1)).join('')+'</div>';
}
function crUserPresets(){try{return JSON.parse(localStorage.getItem('lk_crpresets')||'[]');}catch(e){return [];}}
function crSaveUserPresets(a){try{localStorage.setItem('lk_crpresets',JSON.stringify(a));}catch(e){toast('Could not save preset');}}
function crRenderPanel(){
  const sec=CR.sec,pn=$('#crpanel');
  [...document.querySelectorAll('#crtabs button')].forEach(b=>b.classList.toggle('on',b.dataset.sec===sec));
  pn.innerHTML=({edit:crPanelEdit,mask:crPanelMask,heal:crPanelHeal,red:crPanelRed,snap:crPanelSnap,pre:crPanelPre})[sec]();
  crSync();crDrawCurve();crDrawWheels();
  if(sec==='pre')crPresetThumbs();
  if(sec==='heal'&&!['heal','clone'].includes(CR.tool))crSetTool('heal');
  else if(sec==='red')crSetTool('red');
  else if(sec==='mask'&&!['brush','linear','radial'].includes(CR.tool))crSetTool('brush');
  else if(sec==='edit'&&['brush','linear','radial','heal','clone','red'].includes(CR.tool))crSetTool('hand');
  else if(sec==='snap'||sec==='pre'){if(['brush','linear','radial','heal','clone','red'].includes(CR.tool))crSetTool('hand');}
}
function crSync(){
  document.querySelectorAll('#crpanel [data-p]').forEach(el=>{const v=crGet(el.dataset.p);if(v==null)return;if(el!==document.activeElement)el.value=(+v).toFixed(el.step&&el.step<1?2:0).replace(/\.00$/,'').replace(/(\.\d)0$/,'$1');});
  document.querySelectorAll('#crpanel input[type=range][data-p]').forEach(el=>{const v=crGet(el.dataset.p);if(v!=null)el.value=v;});
  const t=$('#cr-wb');if(t)t.value=CR.st.wb;
}
/* ---------- curve editor ---------- */
function crCurvePts(){const k=CR.cch||'curve';return CR.st.p[k]||[[0,0],[255,255]];}
function crDrawCurve(){
  const c=$('#cr-curve');if(!c)return;const x=c.getContext('2d'),W=c.width,H=c.height;x.clearRect(0,0,W,H);x.fillStyle='#1b1b1b';x.fillRect(0,0,W,H);
  x.strokeStyle='#333';x.lineWidth=1;for(let i=1;i<4;i++){x.beginPath();x.moveTo(i*W/4,0);x.lineTo(i*W/4,H);x.moveTo(0,i*H/4);x.lineTo(W,i*H/4);x.stroke();}
  const h=raw_histogram(CR.prevIn);x.globalAlpha=.35;x.fillStyle='#888';for(let i=0;i<256;i++){const v=Math.min(1,h.l[i]/h.max)*H;x.fillRect(i*W/256,H-v,W/256+1,v);}x.globalAlpha=1;
  const pts=crCurvePts(),L=raw_curveLUT(pts),col={curve:'#ddd',curveR:'#f55',curveG:'#5d5',curveB:'#58f'}[CR.cch||'curve'];
  x.strokeStyle=col;x.lineWidth=2;x.beginPath();for(let i=0;i<=255;i++){const y=raw_lutAt(L,i/255);if(!i)x.moveTo(i*W/255,H-y*H);else x.lineTo(i*W/255,H-y*H);}x.stroke();
  x.fillStyle='#fff';x.strokeStyle='#000';pts.forEach(q=>{x.beginPath();x.arc(q[0]/255*W,H-q[1]/255*H,4.5,0,7);x.fill();x.stroke();});
}
function crCurveDown(e){
  const c=e.target,r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*255,py=255-(e.clientY-r.top)/r.height*255,k=CR.cch||'curve';
  let pts=crCurvePts().map(q=>q.slice()),hit=-1;
  pts.forEach((q,i)=>{if(Math.hypot(q[0]-px,q[1]-py)<14)hit=i;});
  if(hit<0){pts.push([Math.max(0,Math.min(255,px)),Math.max(0,Math.min(255,py))]);pts.sort((a,b)=>a[0]-b[0]);hit=pts.findIndex(q=>q[0]===Math.max(0,Math.min(255,px)));}
  CR.st.p[k]=pts;CR.cdrag=hit;c.setPointerCapture(e.pointerId);crDrawCurve();crQueue();
}
function crCurveMove(e){
  if(CR.cdrag==null)return;const c=e.target,r=c.getBoundingClientRect(),k=CR.cch||'curve',pts=CR.st.p[k];
  let px=(e.clientX-r.left)/r.width*255,py=255-(e.clientY-r.top)/r.height*255;py=Math.max(0,Math.min(255,py));px=Math.max(0,Math.min(255,px));
  const i=CR.cdrag,lo=i>0?pts[i-1][0]+1:0,hi=i<pts.length-1?pts[i+1][0]-1:255;
  pts[i]=[Math.max(lo,Math.min(hi,px)),py];crDrawCurve();crQueue();
}
function crCurveUp(){if(CR.cdrag==null)return;CR.cdrag=null;const k=CR.cch||'curve',p=CR.st.p[k];if(p&&p.length===2&&p[0][0]===0&&p[0][1]===0&&p[1][0]===255&&p[1][1]===255)CR.st.p[k]=null;crPush();}
function crCurveDbl(e){const c=e.target,r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*255,py=255-(e.clientY-r.top)/r.height*255,k=CR.cch||'curve',pts=crCurvePts();
  const i=pts.findIndex(q=>Math.hypot(q[0]-px,q[1]-py)<14);if(i>0&&i<pts.length-1){pts.splice(i,1);CR.st.p[k]=pts;crDrawCurve();crQueue();crPush();}}
/* ---------- colour wheels ---------- */
function crDrawWheels(){
  document.querySelectorAll('.crwheel').forEach(c=>{const x=c.getContext('2d'),W=c.width,R=W/2-3,g=CR.st.p.grade[c.dataset.z];
    const img=x.createImageData(W,W);for(let y=0;y<W;y++)for(let xx=0;xx<W;xx++){const dx=xx-W/2,dy=y-W/2,d=Math.hypot(dx,dy);if(d>R)continue;const h=(Math.atan2(dy,dx)*180/Math.PI+360)%360,rgb=hsl2rgbCR(h,d/R*0.9,0.5),j=(y*W+xx)*4;img.data[j]=rgb[0];img.data[j+1]=rgb[1];img.data[j+2]=rgb[2];img.data[j+3]=255;}
    x.clearRect(0,0,W,W);x.putImageData(img,0,0);
    const a=g.h*Math.PI/180,r=g.s/100*R;x.strokeStyle='#000';x.fillStyle='#fff';x.lineWidth=1.5;x.beginPath();x.arc(W/2+Math.cos(a)*r,W/2+Math.sin(a)*r,5,0,7);x.fill();x.stroke();});
}
function hsl2rgbCR(h,s,l){const a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return l-a*Math.max(-1,Math.min(k-3,9-k,1));};return [f(0)*255,f(8)*255,f(4)*255];}
function crWheelSet(e){const c=e.target,r=c.getBoundingClientRect(),W=c.width,sx=c.width/r.width,dx=(e.clientX-r.left)*sx-W/2,dy=(e.clientY-r.top)*sx-W/2,R=W/2-3,g=CR.st.p.grade[c.dataset.z];
  g.h=Math.round((Math.atan2(dy,dx)*180/Math.PI+360)%360);g.s=Math.round(Math.min(1,Math.hypot(dx,dy)/R)*100);crDrawWheels();crQueue();}
/* ---------- rendering ---------- */
function crQueue(){if(CR.q)return;CR.q=true;requestAnimationFrame(()=>{CR.q=false;crRender();});}
function crRender(){
  if(!CR)return;
  const t0=performance.now();
  CR.out=$('#cr-prev').checked?crDevelop(CR.prevIn,CR.st,CR.pscale):CR.prevIn;
  CR.ms=performance.now()-t0;
  CR.outC=crToCanvas(CR.out);
  crDraw();crHist();
  if(CR.sec==='edit'&&CR.cdrag==null)crDrawCurve();
}
function crToCanvas(img){const c=mkCanvas(img.width,img.height);cctx(c).putImageData(img,0,0);return c;}
function crFit(){const s=$('#cr .crstage');const W=s.clientWidth,H=s.clientHeight;return Math.min(W/CR.pw,H/CR.ph)*0.97;}
function crView(){const s=$('#cr .crstage'),W=s.clientWidth,H=s.clientHeight,z=CR.zoom||crFit();return {W,H,z,x:W/2-CR.cx*z,y:H/2-CR.cy*z};}
function crToImg(e){const r=$('#crc').getBoundingClientRect(),v=crView();return [(e.clientX-r.left-v.x)/v.z,(e.clientY-r.top-v.y)/v.z];}
function crDraw(){
  if(!CR||!CR.outC)return;
  const cv=$('#crc'),s=$('#cr .crstage'),W=s.clientWidth,H=s.clientHeight,dpr=1;
  if(cv.width!==W||cv.height!==H){cv.width=W;cv.height=H;}
  const x=cv.getContext('2d');x.fillStyle='#262626';x.fillRect(0,0,W,H);x.imageSmoothingEnabled=CR.zoom>=2?false:true;
  const v=crView(),after=CR.outC,bef=CR.befC,mode=CR.vmode;
  const draw=(c,rx,ry,rw,rh,clipx)=>{x.save();x.beginPath();x.rect(rx,ry,rw,rh);x.clip();x.drawImage(c,v.x,v.y,CR.pw*v.z,CR.ph*v.z);x.restore();};
  const showBef=CR.holdBefore;
  if(mode===0||mode>3)draw(showBef?bef:after,0,0,W,H);
  else if(mode===2){draw(bef,0,0,W/2,H);draw(after,W/2,0,W/2,H);x.fillStyle='#fff';x.fillRect(W/2-1,0,2,H);x.fillStyle='#000a';x.fillText('Before',8,16);x.fillText('After',W/2+8,16);}
  else if(mode===3){draw(bef,0,0,W,H/2);draw(after,0,H/2,W,H/2);x.fillStyle='#fff';x.fillRect(0,H/2-1,W,2);}
  else if(mode===1){ // side by side, each fitted to its half
    const z=Math.min(W/2/CR.pw,H/CR.ph)*0.96,ox=(W/2-CR.pw*z)/2,oy=(H-CR.ph*z)/2;
    x.drawImage(bef,ox,oy,CR.pw*z,CR.ph*z);x.drawImage(after,W/2+ox,oy,CR.pw*z,CR.ph*z);x.fillStyle='#fff';x.fillRect(W/2-1,0,2,H);
    x.fillStyle='#fff';x.font='12px sans-serif';x.fillText('Before',8,16);x.fillText('After',W/2+8,16);crOverlay(x,{x:W/2+ox,y:oy,z});return;}
  if(CR.clipS||CR.clipH){
    const d=CR.out.data,oc=mkCanvas(CR.pw,CR.ph),ox=cctx(oc),im=ox.createImageData(CR.pw,CR.ph),o=im.data;
    for(let i=0;i<d.length;i+=4){const mx=Math.max(d[i],d[i+1],d[i+2]),mn=Math.min(d[i],d[i+1],d[i+2]);
      if(CR.clipH&&mn>=250){o[i]=255;o[i+1]=40;o[i+2]=40;o[i+3]=255;}else if(CR.clipS&&mx<=4){o[i]=40;o[i+1]=90;o[i+2]=255;o[i+3]=255;}}
    ox.putImageData(im,0,0);x.drawImage(oc,v.x,v.y,CR.pw*v.z,CR.ph*v.z);}
  crOverlay(x,v);
  $('#cr-info').textContent=Math.round(v.z*100)+'%  ·  preview '+CR.pw+'×'+CR.ph+(CR.ms?'  ·  '+Math.round(CR.ms)+' ms':'');
}
function crOverlay(x,v){
  const m=crSel();
  if(m&&(CR.overlay||CR.painting)){
    if(!CR.ovC||CR.maskDirty){CR.maskDirty=false;const md=crMaskData(m,CR.pw,CR.ph,CR.prevIn),c=mkCanvas(CR.pw,CR.ph),cx=cctx(c),im=cx.createImageData(CR.pw,CR.ph);for(let i=0;i<md.length;i++){const a=md[i];im.data[i*4]=255;im.data[i*4+1]=30;im.data[i*4+2]=30;im.data[i*4+3]=a*150;}cx.putImageData(im,0,0);CR.ovC=c;}
    x.drawImage(CR.ovC,v.x,v.y,CR.pw*v.z,CR.ph*v.z);
  }
  const P=(nx,ny)=>[v.x+nx*CR.pw*v.z,v.y+ny*CR.ph*v.z];
  x.lineWidth=1.5;x.font='11px sans-serif';
  const ring=(cx,cy,r,col,dash)=>{x.strokeStyle='#000';x.lineWidth=3;x.setLineDash(dash||[]);x.beginPath();x.arc(cx,cy,r,0,7);x.stroke();x.strokeStyle=col;x.lineWidth=1.5;x.beginPath();x.arc(cx,cy,r,0,7);x.stroke();x.setLineDash([]);};
  const pin=(cx,cy,on)=>{x.fillStyle=on?'#2d8ceb':'#fff';x.strokeStyle='#000';x.lineWidth=1.5;x.beginPath();x.arc(cx,cy,6,0,7);x.fill();x.stroke();};
  if(CR.sec==='heal'||CR.tool==='heal'||CR.tool==='clone')CR.st.spots.forEach((s,i)=>{const [a,b]=P(s.x,s.y),r=s.r*CR.pw*v.z,on=CR.sel&&CR.sel.kind==='spot'&&CR.sel.i===i;ring(a,b,Math.max(4,r),on?'#fff':'#bbb');if(on){const [c,d]=P(s.sx,s.sy);ring(c,d,Math.max(4,r),'#4af',[5,4]);x.strokeStyle='#4af';x.beginPath();x.moveTo(a,b);x.lineTo(c,d);x.stroke();}});
  if(CR.sec==='red')CR.st.reds.forEach(e=>{const [a,b]=P(e.x,e.y);ring(a,b,Math.max(4,e.r*CR.pw*v.z),'#f66');});
  if(CR.sec==='mask'||CR.tool==='linear'||CR.tool==='radial'||CR.tool==='brush'){
    CR.st.masks.forEach((mk,i)=>{const on=i===CR.selMask;
      if(mk.type==='linear'){const a=P(mk.x1,mk.y1),b=P(mk.x2,mk.y2);x.strokeStyle=on?'#fff':'#999';x.lineWidth=on?2:1;x.beginPath();x.moveTo(a[0],a[1]);x.lineTo(b[0],b[1]);x.stroke();pin(a[0],a[1],on);pin(b[0],b[1],on);}
      else if(mk.type==='radial'){const c=P(mk.cx,mk.cy);ring(c[0],c[1],1,'#fff');x.save();x.translate(c[0],c[1]);x.strokeStyle=on?'#fff':'#999';x.lineWidth=on?2:1;x.beginPath();x.ellipse(0,0,mk.rx*CR.pw*v.z,mk.ry*CR.pw*v.z,0,0,7);x.stroke();x.restore();pin(c[0],c[1],on);if(on)pin(c[0]+mk.rx*CR.pw*v.z,c[1],true);}
      else if(mk.strokes.length&&mk.strokes[0].pts.length){const q=mk.strokes[0].pts[0],c=P(q[0],q[1]);pin(c[0],c[1],on);}
    });
    if(CR.tool==='brush'&&CR.mouse){const r=CR.opt.size/200*CR.pw*v.z;ring(CR.mouse[0],CR.mouse[1],Math.max(3,r),'#fff');}
  }
  CR.samplers.forEach((q,i)=>{const [a,b]=P(q[0],q[1]);x.strokeStyle='#000';x.lineWidth=3;x.beginPath();x.moveTo(a-7,b);x.lineTo(a+7,b);x.moveTo(a,b-7);x.lineTo(a,b+7);x.stroke();x.strokeStyle='#fff';x.lineWidth=1;x.stroke();x.fillStyle='#fff';x.fillText(String(i+1),a+8,b-6);});
  if(CR.tool==='tai'&&CR.taiPin){const [a,b]=P(CR.taiPin[0],CR.taiPin[1]);pin(a,b,true);}
}
function crHist(){
  const c=$('#crh'),x=c.getContext('2d');x.clearRect(0,0,c.width,c.height);x.fillStyle='#1b1b1b';x.fillRect(0,0,c.width,c.height);
  raw_drawHistogram(x,raw_histogram(CR.out),c.width,c.height);
  x.fillStyle=CR.clipS?'#58f':'#777';x.beginPath();x.moveTo(3,3);x.lineTo(15,3);x.lineTo(3,15);x.fill();
  x.fillStyle=CR.clipH?'#f55':'#777';x.beginPath();x.moveTo(c.width-3,3);x.lineTo(c.width-15,3);x.lineTo(c.width-3,15);x.fill();
}
function crReadout(e){
  const [ix,iy]=crToImg(e),X=Math.round(ix),Y=Math.round(iy);
  if(X<0||Y<0||X>=CR.pw||Y>=CR.ph){$('#crrgb').textContent='R — G — B —';return;}
  const j=(Y*CR.pw+X)*4,d=CR.out.data;$('#crrgb').textContent='R '+d[j]+'   G '+d[j+1]+'   B '+d[j+2];
}
function crSamplerList(){$('#crsamp').innerHTML=CR.samplers.map((q,i)=>{const X=Math.round(q[0]*CR.pw),Y=Math.round(q[1]*CR.ph),j=(Math.min(CR.ph-1,Y)*CR.pw+Math.min(CR.pw-1,X))*4,d=CR.out.data;return '<span>#'+(i+1)+' '+d[j]+' '+d[j+1]+' '+d[j+2]+'</span>';}).join('');}
/* ---------- undo, snapshots, tools ---------- */
function crPush(){const s=JSON.stringify(CR.st);if(CR.hist[CR.hi]===s)return;CR.hist=CR.hist.slice(0,CR.hi+1);CR.hist.push(s);if(CR.hist.length>80)CR.hist.shift();CR.hi=CR.hist.length-1;crBtns();}
function crUndo(d){const n=CR.hi+d;if(n<0||n>=CR.hist.length)return;CR.hi=n;CR.st=JSON.parse(CR.hist[n]);if(CR.selMask!=null&&CR.selMask>=CR.st.masks.length)CR.selMask=null;CR.maskDirty=true;crRenderPanel();crQueue();crBtns();}
function crBtns(){$('#cr-undo').disabled=CR.hi<=0;$('#cr-redo').disabled=CR.hi>=CR.hist.length-1;}
function crSetTool(t){CR.tool=t;document.querySelectorAll('#cr .crt').forEach(b=>b.classList.toggle('on',b.dataset.tool===t));
  const hints={hand:'Drag to pan. Scroll to zoom.',zoom:'Click to zoom in, Alt+click to zoom out.',wb:'Click on something that should be neutral grey or white.',samp:'Click to drop colour samplers (up to 9).',tai:'Drag up or down on the picture to change the colour or tone under the cursor.',brush:'Paint the area to adjust. Hold Alt to erase.',linear:'Drag to place a linear gradient.',radial:'Drag from the centre outwards.',heal:'Click a blemish to remove it.',clone:'Click a spot to clone over it.',red:'Click on a red pupil.'};
  $('#crhint').textContent=hints[t]||'';
  $('#crc').style.cursor=({hand:'grab',zoom:'zoom-in',wb:'crosshair',samp:'crosshair',tai:'crosshair',brush:'none',linear:'crosshair',radial:'crosshair',heal:'crosshair',clone:'crosshair',red:'crosshair'})[t]||'default';
  if(t==='heal'||t==='clone'){CR.opt.hmode=t==='clone'?'clone':CR.opt.hmode;}
  crDraw();
}
function crSetView(m){CR.vmode=m;$('#cr-view').textContent=['Single view','Side by side','Split (left/right)','Top / bottom'][m];crDraw();}
function crApplyWB(rgb){const [t,ti]=crSolveWB(rgb);CR.st.p.temp=t;CR.st.p.tint=ti;CR.st.wb='Custom';crSync();crQueue();crPush();}
/* ---------- presets ---------- */
function crLerp(def,pre,a){
  if(typeof pre==='number'&&typeof def==='number')return def+(pre-def)*a;
  if(Array.isArray(pre)||pre===null||typeof pre!=='object'||typeof pre==='boolean')return (typeof pre==='boolean')?(a>0.5?pre:def):(Array.isArray(pre)?(a>0.5?pre:def):pre);
  const o={};for(const k in pre)o[k]=crLerp(def?def[k]:undefined,pre[k],a);return o;
}
function crPresetP(id){let p;if(id.startsWith('b:')){const f=RAW_PRESETS.find(x=>x.id===id.slice(2));p=f&&f.p;}else{const f=crUserPresets()[+id.slice(2)];p=f&&f.p;}return p;}
function crApplyPreset(id){
  const pp=crPresetP(id);if(!pp)return;const full=raw_params(pp),def=raw_mkDefaults(),a=CR.opt.pamt/100;
  const base=CR.st.p;const np=crLerp(def,full,a);CR.st.p=raw_params(np);
  CR.st.p.bw=full.bw;CR.st.wb='As Shot';crRenderPanel();crQueue();crPush();
}
function crPresetThumbs(){
  const src=mkCanvas(96,72),sx=cctx(src);sx.drawImage(CR.befC,0,0,96,72);const base=sx.getImageData(0,0,96,72);
  document.querySelectorAll('#crpanel .crpre').forEach(el=>{const pp=crPresetP(el.dataset.pre);if(!pp)return;const out=raw_process(base,raw_params(pp),{scale:96/doc.w});el.querySelector('canvas').getContext('2d').putImageData(out,0,0);});
}
