/* ===== Mockup Batch (built-in plugin): put many artworks into many PSD mockup templates ===== */
const MB={mockups:[],art:[],outDir:null,busy:false,cancel:false,set:{name:'@artwork',place:'stretch',fmt:'png',q:92,struct:'flat',suffix:false,scale:100}};
const MB_IMG=/\.(png|jpe?g|webp|gif|bmp|avif)$/i,MB_PSD=/\.psd$/i;
const mbHasDir=()=>typeof window.showDirectoryPicker==='function';
async function mbListDir(dir,rx){const out=[];for await(const [name,h] of dir.entries()){if(h.kind==='file'&&rx.test(name))out.push({name,get:()=>h.getFile()});}out.sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}));return out;}
const mbFiles=list=>[...list].filter(f=>f).map(f=>({name:f.name,get:async()=>f})).sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}));
/* ---- geometry: find the four corners of the smart-object shape, then warp the artwork onto them ---- */
function mbQuad(cv,mask){
  const w=cv.width,h=cv.height,d=cctx(cv).getImageData(0,0,w,h).data;let md=null;
  if(mask){md=cctx(mask).getImageData(0,0,mask.width,mask.height).data;}
  let tl=null,tr=null,br=null,bl=null,a1=1e9,a2=-1e9,b1=-1e9,b2=1e9,cnt=0,x0=w,y0=h,x1=-1,y1=-1;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;let al=d[i+3];if(md)al=al*md[i+3]/255;if(al<128)continue;cnt++;
    if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;
    const s=x+y,df=x-y;
    if(s<a1){a1=s;tl=[x,y];}if(s>a2){a2=s;br=[x,y];}if(df>b1){b1=df;tr=[x,y];}if(df<b2){b2=df;bl=[x,y];}}
  if(!cnt)return null;
  const bw=x1-x0+1,bh=y1-y0+1;
  if(cnt/(bw*bh)>0.985)return {rect:true,q:[[x0,y0],[x1+1,y0],[x1+1,y1+1],[x0,y1+1]],bw,bh};
  const q=[tl,tr,br,bl];
  // a little outward so the picture reaches the true edge
  return {rect:false,q,bw,bh};
}
function mbHomog(q){ // unit square -> quad
  const [p0,p1,p2,p3]=q,dx1=p1[0]-p2[0],dx2=p3[0]-p2[0],dx3=p0[0]-p1[0]+p2[0]-p3[0],dy1=p1[1]-p2[1],dy2=p3[1]-p2[1],dy3=p0[1]-p1[1]+p2[1]-p3[1];
  let g,hh;const den=dx1*dy2-dx2*dy1;
  if(Math.abs(dx3)<1e-9&&Math.abs(dy3)<1e-9){g=0;hh=0;}else{g=(dx3*dy2-dx2*dy3)/den;hh=(dx1*dy3-dx3*dy1)/den;}
  const a=p1[0]-p0[0]+g*p1[0],b=p3[0]-p0[0]+hh*p3[0],c=p0[0],d=p1[1]-p0[1]+g*p1[1],e=p3[1]-p0[1]+hh*p3[1],f=p0[1];
  return (u,v)=>{const w=g*u+hh*v+1;return [(a*u+b*v+c)/w,(d*u+e*v+f)/w];};
}
function mbTri(ctx,img,s0,s1,s2,d0,d1,d2){
  const cx=(d0[0]+d1[0]+d2[0])/3,cy=(d0[1]+d1[1]+d2[1])/3,gro=p=>{const vx=p[0]-cx,vy=p[1]-cy,l=Math.hypot(vx,vy)||1;return [p[0]+vx/l*0.7,p[1]+vy/l*0.7];};
  const e0=gro(d0),e1=gro(d1),e2=gro(d2);
  const den=(s0[0]*(s1[1]-s2[1])+s1[0]*(s2[1]-s0[1])+s2[0]*(s0[1]-s1[1]));if(Math.abs(den)<1e-9)return;
  const a=(d0[0]*(s1[1]-s2[1])+d1[0]*(s2[1]-s0[1])+d2[0]*(s0[1]-s1[1]))/den,
        b=(d0[1]*(s1[1]-s2[1])+d1[1]*(s2[1]-s0[1])+d2[1]*(s0[1]-s1[1]))/den,
        c=(d0[0]*(s2[0]-s1[0])+d1[0]*(s0[0]-s2[0])+d2[0]*(s1[0]-s0[0]))/den,
        d=(d0[1]*(s2[0]-s1[0])+d1[1]*(s0[0]-s2[0])+d2[1]*(s1[0]-s0[0]))/den,
        e=(d0[0]*(s1[0]*s2[1]-s2[0]*s1[1])+d1[0]*(s2[0]*s0[1]-s0[0]*s2[1])+d2[0]*(s0[0]*s1[1]-s1[0]*s0[1]))/den,
        f=(d0[1]*(s1[0]*s2[1]-s2[0]*s1[1])+d1[1]*(s2[0]*s0[1]-s0[0]*s2[1])+d2[1]*(s0[0]*s1[1]-s1[0]*s0[1]))/den;
  ctx.save();ctx.beginPath();ctx.moveTo(e0[0],e0[1]);ctx.lineTo(e1[0],e1[1]);ctx.lineTo(e2[0],e2[1]);ctx.closePath();ctx.clip();
  ctx.setTransform(a,b,c,d,e,f);ctx.drawImage(img,0,0);ctx.restore();
}
/* draw the artwork on a flat "unit" canvas using the placement method */
function mbPlace(art,W,H,method){
  const c=mkCanvas(W,H),x=cctx(c);x.imageSmoothingQuality='high';
  const aw=art.width,ah=art.height;let dw,dh;
  if(method==='stretch'){dw=W;dh=H;}
  else if(method==='fit'){const k=Math.min(W/aw,H/ah);dw=aw*k;dh=ah*k;}
  else if(method==='fill'){const k=Math.max(W/aw,H/ah);dw=aw*k;dh=ah*k;}
  else{dw=aw;dh=ah;} // center: as it is
  x.drawImage(art,(W-dw)/2,(H-dh)/2,dw,dh);return c;
}
function mbReplace(target,geo,art,method){
  const cv=target.canvas,out=mkCanvas(cv.width,cv.height),x=cctx(out);x.imageSmoothingQuality='high';
  const q=geo.q,len=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
  let W=Math.round((len(q[0],q[1])+len(q[3],q[2]))/2),H=Math.round((len(q[0],q[3])+len(q[1],q[2]))/2);
  const mx=Math.max(W,H);if(mx>3000){const k=3000/mx;W=Math.round(W*k);H=Math.round(H*k);}
  W=Math.max(2,W);H=Math.max(2,H);
  const flat=mbPlace(art,W,H,method);
  if(geo.rect){x.drawImage(flat,q[0][0],q[0][1],q[1][0]-q[0][0],q[3][1]-q[0][1]);}
  else{const Hm=mbHomog(q),N=geo.skew?2:18;
    for(let j=0;j<N;j++)for(let i=0;i<N;i++){
      const u0=i/N,u1=(i+1)/N,v0=j/N,v1=(j+1)/N,P=[Hm(u0,v0),Hm(u1,v0),Hm(u1,v1),Hm(u0,v1)],S=[[u0*W,v0*H],[u1*W,v0*H],[u1*W,v1*H],[u0*W,v1*H]];
      mbTri(x,flat,S[0],S[1],S[2],P[0],P[1],P[2]);mbTri(x,flat,S[0],S[2],S[3],P[0],P[2],P[3]);}}
  // keep the original shape (rounded corners, cut-outs)
  x.globalCompositeOperation='destination-in';x.drawImage(cv,0,0);
  return out;
}
/* ---- composite a mockup ---- */
function mbCompose(M,repl){
  const W=M.w,H=M.h,main=mkCanvas(W,H),mx=cctx(main);
  const drawL=(ctx,L,cv)=>{const t=mkCanvas(W,H),tx=cctx(t);tx.drawImage(cv,Math.round(L.x-cv.width/2),Math.round(L.y-cv.height/2));
    if(L.mask){const m=mkCanvas(W,H);cctx(m).drawImage(L.mask,Math.round(L.x-cv.width/2),Math.round(L.y-cv.height/2),cv.width,cv.height);tx.globalCompositeOperation='destination-in';tx.drawImage(m,0,0);}return t;};
  const L=M.layers;
  for(let i=0;i<L.length;i++){
    let j=i+1;while(j<L.length&&L[j].clip)j++;
    const base=L[i];if(!base.visible){i=j-1;continue;}
    const src=repl.get(base)||base.canvas;
    if(j===i+1){const t=drawL(null,base,src);mx.save();mx.globalAlpha=base.opacity;mx.globalCompositeOperation=base.blend||'source-over';mx.drawImage(t,0,0);mx.restore();continue;}
    const tmp=drawL(null,base,src),tx=cctx(tmp),alpha=mkCanvas(W,H);cctx(alpha).drawImage(tmp,0,0);
    for(let k=i+1;k<j;k++){const c=L[k];if(!c.visible)continue;const ct=drawL(null,c,repl.get(c)||c.canvas);cctx(ct).globalCompositeOperation='destination-in';cctx(ct).drawImage(alpha,0,0);tx.save();tx.globalAlpha=c.opacity;tx.globalCompositeOperation=c.blend||'source-over';tx.drawImage(ct,0,0);tx.restore();}
    mx.save();mx.globalAlpha=base.opacity;mx.globalCompositeOperation=base.blend||'source-over';mx.drawImage(tmp,0,0);mx.restore();
    i=j-1;
  }
  return main;
}
async function mbLoadArt(f){
  const file=await f.get();
  if(MB_PSD.test(f.name)){const r=await readPSD(await file.arrayBuffer());const M={w:r.w,h:r.h,layers:r.layers},c=mbCompose(M,new Map());return c;}
  const bmp=await createImageBitmap(file),c=mkCanvas(bmp.width,bmp.height);cctx(c).drawImage(bmp,0,0);if(bmp.close)bmp.close();return c;
}
const mbSafe=s=>String(s).replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]+/g,'_');
async function mbWrite(dir,path,blob){
  const parts=path.split('/');let d=dir;for(let i=0;i<parts.length-1;i++)d=await d.getDirectoryHandle(parts[i],{create:true});
  const fh=await d.getFileHandle(parts[parts.length-1],{create:true}),w=await fh.createWritable();await w.write(blob);await w.close();
}
async function mbRun(ui){
  const S0=MB.set;
  if(!MB.mockups.length||!MB.art.length){ui.msg('Choose your mockups and your artworks first.');return;}
  MB.busy=true;MB.cancel=false;ui.busy(true);
  const total=MB.mockups.length*MB.art.length;let done=0,fail=0;const zip=[];const arts=[];
  const ext={png:'png',jpg:'jpg',webp:'webp'}[S0.fmt]||'png',mime={png:'image/png',jpg:'image/jpeg',webp:'image/webp'}[S0.fmt];
  const wantName=S0.name.trim().toLowerCase().replace(/^@/,'');
  try{
    for(const a of MB.art){try{arts.push({name:a.name,cv:await mbLoadArt(a)});}catch(e){fail++;ui.log('Could not read artwork '+a.name);}}
    for(const mk of MB.mockups){
      if(MB.cancel)break;
      let M;try{M=await readPSD(await (await mk.get()).arrayBuffer());}catch(e){fail+=arts.length;done+=arts.length;ui.log('Could not open mockup '+mk.name+' (needs an 8-bit RGB PSD)');ui.prog(done,total);continue;}
      const targets=M.layers.filter(l=>l.name.trim().toLowerCase().replace(/^@/,'')===wantName);
      if(!targets.length){fail+=arts.length;done+=arts.length;ui.log('No layer named "'+S0.name+'" in '+mk.name);ui.prog(done,total);continue;}
      const geos=new Map();targets.forEach(t=>geos.set(t,mbQuad(t.canvas,t.mask)));
      let n=0;
      for(const a of arts){
        if(MB.cancel)break;
        try{
          const repl=new Map();targets.forEach(t=>{const g=geos.get(t);if(g)repl.set(t,mbReplace(t,g,a.cv,S0.place));});
          let c=mbCompose(M,repl);
          if(S0.scale&&S0.scale!==100){const k=S0.scale/100,r=mkCanvas(Math.max(1,Math.round(c.width*k)),Math.max(1,Math.round(c.height*k)));const rx=cctx(r);rx.imageSmoothingQuality='high';rx.drawImage(c,0,0,r.width,r.height);c=r;}
          if(ext==='jpg'){const f=mkCanvas(c.width,c.height),fx=cctx(f);fx.fillStyle='#fff';fx.fillRect(0,0,f.width,f.height);fx.drawImage(c,0,0);c=f;}
          const blob=await new Promise(r=>c.toBlob(r,mime,S0.q/100));
          n++;const base=mbSafe(mk.name)+'_'+mbSafe(a.name)+(S0.suffix?'_'+String(done+1).padStart(3,'0'):'');
          const folder=S0.struct==='mockup'?mbSafe(mk.name)+'/':S0.struct==='art'?mbSafe(a.name)+'/':'';
          const path=folder+base+'.'+ext;
          if(MB.outDir)await mbWrite(MB.outDir,path,blob);else zip.push({name:path,data:new Uint8Array(await blob.arrayBuffer())});
          if(ui.preview&&(done%3===0))ui.preview(c);
        }catch(e){console.error(e);fail++;ui.log('Failed: '+mk.name+' + '+a.name);}
        done++;ui.prog(done,total);await new Promise(r=>setTimeout(r,0));
      }
    }
    if(!MB.outDir&&zip.length){await saveBlob(zipMany(zip),'mockups.zip');}
    ui.msg(MB.cancel?'Stopped. '+(done-fail)+' mockups were made.':'Finished. '+(done-fail)+' mockup'+(done-fail===1?'':'s')+' made'+(fail?', '+fail+' failed':'')+(MB.outDir?' and saved in your export folder.':'. The ZIP file was saved.'));
  }catch(e){console.error(e);ui.msg('Something went wrong: '+(e.message||e));}
  MB.busy=false;ui.busy(false);
}
function openMockupBatch(){
  const selRow=(id,label,hint)=>'<div class="mbrow"><div class="mbl"><b>'+label+'</b><span class="muted" id="'+id+'-n">Nothing chosen</span></div><div class="mbb">'+(mbHasDir()?'<button data-mb="'+id+'-dir">Choose folder...</button>':'')+'<button data-mb="'+id+'-files">Choose files...</button></div></div>';
  const o=(v,l,cur)=>'<option value="'+v+'"'+(cur===v?' selected':'')+'>'+l+'</option>';
  const S0=MB.set;
  modalOpen('Mockup Batch',
   '<div class="mb"><p class="muted">Put every artwork into every mockup in one go. In each PSD mockup, name the layer that holds the picture <b>'+esc(S0.name)+'</b>.</p>'
   +selRow('mk','Mockups (PSD)')+selRow('ar','Artworks (PNG, JPG, WebP, GIF, BMP, PSD)')
   +'<div class="mbrow"><div class="mbl"><b>Export folder</b><span class="muted" id="ex-n">'+(MB.outDir?esc(MB.outDir.name):(mbHasDir()?'Not chosen: you will get one ZIP file':'You will get one ZIP file'))+'</span></div><div class="mbb">'+(mbHasDir()?'<button data-mb="ex-dir">Choose folder...</button>':'')+'</div></div>'
   +'<div class="mbgrid"><label>Layer name<input type="text" id="mb-name" value="'+esc(S0.name)+'"></label>'
   +'<label>Placement<select id="mb-place">'+o('stretch','Stretch (fill exactly)',S0.place)+o('fit','Fit (keep shape, show all)',S0.place)+o('fill','Fill (keep shape, crop)',S0.place)+o('center','Center (original size)',S0.place)+'</select></label>'
   +'<label>Export as<select id="mb-fmt">'+o('png','PNG',S0.fmt)+o('jpg','JPG',S0.fmt)+o('webp','WebP',S0.fmt)+'</select></label>'
   +'<label>Quality (JPG, WebP) <input type="range" id="mb-q" min="50" max="100" value="'+S0.q+'"></label>'
   +'<label>Folders<select id="mb-struct">'+o('flat','All files in the export folder',S0.struct)+o('mockup','A folder for each mockup',S0.struct)+o('art','A folder for each artwork',S0.struct)+'</select></label>'
   +'<label>Output size<select id="mb-scale">'+o('100','100%',String(S0.scale))+o('75','75%',String(S0.scale))+o('50','50%',String(S0.scale))+o('25','25%',String(S0.scale))+'</select></label></div>'
   +'<label class="row"><input type="checkbox" id="mb-suf"'+(S0.suffix?' checked':'')+'> Add a unique number to each file name</label>'
   +'<div class="mbprog" id="mb-prog" hidden><div class="mbbar"><i id="mb-bar"></i></div><div id="mb-pt" class="muted"></div><canvas id="mb-pv" width="220" height="140"></canvas></div><div id="mb-log" class="muted mblog"></div><div id="mb-msg" class="mbmsg"></div>'
   +'<div class="row"><button class="primary" id="mb-go">Start</button><button id="mb-stop" hidden>Stop</button></div></div>',
   [{label:'Close'}],root=>{
    const q=s=>root.querySelector(s);
    const upd=()=>{q('#mk-n').textContent=MB.mockups.length?MB.mockups.length+' mockup'+(MB.mockups.length===1?'':'s'):'Nothing chosen';q('#ar-n').textContent=MB.art.length?MB.art.length+' artwork'+(MB.art.length===1?'':'s'):'Nothing chosen';if(MB.outDir)q('#ex-n').textContent=MB.outDir.name;};upd();
    const pickFiles=(rx,accept,cb)=>{const i=document.createElement('input');i.type='file';i.multiple=true;i.accept=accept;i.onchange=()=>{cb(mbFiles(i.files).filter(f=>rx.test(f.name)));upd();};i.click();};
    const pickDir=async(rx,cb)=>{try{const d=await window.showDirectoryPicker({mode:'read'});cb(await mbListDir(d,rx));upd();}catch(e){if(e&&e.name!=='AbortError')toast('Could not open that folder');}};
    root.addEventListener('click',async e=>{const b=e.target.closest('[data-mb]');if(!b)return;const k=b.dataset.mb;
      if(k==='mk-dir')pickDir(MB_PSD,l=>MB.mockups=l);else if(k==='mk-files')pickFiles(MB_PSD,'.psd',l=>MB.mockups=l);
      else if(k==='ar-dir')pickDir(new RegExp(MB_IMG.source+'|'+MB_PSD.source,'i'),l=>MB.art=l);else if(k==='ar-files')pickFiles(new RegExp(MB_IMG.source+'|'+MB_PSD.source,'i'),'image/*,.psd',l=>MB.art=l);
      else if(k==='ex-dir'){try{MB.outDir=await window.showDirectoryPicker({mode:'readwrite'});upd();}catch(e2){}}});
    root.addEventListener('input',e=>{const t=e.target;if(t.id==='mb-name')S0.name=t.value||'@artwork';else if(t.id==='mb-q')S0.q=+t.value;});
    root.addEventListener('change',e=>{const t=e.target;if(t.id==='mb-place')S0.place=t.value;else if(t.id==='mb-fmt')S0.fmt=t.value;else if(t.id==='mb-struct')S0.struct=t.value;else if(t.id==='mb-scale')S0.scale=+t.value;else if(t.id==='mb-suf')S0.suffix=t.checked;});
    const ui={msg:m=>{q('#mb-msg').textContent=m;},log:m=>{const d=q('#mb-log');d.textContent=(d.textContent?d.textContent+'\n':'')+m;},
      prog:(d,t)=>{q('#mb-bar').style.width=Math.round(d/t*100)+'%';q('#mb-pt').textContent=d+' of '+t;},
      busy:b=>{q('#mb-go').disabled=b;q('#mb-stop').hidden=!b;q('#mb-prog').hidden=false;},
      preview:c=>{const pv=q('#mb-pv');if(!pv)return;const x=pv.getContext('2d'),k=Math.min(pv.width/c.width,pv.height/c.height);x.clearRect(0,0,pv.width,pv.height);x.drawImage(c,(pv.width-c.width*k)/2,(pv.height-c.height*k)/2,c.width*k,c.height*k);}};
    q('#mb-go').onclick=()=>{q('#mb-log').textContent='';q('#mb-msg').textContent='';mbRun(ui);};
    q('#mb-stop').onclick=()=>{MB.cancel=true;};
  },{wide:true});
}
ACT.mockupBatch=openMockupBatch;
/* show it in the Plugins menu and in the Plugins window */
{const pm=MENUS.find(m=>m.label==='Plugins');if(pm){const d=Object.getOwnPropertyDescriptor(pm,'items');const g=d.get;Object.defineProperty(pm,'items',{get(){const a=g.call(pm);a.splice(1,0,SEP,al('Mockup Batch...','','mockupBatch'));return a;}});}}
PLUG_BUILTIN.push({name:'Mockup Batch',version:'1.0',desc:'Fill many PSD mockups with many artworks and export them all.',open:'mockupBatch'});
