/* ===== Text: full Character + Paragraph properties, Warp Text ===== */
const TXT_DEF={ls:0,kern:1,hs:100,vs:100,bs:0,fb:0,fi:0,small:0,sup:0,sub:0,ul:0,st:0,lig:1,indL:0,indR:0,indF:0,spB:0,spA:0,bw:0,wst:'none',wb:50,wh:0,wv:0,lastAlign:'left'};
const tget=(p,k)=>p[k]===undefined?TXT_DEF[k]:p[k];
function txtWarpFn(style,b,wh,wv,w,h){
  const cx=w/2,cy=h/2,A=w*0.3;
  return (x,y,o)=>{const u=x/w;let sx=x,sy=y;
    switch(style){
      case 'arc':sy=y+b*A*Math.sin(Math.PI*u);break;
      case 'arch':{const s=1+Math.abs(b)*0.35*Math.sin(Math.PI*u);sy=cy+(y-cy)/s+b*A*0.9*Math.sin(Math.PI*u);break;}
      case 'bulge':sy=cy+(y-cy)/(1+b*0.8*Math.sin(Math.PI*u));break;
      case 'flag':sy=y+b*A*0.3*Math.sin(2*Math.PI*u);break;
      case 'wave':{const s=1+b*0.25*Math.sin(2*Math.PI*u);sy=cy+(y-cy)/Math.max(0.3,s)+b*A*0.2*Math.sin(2*Math.PI*u);break;}
      case 'rise':sy=cy+(y-cy)/Math.max(0.3,1+b*0.7*(u*2-1))+b*A*0.2*(1-2*u);break;
      case 'squeeze':sy=cy+(y-cy)/Math.max(0.3,1-b*0.6*Math.sin(Math.PI*u));break;
      case 'twist':sy=y+b*A*0.5*(u-0.5)*(1+0)*Math.sin(Math.PI*u)*2+ (y-cy)*b*0.3*(u-0.5);break;
      case 'fisheye':{const dx=(x-cx)/cx,dy=(y-cy)/cy,r=Math.hypot(dx,dy),k=1/(1+b*0.8*Math.max(0,1-r*r));sx=cx+dx*cx*k;sy=cy+dy*cy*k;break;}
      case 'inflate':{const dx=(x-cx)/cx,dy=(y-cy)/cy,r=Math.hypot(dx,dy),k=1+b*0.6*Math.max(0,1-r)*(r>0?1:0);sx=cx+dx*cx/ k;sy=cy+dy*cy/k;break;}
    }
    if(wh)sx+=wh/100*(y-cy)*0.5;if(wv)sy+=wv/100*(x-cx)*0.3;o[0]=sx;o[1]=sy;};
}
function renderText(l){
  const p=l.props,T=k=>tget(p,k),sz0=p.size,sz=sz0*((T('sup')||T('sub'))?0.62:1),txt=p.caps?p.text.toUpperCase():p.text,hs=T('hs')/100,vs=T('vs')/100;
  const base=Object.assign({},p,{size:sz}),spec=fontSpec(base),lsp=((T('ls'))*sz/1000*10)+'px';
  const setCtx=(x)=>{x.font=spec;try{x.letterSpacing=lsp;x.fontKerning=T('kern')?'auto':'none';x.fontVariantCaps=T('small')?'small-caps':'normal';x.textRendering=T('lig')?'optimizeLegibility':'optimizeSpeed';}catch(e){}};
  setCtx(scratch);
  const mW=s=>scratch.measureText(s).width*hs;
  const vert=!!p.vert,boxW=vert?0:T('bw');
  // build lines
  let L=[];
  if(vert){Array.from(txt.replace(/\n/g,'')).forEach(ch=>L.push({t:ch,w:mW(ch),first:true,last:true,pf:false,pl:false}));}
  else{
    txt.split('\n').forEach(par=>{
      const words=par.split(' ');let lines=[];
      if(boxW>0){let cur='',first=true;const avail=f=>boxW-T('indL')-T('indR')-(f?T('indF'):0);
        for(const w of words){const test=cur?cur+' '+w:w;if(cur&&mW(test)>avail(first)){lines.push({t:cur,first});cur=w;first=false;}else cur=test;}
        lines.push({t:cur,first});}
      else lines=[{t:par,first:true}];
      lines.forEach((ln,i)=>{L.push({t:ln.t,w:mW(ln.t),first:ln.first,last:i===lines.length-1,pf:i===0,pl:i===lines.length-1});});
    });
  }
  const indOf=(ln)=>vert?0:T('indL')+(ln.first?T('indF'):0);
  let mw=1;for(const ln of L)mw=Math.max(mw,ln.w+indOf(ln)+(vert?0:T('indR')));
  if(boxW>0)mw=boxW;
  const slant=T('fi')?0.25:0;
  const pad=Math.ceil(sz0*0.12+p.sw+p.shadow*1.6+4+Math.max(0,T('ls'))*sz0/100+Math.abs(T('bs'))*0+(slant?sz0*0.2:0)),lh=sz0*p.lh;
  // vertical positions
  let y=0;const ys=[];L.forEach(ln=>{if(ln.pf&&ys.length)y+=T('spB');y+=lh*vs*0+lh;ys.push(y-lh/2);if(ln.pl)y+=T('spA');});
  const totalH=Math.max(lh,y+(L.length&&L[0].pf?T('spB'):0)),shiftTop=0;
  const c=l.canvas;c.width=Math.ceil(mw+pad*2);c.height=Math.ceil(totalH*Math.max(1,vs)+pad*2+Math.abs(T('bs'))*2);
  const ctx=cctx(c);setCtx(ctx);ctx.textBaseline='middle';ctx.textAlign='left';ctx.lineJoin='round';
  const align=vert?'center':p.align,baseShift=-T('bs')-(T('sup')?sz0*0.33:0)+(T('sub')?sz0*0.2:0);
  const spaceW=scratch.measureText(' ').width*hs;
  L.forEach((ln,i)=>{
    const cy=pad+Math.abs(T('bs'))+ys[i]*Math.max(1,vs)+baseShift+(T('sup')?sz0*0.31:0);
    let eff=align;if(align==='justify'){eff=(ln.last)?T('lastAlign'):'justify';} if(align==='justifyAll')eff=ln.last&&!boxW?'left':'justify';
    const left=indOf(ln),right=mw-(vert?0:T('indR')),avail=right-left;let x0;
    if(vert||eff==='center')x0=vert?(mw-ln.w)/2:left+(avail-ln.w)/2;else if(eff==='right')x0=right-ln.w;else x0=left;
    const draw=(s,x,fn)=>{ctx.save();ctx.translate(pad+x,cy);ctx.transform(hs,0,-slant*vs*0+(-slant),vs,0,0);fn(s);ctx.restore();};
    const paint=(s,x)=>{draw(s,x,t=>{
      if(p.sw>0){ctx.strokeStyle=p.stroke;ctx.lineWidth=p.sw*2/Math.max(0.01,hs);ctx.strokeText(t,0,0);}
      if(p.shadow>0){ctx.shadowColor=p.shadowColor;ctx.shadowBlur=p.shadow;ctx.shadowOffsetY=p.shadow/3;}
      ctx.fillStyle=p.color;ctx.fillText(t,0,0);
      if(T('fb')){ctx.strokeStyle=p.color;ctx.lineWidth=Math.max(1,sz/28)/Math.max(0.01,hs);ctx.strokeText(t,0,0);}
      ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.shadowOffsetY=0;});};
    let wTot=ln.w;
    if(eff==='justify'&&!vert&&ln.t.indexOf(' ')>0){
      const words=ln.t.split(' '),ww=words.map(w=>mW(w)),sumw=ww.reduce((a,b)=>a+b,0),gap=(avail-sumw)/(words.length-1);let x=left;
      words.forEach((w,k)=>{paint(w,x/hs*hs);x+=ww[k]+gap;});wTot=avail;x0=left;
    }else paint(ln.t,x0);
    const thick=Math.max(1,sz/16);
    const deco=(yy)=>{ctx.save();ctx.fillStyle=p.color;ctx.fillRect(pad+x0,cy+yy,wTot,thick);ctx.restore();};
    if(T('ul'))deco(sz*0.42*vs);if(T('st'))deco(-thick/2);
  });
  l.mask=null;
  if(T('wst')&&T('wst')!=='none'){
    const w0=c.width,h0=c.height,m=Math.ceil(Math.abs(T('wb'))/100*Math.max(w0,h0)*0.35+Math.abs(T('wv'))*0.3);
    const src=mkCanvas(w0,h0+m*2);cctx(src).drawImage(c,0,m);const id=cctx(src).getImageData(0,0,src.width,src.height);
    const out=warp(id,txtWarpFn(T('wst'),T('wb')/100,T('wh'),T('wv'),src.width,src.height));
    c.width=src.width;c.height=src.height;cctx(c).putImageData(out,0,0);
  }
  touch(l);
  if(document.fonts&&!document.fonts.check(spec,'Aa')){
    document.fonts.load(spec,'Aa').then(()=>{if(l.props&&l.props.font===p.font){renderText(l);}}).catch(()=>{});
  }
}
/* ---- UI: shared by Properties and the Character / Paragraph panels ---- */
const slx=(p,k,lab,min,max,step)=>{const v=tget(p,k);return '<label class="sl"><span>'+lab+'</span><input type="range" data-tx="'+k+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+v+'"><input type="number" class="nv" data-tx="'+k+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+v+'"></label>';};
const rawsl=(p,k,lab,min,max,step)=>{const v=p[k];return '<label class="sl"><span>'+lab+'</span><input type="range" data-tx="'+k+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+v+'"><input type="number" class="nv" data-tx="'+k+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+v+'"></label>';};
function txtCharHTML(l){
  const p=l.props,T=k=>tget(p,k);
  const tg=(k,lab,title)=>'<button class="tgl'+(T(k)?' on':'')+'" data-tt="'+k+'" title="'+title+'">'+lab+'</button>';
  return '<div class="row"><select data-tx="font" aria-label="Font">'+fontOptionsHtml(p.font)+'</select><button class="fbtn" data-fontpick="x" title="Browse fonts">Aa</button><input type="color" data-tx="color" value="'+p.color+'" title="Text colour"></div>'
   +'<div class="row"><label class="opt">Style <select data-tx="style"><option value="r"'+(!p.bold&&!p.italic?' selected':'')+'>Regular</option><option value="b"'+(p.bold&&!p.italic?' selected':'')+'>Bold</option><option value="i"'+(!p.bold&&p.italic?' selected':'')+'>Italic</option><option value="bi"'+(p.bold&&p.italic?' selected':'')+'>Bold Italic</option></select></label></div>'
   +rawsl(p,'size','Size',4,1500)+rawsl(p,'lh','Leading',0.6,3,0.05)+slx(p,'ls','Tracking',-100,1000)+slx(p,'bs','Baseline shift',-200,200)+slx(p,'hs','Horizontal scale %',10,400)+slx(p,'vs','Vertical scale %',10,400)
   +'<div class="tgrow">'+tg('fb','<b>T</b>','Faux bold')+tg('fi','<i>T</i>','Faux italic')+'<button class="tgl'+(p.caps?' on':'')+'" data-tcaps title="All caps">TT</button>'+tg('small','Tᴛ','Small caps')+tg('sup','T¹','Superscript')+tg('sub','T₁','Subscript')+tg('ul','<u>T</u>','Underline')+tg('st','<s>T</s>','Strikethrough')+'</div>'
   +'<div class="row"><label><input type="checkbox" data-tx="kern" '+(T('kern')?'checked':'')+'> Kerning</label><label><input type="checkbox" data-tx="lig" '+(T('lig')?'checked':'')+'> Ligatures</label><label><input type="checkbox" data-tx="vert" '+(p.vert?'checked':'')+'> Vertical</label></div>'
   +'<div class="h">Outline and shadow</div><div class="row"><input type="color" data-tx="stroke" value="'+p.stroke+'" title="Outline colour"><span class="muted">Outline</span></div>'+rawsl(p,'sw','Outline',0,40)
   +'<div class="row"><input type="color" data-tx="shadowColor" value="'+p.shadowColor+'" title="Shadow colour"><span class="muted">Shadow</span></div>'+rawsl(p,'shadow','Shadow',0,60)
   +'<p class="muted" style="margin:2px 0">Applies to the whole text layer. Use separate text layers for mixed styles.</p>';
}
function txtParaHTML(l){
  const p=l.props,T=k=>tget(p,k),al=(v,svg,t)=>'<button class="'+(p.align===v?'on':'')+'" data-align="'+v+'" title="'+t+'">'+svg+'</button>';
  return '<div class="seg wrap">'+al('left','⬅','Align left')+al('center','↔','Align centre')+al('right','➡','Align right')+al('justify','☰','Justify (last line follows setting below)')+al('justifyAll','▤','Justify all lines')+'</div>'
   +'<div class="row"><label class="opt">Last line <select data-tx="lastAlign">'+['left','center','right'].map(a=>'<option value="'+a+'"'+(T('lastAlign')===a?' selected':'')+'>'+a+'</option>').join('')+'</select></label></div>'
   +slx(p,'indL','Indent left',0,1500)+slx(p,'indR','Indent right',0,1500)+slx(p,'indF','First line indent',-500,1500)+slx(p,'spB','Space before',0,500)+slx(p,'spA','Space after',0,500)+slx(p,'bw','Wrap width (0 = no wrap)',0,4000);
}
function txtWarpHTML(l){const p=l.props,T=k=>tget(p,k);return '<div class="row"><label class="opt">Style <select data-tx="wst">'+['none','arc','arch','bulge','flag','wave','fisheye','rise','inflate','squeeze','twist'].map(s=>'<option value="'+s+'"'+(T('wst')===s?' selected':'')+'>'+(s==='none'?'None':s[0].toUpperCase()+s.slice(1))+'</option>').join('')+'</select></label></div>'+slx(p,'wb','Bend %',-100,100)+slx(p,'wh','Horizontal distortion',-100,100)+slx(p,'wv','Vertical distortion',-100,100);}
{
  const _rp=renderProps;
  renderProps=function(){
    _rp();
    const l=doc&&active();if(!l||l.type!=='text')return;
    const box=$('#tab-props'),h=box.innerHTML,idx=h.indexOf('<div class="h">Mask and style</div>');if(idx<0)return;
    const nh='<div class="h">Text</div><textarea id="p-text" rows="3">'+esc(l.props.text)+'</textarea>'
     +'<details class="tpanel" id="tp-char" '+(S.tpOpen!==false?'open':'')+'><summary>Character</summary>'+txtCharHTML(l)+'</details>'
     +'<details class="tpanel" id="tp-para" '+(S.tpPara?'open':'')+'><summary>Paragraph</summary>'+txtParaHTML(l)+'</details>'
     +'<details class="tpanel" id="tp-warp" '+(S.tpWarp?'open':'')+'><summary>Warp Text</summary>'+txtWarpHTML(l)+'</details>';
    box.innerHTML=nh+h.slice(idx);
  };
  const refreshText=()=>{renderProps();if(typeof PANELS!=='undefined'){['character','paragraph'].forEach(id=>{const p=PANELS[id];if(p&&p.render&&$('#tab-'+id)&&$('#tab-'+id).classList.contains('on'))p.render();});}};
  const NUM_RAW=['size','lh','sw','shadow'];
  document.addEventListener('input',e=>{const t=e.target,l=doc&&active();if(!l||l.type!=='text'||!t.dataset||!t.dataset.tx)return;const k=t.dataset.tx;
    if(t.type==='range'||t.type==='number'){const v=+t.value;l.props[k]=v;document.querySelectorAll('[data-tx="'+k+'"]').forEach(o=>{if(o!==t&&(o.type==='range'||o.type==='number'))o.value=v;});renderText(l);pend=true;redraw();}
    else if(t.type==='color'){l.props[k]=t.value;renderText(l);pend=true;redraw();}
  });
  document.addEventListener('change',e=>{const t=e.target,l=doc&&active();if(!l||l.type!=='text'||!t.dataset||!t.dataset.tx)return;const k=t.dataset.tx;
    if(t.type==='checkbox'){l.props[k]=t.checked?1:0;renderText(l);commit('Type');return;}
    if(t.tagName==='SELECT'){
      if(k==='style'){l.props.bold=t.value.includes('b');l.props.italic=t.value.includes('i');}else l.props[k]=t.value;
      renderText(l);commit(k==='wst'?'Warp text':'Type');if(k==='wst'||k==='style')refreshText();return;}
    commit('Type');
  });
  document.addEventListener('click',e=>{const t=e.target.closest('[data-tt],[data-tcaps],[data-align]'),l=doc&&active();if(!t||!l||l.type!=='text')return;
    if(t.dataset.align&&!t.closest('#tab-props,#tab-paragraph'))return;
    if(t.closest('#tab-props')&&t.dataset.align)return; // handled by Properties itself
    flush();
    if(t.dataset.align){l.props.align=t.dataset.align;}
    else if(t.dataset.tcaps!==undefined){l.props.caps=!l.props.caps;}
    else{const k=t.dataset.tt;l.props[k]=tget(l.props,k)?0:1;if(k==='sup'&&l.props.sup)l.props.sub=0;if(k==='sub'&&l.props.sub)l.props.sup=0;}
    renderText(l);commit('Type');refreshText();},true);
  document.addEventListener('toggle',e=>{const d=e.target;if(d.id==='tp-char')S.tpOpen=d.open;if(d.id==='tp-para')S.tpPara=d.open;if(d.id==='tp-warp')S.tpWarp=d.open;},true);
  const needT=()=>{const l=doc&&active();return l&&l.type==='text'?l:null;};
  PANELS.character.render=pnl('character',()=>needT()?txtCharHTML(needT())+'<div class="pbtns"><button data-act="textToShape">Convert to shape</button><button data-act="textToLetters">Letters to shapes</button><button data-act="textToPath">Work path</button></div>':'<p class="muted">Select a text layer to change its letters. Use the Type tool to add one.</p>');
  PANELS.paragraph.render=pnl('paragraph',()=>needT()?txtParaHTML(needT())+'<div class="h">Warp Text</div>'+txtWarpHTML(needT()):'<p class="muted">Select a text layer first.</p>');
  const openTextPanel=(id,det)=>{if(!needT()){toast('Select a text layer first, or add text with the Type tool');}openPanel(id);};
  ACT.panelChar=()=>openTextPanel('character');ACT.panelPara=()=>openTextPanel('paragraph');ACT.warpText=()=>openTextPanel('paragraph');
  const Ty=MENUS.find(m=>m.label==='Type');if(Ty){Ty.items.push(SEP,mi('Character panel','','panelChar'),mi('Paragraph panel','','panelPara'),mi('Warp text...','','warpText'),SEP,mi('Justify','','txtJ'));}
  ACT.txtJ=()=>{const l=active();if(!l||l.type!=='text'){toast('Select a text layer first');return;}l.props.align='justify';renderText(l);commit('Type');refreshText();};
  // re-render the open Character/Paragraph panels whenever the selection changes
  const _rl=refreshLayers;refreshLayers=function(){_rl();if(typeof PANELS!=='undefined')['character','paragraph'].forEach(id=>{const sec=$('#tab-'+id);if(sec&&sec.classList.contains('on')&&PANELS[id].render)PANELS[id].render();});};
}
