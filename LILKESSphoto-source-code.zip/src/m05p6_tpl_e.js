/* ===== Templates with photo frames (edit text, replace or delete photos) ===== */
TEMPLATES.push(
{name:'Movie premiere poster',cat:'Movie & Sports',tags:'movie film premiere poster boxing action cinema photo',w:1080,h:1440,build(){
  tGrad('#0b0b10','#1b0f0f',180);
  tShape('ellipse',.0,.75,.9,.9,'#e11d2e',{name:'Red light'}).opacity=.45;
  tShape('ellipse',1.0,.8,.9,.9,'#1d4ed8',{name:'Blue light'}).opacity=.45;
  tPhoto(.27,.4,.5,.66,{name:'Photo 1 (hero left)',fill:'#3a3a44'});
  tPhoto(.74,.4,.5,.66,{name:'Photo 2 (hero right)',fill:'#44343a'});
  tShape('rect',.5,.5,1,1,'#000000',{name:'Dark fade'}).opacity=0;
  tShape('rect',.5,.72,1,.5,'#8b1111',{name:'Red glow'}).opacity=.0;
  tPhoto(.12,.06,.1,.1,{kind:'ellipse',name:'Logo 1',fill:'#d1d5db'});
  tPhoto(.88,.06,.1,.1,{kind:'ellipse',name:'Logo 2',fill:'#d1d5db'});
  tText('YOUR STUDIO PRESENTS',0.5,0.045,{font:'Outfit',size:44,color:'#ffffff'});
  tText('A PRODUCTION FILM',0.5,0.075,{font:'Outfit',size:44,bold:false,color:'#ffffff'});
  tText('RISING',0.38,0.545,{font:'Erica One',size:150,bold:false,color:'#f59e0b',stroke:'#3b1d00',sw:6});
  tText('FROM',0.78,0.53,{font:'Erica One',size:80,bold:false,color:'#ffffff',stroke:'#000000',sw:5});
  tText('YOUR TITLE',0.5,0.64,{font:'Erica One',size:125,bold:false,color:'#f59e0b',stroke:'#3b1d00',sw:6});
  tText('ONE FIGHT. ONE FAMILY. ONE LEGACY.',0.5,0.745,{font:'Outfit',size:46,color:'#fde7c4'});
  tText('DIRECTED BY: YOUR NAME',0.5,0.79,{font:'Outfit',size:32,color:'#ffffff'});
  tShape('round',.5,.845,.4,.07,'#e11d2e',{name:'Premiering box',p:{radius:20}});
  tText('PREMIERING',0.5,0.845,{font:'Outfit',size:54,color:'#ffffff'});
  tIcon('cal',.17,.915,.075,'#e11d2e','#ffffff');tIcon('clock',.5,.915,.075,'#e11d2e','#ffffff');tIcon('pin',.82,.915,.075,'#e11d2e','#ffffff');
  tText('16TH FEB. 2026',0.17,0.96,{font:'Outfit',size:34,color:'#ffffff'});
  tText('5PM',0.5,0.96,{font:'Outfit',size:34,color:'#ffffff'});
  tText('YOUR VENUE',0.82,0.96,{font:'Outfit',size:34,color:'#ffffff'});
}},
{name:'Drama movie poster',cat:'Movie & Sports',tags:'movie film drama poster premiere cinema photo web',w:1080,h:1528,build(){
  tGrad('#7a4a1c','#0a0705',180);
  tShape('ellipse',.5,.3,1.2,1.2,'#d99a4a',{name:'Warm light'}).opacity=.25;
  tPhoto(.3,.38,.46,.62,{name:'Photo 1 (actor)',fill:'#6b5742'});
  tPhoto(.68,.4,.5,.64,{name:'Photo 2 (actor)',fill:'#8a7058'});
  tShape('rect',.5,.62,1,.5,'#0a0705',{name:'Shade'}).opacity=.0;
  tPhoto(.45,.07,.07,.07,{kind:'ellipse',name:'Logo 1',fill:'#d1d5db'});tPhoto(.56,.07,.07,.07,{kind:'ellipse',name:'Logo 2',fill:'#d1d5db'});
  tText('YOUR STUDIO',0.5,0.14,{font:'Outfit',size:54,color:'#ffffff'});
  tText('P R E S E N T S',0.5,0.17,{font:'Outfit',size:26,bold:false,color:'#ffffff'});
  tText('A PRODUCTION FILM',0.5,0.2,{font:'Outfit',size:34,color:'#ffffff'});
  tText('BLOOD',0.5,0.6,{font:'Erica One',size:210,bold:false,color:'#ff1111',stroke:'#ffffff',sw:8});
  tText('WEB',0.5,0.72,{font:'Erica One',size:210,bold:false,color:'#ff1111',stroke:'#ffffff',sw:8});
  tText('LOYALTY / JUSTICE',0.5,0.795,{font:'Outfit',size:40,bold:false,color:'#c9985b'});
  tText('Directed By Your Name',0.5,0.845,{font:'Outfit',size:32,bold:false,color:'#ffffff'});
  tText('P R E M I E R E S',0.5,0.885,{font:'Outfit',size:46,bold:false,color:'#ffffff'});
  tIcon('cal',.1,.945,.06,'#d4a017','#0a0705');tIcon('pin',.4,.945,.06,'#d4a017','#0a0705');tIcon('clock',.7,.945,.06,'#d4a017','#0a0705');
  tText('WEDNESDAY, 18TH\nFEBRUARY, 2026',0.25,0.945,{font:'Outfit',size:26,color:'#ffffff',lh:1.15});
  tText('YOUR VENUE',0.55,0.945,{font:'Outfit',size:26,color:'#ffffff'});
  tText('5:00 PM\nPROMPT',0.86,0.945,{font:'Outfit',size:34,color:'#ffffff',lh:1});
}},
{name:'Youth week with speakers',cat:'Church',tags:'church youth week conference speakers photos teal event',w:1080,h:1080,build(){
  tGrad('#0f766e','#2aa6a9',120);
  tPhoto(.8,.2,.26,.26,{name:'Speaker photo 1',kind:'round',radius:60,fill:'#f5b82e'});
  tPhoto(.68,.4,.26,.26,{name:'Speaker photo 2',kind:'round',radius:60,fill:'#ffffff'});
  tPhoto(.56,.6,.26,.26,{name:'Speaker photo 3',kind:'round',radius:60,fill:'#f5b82e'});
  tPhoto(.44,.8,.26,.26,{name:'Speaker photo 4',kind:'round',radius:60,fill:'#ffffff'});
  tPhoto(.09,.07,.08,.08,{kind:'ellipse',name:'Logo',fill:'#e5e7eb'});
  tText('YOUR CHURCH NAME\nYOUTH MINISTRY',0.17,0.07,{font:'Outfit',size:26,color:'#ffffff',lh:1.15,align:'left'});
  tText('P R E S E N T S',0.19,0.15,{font:'Outfit',size:22,color:'#ffffff'});
  tText('DISTRICT',0.2,0.225,{font:'Instrument Serif',size:64,bold:false,italic:true,color:'#ffffff'});
  tText('YOUTH',0.06,0.32,{font:'Outfit',size:120,color:'#f5b82e',align:'left'});
  tText('WEEK',0.06,0.44,{font:'Outfit',size:120,color:'#f5b82e',align:'left'});
  tText('CELEBRATION',0.07,0.53,{font:'Outfit',size:34,color:'#ffffff',align:'left'});
  tText('THEME',0.06,0.62,{font:'Outfit',size:24,color:'#ffffff',align:'left'});
  tText('RUN TO WIN',0.15,0.62,{font:'Outfit',size:44,color:'#ffffff',align:'left'});
  tText('2 TIMOTHY 2:15',0.15,0.66,{font:'Outfit',size:24,bold:false,color:'#ffffff',align:'left'});
  tText('16th',0.06,0.735,{font:'Outfit',size:50,color:'#ffffff',align:'left'});tText('18th',0.21,0.735,{font:'Outfit',size:50,color:'#ffffff',align:'left'});
  tText('SEPT. 2026',0.06,0.775,{font:'Outfit',size:20,color:'#ffffff',align:'left'});tText('SEPT. 2026',0.21,0.775,{font:'Outfit',size:20,color:'#ffffff',align:'left'});
  tText('6PM Each NIGHT',0.06,0.83,{font:'Outfit',size:28,color:'#f5b82e',align:'left'});
  tText('YOUR VENUE NAME',0.06,0.92,{font:'Outfit',size:24,bold:false,color:'#ffffff',align:'left'});
  tText('SPEAKERS',0.8,0.65,{font:'Outfit',size:20,color:'#f5b82e',align:'left'});
  tText('SPEAKER NAME 1\n(TITLE)',0.8,0.7,{font:'Outfit',size:15,color:'#ffffff',lh:1.15,align:'left'});tText('SPEAKER NAME 2\n(TITLE)',0.8,0.77,{font:'Outfit',size:15,color:'#ffffff',lh:1.15,align:'left'});
  tText('SPEAKER NAME 3\n(TITLE)',0.8,0.84,{font:'Outfit',size:15,color:'#ffffff',lh:1.15,align:'left'});tText('SPEAKER NAME 4\n(TITLE)',0.8,0.91,{font:'Outfit',size:15,color:'#ffffff',lh:1.15,align:'left'});
}},
{name:'Youth week bold green',cat:'Church',tags:'church youth week cross green gold typography event',w:1080,h:1225,build(){
  tRadial('#17805e','#052b1f',.5,.18,.9);
  tPhoto(.42,.065,.07,.07,{kind:'ellipse',name:'Logo 1',fill:'#e5e7eb'});tPhoto(.58,.065,.07,.07,{kind:'ellipse',name:'Logo 2',fill:'#e5e7eb'});
  tText('YOUR CHURCH NAME\nYOUTH MINISTRY',0.5,0.14,{font:'Outfit',size:32,color:'#ffffff',lh:1.15});
  tText('DISTRICT',0.5,0.215,{font:'Big Shoulders Display',size:130,color:'#fbbf24'});
  tText('YOUTH',0.5,0.37,{font:'Big Shoulders Display',size:290,color:'#ffffff',shadow:12,shadowColor:'#00000088'});
  tText('WEEK CELEBRATION',0.5,0.53,{font:'Big Shoulders Display',size:110,color:'#fbbf24'});
  tRule(.27,.605,.3,'#ffffff',2);tRule(.27,.77,.3,'#ffffff',2);
  tText('WED. 16TH',0.4,0.66,{font:'Big Shoulders Display',size:80,color:'#ffffff',align:'right'});
  tText('FRI. 18TH',0.4,0.715,{font:'Big Shoulders Display',size:80,color:'#ffffff',align:'right'});
  tText('SEPTEMBER 2026',0.4,0.75,{font:'Outfit',size:30,bold:false,color:'#fde68a',align:'right'});
  tText('THEME:',0.9,0.62,{font:'Outfit',size:28,color:'#ffffff',align:'right'});
  tText('RUN',0.9,0.69,{font:'Big Shoulders Display',size:150,color:'#fbbf24',align:'right'});
  tText('TO WIN',0.9,0.765,{font:'Big Shoulders Display',size:100,color:'#fbbf24',align:'right'});
  tText('2 TIMOTHY 2:15',0.9,0.805,{font:'Outfit',size:24,color:'#ffffff',align:'right'});
  tShape('rect',.5,.935,1,.13,'#ece9e2',{name:'Paper strip'});
  tShape('rect',.5,.88,.5,.04,'#0f6b3d',{name:'Time bar'});
  tText('TIME   6:00 PM EACH NIGHT',0.5,0.88,{font:'Outfit',size:32,color:'#ffffff'});
  tText('YOUR VENUE NAME',0.5,0.93,{font:'Outfit',size:38,color:'#0a3f2f'});
  tText('NOTE: Add any extra information here.',0.5,0.97,{font:'Outfit',size:24,bold:false,color:'#222222'});
}},
{name:'Traditional service',cat:'Church',tags:'church traditional palm sunday service ghana kente culture photo',w:1080,h:1528,build(){
  tGrad('#e7f3d7','#b9d89a',180);
  tPhoto(.5,.78,1,.58,{name:'Photo (group)',fill:'#9db07f'});
  tPhoto(.1,.065,.1,.1,{kind:'ellipse',name:'Logo',fill:'#d1d5db'});
  tText('YOUR CHURCH NAME\nASSEMBLY NAME',0.55,0.07,{font:'Libre Baskerville',size:30,color:'#1b3a6b',lh:1.2});
  tText('Presents',0.4,0.12,{font:'Instrument Serif',size:36,bold:false,italic:true,color:'#7a1f1f'});
  tText('TRADITIONAL',0.5,0.185,{font:'Jura',size:120,color:'#141414'});
  tText('& PALM',0.4,0.255,{font:'Jura',size:120,color:'#141414'});
  tText('SUNDAY',0.5,0.34,{font:'Jura',size:190,color:'#141414'});
  tText('S E R V I C E',0.5,0.405,{font:'Libre Baskerville',size:46,color:'#141414'});
  tShape('round',.24,.455,.22,.045,'#1b4d2a',{name:'Time box',p:{radius:8}});
  tText('9:30AM',0.24,0.455,{font:'Outfit',size:44,color:'#ffffff'});
  tText('SUNDAY, 29TH\nMARCH, 2026',0.65,0.455,{font:'Outfit',size:44,color:'#1b4d2a',lh:1});
  tText('Your Venue Name',0.38,0.5,{font:'Outfit',size:40,color:'#1b4d2a'});
  tShape('rect',.5,.97,1,.05,'#1d3f8f',{name:'Pattern strip'});tShape('rect',.5,.9575,1,.012,'#d32f2f',{name:'Pattern line'});
}},
{name:'Fundraising envelope',cat:'Church',tags:'fundraising envelope church building donation offering',w:1500,h:700,build(){
  tSolid('#ffffff');
  tShape('round',.5,.5,.98,.44,'#f4f8fc',{name:'Panel',p:{radius:30,stroke:'#cfdcee',sw:2}});
  tPhoto(.09,.2,.09,.09,{kind:'ellipse',name:'Logo',fill:'#bcd0ec'});
  tText('YOUR MINISTRY NAME',0.17,0.15,{font:'Outfit',size:64,color:'#1e4f9c',align:'left'});
  tText('TRANSFORMING LIVES AND SHAPING DESTINY',0.17,0.235,{font:'Outfit',size:28,bold:false,color:'#1e3a6b',align:'left'});
  tShape('round',.84,.15,.28,.085,'#e4eefb',{name:'Date box',p:{radius:40,stroke:'#9fbce3',sw:3}});
  tText('DATE:  1 NOV. 2026',0.72,0.12,{font:'Outfit',size:26,color:'#1e3a6b',align:'left'});
  tText('TIME:  9:00 AM',0.72,0.18,{font:'Outfit',size:26,color:'#1e3a6b',align:'left'});
  tText('FUND RAISING',0.06,0.38,{font:'Outfit',size:105,color:'#1e4f9c',shadow:6,shadowColor:'#1e4f9c55',align:'left'});
  tShape('round',.3,.5,.46,.055,'#2f86e0',{name:'Subtitle bar',p:{radius:30}});
  tText('IN AID OF CHURCH BUILDING',0.3,0.5,{font:'Outfit',size:38,color:'#ffffff'});
  tPhoto(.84,.55,.28,.27,{name:'Photo (building)',fill:'#cdd9ea',kind:'round',radius:20});
  tText('Psalm 50:5',0.12,0.62,{font:'Outfit',size:32,color:'#1e3a6b',align:'left'});
  tText('"Gather my saints together unto me;\nthose that have made a covenant with me\nby sacrifice."',0.12,0.72,{font:'Instrument Serif',size:32,bold:false,italic:true,color:'#1e3a6b',lh:1.15,align:'left'});
  tShape('round',.49,.84,.94,.075,'#e4eefb',{name:'Fields',p:{radius:40,stroke:'#9fbce3',sw:3}});
  tText('NAME: ..............................',0.1,0.84,{font:'Outfit',size:30,color:'#1e3a6b',align:'left'});
  tText('AMOUNT: ..............................',0.56,0.84,{font:'Outfit',size:30,color:'#1e3a6b',align:'left'});
  tShape('rect',.5,.97,1,.1,'#1e4f9c',{name:'Footer'});
  tText('LOCATION:  Your address, street name and landmark',0.5,0.955,{font:'Outfit',size:28,color:'#ffffff'});
}},
{name:'Hiring story (list)',cat:'Business',tags:'hiring job vacancy recruitment positions story flyer',w:1080,h:1920,build(){
  tGrad('#0b2a6b','#07194a',180);
  tShape('ellipse',.0,.2,.3,.3,'#f59e0b',{name:'Blob'}).opacity=.9;tShape('ellipse',1,.95,.4,.4,'#f59e0b',{name:'Blob 2'}).opacity=.9;
  tText('YOUR COMPANY',0.5,0.065,{font:'Outfit',size:96,color:'#ffffff'});
  tText('IS HIRING!',0.5,0.115,{font:'Outfit',size:130,color:'#fbbf24'});
  tShape('rect',.5,.15,.8,.004,'#3b82f6',{name:'Line'});
  tText('WE ARE EXPANDING OUR SERVICES TO 24/7!',0.5,0.19,{font:'Outfit',size:42,color:'#ffffff'});
  tText('24 HOURS A DAY, 7 DAYS A WEEK',0.5,0.225,{font:'Outfit',size:44,color:'#fbbf24'});
  tText('NEED MORE EXPERIENCED HANDS TO JOIN THE TEAM',0.5,0.25,{font:'Outfit',size:28,bold:false,color:'#ffffff'});
  tShape('round',.5,.31,.7,.045,'#1d4ed8',{name:'Label',p:{radius:30}});
  tText('OPEN POSITIONS:',0.5,0.31,{font:'Outfit',size:44,color:'#ffffff'});
  tShape('round',.5,.42,.95,.24,'#0e2a63',{name:'List panel',p:{radius:30}});
  tText('POSITION ONE\nPOSITION TWO\nPOSITION THREE\nPOSITION FOUR\nPOSITION FIVE',0.2,0.42,{font:'Outfit',size:42,color:'#ffffff',lh:1.45,align:'left'});
  tPhoto(.88,.36,.1,.1,{name:'Icon photo 1',kind:'round',radius:20,fill:'#cbd5e1'});tPhoto(.88,.46,.1,.1,{name:'Icon photo 2',kind:'round',radius:20,fill:'#cbd5e1'});
  tShape('round',.5,.60,.9,.14,'#f59e0b',{name:'Notice',p:{radius:30,stroke:'#b45309',sw:4}});
  tText('FLEXIBLE WORKING HOURS!',0.5,0.57,{font:'Outfit',size:52,color:'#0b2a6b'});
  tText('Add the location details for applicants here.',0.5,0.605,{font:'Outfit',size:30,bold:false,color:'#0b2a6b'});
  tText('SUITABLE FOR THOSE SCHOOLING\nAND NEED PART-TIME JOB',0.5,0.69,{font:'Outfit',size:50,color:'#fbbf24',lh:1.2});
  tShape('rect',.5,.84,1,.34,'#ffffff',{name:'White band'});
  tShape('round',.5,.77,.45,.05,'#fbbf24',{name:'Send box',p:{radius:6}});
  tText('SEND YOUR CVs TO:',0.5,0.77,{font:'Outfit',size:42,color:'#0b2a6b'});
  tText('024 000 0000\n053 000 0000',0.5,0.835,{font:'Outfit',size:90,color:'#0b2a6b',lh:1.1});
  tText('YOUR COMPANY',0.5,0.95,{font:'Outfit',size:48,color:'#ffffff'});
  tText('JOIN OUR GROWING TEAM!',0.5,0.975,{font:'Outfit',size:38,color:'#fbbf24'});
}},
{name:'Inter-house competition',cat:'Movie & Sports',tags:'competition drums school event red gold jama cultural photo',w:1080,h:1080,build(){
  tGrad('#5b0a0a','#2a0404',180);
  tShape('ellipse',.0,.0,.5,.5,'#ff2a2a',{name:'Spot 1'}).opacity=.4;tShape('ellipse',1,0,.5,.5,'#ff2a2a',{name:'Spot 2'}).opacity=.4;
  tPhoto(.5,.07,.34,.075,{name:'Logos strip',kind:'round',radius:20,fill:'#2a0f0f'});
  tText('P R E S E N T S',0.5,0.14,{font:'Outfit',size:20,color:'#f5b82e'});
  tShape('round',.5,.23,.75,.075,null,{name:'Tag outline',p:{radius:18,stroke:'#ffffff',sw:3,nofill:true}});
  tText('INTER- HOUSE',0.5,0.23,{font:'Outfit',size:50,color:'#ffffff'});
  tText('YOUR',0.5,0.37,{font:'Outfit',size:260,color:'#ffd21f',italic:true,stroke:'#ff2a00',sw:0,shadow:20,shadowColor:'#ff2a0088'});
  tText('COMPETITION',0.5,0.55,{font:'Outfit',size:140,color:'#ffffff'});
  tShape('round',.5,.65,.74,.07,'#2a0f0f',{name:'Scroll',p:{radius:12,stroke:'#d4a017',sw:5}});
  tText('[HOUSE ONE. HOUSE TWO. HOUSE THREE. HOUSE FOUR]',0.5,0.65,{font:'Big Shoulders Display',size:40,color:'#ffffff'});
  tPhoto(.5,.8,.75,.28,{name:'Photo (drums or artwork)',fill:'#8a5a3a'});
  tShape('rect',.5,.9,.84,.16,'#150404',{name:'Info bar'});
  tShape('rect',.26,.855,.1,.03,'#e11d2e',{name:'Date label'});tText('Date:',0.26,0.855,{font:'Outfit',size:28,color:'#ffffff'});
  tShape('rect',.56,.855,.1,.03,'#e11d2e',{name:'Venue label'});tText('Venue:',0.56,0.855,{font:'Outfit',size:28,color:'#ffffff'});
  tText('THURSDAY, 15TH\nOCTOBER, 2026',0.27,0.905,{font:'Outfit',size:34,color:'#ffffff',lh:1.1});
  tText('YOUR VENUE\nNAME HERE',0.56,0.905,{font:'Outfit',size:34,color:'#ffffff',lh:1.1});
  tShape('round',.82,.9,.2,.1,'#e11d2e',{name:'Time box',p:{radius:30}});
  tText('9AM\nSHARP',0.82,0.9,{font:'Outfit',size:44,color:'#ffffff',lh:1});
  tText('For more enquiries contact: 000 000 0000',0.4,0.975,{font:'Outfit',size:26,bold:false,color:'#ffffff'});
}},
{name:'Sports recruiting graphic',cat:'Movie & Sports',tags:'sports basketball team coaches staff recruiting photos black orange',w:1080,h:1315,build(){
  tSolid('#0e0e0e');
  tShape('ellipse',.5,.42,.9,.5,'#1d1d1d',{name:'Arena glow'});
  tText('YOUR TEAM NAME',0.5,0.06,{font:'Libre Baskerville',size:28,color:'#ffffff'});
  tShape('triangle',.5,.1,.14,.06,'#e8742a',{name:'Team mark'});
  tPhoto(.27,.66,.125,.4,{name:'Photo 1',fill:'#c8742e'});
  tPhoto(.395,.61,.125,.4,{name:'Photo 2',fill:'#cfcfcf'});
  tPhoto(.52,.56,.125,.4,{name:'Photo 3',fill:'#c8742e'});
  tPhoto(.645,.51,.125,.4,{name:'Photo 4',fill:'#e8e8e8'});
  tPhoto(.77,.46,.125,.4,{name:'Photo 5',fill:'#c8742e'});
  tText('NAME ONE',0.32,0.72,{font:'Outfit',size:34,color:'#ffffff'}).r=-Math.PI/2;
  tText('NAME TWO',0.445,0.67,{font:'Outfit',size:34,color:'#333333'}).r=-Math.PI/2;
  tText('NAME THREE',0.57,0.62,{font:'Outfit',size:34,color:'#ffffff'}).r=-Math.PI/2;
  tText('NAME FOUR',0.695,0.57,{font:'Outfit',size:34,color:'#333333'}).r=-Math.PI/2;
  tText('NAME FIVE',0.82,0.52,{font:'Outfit',size:34,color:'#ffffff'}).r=-Math.PI/2;
  tText('SINCE THE SWEET 16:',0.5,0.795,{font:'Outfit',size:48,color:'#e8742a'});
  tText('LANDED THE SECOND #1 RANKED\nRECRUIT IN PROGRAM HISTORY',0.5,0.835,{font:'Outfit',size:24,color:'#ffffff',lh:1.2});
  tText('#1 OVERALL RANKED RECRUITING CLASS IN THE NATION',0.5,0.88,{font:'Outfit',size:24,color:'#ffffff'});
  tText('TOP 5 TRANSFER PORTAL CLASS BY ALL MAJOR SITES',0.5,0.915,{font:'Outfit',size:24,color:'#ffffff'});
  tText('TOP 5 RANKED RECRUITING CLASS BY ESPN',0.5,0.95,{font:'Outfit',size:24,color:'#ffffff'});
}},
{name:'Player commitment',cat:'Movie & Sports',tags:'sports football player commit signing announcement photo stadium',w:1080,h:1344,build(){
  tGrad('#dfe9f2','#ffffff',180);
  tPhoto(.5,.8,1,.4,{name:'Photo (stadium background)',fill:'#8e9aa6'});
  tPhoto(.72,.46,.42,.78,{name:'Photo (player cutout)',fill:'#b5bdc7',kind:'round',radius:40});
  tText('YOUR TEAM NAME',0.5,0.035,{font:'Libre Baskerville',size:26,color:'#6b7280'});
  tText('PLAYER',0.2,0.2,{font:'Big Shoulders Display',size:70,color:'#111111'});
  tText('SURNAME',0.27,0.29,{font:'Big Shoulders Display',size:115,color:'#6b5a3a'});
  tText('Add a short caption here:',0.22,0.4,{font:'Outfit',size:34,bold:false,color:'#111111'});
}},
{name:'Beauty studio promo',cat:'Beauty & Salon',tags:'beauty salon makeup lash nails studio brown cream services photo',w:1080,h:1350,build(){
  tSolid('#f3e6d3');
  tShape('round',.78,.18,.4,.62,'#5a3422',{name:'Arch',p:{radius:200}});
  tPhoto(.74,.42,.5,.62,{name:'Photo (model)',fill:'#c9a58a',kind:'round',radius:60});
  tText('20% OFF',0.78,0.065,{font:'Outfit',size:62,color:'#ffffff'});
  tText('THIS WEEKEND\n(14TH - 17TH MARCH)',0.78,0.115,{font:'Outfit',size:28,color:'#ffffff',lh:1.2});
  tPhoto(.1,.07,.08,.08,{kind:'ellipse',name:'Logo',fill:'#d6c3ad'});tText('Your Brand\nStudio',0.24,0.07,{font:'Outfit',size:26,bold:false,color:'#222222',lh:1.15,align:'left'});
  tText('YOUR',0.06,0.18,{font:'Outfit',size:90,color:'#2b1a10',align:'left'});
  tText('BRAND',0.06,0.255,{font:'Outfit',size:90,color:'#3d2314',align:'left'});
  tText('STUDIO',0.06,0.33,{font:'Outfit',size:90,color:'#7a4a2e',align:'left'});
  tText('...Your tagline here',0.06,0.39,{font:'Outfit',size:30,italic:true,bold:false,color:'#333333',align:'left'});
  tShape('round',.3,.56,.5,.28,'#5a3422',{name:'Services box',p:{radius:24}});
  tShape('round',.3,.465,.26,.045,'#f3e6d3',{name:'Services label',p:{radius:16}});
  tText('SERVICES:',0.3,0.465,{font:'Outfit',size:38,color:'#222222'});
  tText('▪ Makeup\n▪ Lash Extensions\n▪ Gel Nails\n▪ Bridal Glam...',0.08,0.565,{font:'Outfit',size:42,bold:false,color:'#ffffff',lh:1.35,align:'left'});
  tPhoto(.12,.76,.14,.14,{name:'Photo 1',kind:'round',radius:20,fill:'#c9b6ff'});tPhoto(.29,.76,.14,.14,{name:'Photo 2',kind:'round',radius:20,fill:'#d8c0a8'});tPhoto(.46,.76,.14,.14,{name:'Photo 3',kind:'round',radius:20,fill:'#b8a8c8'});
  tCustom('burst',.77,.73,.14,.14,'#f3e6d3',{name:'Book now badge'});tText('BOOK\nNOW!',0.77,0.73,{font:'Outfit',size:34,color:'#2b1a10',lh:1});
  tShape('rect',.5,.93,1,.16,'#5a3422',{name:'Footer'});
  tShape('round',.5,.935,.94,.09,null,{name:'Footer outline',p:{radius:24,stroke:'#f3e6d3',sw:3,nofill:true}});
  tText('YOUR TOWN,\nYOUR STATE.',0.2,0.935,{font:'Outfit',size:32,color:'#ffffff',lh:1.1,align:'left'});
  tText('+000 000 000 0000\n+000 000 000 0000',0.7,0.935,{font:'Outfit',size:32,color:'#ffffff',lh:1.1});
}},
{name:'Nail studio pink',cat:'Beauty & Salon',tags:'nails nail tech studio pink beauty services photos',w:1080,h:1310,build(){
  tGrad('#fde4ef','#ffd0e4',160);
  tPhoto(.3,.3,.62,.58,{name:'Photo (hero)',fill:'#c99a8b'});
  tText('Your Name',0.74,0.1,{font:'Great Vibes',size:100,color:'#b0124e'});
  tText('Nails Studio',0.74,0.175,{font:'Great Vibes',size:80,color:'#b0124e'});
  tShape('rect',.74,.32,.28,.04,'#e91e8c',{name:'Label'});tText('Our Services',0.74,0.32,{font:'Outfit',size:32,color:'#ffffff'});
  const sv=['Acrylic Nails','Gel Polish Nails','Nail Wraps','Nail Tips'];
  sv.forEach((t,i)=>{tShape('round',.73,.4+i*.075,.44,.055,'#f23f9f',{name:'Service bar',p:{radius:40}});tIcon('check',.53,.4+i*.075,.05,'#ffffff','#e91e8c');tText(t,0.75,.4+i*.075,{font:'Outfit',size:40,color:'#111111'});});
  tShape('round',.5,.77,.95,.2,'#ffffff',{name:'Gallery card',p:{radius:30}});
  [.14,.38,.62,.86].forEach((x,i)=>tPhoto(x,.77,.2,.17,{name:'Gallery photo '+(i+1),kind:'round',radius:20,fill:['#c9a0d0','#d0b0e0','#a0b8e0','#d8c0a0'][i]}));
  tShape('round',.5,.93,1.0,.14,'#e91e8c',{name:'Footer'});
  tText('CALL/WHATSAPP\n000 000 0000',0.22,0.935,{font:'Outfit',size:40,color:'#ffffff',lh:1.15});
  tText('LOCATION:\nYour address, city, state.',0.55,0.935,{font:'Outfit',size:26,color:'#ffffff',lh:1.15,align:'left'});
}},
{name:'Eden beauty services',cat:'Beauty & Salon',tags:'beauty salon nails lash wigs braiding hair services gallery photo',w:1080,h:1365,build(){
  tGrad('#f8e9dc','#a35a3a',180);
  tPhoto(.5,.28,1,.55,{name:'Photo (hero)',fill:'#d3a58b'});
  tText("YOUR NAME'S",0.06,0.07,{font:'Gloock',size:80,bold:false,color:'#6b3a22',align:'left'});
  tText('SALON',0.06,0.14,{font:'Gloock',size:80,bold:false,color:'#6b3a22',align:'left'});
  tText('WHERE BEAUTY MEETS PERFECTION',0.06,0.2,{font:'Outfit',size:24,color:'#3a1d10',align:'left'});
  tShape('round',.5,.65,.95,.38,'#fbe2d6',{name:'Services card',p:{radius:40}});
  tShape('round',.5,.485,.35,.06,'#c88a63',{name:'Services label',p:{radius:40}});
  tText('OUR SERVICES',0.5,0.485,{font:'Outfit',size:48,color:'#ffffff'});
  tText('NAIL     PEDICURE     PONY     WIGS',0.5,0.53,{font:'Outfit',size:32,color:'#5a2d18'});
  tText('BRAIDING     LASH     WASHING     RETOUCH',0.5,0.56,{font:'Outfit',size:32,color:'#5a2d18'});
  const xs=[.18,.5,.82];xs.forEach((x,i)=>tPhoto(x,.64,.28,.18,{name:'Gallery photo '+(i+1),kind:'round',radius:24,fill:['#d9c3b5','#c8b0a0','#d0b8a8'][i]}));
  [.12,.37,.62,.87].forEach((x,i)=>tPhoto(x,.82,.22,.15,{name:'Gallery photo '+(i+4),kind:'round',radius:24,fill:['#cdb8a8','#e0d0c0','#bfa896','#c8a8e0'][i]}));
  tText('+000 (0) 00 000 0000',0.3,0.955,{font:'Outfit',size:44,color:'#ffffff'});
  tText('YOUR TOWN\nYour landmark',0.76,0.955,{font:'Outfit',size:32,color:'#ffffff',lh:1.05,align:'left'});
}},
{name:'Beauty services list',cat:'Beauty & Salon',tags:'beauty services nails lash manicure pedicure list gallery photos brown',w:1080,h:1350,build(){
  tGrad('#fbf3ea','#e9d5c0',160);
  tShape('rect',.5,.88,1,.5,'#4a2412',{name:'Brown base'});
  tPhoto(.7,.1,.6,.2,{name:'Photo (header)',fill:'#d9c3b0'});
  tText('Your',0.2,0.055,{font:'Young Serif',size:110,bold:false,color:'#3a1b0d'});
  tText('Beauty Services',0.31,0.115,{font:'Young Serif',size:70,bold:false,color:'#5a2d18'});
  tShape('round',.3,.16,.55,.04,'#8a4a28',{name:'Tagline bar',p:{radius:6}});
  tText('We bring beauty and elegance to your doorstep....',0.3,0.16,{font:'Outfit',size:24,color:'#ffffff'});
  tShape('round',.17,.5,.3,.47,'#fff7ee',{name:'Services card',p:{radius:24}});
  tText('OUR SERVICES',0.17,0.24,{font:'Outfit',size:30,color:'#5a2d18'});
  tText('All types of Nails\nStick-on Nails\nAcrylic Nails\nNail Polishing\nNatural Nails Trimming\nManicure\nPedicure',0.08,0.345,{font:'Outfit',size:34,color:'#2b1a10',lh:1.3,align:'left'});
  tText('Lash Fixation',0.17,0.5,{font:'Outfit',size:30,color:'#5a2d18'});
  tText('Cluster Lash Set\nFlare Lash Set\nStrip Lash Set\nTrimming of brows',0.08,0.6,{font:'Outfit',size:34,color:'#2b1a10',lh:1.3,align:'left'});
  [[.57,.3],[.82,.3],[.57,.55],[.82,.55],[.57,.8],[.82,.8]].forEach((q,i)=>tPhoto(q[0],q[1],.22,.2,{name:'Photo '+(i+1),kind:'round',radius:24,stroke:'#d9803c',sw:5,fill:['#d9b6a8','#e0a888','#d8c0b0','#c8d4d8','#bca894','#c8b0a8'][i]}));
  tText('Location',0.1,0.865,{font:'Outfit',size:26,color:'#ffffff'});tShape('round',.17,.9,.3,.04,'#ffffff',{name:'Loc box',p:{radius:6}});tText('Your location',0.17,0.9,{font:'Outfit',size:28,color:'#111111'});
  tText('Call / Whatsapp',0.12,0.94,{font:'Outfit',size:26,color:'#ffffff'});tShape('round',.17,.97,.3,.04,'#ffffff',{name:'Phone box',p:{radius:6}});tText('0000 000 000',0.17,0.97,{font:'Outfit',size:30,color:'#111111'});
  tShape('round',.82,.955,.3,.05,'#ffffff',{name:'CTA box',p:{radius:14}});tText('BOOK US TODAY!!!',0.82,0.955,{font:'Outfit',size:28,color:'#2b1a10'});
}},
{name:'Triple portrait',cat:'Portrait',tags:'portrait photo three panels collage name poster',w:1080,h:1598,build(){
  tSolid('#f1f3f6');
  tPhoto(.17,.5,.3,.84,{name:'Photo left',fill:'#8b8f99'});tPhoto(.5,.52,.33,1.05,{name:'Photo centre',fill:'#b6bcc8'});tPhoto(.83,.5,.3,.84,{name:'Photo right',fill:'#8b8f99'});
  tText('YOUR NAME',0.5,0.88,{font:'Big Shoulders Display',size:320,color:'#ffffff'}).fx={shadow:{on:true,color:'#000000',op:.4,angle:120,dist:6,size:12,blend:'multiply',spread:0,noise:0,knock:true}};
}},
{name:'Services flyer (blue)',cat:'Business',tags:'media services flyer graphic design video animation blue photos book now',w:1080,h:1512,build(){
  tSolid('#ffffff');
  tShape('rect',.08,.5,.16,1.4,'#17238f',{name:'Left bar'});tShape('rect',.9,.5,.2,1.4,'#17238f',{name:'Right bar'});
  tText('YOUR BRAND',0.075,0.52,{font:'Big Shoulders Display',size:200,color:'#ffffff'}).r=-Math.PI/2;
  tText('Home of media',0.135,0.6,{font:'Outfit',size:64,color:'#17238f'}).r=-Math.PI/2;
  tPhoto(.9,.075,.2,.07,{name:'Logos',kind:'round',radius:30,fill:'#c8cdf0'});
  tPhoto(.82,.2,.24,.27,{name:'Photo 1 (portrait)',kind:'ellipse',fill:'#8f96c4',stroke:'#ffffff',sw:8});
  tShape('round',.45,.33,.4,.3,'#17238f',{name:'Services box',p:{radius:40,stroke:'#000000',sw:5}});
  tShape('round',.45,.195,.3,.05,'#000000',{name:'Services label',p:{radius:20}});tText('OUR SERVICES',0.45,0.195,{font:'Outfit',size:34,color:'#ffffff'});
  tText('Graphic Design\n(Flyer, poster, logo etc)\nVideo Editing\n(Promo videos, reels etc)\nAnimation\n(Logo animation, motion graphics)',0.45,0.34,{font:'Outfit',size:30,bold:false,color:'#ffffff',lh:1.2,align:'left'});
  tPhoto(.48,.75,.7,.5,{name:'Photo 2 (portrait)',fill:'#6b7280'});
  tShape('round',.36,.925,.3,.07,'#17238f',{name:'Book now box',p:{radius:10,stroke:'#000000',sw:4}});tText('BOOK\nNOW!',0.36,0.925,{font:'Outfit',size:50,color:'#ffffff',lh:.95});
  tShape('round',.5,.97,.72,.05,'#ffffff',{name:'Phone box',p:{radius:40,stroke:'#000000',sw:5}});
  tText('000 000 0000',0.5,0.97,{font:'Outfit',size:58,color:'#000000'});
}},
{name:'Happy birthday portrait (blue)',cat:'Birthday',tags:'birthday blue photo portrait wish friend',w:1080,h:1080,build(){
  tSolid('#f3f4f8');
  tShape('rect',.12,.5,.25,1,'#030d4a',{name:'Left bar'});
  tPhoto(.27,.48,.5,.8,{name:'Photo (birthday person)',kind:'round',radius:140,fill:'#2540c8',stroke:'#ffffff',sw:12});
  tText('Happy',0.56,0.27,{font:'Great Vibes',size:90,color:'#1d3dff',italic:true,align:'left'});
  tText('BIRTHDAY',0.56,0.345,{font:'Outfit',size:78,color:'#111111',align:'left'});
  tShape('rect',.78,.42,.44,.05,'#1d3dff',{name:'Name bar'});
  tText('YOUR NAME',0.78,0.42,{font:'Outfit',size:40,color:'#ffffff'});
  tText('Celebrating a shining example of\nkindness, strength, and purpose.\nMay your special day be filled\nwith joy, love, and gratitude.\nWishing you many more\nbeautiful years.',0.56,0.58,{font:'Outfit',size:25,bold:false,italic:true,color:'#111111',lh:1.25,align:'left'});
  tShape('ellipse',.77,.82,.11,.11,'#1d3dff',{name:'Date circle'});tText('8TH\nMAR',0.77,0.82,{font:'Outfit',size:30,color:'#ffffff',lh:1.1});
  tShape('round',.5,.94,.4,.06,'#ffffff',{name:'Social box',p:{radius:12}});tText('@yourhandle',0.5,0.94,{font:'Outfit',size:28,color:'#111111'});
}},
{name:'Happy birthday portrait (dark)',cat:'Birthday',tags:'birthday black gold photo portrait woman stylish',w:1080,h:1080,build(){
  tGrad('#000000','#14100c',160);
  tPhoto(.62,.38,.62,.8,{name:'Photo (large)',fill:'#3a2f28'});
  tPhoto(.2,.5,.34,.46,{name:'Photo (small)',fill:'#5a4a3c',kind:'round',radius:30});
  tShape('ellipse',.2,.19,.2,.2,null,{name:'Date ring',p:{stroke:'#ffffff',sw:6,nofill:true}});
  tText('4TH\nFEB\n2026',0.2,0.19,{font:'Outfit',size:36,color:'#ffffff',lh:1.05});
  tText('H A P P Y   B I R T H D A Y',0.5,0.045,{font:'Outfit',size:24,color:'#ffffff'});
  tText('Your',0.57,0.65,{font:'Great Vibes',size:110,color:'#f0b98a'});
  tText('Name',0.5,0.75,{font:'Outfit',size:140,color:'#ffffff'});
  tText('May this new year of your life be filled with endless blessings,\nbeautiful moments, and dreams coming true.',0.5,0.92,{font:'Outfit',size:24,bold:false,color:'#ffffff',lh:1.2});
}},
{name:'Food and drinks promo',cat:'Business',tags:'food drinks chef restaurant catering red yellow photos order now',w:1080,h:1080,build(){
  tGrad('#c1121f','#7a0a12',180);
  tShape('round',.4,.4,.75,.4,'#ffd21f',{name:'Yellow card',p:{radius:50}});
  tShape('round',.2,.32,.2,.05,'#c1121f',{name:'Title bar',p:{radius:10}});
  tText('YOUR TITLE HERE',0.25,0.32,{font:'Outfit',size:30,color:'#ffffff'});
  tPhoto(.7,.28,.34,.46,{name:'Photo (chef / person)',fill:'#e8b8b0',kind:'round',radius:40});
  tShape('round',.45,.62,.9,.2,'#ffffff',{name:'Food strip',p:{radius:40}});
  [.12,.31,.5,.69].forEach((x,i)=>tPhoto(x,.62,.17,.16,{name:'Food photo '+(i+1),kind:'round',radius:14,fill:['#d9a27a','#c68a5a','#d8a868','#e0b878'][i]}));
  tPhoto(.85,.64,.26,.4,{name:'Photo (drinks)',fill:'#d8d0c8',kind:'round',radius:40});
  tCustom('burst',.82,.66,.17,.17,'#d81f2d',{name:'Chilled drinks badge'});
  tText('CHILLED\nDRINKS',0.82,0.66,{font:'Outfit',size:24,color:'#ffffff',lh:1});
  tShape('round',.2,.92,.34,.1,'#ffffff',{name:'Phone box',p:{radius:20}});
  tIcon('phone',.1,.92,.07,'#c1121f','#ffffff');
  tText('000 000 0000',0.28,0.92,{font:'Outfit',size:34,color:'#7a0a12'});
  tShape('round',.67,.93,.5,.1,'#ffd21f',{name:'Location box',p:{radius:20}});
  tIcon('pin',.5,.93,.07,'#c1121f','#ffffff');
  tText('Your location here',0.7,0.93,{font:'Outfit',size:30,color:'#7a0a12'});
}}
);
