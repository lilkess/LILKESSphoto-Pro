/* ===== High-quality scaling: sharp exports (text/shapes redrawn), resampling, DPI ===== */
function resampleCanvas(c,nw,nh,mode){
  nw=Math.max(1,Math.round(nw));nh=Math.max(1,Math.round(nh));
  mode=mode||'smooth';
  const step=(src,w,h,q)=>{const n=mkCanvas(w,h),x=n.getContext('2d');
    if(q==='nearest'){x.imageSmoothingEnabled=false;}else{x.imageSmoothingEnabled=true;x.imageSmoothingQuality=q;}
    x.drawImage(src,0,0,w,h);return n;};
  if(mode==='nearest')return step(c,nw,nh,'nearest');
  if(mode==='bilinear')return step(c,nw,nh,'low');
  let cur=c;
  // stepped resampling: never jump by more than 1.5x up or 2x down (much cleaner than one big stretch)
  for(let guard=0;guard<24&&(cur.width!==nw||cur.height!==nh);guard++){
    const fx=nw/cur.width,fy=nh/cur.height;
    const sx=fx>1?Math.min(fx,1.5):Math.max(fx,.5),sy=fy>1?Math.min(fy,1.5):Math.max(fy,.5);
    const w=(Math.abs(fx-1)<1e-6||sx===fx)?nw:Math.max(1,Math.round(cur.width*sx));
    const h=(Math.abs(fy-1)<1e-6||sy===fy)?nh:Math.max(1,Math.round(cur.height*sy));
    cur=step(cur,w,h,'high');
  }
  if(cur===c)cur=step(c,nw,nh,'high');
  if(mode==='detail'&&(nw>c.width||nh>c.height))cur=unsharpCanvas(cur,.6,Math.max(.6,Math.min(2,nw/c.width*.5)));
  return cur;
}
function unsharpCanvas(c,amount,radius){
  const w=c.width,h=c.height;
  const b=mkCanvas(w,h),bx=b.getContext('2d');
  if(!('filter' in bx))return c;
  bx.filter='blur('+radius+'px)';bx.drawImage(c,0,0);bx.filter='none';
  const o=c.getContext('2d'),A=o.getImageData(0,0,w,h),B=bx.getImageData(0,0,w,h),a=A.data,d=B.data;
  for(let i=0;i<a.length;i+=4){
    if(a[i+3]===0)continue;
    for(let k=0;k<3;k++){const v=a[i+k]+amount*(a[i+k]-d[i+k]);a[i+k]=v<0?0:v>255?255:v;}
  }
  const n=mkCanvas(w,h);n.getContext('2d').putImageData(A,0,0);return n;
}
/* draw the design on a bigger canvas; text, shapes and layer styles are redrawn at the new size, so edges stay crisp */
function hiResRun(k,fn){
  const keep=doc,keepFx=FX_SCALE;
  const W=Math.round(doc.w*k),H=Math.round(doc.h*k),kx=W/doc.w,ky=H/doc.h;
  const nd=Object.assign({},doc);nd.w=W;nd.h=H;nd.guides=[];
  if(doc.extra&&doc.extra.boards)nd.extra=Object.assign({},doc.extra,{boards:doc.extra.boards.map(b=>Object.assign({},b,{x:b.x*kx,y:b.y*ky,w:b.w*kx,h:b.h*ky}))});
  const rs=(c,m)=>resampleCanvas(c,c.width*kx,c.height*ky,m||S.exportRs||'smooth');
  nd.layers=doc.layers.map(l=>{
    const n=Object.assign({},l);delete n._fc;delete n._mc;delete n._gc;n.pv=null;n.pvv=0;
    n.x=l.x*kx;n.y=l.y*ky;n.ver=(l.ver||0)+1;n.mver=(l.mver||0)+1;
    if(l.props)n.props=JSON.parse(JSON.stringify(l.props));
    if(l.fx)n.fx=JSON.parse(JSON.stringify(l.fx));
    if(l.adj)n.adj=JSON.parse(JSON.stringify(l.adj));
    const mask=l.mask;
    if(l.type==='text'&&l.props){const p=n.props;p.size*=kx;p.sw=(p.sw||0)*kx;p.shadow=(p.shadow||0)*kx;n.canvas=mkCanvas(1,1);renderText(n);}
    else if(l.type==='shape'&&l.props&&l.props.kind!=='path'&&l.props.kind!=='custom'){const p=n.props;p.w*=kx;p.h*=kx;p.sw=(p.sw||0)*kx;p.radius=(p.radius||0)*kx;n.canvas=mkCanvas(1,1);renderShape(n);}
    else if(l.type!=='adjust'&&l.canvas){n.canvas=rs(l.canvas);}
    if(mask)n.mask=rs(mask,'bilinear');
    return n;
  });
  doc=nd;FX_SCALE=k;
  try{return fn();}finally{doc=keep;FX_SCALE=keepFx;}
}
/* write the print resolution into PNG / JPEG files */
async function setDpiBlob(blob,dpi){
  if(!dpi||!blob)return blob;
  try{
    const u=new Uint8Array(await blob.arrayBuffer());
    if(blob.type==='image/png'){
      const ppm=Math.round(dpi/0.0254),dv=new DataView(new ArrayBuffer(21)),b=new Uint8Array(dv.buffer);
      dv.setUint32(0,9);b.set([112,72,89,115],4);dv.setUint32(8,ppm);dv.setUint32(12,ppm);b[16]=1;
      const crc=crc32(b.subarray(4,17));dv.setUint32(17,crc>>>0);
      const at=33; // after signature(8)+IHDR(25)
      const out=new Uint8Array(u.length+21);out.set(u.subarray(0,at));out.set(b,at);out.set(u.subarray(at),at+21);
      return new Blob([out],{type:'image/png'});
    }
    if(blob.type==='image/jpeg'&&u[2]===0xFF&&u[3]===0xE0){
      u[13]=1;u[14]=dpi>>8;u[15]=dpi&255;u[16]=dpi>>8;u[17]=dpi&255;
      return new Blob([u],{type:'image/jpeg'});
    }
  }catch(e){}
  return blob;
}
