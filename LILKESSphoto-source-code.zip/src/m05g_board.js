/* ===== layer Fill + Lock row, drag-to-reorder layers, and real artboards ===== */

/* ---------- lock transparent pixels ---------- */
function applyAlphaLock(d){
  const c=d.tg,ctx=cctx(c),w=c.width,h=c.height,now=ctx.getImageData(0,0,w,h),bf=cctx(d.tlock).getImageData(0,0,w,h),a=now.data,b=bf.data;
  for(let i=0;i<a.length;i+=4){a[i+3]=b[i+3];if(!b[i+3]){a[i]=a[i+1]=a[i+2]=0;}}
  ctx.putImageData(now,0,0);touch(d.l);
}

/* ---------- Fill slider and the four Lock buttons in the Layers panel ---------- */
(function(){
  const sl=$('#tab-layers .row');
  sl.insertAdjacentHTML('afterend',
    '<div class="lockrow" role="group" aria-label="Lock"><span>Lock</span>'
    +'<button data-lk="t" title="Lock transparent pixels: paint only where there are already pixels" aria-label="Lock transparent pixels"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16"/><path d="M4 4h8v8H4zM12 12h8v8h-8z" fill="currentColor" stroke="none" opacity=".55"/></svg></button>'
    +'<button data-lk="i" title="Lock image pixels: no painting on this layer" aria-label="Lock image pixels"><svg viewBox="0 0 24 24"><path d="M4 20l1-4L16 5l3 3L8 19z"/></svg></button>'
    +'<button data-lk="p" title="Lock position: this layer cannot be moved" aria-label="Lock position"><svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/></svg></button>'
    +'<button data-lk="a" title="Lock all" aria-label="Lock all"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></button></div>'
    +'<div class="sl"><span>Fill</span><input type="range" id="l-fill" min="0" max="100" value="100"><output id="l-fillv">100</output></div>');
  $('#tab-layers').addEventListener('input',e=>{
    if(e.target.id!=='l-fill')return;const a=active();if(!a)return;
    a.fillOp=e.target.value/100;$('#l-fillv').textContent=e.target.value;pend=true;touch(a);
  });
  $('#tab-layers').addEventListener('click',e=>{
    const b=e.target.closest('[data-lk]');if(!b||!doc)return;const a=active();if(!a)return;flush();
    const k=b.dataset.lk;
    if(k==='a'){a.locked=!a.locked;commit(a.locked?'Lock all':'Unlock');}
    else{a.lk=Object.assign({t:false,i:false,p:false},a.lk);a.lk[k]=!a.lk[k];commit('Lock '+({t:'transparent pixels',i:'image pixels',p:'position'})[k]);}
    syncLocks();
  });
  function syncLocks(){
    const a=doc&&active(),lk=(a&&a.lk)||{};
    $$('#tab-layers [data-lk]').forEach(b=>{const k=b.dataset.lk;b.classList.toggle('on',!!a&&(k==='a'?a.locked:!!lk[k]));b.disabled=!a;});
    const f=$('#l-fill');if(f){const v=Math.round((a&&a.fillOp!=null?a.fillOp:1)*100);f.value=v;$('#l-fillv').textContent=v;}
  }
  const _rl=refreshLayers;
  refreshLayers=function(){_rl();syncLocks();};
})();

/* ---------- drag layers up and down to reorder ---------- */
(function(){
  const box=$('#layerlist');let st=null,ghost=null,line=null,swallow=false;
  const rowsOf=()=>[...box.querySelectorAll('.lrow')].filter(r=>r!==ghost);
  function begin(){
    st.active=true;st.row.classList.add('dragging');
    ghost=st.row.cloneNode(true);ghost.className='lrow ghost';ghost.style.width=st.row.offsetWidth+'px';document.body.appendChild(ghost);
    line=document.createElement('div');line.className='dropline';box.appendChild(line);
    if(navigator.vibrate)try{navigator.vibrate(12);}catch(err){}
  }
  function place(e){
    ghost.style.left=st.row.getBoundingClientRect().left+'px';ghost.style.top=(e.clientY-ghost.offsetHeight/2)+'px';
    const rows=rowsOf(),pos=rows.filter(r=>{const b=r.getBoundingClientRect();return b.top+b.height/2<e.clientY;}).length;
    const br=box.getBoundingClientRect();let y,tgt=null,bd='';st.noMove=false;
    const over=[...box.querySelectorAll('.brow')].find(h=>{const r=h.getBoundingClientRect();return e.clientY>=r.top&&e.clientY<=r.bottom;});
    if(over){
      const nx=over.nextElementSibling;bd=over.dataset.bdid||'';y=over.getBoundingClientRect().bottom;
      if(nx&&nx.classList.contains('lrow')&&nx!==st.row){st.before=nx;st.afterRow=null;}else{st.before=null;st.afterRow=null;st.noMove=true;}
    }else if(pos<rows.length){
      tgt=rows[pos];bd=tgt.dataset.bd||'';
      const hd=tgt.previousElementSibling;
      if(pos>0&&hd&&hd.classList.contains('brow')&&hd.getBoundingClientRect().top+hd.offsetHeight/2>e.clientY){ // bottom of the board above
        const pr=rows[pos-1];bd=pr.dataset.bd||'';y=pr.getBoundingClientRect().bottom;st.afterRow=pr;st.before=null;
      }else{y=tgt.getBoundingClientRect().top;st.before=tgt;st.afterRow=null;}
    }else{
      if(rows.length){const b=rows[rows.length-1].getBoundingClientRect();y=b.bottom;bd=rows[rows.length-1].dataset.bd||'';st.afterRow=rows[rows.length-1];st.before=null;}else y=br.top;
    }
    st.pos=pos;st.bd=bd;
    line.style.top=(y-br.top+box.scrollTop-1)+'px';
    const edge=28;if(e.clientY<br.top+edge)box.scrollTop-=8;else if(e.clientY>br.bottom-edge)box.scrollTop+=8;
  }
  function end(drop){
    clearTimeout(st.timer);
    if(st.active){
      st.row.classList.remove('dragging');ghost&&ghost.remove();line&&line.remove();ghost=line=null;swallow=true;setTimeout(()=>{swallow=false;},60);
      if(drop&&doc){
        const mv=doc.layers.find(l=>l.id===+st.row.dataset.id);
        const V=[...doc.layers].reverse(),from=V.indexOf(mv);
        let ti=-1;
        if(st.before)ti=V.findIndex(l=>l.id===+st.before.dataset.id);
        else if(st.afterRow)ti=V.findIndex(l=>l.id===+st.afterRow.dataset.id)+1;
        else ti=V.length;
        let changed=false;
        if(mv&&ti>=0&&!st.noMove){
          V.splice(from,1);if(ti>from)ti--;V.splice(ti,0,mv);
          const nl=V.slice().reverse();if(nl.some((l,k)=>l!==doc.layers[k]))changed=true;
          flush();doc.layers=nl;
        }
        const nb=(doc.extra&&doc.extra.boards||[]).find(b=>b.id===st.bd)||null,ob=layerBoard(mv);
        if(mv&&(doc.extra&&doc.extra.boards||[]).length&&nb&&nb!==ob){mv.bd=nb.id;if(ob){mv.x+=nb.x-ob.x;mv.y+=nb.y-ob.y;mv._mc=null;mv._fc=null;}changed=true;S.bsel=doc.extra.boards.indexOf(nb);}
        if(changed){commit('Arrange layers');redraw();}
      }
    }
    st=null;
  }
  box.addEventListener('pointerdown',e=>{
    if(!doc||(e.pointerType==='mouse'&&e.button!==0))return;
    const row=e.target.closest('.lrow');if(!row||e.target.closest('input,button.eye'))return;
    st={row,x:e.clientX,y:e.clientY,active:false,pos:0,touch:e.pointerType!=='mouse'};
    if(st.touch)st.timer=setTimeout(()=>{if(st&&!st.active){st.ready=true;if(navigator.vibrate)try{navigator.vibrate(10);}catch(err){}}},320);
  });
  document.addEventListener('pointermove',e=>{
    if(!st)return;
    if(!st.active){
      const d=Math.hypot(e.clientX-st.x,e.clientY-st.y);
      if(st.touch){if(st.ready){if(d>6)begin();else return;}else{if(d>10){clearTimeout(st.timer);st=null;}return;}}
      else{if(d>5)begin();else return;}
    }
    place(e);
  });
  document.addEventListener('pointerup',()=>{if(st)end(true);});
  document.addEventListener('pointercancel',()=>{if(st)end(false);});
  box.addEventListener('touchmove',e=>{if(st&&(st.active||st.ready)&&e.cancelable)e.preventDefault();},{passive:false});
  box.addEventListener('click',e=>{if(swallow){e.stopPropagation();e.preventDefault();}},true);
  box.addEventListener('contextmenu',e=>{if(st&&st.active)e.preventDefault();});
})();

/* ---------- Artboards ---------- */
const BOARD_PRESETS=[['custom','Custom'],['ig','Instagram post 1080 × 1080',1080,1080],['story','Story / Reel 1080 × 1920',1080,1920],['phone','Phone screen 1170 × 2532',1170,2532],['a4','A4 page 2480 × 3508',2480,3508],['hd','Desktop 1920 × 1080',1920,1080],['fb','Facebook cover 1640 × 624',1640,624],['yt','YouTube thumbnail 1280 × 720',1280,720],['card','Business card 1050 × 600',1050,600],['logo','Logo 1000 × 1000',1000,1000]];
S.bsel=-1;S.bpre='ig';
const boards=()=>exa('boards');
function drawBoardsBg(ctx){
  if(!doc||!doc.extra||!doc.extra.boards||!doc.extra.boards.length)return;
  for(const b of doc.extra.boards){if(b.bg){ctx.fillStyle=b.bg;ctx.fillRect(b.x,b.y,b.w,b.h);}}
}
function growDocTo(x0,y0,x1,y1){
  const nx=Math.min(0,Math.floor(x0)),ny=Math.min(0,Math.floor(y0)),W=Math.ceil(Math.max(doc.w,x1))-nx,H=Math.ceil(Math.max(doc.h,y1))-ny;
  if(nx===0&&ny===0&&W===doc.w&&H===doc.h)return {dx:0,dy:0};
  for(const l of doc.layers){l.x-=nx;l.y-=ny;l._mc=null;l._fc=null;}
  boards().forEach(b=>{b.x-=nx;b.y-=ny;});
  (doc.extra.paths||[]);if(doc.paths)doc.paths.forEach(p=>{p.path=vec_translate(p.path,-nx,-ny);});
  doc.w=W;doc.h=H;doc.guides=[];S.sel=null;resizeStage();return {dx:-nx,dy:-ny};
}
function boardMembers(b){return doc.layers.filter(l=>layerBoard(l)===b);}
function boardAt(p){const L=boards();for(let i=L.length-1;i>=0;i--){const b=L[i];if(p.x>=b.x&&p.x<=b.x+b.w&&p.y>=b.y&&p.y<=b.y+b.h)return i;}return -1;}
function wrapFirstBoard(){
  const L=boards();if(L.length)return;
  const b0={name:'Artboard 1',x:0,y:0,w:doc.w,h:doc.h,bg:null};bid(b0);L.push(b0);doc.layers.forEach(l=>{l.bd=b0.id;});
}
function createBoard(x,y,w,h,name){
  wrapFirstBoard();
  const g=growDocTo(x,y,x+w,y+h);x+=g.dx;y+=g.dy;
  const L=boards();L.push({name:name||'Artboard '+(L.length+1),x:Math.round(x),y:Math.round(y),w:Math.round(w),h:Math.round(h),bg:'#ffffff'});
  S.bsel=L.length-1;commit('New artboard');redraw();renderOpts();
}
function presetSize(){const p=BOARD_PRESETS.find(q=>q[0]===S.bpre);return p&&p[2]?[p[2],p[3]]:[1080,1080];}
function handleHit(b,p){
  const t=14/S.zoom,cs=[[b.x,b.y,'nw'],[b.x+b.w,b.y,'ne'],[b.x+b.w,b.y+b.h,'se'],[b.x,b.y+b.h,'sw']];
  for(const c of cs)if(Math.hypot(p.x-c[0],p.y-c[1])<t)return c[2];return null;
}
TOOLS.artboard={
  opts(){
    const b=doc&&boards()[S.bsel];
    return '<label class="opt">Size '+sel('o-bpre',BOARD_PRESETS.map(q=>[q[0],q[1]]),S.bpre)+'</label><button class="primary" data-act="boardAdd">Add artboard</button>'
      +(b?'<span class="vsep"></span><label class="opt">Name <input type="text" id="o-bname" value="'+esc(b.name)+'" style="width:110px"></label><label class="opt">W <input type="number" id="o-bw" value="'+b.w+'" style="width:70px"></label><label class="opt">H <input type="number" id="o-bh" value="'+b.h+'" style="width:70px"></label><label class="opt">Colour <input type="color" id="o-bbg" value="'+(b.bg||'#ffffff')+'"></label><button data-act="boardDup">Duplicate</button><button data-act="boardFit">Zoom to it</button><button data-act="boardExport">Export</button><button data-act="boardDel">Delete</button>'
        :'<span class="opt muted">Drag on the canvas to draw an artboard, or tap one to select it. Drag it to move it with its layers.</span>');
  },
  down(p){
    const L=boards();
    if(S.bsel>=0&&L[S.bsel]){const h=handleHit(L[S.bsel],p);if(h){drag={k:'x',tool:'artboard',mode:'resize',h,b:L[S.bsel],o:Object.assign({},L[S.bsel]),p0:p};return;}}
    const i=boardAt(p);
    if(i>=0){S.bsel=i;const b=L[i];drag={k:'x',tool:'artboard',mode:'move',b,mem:boardMembers(b),p0:p,o:{x:b.x,y:b.y},moved:false,lx:p.x,ly:p.y};renderOpts();redraw();return;}
    S.bsel=-1;drag={k:'x',tool:'artboard',mode:'draw',p0:p,p1:p};renderOpts();
  },
  move(p){
    const d=drag;
    if(d.mode==='draw'){d.p1=p;}
    else if(d.mode==='move'){
      const dx=Math.round(p.x-d.p0.x),dy=Math.round(p.y-d.p0.y);if(!d.moved&&Math.hypot(dx,dy)*S.zoom<3)return;d.moved=true;
      const ox=d.b.x,oy=d.b.y;d.b.x=d.o.x+dx;d.b.y=d.o.y+dy;const ddx=d.b.x-ox,ddy=d.b.y-oy;
      d.mem.forEach(l=>{l.x+=ddx;l.y+=ddy;});
    }else{
      const o=d.o,b=d.b;let x0=o.x,y0=o.y,x1=o.x+o.w,y1=o.y+o.h;
      if(d.h.includes('w'))x0=Math.min(p.x,x1-20);else x1=Math.max(p.x,x0+20);
      if(d.h.includes('n'))y0=Math.min(p.y,y1-20);else y1=Math.max(p.y,y0+20);
      b.x=Math.round(x0);b.y=Math.round(y0);b.w=Math.round(x1-x0);b.h=Math.round(y1-y0);
    }
    redraw();
  },
  up(d,p){
    if(d.mode==='draw'){const w=Math.abs(p.x-d.p0.x),h=Math.abs(p.y-d.p0.y);if(w>20&&h>20)createBoard(Math.min(p.x,d.p0.x),Math.min(p.y,d.p0.y),w,h);else if(w<6&&h<6){const [pw,ph]=presetSize();createBoard(p.x-pw/2,p.y-ph/2,pw,ph);}}
    else if(d.mode==='resize'){let b=d.b;const g=growDocTo(b.x,b.y,b.x+b.w,b.y+b.h);commit('Resize artboard');renderOpts();}
    else if(d.moved){const b=d.b,g=growDocTo(b.x,b.y,b.x+b.w,b.y+b.h);commit('Move artboard');}
    redraw();
  },
  dbl(p){const i=boardAt(p);if(i>=0){S.bsel=i;ACT.boardFit();}},
  key(c){if((c==='Delete'||c==='Backspace')&&S.bsel>=0){ACT.boardDel();return true;}return false;},
  over(o,z){
    const L=boards();
    L.forEach((b,i)=>{
      o.save();o.lineWidth=(i===S.bsel?2:1)/z;o.strokeStyle=i===S.bsel?'#4b9eff':'rgba(255,255,255,.55)';o.strokeRect(b.x,b.y,b.w,b.h);
      o.fillStyle=i===S.bsel?'#4b9eff':'#ddd';o.font=(13/z)+'px sans-serif';o.fillText(b.name+'  '+b.w+' × '+b.h,b.x,b.y-6/z);
      if(i===S.bsel){o.fillStyle='#fff';const hs=12/z;[[b.x,b.y],[b.x+b.w,b.y],[b.x+b.w,b.y+b.h],[b.x,b.y+b.h]].forEach(c=>{o.fillRect(c[0]-hs/2,c[1]-hs/2,hs,hs);o.strokeRect(c[0]-hs/2,c[1]-hs/2,hs,hs);});}
      o.restore();
    });
    const d=drag;if(d&&d.tool==='artboard'&&d.mode==='draw'){o.save();o.strokeStyle='#4b9eff';o.lineWidth=1.5/z;o.setLineDash([6/z,4/z]);o.strokeRect(Math.min(d.p0.x,d.p1.x),Math.min(d.p0.y,d.p1.y),Math.abs(d.p1.x-d.p0.x),Math.abs(d.p1.y-d.p0.y));o.restore();}
  }
};
/* names of boards are drawn on the canvas whenever any tool is active, so you always see them */
const _dto=drawToolOver;
drawToolOver=function(o,z){
  _dto(o,z);
  if(S.tool==='artboard'||!doc||!doc.extra||!doc.extra.boards)return;
  doc.extra.boards.forEach(b=>{o.save();o.lineWidth=1/z;o.strokeStyle='rgba(255,255,255,.35)';o.strokeRect(b.x,b.y,b.w,b.h);o.fillStyle='rgba(255,255,255,.8)';o.font=(12/z)+'px sans-serif';o.fillText(b.name,b.x,b.y-5/z);o.restore();});
};
$('#opts').addEventListener('input',e=>{
  const t=e.target;if(!doc)return;
  if(t.id==='o-bpre'){S.bpre=t.value;return;}
  const b=boards()[S.bsel];if(!b)return;
  if(t.id==='o-bname'){b.name=t.value;redraw();}
  else if(t.id==='o-bbg'){b.bg=t.value;redraw();pend=true;}
  else if(t.id==='o-bw'||t.id==='o-bh'){const v=Math.max(20,Math.round(+t.value||20));if(t.id==='o-bw')b.w=v;else b.h=v;growDocTo(b.x,b.y,b.x+b.w,b.y+b.h);redraw();pend=true;}
});
$('#opts').addEventListener('change',e=>{if(/^o-b(name|bg|w|h)$/.test(e.target.id)&&pend){pend=false;commit('Artboard settings');}});
ACT.boardAdd=D(()=>{
  const [w,h]=presetSize(),L=boards();let x=0,y=0;
  if(L.length){const r=Math.max(...L.map(b=>b.x+b.w));x=r+60;y=L[L.length-1].y;}else{x=doc.w+60;y=0;}
  createBoard(x,y,w,h);S.autoFit=true;fitView();
});
ACT.boardDel=D(()=>{
  const L=boards(),b=L[S.bsel];if(!b){toast('Select an artboard first');return;}
  const mem=boardMembers(b);
  if(mem.length){const ids=new Set(mem.map(l=>l.id));doc.layers=doc.layers.filter(l=>!ids.has(l.id));if(!doc.layers.find(l=>l.id===doc.active))doc.active=doc.layers.length?doc.layers[doc.layers.length-1].id:null;}
  L.splice(S.bsel,1);S.bsel=-1;commit('Delete artboard');refreshLayers();renderOpts();redraw();
});
ACT.boardDup=D(()=>{
  const L=boards(),b=L[S.bsel];if(!b){toast('Select an artboard first');return;}
  const mem=boardMembers(b),nx=b.x+b.w+60,ny=b.y,dx=nx-b.x;
  const g=growDocTo(nx,ny,nx+b.w,ny+b.h);
  const nb=Object.assign({},b,{name:b.name+' copy',x:nx+g.dx,y:ny+g.dy});delete nb.id;bid(nb);
  const mem2=boardMembers(b);
  mem2.forEach(l=>{const n=dupLayer(l,0);n.x=l.x+(nb.x-b.x-g.dx*0)+0;n.name=l.name;n.bd=nb.id;});
  L.push(nb);S.bsel=L.length-1;commit('Duplicate artboard');refreshLayers();renderOpts();redraw();
});
ACT.boardFit=D(()=>{
  const b=boards()[S.bsel];if(!b)return;const r=vp.getBoundingClientRect(),m=30;
  S.zoom=clamp(Math.min((r.width-m*2)/b.w,(r.height-m*2)/b.h),0.02,8);S.px=(r.width-b.w*S.zoom)/2-b.x*S.zoom;S.py=(r.height-b.h*S.zoom)/2-b.y*S.zoom;S.autoFit=false;applyView();
});
async function exportBoard(b,i){
  const src=mkCanvas(doc.w,doc.h);compose(cctx(src),1);
  const c=mkCanvas(b.w,b.h);cctx(c).drawImage(src,b.x,b.y,b.w,b.h,0,0,b.w,b.h);
  const blob=await new Promise(r=>c.toBlob(r,'image/png'));
  await saveBlob(blob,((doc.name||'design')+'_'+b.name).replace(/[^\w\-]+/g,'_')+'.png');
}
ACT.boardExport=D(async()=>{const b=boards()[S.bsel];if(!b){toast('Select an artboard first');return;}await exportBoard(b);});
ACT.boardExportAll=D(async()=>{const L=boards();if(!L.length){toast('Make an artboard first with the Artboard tool');return;}for(let i=0;i<L.length;i++)await exportBoard(L[i],i);});

/* ---------- "+" buttons around each artboard, pasteboard margin ---------- */
const BOARD_GAP=60,BOARD_MARGIN=220;
function ensureMargin(){
  const L=boards();if(!L.length)return;
  const x0=Math.min(...L.map(b=>b.x)),y0=Math.min(...L.map(b=>b.y)),x1=Math.max(...L.map(b=>b.x+b.w)),y1=Math.max(...L.map(b=>b.y+b.h));
  growDocTo(x0-BOARD_MARGIN,y0-BOARD_MARGIN,x1+BOARD_MARGIN,y1+BOARD_MARGIN);
}
function plusSpots(b){
  const o=26/S.zoom,L=boards();
  const all=[['r',b.x+b.w+o,b.y+b.h/2],['l',b.x-o,b.y+b.h/2],['b',b.x+b.w/2,b.y+b.h+o],['t',b.x+b.w/2,b.y-o]];
  return all.filter(s=>{
    const nx=s[0]==='r'?b.x+b.w+BOARD_GAP+b.w/2:s[0]==='l'?b.x-BOARD_GAP-b.w/2:b.x+b.w/2,ny=s[0]==='b'?b.y+b.h+BOARD_GAP+b.h/2:s[0]==='t'?b.y-BOARD_GAP-b.h/2:b.y+b.h/2;
    return !L.some(q=>nx>q.x&&nx<q.x+q.w&&ny>q.y&&ny<q.y+q.h);
  });
}
function addBoardBeside(b,side){
  let x=b.x,y=b.y;
  if(side==='r')x=b.x+b.w+BOARD_GAP;else if(side==='l')x=b.x-b.w-BOARD_GAP;else if(side==='b')y=b.y+b.h+BOARD_GAP;else y=b.y-b.h-BOARD_GAP;
  const L=boards(),src=b,bg=b.bg||'#ffffff';
  const g=growDocTo(x-BOARD_MARGIN,y-BOARD_MARGIN,x+b.w+BOARD_MARGIN,y+b.h+BOARD_MARGIN);
  L.push({name:'Artboard '+(L.length+1),x:Math.round(x+g.dx),y:Math.round(y+g.dy),w:src.w,h:src.h,bg});
  S.bsel=L.length-1;ensureMargin();commit('New artboard');renderOpts();redraw();
}
const _bd=TOOLS.artboard.down;
TOOLS.artboard.down=function(p,e){
  const L=boards(),r=18/S.zoom;
  for(let i=0;i<L.length;i++)for(const s of plusSpots(L[i])){if(Math.hypot(p.x-s[1],p.y-s[2])<r){addBoardBeside(L[i],s[0]);S.autoFit=true;fitView();return;}}
  return _bd.call(this,p,e);
};
const _bo=TOOLS.artboard.over;
TOOLS.artboard.over=function(o,z){
  _bo.call(this,o,z);
  boards().forEach(b=>plusSpots(b).forEach(s=>{
    const r=13/z;o.save();o.fillStyle='#4b9eff';o.strokeStyle='#fff';o.lineWidth=2/z;o.beginPath();o.arc(s[1],s[2],r,0,7);o.fill();o.stroke();
    o.beginPath();o.moveTo(s[1]-r*.5,s[2]);o.lineTo(s[1]+r*.5,s[2]);o.moveTo(s[1],s[2]-r*.5);o.lineTo(s[1],s[2]+r*.5);o.stroke();o.restore();
  }));
};
TOOLS.artboard.hover=function(p){S.bhov=p;};
/* the first time the tool is picked, the current sheet becomes Artboard 1 so its "+" buttons show at once */
(function(){
  const _ts=toolSwitch;
  toolSwitch=function(a,b){
    _ts(a,b);
    if(b==='artboard'&&a!=='artboard'&&doc){
      const had=boards().length>0;wrapFirstBoard();
      const b0=boards()[0];if(b0&&!b0.bg)b0.bg='#ffffff';
      const w0=doc.w,h0=doc.h;ensureMargin();
      if(S.bsel<0)S.bsel=0;
      if(!had||doc.w!==w0||doc.h!==h0){commit('Artboards');S.autoFit=true;setTimeout(fitView,0);}
    }
  };
  const _dto2=drawToolOver;
  drawToolOver=function(o,z){document.body.classList.toggle('has-boards',!!(doc&&doc.extra&&doc.extra.boards&&doc.extra.boards.length));_dto2(o,z);};
})();
/* the hint in the options bar */
(function(){const _o=TOOLS.artboard.opts;TOOLS.artboard.opts=function(){return _o.call(this).replace(/<span class="opt muted">[^<]*<\/span>$/,'<span class="opt muted">Tap the blue + beside a sheet to add another sheet. Drag a sheet to move it with its layers.</span>');};})();
