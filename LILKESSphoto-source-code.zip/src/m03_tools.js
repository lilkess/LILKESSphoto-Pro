
/* ===== regions: bucket fill, magic wand ===== */
function regionMask(l,px,py,tol,contig){
  const c=l.canvas,w=c.width,h=c.height;px=Math.floor(px);py=Math.floor(py);
  if(px<0||py<0||px>=w||py>=h)return null;
  const d=cctx(c).getImageData(0,0,w,h).data,i0=(py*w+px)*4,tr=d[i0],tg=d[i0+1],tb=d[i0+2],ta=d[i0+3],m=new Uint8Array(w*h);
  const match=ta<10?(i=>d[i+3]<10):(i=>Math.abs(d[i]-tr)<=tol&&Math.abs(d[i+1]-tg)<=tol&&Math.abs(d[i+2]-tb)<=tol&&Math.abs(d[i+3]-ta)<=tol*1.5);
  if(!contig){for(let k=0;k<w*h;k++)if(match(k*4))m[k]=1;return {m,w,h};}
  const stack=[px,py];
  while(stack.length){
    const y=stack.pop();let x=stack.pop(),xl=x;
    while(xl>=0&&!m[y*w+xl]&&match((y*w+xl)*4))xl--;
    xl++;let up=false,dn=false;
    for(let xx=xl;xx<w&&!m[y*w+xx]&&match((y*w+xx)*4);xx++){
      m[y*w+xx]=1;
      if(y>0){const ok=!m[(y-1)*w+xx]&&match(((y-1)*w+xx)*4);if(ok&&!up){stack.push(xx,y-1);up=true;}else if(!ok)up=false;}
      if(y<h-1){const ok=!m[(y+1)*w+xx]&&match(((y+1)*w+xx)*4);if(ok&&!dn){stack.push(xx,y+1);dn=true;}else if(!ok)dn=false;}
    }
  }
  return {m,w,h};
}
function applyRegion(l,rg,rgba){
  const ctx=cctx(l.canvas),id=ctx.getImageData(0,0,rg.w,rg.h),d=id.data;
  for(let k=0;k<rg.m.length;k++)if(rg.m[k]){const i=k*4;if(rgba){d[i]=rgba[0];d[i+1]=rgba[1];d[i+2]=rgba[2];d[i+3]=rgba[3];}else d[i+3]=0;}
  ctx.putImageData(id,0,0);touch(l);
}
function regionToSelection(l,rg,mode){
  const lc=mkCanvas(rg.w,rg.h),lx=cctx(lc),id=lx.createImageData(rg.w,rg.h),d=id.data;
  for(let k=0;k<rg.m.length;k++)if(rg.m[k]){d[k*4]=d[k*4+1]=d[k*4+2]=255;d[k*4+3]=255;}
  lx.putImageData(id,0,0);
  const n=selNew();n.ctx.save();n.ctx.translate(l.x,l.y);n.ctx.rotate(l.r);n.ctx.scale(l.s,l.s);n.ctx.drawImage(lc,-rg.w/2,-rg.h/2);n.ctx.restore();
  setSelection(n.c,mode);
}
function withSel(l,fn){
  if(!S.sel){fn();return;}
  const ctx=cctx(l.canvas),w=l.canvas.width,h=l.canvas.height,before=ctx.getImageData(0,0,w,h);
  fn();
  const after=ctx.getImageData(0,0,w,h),sa=selAlphaLocal(l);
  ctx.putImageData(mixSel(before,after,sa),0,0);touch(l);
}
function restrictCanvasToSel(l){
  if(!S.sel)return;const sc2=selAlphaCanvasLocal(l),x=l.canvas.getContext('2d');
  x.save();x.globalCompositeOperation='destination-in';x.drawImage(sc2,0,0);x.restore();touch(l);
}

/* ===== painting ===== */
function stamp(ctx,x,y,r,hard,rgb,a,erase){
  ctx.save();ctx.globalCompositeOperation=erase?'destination-out':'source-over';
  const col=erase?'0,0,0':rgb.join(',');
  if(hard>=0.99){ctx.fillStyle='rgba('+col+','+a+')';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();}
  else{const g=ctx.createRadialGradient(x,y,r*hard*0.9,x,y,r);g.addColorStop(0,'rgba('+col+','+a+')');g.addColorStop(1,'rgba('+col+',0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);}
  ctx.restore();
}
const pressureFactor=e=>(e&&e.pointerType==='pen'&&e.pressure>0)?0.25+0.75*e.pressure:1;
function paintLayerFor(erase){
  let l=active();
  if(!l){if(erase)return null;l=addLayer({name:'Layer'});refreshLayers();return l;}
  if(pxLocked(l)){toast('This layer is locked');return null;}
  if(l.editMask&&l.mask)return l;
  if(l.smart){toast('This is a smart object. Double-click its icon to edit the contents, or rasterize it to paint.');return null;}
  if(l.type==='adjust'){toast('Select a picture layer to paint on');return null;}
  if(l.type==='text'||l.type==='shape'){
    if(erase){rasterize(l);toast('Layer converted to pixels so it can be erased');renderProps();}
    else{l=addLayer({name:'Paint',above:true});refreshLayers();}
  }
  return l;
}
function restrictSeg(d,a,b,rad){
  if(!d.sel)return;
  const W=d.tg.width,H=d.tg.height,pad=Math.ceil(rad+4);
  const x0=Math.max(0,Math.floor(Math.min(a.x,b.x)-pad)),y0=Math.max(0,Math.floor(Math.min(a.y,b.y)-pad));
  const x1=Math.min(W,Math.ceil(Math.max(a.x,b.x)+pad)),y1=Math.min(H,Math.ceil(Math.max(a.y,b.y)+pad)),w=x1-x0,h=y1-y0;
  if(w<=0||h<=0)return;
  const out=mkCanvas(w,h),ox=out.getContext('2d');
  ox.drawImage(d.before,x0,y0,w,h,0,0,w,h);
  ox.globalCompositeOperation='destination-out';ox.drawImage(d.sel,x0,y0,w,h,0,0,w,h);
  const t=mkCanvas(w,h),tx=t.getContext('2d');
  tx.drawImage(d.tg,x0,y0,w,h,0,0,w,h);tx.globalCompositeOperation='destination-in';tx.drawImage(d.sel,x0,y0,w,h,0,0,w,h);
  ox.globalCompositeOperation='lighter';ox.drawImage(t,0,0);
  const c=d.tg.getContext('2d');c.clearRect(x0,y0,w,h);c.drawImage(out,x0,y0);
}
function paintSeg(d,a,b,first){
  const ctx=d.tg.getContext('2d'),rl=d.prm.size*d.pf/2/d.l.s,sp=Math.max(0.6,rl*2*(S.bs.spacing/100));
  const n=first?1:Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/sp));
  const al=d.prm.flow>=0.99?1:1-Math.pow(1-d.prm.flow,0.1);
  for(let i=1;i<=n;i++){const t=first?1:i/n;stamp(ctx,a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,rl,d.prm.hard,d.rgb,al,d.erase);}
  restrictSeg(d,a,b,rl);d.last=b;
  if(d.mask)touchMask(d.l);else touch(d.l);
}
function paintDown(p,e,erase){
  const l=paintLayerFor(erase);if(!l)return;
  const maskMode=!!(l.editMask&&l.mask),tg=maskMode?l.mask:l.canvas,lp=toLocal(l,p),prm=erase?S.eraser:S.brush;
  let er=erase;if(maskMode)er=(lumHex(S.fg)<128)!==erase;
  drag={k:'paint',l,tg,mask:maskMode,erase:er,prm,last:lp,rgb:maskMode?[255,255,255]:hexRgb(S.fg),pf:pressureFactor(e),sel:null,before:null};
  if(S.sel){drag.sel=selAlphaCanvasLocal(l);drag.before=cloneCanvas(tg);}
  if(l.lk&&l.lk.t&&!maskMode)drag.tlock=cloneCanvas(tg);
  paintSeg(drag,lp,lp,true);
}
function retouchStamp(l,lx,ly,r,str,mode,off){
  const c=l.canvas,ctx=cctx(c);
  const x0=Math.max(0,Math.floor(lx-r)),y0=Math.max(0,Math.floor(ly-r)),x1=Math.min(c.width,Math.ceil(lx+r)),y1=Math.min(c.height,Math.ceil(ly+r));
  const w=x1-x0,h=y1-y0;if(w<2||h<2)return;
  const id=ctx.getImageData(x0,y0,w,h),d=id.data;
  let bl=null,sd=null;
  if(mode==='blur'||mode==='smooth'||mode==='sharpen'){bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(1,Math.round(r/9)),2);}
  if(mode==='clone'||mode==='smudge')sd=ctx.getImageData(Math.round(x0+off.x),Math.round(y0+off.y),w,h).data;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const dist=Math.hypot(x+x0-lx,y+y0-ly)/r;if(dist>=1)continue;
    const f=Math.pow(1-dist*dist,1.3)*str,i=(y*w+x)*4;
    if(mode==='blur'){for(let k=0;k<3;k++)d[i+k]+=(bl[i+k]-d[i+k])*f;}
    else if(mode==='smooth'){
      const diff=(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])-(0.299*bl[i]+0.587*bl[i+1]+0.114*bl[i+2]);
      const k2=f*Math.exp(-(diff*diff)/(2*22*22));
      for(let k=0;k<3;k++)d[i+k]+=(bl[i+k]-d[i+k])*k2;
    }
    else if(mode==='sharpen'){for(let k=0;k<3;k++)d[i+k]+=(d[i+k]-bl[i+k])*f*1.5;}
    else if(mode==='lighten'){for(let k=0;k<3;k++)d[i+k]+=(255-d[i+k])*f*0.14;}
    else if(mode==='darken'){for(let k=0;k<3;k++)d[i+k]*=1-f*0.14;}
    else if(mode==='sponge'){const g=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],k2=S.retouch.sponge==='sat'?1+f*0.18:1-f*0.18;for(let k=0;k<3;k++)d[i+k]=clamp(g+(d[i+k]-g)*k2,0,255);}
    else if(mode==='clone'){for(let k=0;k<4;k++)d[i+k]+=(sd[i+k]-d[i+k])*Math.min(1,f*1.6);}
    else if(mode==='smudge'){for(let k=0;k<4;k++)d[i+k]+=(sd[i+k]-d[i+k])*Math.min(1,f*1.1);}
  }
  ctx.putImageData(id,x0,y0);
}
function retSeg(d,a,b,first){
  const r=S.retouch.size*d.pf/2/d.l.s,sp=Math.max(2,r*0.25),mode=S.retouch.mode;
  const n=first?1:Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/sp));
  let pv=a;
  for(let i=1;i<=n;i++){
    const t=first?1:i/n,c2={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};
    const off=mode==='smudge'?{x:pv.x-c2.x,y:pv.y-c2.y}:d.off;
    retouchStamp(d.l,c2.x,c2.y,r,S.retouch.strength,mode,off);pv=c2;
  }
  restrictSeg(d,a,b,r);d.last=b;touch(d.l);
}
function retouchDown(p,e){
  const l=active();
  if(!l||pxLocked(l)){toast('Select an unlocked photo or paint layer first');return;}
  if(l.smart||l.type==='adjust'){toast('Rasterize this layer before retouching it');return;}
  if(l.type==='text'||l.type==='shape'){rasterize(l);toast('Layer converted to pixels');renderProps();}
  const lp=toLocal(l,p);
  if(S.retouch.mode==='clone'){
    if(S.settingSrc||!S.srcPt||S.srcPt.id!==l.id){S.srcPt={x:lp.x,y:lp.y,id:l.id};S.settingSrc=false;toast('Source set. Now paint where you want the copy.');renderOpts();redraw();return;}
    drag={k:'retouch',l,tg:l.canvas,last:lp,off:{x:S.srcPt.x-lp.x,y:S.srcPt.y-lp.y},pf:pressureFactor(e),sel:null,before:null};
  }else drag={k:'retouch',l,tg:l.canvas,last:lp,off:null,pf:pressureFactor(e),sel:null,before:null};
  if(S.sel){drag.sel=selAlphaCanvasLocal(l);drag.before=cloneCanvas(l.canvas);}
  if(l.lk&&l.lk.t)drag.tlock=cloneCanvas(l.canvas);
  retSeg(drag,lp,lp,true);
}
function fillDown(p,e){
  const l=active();
  if(!l||pxLocked(l)){toast('Select an unlocked layer first');return;}
  if(l.smart||l.type==='adjust'){toast('Rasterize this layer first');return;}
  if(l.type==='text'||l.type==='shape'){rasterize(l);toast('Layer converted to pixels');renderProps();}
  const lp=toLocal(l,p),rg=regionMask(l,lp.x,lp.y,S.fill.tol,S.fill.contig!==false);
  if(!rg){toast('Tap inside the layer');return;}
  const erase=S.fill.mode==='erase',c=hexRgb(S.fg);
  withSel(l,()=>applyRegion(l,rg,erase?null:[c[0],c[1],c[2],255]));
  commit(erase?'Magic eraser':'Paint bucket');
}
function gradientLayer(p0,p1){
  const l=addLayer({name:'Gradient',above:true}),ctx=cctx(l.canvas);let g;
  if(S.grad.kind==='radial')g=ctx.createRadialGradient(p0.x,p0.y,0,p0.x,p0.y,Math.max(1,Math.hypot(p1.x-p0.x,p1.y-p0.y)));
  else g=ctx.createLinearGradient(p0.x,p0.y,p1.x,p1.y);
  g.addColorStop(0,S.fg);g.addColorStop(1,S.grad.mode==='fgbg'?S.bg:rgbaStr(S.fg,0));
  ctx.fillStyle=g;ctx.fillRect(0,0,l.canvas.width,l.canvas.height);touch(l);restrictCanvasToSel(l);
}
function pickAt(p){
  render();const x=clamp(Math.floor(p.x),0,doc.w-1),y=clamp(Math.floor(p.y),0,doc.h-1);
  const px=vctx.getImageData(x,y,1,1).data;
  if(px[3]>0){S.fg=rgbHex(px[0],px[1],px[2]);setSwatches();}
}

/* ===== text and shapes on the canvas ===== */
const TEXT0=()=>({text:'Your text',font:PREFS.txtFont||'Montserrat',size:PREFS.txtSize||Math.round(doc.w/10),bold:PREFS.txtBold!==false,italic:false,caps:false,color:S.fg,align:'center',lh:1.15,stroke:'#000000',sw:0,shadow:0,shadowColor:'#000000'});
function textDown(p){
  const hit=[...doc.layers].reverse().find(l=>l.type==='text'&&l.visible&&pointInLayer(l,p));
  if(hit){selectLayer(hit.id);setTab('props');focusText();return;}
  const l=addLayer({name:'Text',type:'text',w:10,h:10,x:p.x,y:p.y,above:true,props:TEXT0()});
  renderText(l);commit('Type');setTool('move');setTab('props');focusText();
}
function focusText(){setTimeout(()=>{const t=$('#p-text');if(t){t.focus();t.select();}},80);}
const KIND_NAMES={rect:'Rectangle',round:'Rounded box',ellipse:'Ellipse',triangle:'Triangle',star:'Star',line:'Line',polygon:'Polygon',custom:'Custom shape'};
function makeShape(d){
  const a=d.p0,b=d.p1;let w=Math.abs(b.x-a.x),h=Math.abs(b.y-a.y),cx=(a.x+b.x)/2,cy=(a.y+b.y)/2;
  if(w<6&&h<6){w=h=Math.round(doc.w*0.3);cx=a.x;cy=a.y;}
  const kind=S.shape.kind,line=kind==='line';
  const l=addLayer({name:kind==='custom'?((VEC_SHAPES.find(q=>q.id===(S.shape.cid||'heart'))||{}).name||'Custom shape'):KIND_NAMES[kind],type:'shape',w:10,h:10,x:cx,y:cy,above:true,
    props:{kind,fill:S.shape.fill,stroke:line?S.shape.fill:S.shape.stroke,sw:line?10:S.shape.sw,radius:Math.min(w,h)*0.18,sides:S.shape.sides||6,cid:kind==='custom'?(S.shape.cid||'heart'):null,w:Math.max(w,line?2:6),h:Math.max(h,line?2:6),flip:(b.x-a.x)*(b.y-a.y)<0,nofill:false}});
  renderShape(l);commit(KIND_NAMES[kind]);setTool('move');
}

/* ===== selection tools ===== */
const selModeOf=e=>e&&e.shiftKey&&e.altKey?'int':e&&e.shiftKey?'add':e&&e.altKey?'sub':S.selMode;
function finishLasso(d){
  if(d.pts.length>2){selFromPathFn(c=>{c.beginPath();d.pts.forEach((q,i)=>i?c.lineTo(q.x,q.y):c.moveTo(q.x,q.y));c.closePath();c.fill();},d.mode);}
  else if(d.mode==='new')selClearNow();
  drag=null;redraw();
}
function lassoDown(p,e){
  if(S.lasso.kind==='poly'){
    if(drag&&drag.k==='lasso'&&drag.poly){
      const f=drag.pts[0];
      if(drag.pts.length>2&&Math.hypot(p.x-f.x,p.y-f.y)<12/S.zoom){finishLasso(drag);return;}
      drag.pts.push(p);redraw();return;
    }
    drag={k:'lasso',poly:true,pts:[p],cursor:p,mode:selModeOf(e)};redraw();return;
  }
  drag={k:'lasso',poly:false,pts:[p],mode:selModeOf(e)};
}
function wandDown(p,e){
  const l=active();if(!l){toast('Select a layer first');return;}
  const lp=toLocal(l,p),rg=regionMask(l,lp.x,lp.y,S.wand.tol,S.wand.contig);
  if(!rg){toast('Tap inside the layer');return;}
  regionToSelection(l,rg,selModeOf(e));
}
function marqueeUp(d){
  const a=d.p0,b=d.p1,x=Math.min(a.x,b.x),y=Math.min(a.y,b.y),w=Math.abs(b.x-a.x),h=Math.abs(b.y-a.y);
  if(w<3||h<3){if(d.mode==='new')selClearNow();return;}
  selFromPathFn(c=>{c.beginPath();if(S.marq.kind==='ellipse')c.ellipse(x+w/2,y+h/2,w/2,h/2,0,0,Math.PI*2);else c.rect(x,y,w,h);c.fill();},d.mode);
}
function cropRect(a,b){
  b={x:clamp(b.x,0,doc.w),y:clamp(b.y,0,doc.h)};
  let w=b.x-a.x,h=b.y-a.y;
  if(S.aspect){
    const ar=S.aspect;
    if(Math.abs(w)/ar>Math.abs(h))h=(h<0?-1:1)*Math.abs(w)/ar;else w=(w<0?-1:1)*Math.abs(h)*ar;
    if(a.x+w<0||a.x+w>doc.w){w=(w<0?-a.x:doc.w-a.x);h=(h<0?-1:1)*Math.abs(w)/ar;}
    if(a.y+h<0||a.y+h>doc.h){h=(h<0?-a.y:doc.h-a.y);w=(w<0?-1:1)*Math.abs(h)*ar;}
  }
  return {x:Math.min(a.x,a.x+w),y:Math.min(a.y,a.y+h),w:Math.abs(w),h:Math.abs(h)};
}
function applyCrop(r){
  r={x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.w),h:Math.round(r.h)};
  if(r.w<8||r.h<8){toast('Drag a larger area to crop');return;}
  for(const l of doc.layers){l.x-=r.x;l.y-=r.y;}
  doc.w=r.w;doc.h=r.h;doc.guides=[];S.sel=null;S.crop=null;resizeStage();commit('Crop');S.autoFit=true;fitView();redraw();
}

/* ===== pointer handling ===== */
const ptrs=new Map();let gest=null,pan=null,spaceDown=false;
function cancelDrag(){if(drag&&(drag.k==='paint'||drag.k==='retouch'||drag.k==='move')){restore(hist[hi]);}drag=null;guides={x:null,y:null};redraw();}
vp.addEventListener('pointerdown',e=>{
  if(!doc)return;
  vp.setPointerCapture(e.pointerId);ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(ptrs.size===2){cancelDrag();startGest();return;}
  if(ptrs.size>2)return;
  closeMenus();
  if(document.body.classList.contains('fx-open')||S.tool==='hand'||spaceDown||e.button===1){pan={x:e.clientX,y:e.clientY,px:S.px,py:S.py};S.autoFit=false;return;}
  if(e.pointerType==='mouse'&&e.button!==0)return;
  flush();toolDown(toDoc(e),e);
});
vp.addEventListener('pointermove',e=>{
  if(!doc)return;
  if(ptrs.has(e.pointerId))ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  const pt=toDoc(e);updateCursorInfo(pt);
  if(gest&&ptrs.size>=2){moveGest();return;}
  if(pan){S.px=pan.px+e.clientX-pan.x;S.py=pan.py+e.clientY-pan.y;applyView();return;}
  if(drag){
    const evs=(e.getCoalescedEvents&&e.getCoalescedEvents())||[];
    if((drag.k==='paint'||drag.k==='retouch')&&evs.length>1)evs.forEach(ev=>toolMove(toDoc(ev),ev));else toolMove(pt,e);
    return;
  }
  if(e.pointerType==='mouse'){hover=pt;const T=TOOLS[S.tool];if(T&&T.hover){T.hover(pt,e);redraw();}else if(brushLike(S.tool))redraw();}
});
function endPtr(e){
  if(!ptrs.has(e.pointerId))return;
  ptrs.delete(e.pointerId);
  if(gest){if(ptrs.size<2)gest=null;return;}
  if(pan){pan=null;return;}
  if(drag)toolUp(toDoc(e),e);
}
vp.addEventListener('pointerup',endPtr);
vp.addEventListener('pointercancel',e=>{if(ptrs.has(e.pointerId)){ptrs.delete(e.pointerId);if(drag)cancelDrag();gest=null;pan=null;}});
vp.addEventListener('pointerleave',()=>{hover=null;if(doc)redraw();});
vp.addEventListener('wheel',e=>{
  if(!doc)return;e.preventDefault();
  const r=vp.getBoundingClientRect();
  if(e.ctrlKey||e.metaKey||e.altKey)zoomAt(S.zoom*Math.exp(-e.deltaY*0.01),e.clientX-r.left,e.clientY-r.top);
  else{S.autoFit=false;if(e.shiftKey)S.px-=e.deltaY;else{S.px-=e.deltaX;S.py-=e.deltaY;}applyView();}
},{passive:false});
vp.addEventListener('dblclick',e=>{
  if(!doc)return;
  if(drag&&drag.k==='lasso'&&drag.poly){finishLasso(drag);return;}
  {const T=TOOLS[S.tool];if(T&&T.dbl){T.dbl(toDoc(e),e);return;}}
  if(S.tool!=='move')return;
  const l=active();if(l&&l.type==='text'){setTab('props');focusText();}
});
vp.addEventListener('dragover',e=>e.preventDefault());
function startGest(){
  const [a,b]=[...ptrs.values()],r=vp.getBoundingClientRect();
  gest={d:Math.hypot(a.x-b.x,a.y-b.y)||1,z:S.zoom,mx:(a.x+b.x)/2-r.left,my:(a.y+b.y)/2-r.top,px:S.px,py:S.py};S.autoFit=false;
}
function moveGest(){
  const [a,b]=[...ptrs.values()],r=vp.getBoundingClientRect();
  const mx=(a.x+b.x)/2-r.left,my=(a.y+b.y)/2-r.top,d=Math.hypot(a.x-b.x,a.y-b.y)||1;
  const z=clamp(gest.z*d/gest.d,0.02,32),qx=(gest.mx-gest.px)/gest.z,qy=(gest.my-gest.py)/gest.z;
  S.zoom=z;S.px=mx-qx*z;S.py=my-qy*z;applyView();
}
['#rulerH','#rulerV'].forEach(sel=>{
  const el=$(sel),horiz=sel==='#rulerH';
  el.addEventListener('pointerdown',e=>{
    if(!doc)return;e.preventDefault();el.setPointerCapture(e.pointerId);
    const upd=ev=>{const r=stage.getBoundingClientRect();return horiz?(ev.clientY-r.top)/S.zoom:(ev.clientX-r.left)/S.zoom;};
    S.dragGuide={o:horiz?'h':'v',p:upd(e)};redraw();
    const mv=ev=>{S.dragGuide.p=upd(ev);redraw();};
    const up=()=>{
      el.removeEventListener('pointermove',mv);el.removeEventListener('pointerup',up);el.removeEventListener('pointercancel',up);
      const g=S.dragGuide;S.dragGuide=null;
      if(g&&g.p>0&&g.p<(g.o==='h'?doc.h:doc.w)){doc.guides.push({o:g.o,p:Math.round(g.p)});S.showGuides=true;doc.modified=true;}
      redraw();
    };
    el.addEventListener('pointermove',mv);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
  });
});

function toolDown(p,e){
  switch(S.tool){
    case 'move':return moveDown(p);
    case 'marquee':drag={k:'marquee',p0:p,p1:p,mode:selModeOf(e)};break;
    case 'lasso':return lassoDown(p,e);
    case 'wand':return wandDown(p,e);
    case 'crop':drag={k:'crop',p0:p,p1:p};break;
    case 'brush':return paintDown(p,e,false);
    case 'eraser':return paintDown(p,e,true);
    case 'retouch':return retouchDown(p,e);
    case 'fill':return fillDown(p,e);
    case 'gradient':drag={k:'gradient',p0:p,p1:p};break;
    case 'pick':drag={k:'pick'};pickAt(p);break;
    case 'text':return textDown(p);
    case 'shape':drag={k:'shape',p0:p,p1:p};break;
    case 'zoom':{const r=vp.getBoundingClientRect();zoomAt(S.zoom*(e&&e.altKey?0.5:2),(e.clientX-r.left),(e.clientY-r.top));break;}
    default:{const T=TOOLS[S.tool];if(T&&T.down)return T.down(p,e);}
  }
}
function toolMove(p,e){
  if(!drag)return;
  switch(drag.k){
    case 'move':return moveMove(p);
    case 'marquee':drag.p1=p;redraw();break;
    case 'lasso':if(drag.poly)drag.cursor=p;else drag.pts.push(p);redraw();break;
    case 'crop':drag.p1=p;S.crop=cropRect(drag.p0,p);redraw();break;
    case 'paint':drag.pf=pressureFactor(e);paintSeg(drag,drag.last,toLocal(drag.l,p),false);break;
    case 'retouch':drag.pf=pressureFactor(e);retSeg(drag,drag.last,toLocal(drag.l,p),false);break;
    case 'gradient':case 'shape':drag.p1=p;redraw();break;
    case 'pick':pickAt(p);break;
    default:if(drag.tool&&TOOLS[drag.tool]&&TOOLS[drag.tool].move)TOOLS[drag.tool].move(p,e);
  }
}
function toolUp(p,e){
  const d=drag;
  if(d.k==='lasso'&&d.poly){redraw();return;}
  drag=null;guides={x:null,y:null};
  switch(d.k){
    case 'move':if(d.moved){bake(d.l);commit('Move');renderProps();}redraw();break;
    case 'marquee':d.p1=p;marqueeUp(d);break;
    case 'lasso':finishLasso(d);break;
    case 'crop':if(S.crop&&(S.crop.w<8||S.crop.h<8))S.crop=null;redraw();break;
    case 'paint':if(d.tlock)applyAlphaLock(d);commit(d.mask?'Paint mask':d.erase?'Eraser':'Brush');break;
    case 'retouch':if(d.tlock)applyAlphaLock(d);commit('Retouch');break;
    case 'gradient':if(Math.hypot(d.p1.x-d.p0.x,d.p1.y-d.p0.y)>4){gradientLayer(d.p0,d.p1);commit('Gradient');}else redraw();break;
    case 'shape':makeShape(d);break;
    case 'pick':redraw();setSwatches();break;
    default:if(d.tool&&TOOLS[d.tool]&&TOOLS[d.tool].up)TOOLS[d.tool].up(d,p,e);else redraw();
  }
}
function moveDown(p){
  const hd=handleAt(p),l=active();
  if(hd&&l&&!posLocked(l)){
    drag={k:'move',mode:hd,l,p0:p,s0:l.s,r0:l.r,x0:l.x,y0:l.y,a0:Math.atan2(p.y-l.y,p.x-l.x),d0:Math.hypot(p.x-l.x,p.y-l.y)||1,moved:false};return;
  }
  let tgt=l;
  if(S.auto){
    const f=findLayerAt(p);
    if(!f)return;
    if(f.id!==doc.active)selectLayer(f.id);
    tgt=f;
  }
  if(!tgt)return;
  if(posLocked(tgt)){toast('This layer is locked');return;}
  drag={k:'move',mode:'move',l:tgt,p0:p,x0:tgt.x,y0:tgt.y,moved:false};
}
function snapLayer(l,nx,ny){
  guides={x:null,y:null};const th=8/S.zoom;
  const xs=[0,doc.w/2,doc.w],ys=[0,doc.h/2,doc.h];
  for(const g of (doc.guides||[]))(g.o==='v'?xs:ys).push(g.p);
  const save={x:l.x,y:l.y};l.x=nx;l.y=ny;
  const cs=layerCorners(l),X=cs.map(c=>c.x),Y=cs.map(c=>c.y),x0=Math.min(...X),x1=Math.max(...X),y0=Math.min(...Y),y1=Math.max(...Y);
  l.x=save.x;l.y=save.y;
  let bx=null,by=null;
  for(const t of xs)for(const v of [x0,(x0+x1)/2,x1]){const dd=t-v;if(Math.abs(dd)<th&&(bx===null||Math.abs(dd)<Math.abs(bx.d)))bx={d:dd,t};}
  for(const t of ys)for(const v of [y0,(y0+y1)/2,y1]){const dd=t-v;if(Math.abs(dd)<th&&(by===null||Math.abs(dd)<Math.abs(by.d)))by={d:dd,t};}
  if(bx){nx+=bx.d;guides.x=bx.t;}
  if(by){ny+=by.d;guides.y=by.t;}
  return [nx,ny];
}
function moveMove(p){
  const d=drag,l=d.l,dx=p.x-d.p0.x,dy=p.y-d.p0.y;
  if(!d.moved&&Math.hypot(dx,dy)*S.zoom<3)return;
  d.moved=true;
  if(d.mode==='move'){
    let nx=d.x0+dx,ny=d.y0+dy;
    if(S.snap){[nx,ny]=snapLayer(l,nx,ny);}
    l.x=nx;l.y=ny;
  }else if(d.mode==='scale'){
    l.s=clamp(d.s0*Math.hypot(p.x-l.x,p.y-l.y)/d.d0,0.01,60);
  }else{
    let r=d.r0+Math.atan2(p.y-l.y,p.x-l.x)-d.a0;const sn=Math.PI/12,nr=Math.round(r/sn)*sn;
    if(Math.abs(nr-r)<0.05)r=nr;l.r=r;
  }
  redraw();
}

/* ===== layer, image and selection commands ===== */
function flatLayer(l){const c=mkCanvas(doc.w,doc.h);drawLayer(cctx(c),Object.assign({},l,{opacity:1,blend:'source-over',_mc:null,_fc:null}));return c;}
function alphaBBox(c){
  const W=c.width,H=c.height,d=cctx(c).getImageData(0,0,W,H).data;let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(d[(y*W+x)*4+3]>0){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
  return x1<0?null:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
}
function dupLayer(a,off){
  const n=addLayer({name:a.name+' copy',type:a.type,w:a.canvas.width,h:a.canvas.height,x:a.x+(off||0),y:a.y+(off||0),above:true,props:clone(a.props)});
  cctx(n.canvas).drawImage(a.canvas,0,0);n.s=a.s;n.r=a.r;n.opacity=a.opacity;n.blend=a.blend;n.fx=clone(a.fx);n.fillOp=a.fillOp;n.clip=a.clip;n.smart=a.smart;n.sf=clone(a.sf);n.orig=a.orig;n.so=a.so||null;n.adj=clone(a.adj);n.bd=a.bd||null;
  if(a.mask)n.mask=cloneCanvas(a.mask);
  return n;
}
function mergeLayers(list,name){
  const n=addLayer({name,select:false}),x=cctx(n.canvas);
  composeList(x,list);
  return n;
}
function flipPixels(l,horiz){
  const f=c=>{const n=mkCanvas(c.width,c.height),x=cctx(n);
    if(horiz){x.translate(n.width,0);x.scale(-1,1);}else{x.translate(0,n.height);x.scale(1,-1);}
    x.drawImage(c,0,0);const cx=cctx(c);cx.clearRect(0,0,n.width,n.height);cx.drawImage(n,0,0);};
  rasterize(l);f(l.canvas);if(l.mask)f(l.mask);l.ver++;l.mver++;
}
function layerBounds(l){const cs=layerCorners(l),X=cs.map(c=>c.x),Y=cs.map(c=>c.y);return {x0:Math.min(...X),x1:Math.max(...X),y0:Math.min(...Y),y1:Math.max(...Y)};}
function fitLayerTo(l,cover){
  const c=Math.abs(Math.cos(l.r)),s=Math.abs(Math.sin(l.r)),cw=l.canvas.width,ch=l.canvas.height;
  const bw=cw*c+ch*s,bh=cw*s+ch*c;
  l.s=cover?Math.max(doc.w/bw,doc.h/bh):Math.min(doc.w/bw,doc.h/bh);l.x=doc.w/2;l.y=doc.h/2;
  if(l.type==='text'||l.type==='shape')bake(l);
}
function scaleFx(fx,k){
  if(!fx)return;
  const S2=(o,ks)=>{if(o)ks.forEach(q=>{if(typeof o[q]==='number')o[q]*=k;});};
  S2(fx.shadow,['blur','dx','dy','dist','size']);S2(fx.ishadow,['dist','size']);S2(fx.glow,['blur','size']);S2(fx.iglow,['size']);
  S2(fx.bevel,['size']);S2(fx.satin,['dist','size']);S2(fx.stroke,['w']);
}
function resizeImage(nw,nh){
  const kx=nw/doc.w,ky=nh/doc.h,uni=Math.abs(kx-ky)<1e-3;
  for(const l of doc.layers){
    if(uni&&l.type==='text'){const p=l.props;p.size=Math.max(4,p.size*kx);p.sw*=kx;p.shadow*=kx;renderText(l);}
    else if(uni&&l.type==='shape'){const p=l.props;p.w*=kx;p.h*=kx;p.sw*=kx;p.radius*=kx;if(p.cr)p.cr=p.cr.map(v=>v*kx);if(p.vr)p.vr*=kx;renderShape(l);}
    else{
      rasterize(l);
      const rs=c=>resampleCanvas(c,c.width*kx,c.height*ky,S.resampleMode||'smooth');
      l.canvas=rs(l.canvas);if(l.mask)l.mask=rs(l.mask);l.ver++;l.mver++;
    }
    l.x*=kx;l.y*=ky;scaleFx(l.fx,kx);l._mc=null;l._fc=null;
  }
  doc.w=Math.round(nw);doc.h=Math.round(nh);doc.guides=[];S.sel=null;resizeStage();
}
function resizeCanvas(nw,nh,anchor){
  const ax=(anchor%3)/2,ay=Math.floor(anchor/3)/2,dx=(nw-doc.w)*ax,dy=(nh-doc.h)*ay;
  for(const l of doc.layers){l.x+=dx;l.y+=dy;}
  doc.w=Math.round(nw);doc.h=Math.round(nh);doc.guides=[];S.sel=null;resizeStage();
}
function transformCanvas(kind){
  const W=doc.w,H=doc.h;
  for(const l of doc.layers){
    if(kind==='cw'){const x=l.x,y=l.y;l.x=H-y;l.y=x;l.r+=Math.PI/2;}
    else if(kind==='ccw'){const x=l.x,y=l.y;l.x=y;l.y=W-x;l.r-=Math.PI/2;}
    else if(kind==='180'){l.x=W-l.x;l.y=H-l.y;l.r+=Math.PI;}
    else if(kind==='fh'){flipPixels(l,true);l.x=W-l.x;l.r=-l.r;}
    else if(kind==='fv'){flipPixels(l,false);l.y=H-l.y;l.r=-l.r;}
    l._mc=null;l._fc=null;
  }
  if(kind==='cw'||kind==='ccw'){doc.w=H;doc.h=W;}
  doc.guides=[];S.sel=null;resizeStage();
}
function trimTransparent(){
  const c=mkCanvas(doc.w,doc.h);compose(cctx(c),1);
  const b=alphaBBox(c);if(!b){toast('Nothing to trim');return;}
  if(b.w===doc.w&&b.h===doc.h){toast('Nothing to trim');return;}
  applyCrop(b);
}
function selMorph(kind,r){
  if(!S.sel){toast('Make a selection first');return;}
  const W=doc.w,H=doc.h,c=S.sel.c,id=cctx(c).getImageData(0,0,W,H),d=id.data;
  if(kind==='feather'){boxBlur(d,W,H,Math.max(1,Math.round(r*0.85)),3);}
  else{
    boxBlur(d,W,H,Math.max(1,Math.round(r)),1);
    const thr=kind==='grow'?12:kind==='shrink'?243:127;
    for(let i=3;i<d.length;i+=4)d[i]=d[i]>thr?255:0;
  }
  const n=mkCanvas(W,H);cctx(n).putImageData(id,0,0);
  const ctx=n.getContext('2d');ctx.save();ctx.globalCompositeOperation='source-in';ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);ctx.restore();
  setSelection(n,'new');
}
function selFromLayer(){
  const l=active();if(!l)return;
  const c=flatLayer(l),x=c.getContext('2d');x.globalCompositeOperation='source-in';x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);
  setSelection(c,'new');
}
function copySel(cut){
  const l=active();if(!l){toast('Select a layer first');return false;}
  let c=flatLayer(l);
  if(S.sel){const x=c.getContext('2d');x.globalCompositeOperation='destination-in';x.drawImage(S.sel.c,0,0);}
  const b=alphaBBox(c);if(!b){toast('Nothing to copy');return false;}
  const out=mkCanvas(b.w,b.h);cctx(out).drawImage(c,b.x,b.y,b.w,b.h,0,0,b.w,b.h);
  S.clip={canvas:out,x:b.x+b.w/2,y:b.y+b.h/2};
  if(cut){
    if(l.locked){toast('This layer is locked');return true;}
    if(l.type==='text'||l.type==='shape')rasterize(l);
    if(S.sel)withSel(l,()=>cctx(l.canvas).clearRect(0,0,l.canvas.width,l.canvas.height));else cctx(l.canvas).clearRect(0,0,l.canvas.width,l.canvas.height);
    touch(l);
  }
  return true;
}
function withLocal(l,fn){const ctx=cctx(l.canvas);ctx.save();ctx.setTransform.apply(ctx,docToLocalM(l));fn(ctx);ctx.restore();touch(l);}
function pasteClip(inPlace,label){
  if(!S.clip){toast('Nothing copied yet');return;}
  const c=S.clip,n=addLayer({name:label||'Pasted layer',w:c.canvas.width,h:c.canvas.height,x:inPlace?c.x:doc.w/2,y:inPlace?c.y:doc.h/2,above:true});
  cctx(n.canvas).drawImage(c.canvas,0,0);touch(n);commit(label||'Paste');
}
function fillSelection(color){
  let l=active();if(!l||pxLocked(l)){toast('Select an unlocked layer first');return;}
  if(l.type==='text'||l.type==='shape'){l=addLayer({name:'Fill',above:true});}
  if(S.sel){
    const sa=selAlphaCanvasLocal(l),ctx=cctx(l.canvas);
    const tmp=mkCanvas(l.canvas.width,l.canvas.height),tx=tmp.getContext('2d');
    tx.fillStyle=color;tx.fillRect(0,0,tmp.width,tmp.height);tx.globalCompositeOperation='destination-in';tx.drawImage(sa,0,0);
    ctx.drawImage(tmp,0,0);touch(l);
  }else{
    const ctx=cctx(l.canvas);ctx.fillStyle=color;ctx.fillRect(0,0,l.canvas.width,l.canvas.height);touch(l);
  }
  commit('Fill');
}
function clearSelectionPixels(){
  const l=active();if(!l||pxLocked(l)){toast('Select an unlocked layer first');return;}
  if(!S.sel){ACT.ldel();return;}
  if(l.editMask&&l.mask){const sa=selAlphaCanvasLocal(l),x=l.mask.getContext('2d');x.save();x.globalCompositeOperation='destination-out';x.drawImage(sa,0,0);x.restore();touchMask(l);commit('Clear mask');return;}
  if(l.type==='text'||l.type==='shape')rasterize(l);
  const sa=selAlphaCanvasLocal(l),x=l.canvas.getContext('2d');x.save();x.globalCompositeOperation='destination-out';x.drawImage(sa,0,0);x.restore();touch(l);commit('Clear');renderProps();
}
function setMask(kind){
  const l=active();if(!l){toast('Select a layer first');return;}
  if(l.locked){toast('This layer is locked');return;}
  const w=l.canvas.width,h=l.canvas.height;
  if(kind==='del'){if(!l.mask){toast('This layer has no mask');return;}l.mask=null;l.editMask=false;l.mver++;touch(l);commit('Delete mask');return;}
  if(kind==='apply'){
    if(!l.mask){toast('This layer has no mask');return;}
    const x=l.canvas.getContext('2d');x.save();x.globalCompositeOperation='destination-in';x.drawImage(l.mask,0,0,w,h);x.restore();
    l.mask=null;l.editMask=false;l.mver++;touch(l);commit('Apply mask');return;
  }
  if(kind==='invert'){
    if(!l.mask){toast('This layer has no mask');return;}
    const n=mkCanvas(w,h),x=n.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.globalCompositeOperation='destination-out';x.drawImage(l.mask,0,0);
    l.mask=n;l.mver++;touch(l);commit('Invert mask');return;
  }
  if(l.mask){toast('This layer already has a mask. Delete it first.');return;}
  const n=mkCanvas(w,h),x=n.getContext('2d');
  if(kind==='reveal'){x.fillStyle='#fff';x.fillRect(0,0,w,h);}
  else if(kind==='sel'){
    if(!S.sel){toast('Make a selection first');return;}
    x.drawImage(selAlphaCanvasLocal(l),0,0);
  }
  l.mask=n;l.editMask=true;l.mver++;touch(l);commit('Add mask');
}
function alignLayer(kind){
  const l=active();if(!l){toast('Select a layer first');return;}
  const b=layerBounds(l),T=S.sel?{x0:S.sel.bbox.x,y0:S.sel.bbox.y,x1:S.sel.bbox.x+S.sel.bbox.w,y1:S.sel.bbox.y+S.sel.bbox.h}:{x0:0,y0:0,x1:doc.w,y1:doc.h};
  let dx=0,dy=0;
  if(kind==='left')dx=T.x0-b.x0;else if(kind==='hc')dx=(T.x0+T.x1)/2-(b.x0+b.x1)/2;else if(kind==='right')dx=T.x1-b.x1;
  else if(kind==='top')dy=T.y0-b.y0;else if(kind==='vc')dy=(T.y0+T.y1)/2-(b.y0+b.y1)/2;else if(kind==='bottom')dy=T.y1-b.y1;
  l.x+=dx;l.y+=dy;touch(l);commit('Align');
}
function arrange(kind){
  const l=active();if(!l)return;const i=doc.layers.indexOf(l),n=doc.layers.length;let j=i;
  if(kind==='front')j=n-1;else if(kind==='back')j=0;else if(kind==='fwd')j=Math.min(n-1,i+1);else j=Math.max(0,i-1);
  if(j===i)return;doc.layers.splice(i,1);doc.layers.splice(j,0,l);commit('Arrange');redraw();
}
function textProp(k,v){
  const l=active();if(!l||l.type!=='text'){toast('Select a text layer first');return;}
  l.props[k]=(v===undefined)?!l.props[k]:v;renderText(l);commit('Type');renderProps();
}

const D=f=>(...a)=>{if(!doc){toast('Create or open a design first');return;}flush();return f(...a);};
const ACT={
  new:()=>openNewDoc(),
  open:()=>pickFile('open'),
  place:D(()=>pickFile('place')),
  saveProject:D(()=>doSaveProject()),
  savePSD:D(()=>savePSDFile()),
  exportAs:D(()=>openExport()),
  closeDoc:D(()=>closeDoc(cur)),
  closeAll:()=>{flush();const anyMod=docs.some(d=>d.doc.modified);if(anyMod){askCloseAll();}else{while(docs.length)closeDoc(docs.length-1,true);}},
  welcome:()=>{showWelcome();},
  undo,redo,
  cut:D(()=>{if(copySel(true))commit('Cut');}),
  copy:D(()=>{copySel(false);toast('Copied');}),
  paste:D(()=>pasteClip(false,'Pasted layer')),
  pasteInPlace:D(()=>pasteClip(true,'Pasted layer')),
  viaCopy:D(()=>{if(!S.sel){ACT.ldup();return;}if(copySel(false))pasteClip(true,'Layer via copy');}),
  viaCut:D(()=>{if(!S.sel){toast('Make a selection first');return;}if(copySel(true)){commit('Cut');pasteClip(true,'Layer via cut');}}),
  clear:D(()=>clearSelectionPixels()),
  fillFg:D(()=>fillSelection(S.fg)),
  fillBg:D(()=>fillSelection(S.bg)),
  transform:D(()=>{setTool('move');toast('Drag the corner squares to resize and the round handle to rotate');}),
  imageSize:D(()=>openImageSize()),
  canvasSize:D(()=>openCanvasSize()),
  rotCW:D(()=>{transformCanvas('cw');commit('Rotate canvas');fitView();}),
  rotCCW:D(()=>{transformCanvas('ccw');commit('Rotate canvas');fitView();}),
  rot180:D(()=>{transformCanvas('180');commit('Rotate canvas');}),
  flipCH:D(()=>{transformCanvas('fh');commit('Flip canvas');}),
  flipCV:D(()=>{transformCanvas('fv');commit('Flip canvas');}),
  cropSel:D(()=>{if(S.sel)applyCrop(S.sel.bbox);else if(S.crop)applyCrop(S.crop);else{setTool('crop');toast('Drag on the canvas to choose the crop area');}}),
  trim:D(()=>trimTransparent()),
  cropApply:D(()=>{if(S.crop)applyCrop(S.crop);else toast('Drag on the canvas to choose the crop area');}),
  cropReset:()=>{S.crop=null;redraw();},
  lnew:D(()=>{addLayer({name:'Layer '+doc.nextId,above:true});commit('New layer');}),
  lnewFill:D(()=>{addLayer({name:'Color fill',above:true,fill:S.fg});commit('New fill layer');}),
  ldup:D(()=>{const a=active();if(!a){toast('Select a layer first');return;}dupLayer(a,0);commit('Duplicate layer');}),
  ldel:D(()=>{
    const a=active();if(!a){toast('Select a layer first');return;}
    const i=doc.layers.indexOf(a);doc.layers.splice(i,1);
    doc.active=doc.layers.length?doc.layers[Math.max(0,i-1)].id:null;commit('Delete layer');renderProps();redraw();
  }),
  lmerge:D(()=>{
    const a=active();if(!a)return;const i=doc.layers.indexOf(a);
    if(i<1){toast('There is no layer below to merge with');return;}
    const b=doc.layers[i-1],n=mergeLayers([b,a],b.name);doc.layers.pop();doc.layers.splice(i-1,2,n);doc.active=n.id;commit('Merge down');renderProps();redraw();
  }),
  mergeVisible:D(()=>{
    const vis=doc.layers.filter(l=>l.visible);if(vis.length<2){toast('Nothing to merge');return;}
    const n=mergeLayers(vis,'Merged');doc.layers.pop();
    const keep=doc.layers.filter(l=>!l.visible);doc.layers=keep.concat([n]);doc.active=n.id;commit('Merge visible');renderProps();redraw();
  }),
  flatten:D(()=>{
    if(doc.layers.length<2){toast('Already one layer');return;}
    const vis=doc.layers.filter(l=>l.visible),n=mergeLayers(vis,'Background');doc.layers=[n];doc.active=n.id;commit('Flatten image');renderProps();redraw();
  }),
  lfront:D(()=>arrange('front')),lfwd:D(()=>arrange('fwd')),lbwd:D(()=>arrange('bwd')),lback:D(()=>arrange('back')),
  alignL:D(()=>alignLayer('left')),alignHC:D(()=>alignLayer('hc')),alignR:D(()=>alignLayer('right')),
  alignT:D(()=>alignLayer('top')),alignVC:D(()=>alignLayer('vc')),alignB:D(()=>alignLayer('bottom')),
  rasterize:D(()=>{const l=active();if(!l)return;if(l.type!=='text'&&l.type!=='shape'){toast('This layer is already pixels');return;}rasterize(l);commit('Rasterize');renderProps();}),
  lflipH:D(()=>{const l=active();if(!l)return;flipPixels(l,true);commit('Flip layer');renderProps();}),
  lflipV:D(()=>{const l=active();if(!l)return;flipPixels(l,false);commit('Flip layer');renderProps();}),
  rot90:D(()=>{const l=active();if(!l)return;l.r+=Math.PI/2;touch(l);commit('Rotate layer');renderProps();}),
  fitLayer:D(()=>{const l=active();if(!l)return;fitLayerTo(l,false);touch(l);commit('Fit layer');renderProps();}),
  fillLayer:D(()=>{const l=active();if(!l)return;fitLayerTo(l,true);touch(l);commit('Fill canvas');renderProps();}),
  lockToggle:D(()=>{const l=active();if(!l)return;l.locked=!l.locked;commit(l.locked?'Lock layer':'Unlock layer');}),
  visToggle:D(()=>{const l=active();if(!l)return;l.visible=!l.visible;commit('Visibility');redraw();}),
  lstyle:D(()=>openLayerStyle()),
  maskReveal:D(()=>setMask('reveal')),maskHide:D(()=>setMask('hide')),maskSel:D(()=>setMask('sel')),
  maskDel:D(()=>setMask('del')),maskApply:D(()=>setMask('apply')),maskInvert:D(()=>setMask('invert')),
  selAll:D(()=>{selAll();}),
  selNone:D(()=>{selClearNow();}),
  reselect:D(()=>{if(S.lastSel){S.sel=S.lastSel;redraw();}else toast('No previous selection');}),
  selInv:D(()=>{if(!S.sel){toast('Make a selection first');return;}selInverse();}),
  selLayer:D(()=>selFromLayer()),
  selFeather:D(()=>{if(!S.sel){toast('Make a selection first');return;}askNumber('Feather selection','Feather radius (px)',10,1,250,v=>selMorph('feather',v));}),
  selGrow:D(()=>{if(!S.sel){toast('Make a selection first');return;}askNumber('Grow selection','Grow by (px)',8,1,250,v=>selMorph('grow',v));}),
  selShrink:D(()=>{if(!S.sel){toast('Make a selection first');return;}askNumber('Shrink selection','Shrink by (px)',8,1,250,v=>selMorph('shrink',v));}),
  selSmooth:D(()=>{if(!S.sel){toast('Make a selection first');return;}askNumber('Smooth selection','Smooth radius (px)',6,1,100,v=>selMorph('smooth',v));}),
  zin:()=>{if(!doc)return;const r=vp.getBoundingClientRect();zoomAt(S.zoom*1.25,r.width/2,r.height/2);},
  zout:()=>{if(!doc)return;const r=vp.getBoundingClientRect();zoomAt(S.zoom/1.25,r.width/2,r.height/2);},
  zfit:()=>{if(!doc)return;S.autoFit=true;fitView();},
  z100:()=>{if(!doc)return;const r=vp.getBoundingClientRect();zoomAt(1,r.width/2,r.height/2);},
  rulers:()=>{S.rulers=!S.rulers;document.body.classList.toggle('no-rulers',!S.rulers);setTimeout(()=>{if(doc&&S.autoFit)fitView();else drawRulers();},30);},
  grid:()=>{S.grid=!S.grid;redraw();},
  guidesToggle:()=>{S.showGuides=!S.showGuides;redraw();},
  snap:()=>{S.snap=!S.snap;},
  clearGuides:()=>{if(doc){doc.guides=[];redraw();}},
  fullscreen:()=>{const el=document.documentElement;try{if(document.fullscreenElement)document.exitFullscreen();else if(el.requestFullscreen)el.requestFullscreen().catch(()=>toast('Full screen is not available here'));else toast('Full screen is not available here');}catch(err){toast('Full screen is not available here');}},
  capsToggle:D(()=>textProp('caps')),boldToggle:D(()=>textProp('bold')),italicToggle:D(()=>textProp('italic')),
  txtL:D(()=>textProp('align','left')),txtC:D(()=>textProp('align','center')),txtR:D(()=>textProp('align','right')),
  lastFilter:D(()=>runLastFx()),
  fxOk:()=>fxOk(),fxCancel:()=>fxCancel(),fxReset:()=>fxReset(),
  setSrc:()=>{S.settingSrc=true;toast('Tap the spot you want to copy from');},
  adjApply:()=>{if(sess){const s=sess;s.dirty=true;toast('Applied');sessFinish();}},
  adjReset:()=>resetAdj(),
  autoFix:D(()=>applyPreset(PRESETS[1])),
  quickSkin:D(()=>{if(!sessBegin('adjust',processAdjust,adj.p,'Skin smoothing'))return;adj.p=Object.assign({},ADJ0,{smooth:70});sess.p=adj.p;syncAdj();sessPreview();}),
  help:()=>openHelp(),about:()=>openAbout(),
  closeModal:()=>closeModal()
};
