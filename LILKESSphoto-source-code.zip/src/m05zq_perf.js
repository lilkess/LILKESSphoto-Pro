/* ===== speed: keep the layers underneath the one you are editing as one picture, so painting and moving redraw quickly ===== */
const CIDS=new WeakMap();let cidN=0;
const cidOf=c=>{if(!c)return 0;let v=CIDS.get(c);if(!v){v=++cidN;CIDS.set(c,v);}return v;};
function perfLayerKey(l){
  return l.id+','+cidOf(l.canvas)+','+l.canvas.width+'x'+l.canvas.height+','+l.ver+','+cidOf(l.mask)+','+l.mver+','+l.pvv+','+l.x+','+l.y+','+l.s+','+l.r+','+l.opacity+','+l.blend+','+(l.visible?1:0)+','+(l.clip?1:0)+','+(l.fillOp==null?1:l.fillOp)+','+l.type+','+(l.fx&&hasFx(l.fx)?JSON.stringify(l.fx):'')+','+(l.adj?JSON.stringify(l.adj):'')+','+(l.type==='adjust'?JSON.stringify(l.props||'')+(l.ver):'');
}
const PERF={on:true,hits:0,builds:0};
render=function(){
  dirty=false;if(!doc)return;
  vctx.clearRect(0,0,doc.w,doc.h);
  const L=doc.layers,a=doc.active;let idx=L.findIndex(l=>l.id===a);
  if(PERF.on&&idx>=0&&L.length>=4){
    let s=idx;while(s>0&&L[s].clip)s--;
    if(s>=2){
      const below=L.slice(0,s),key=below.map(perfLayerKey).join(';')+'|'+doc.w+'x'+doc.h+'|'+JSON.stringify((doc.extra&&doc.extra.boards)||null);
      let bc=doc._bc;
      if(!bc||bc.key!==key||bc.canvas.width!==doc.w||bc.canvas.height!==doc.h){
        const c=bc&&bc.canvas.width===doc.w&&bc.canvas.height===doc.h?bc.canvas:mkCanvas(doc.w,doc.h),x=cctx(c);x.clearRect(0,0,c.width,c.height);
        x.save();drawBoardsBg(x);composeList(x,below);x.restore();
        bc=doc._bc={key,canvas:c};PERF.builds++;
      }else PERF.hits++;
      vctx.drawImage(bc.canvas,0,0);
      composeList(vctx,L.slice(s));
      drawOver();return;
    }
  }
  compose(vctx,1);drawOver();
};
window.__PERF=PERF;
