/* ===== Built-in plugins, part 3: Chart Maker, 3D Elements, Flags, Emoji, Palette, Batch Edit, shortcuts ===== */
/* ---------- Chart Maker ---------- */
const PLG_PAL={vivid:['#4e79a7','#f28e2b','#e15759','#76b7b2','#59a14f','#edc948','#b07aa1','#ff9da7','#9c755f','#bab0ac'],ocean:['#03045e','#0077b6','#00b4d8','#90e0ef','#48cae4','#023e8a','#0096c7','#ade8f4'],sunset:['#ff5d8f','#ff9e00','#ffd166','#ef476f','#f78c6b','#8338ec','#3a86ff','#06d6a0'],earth:['#6b705c','#a5a58d','#b7b7a4','#cb997e','#ddbea9','#ffe8d6','#7f5539','#9c6644'],mono:['#111827','#374151','#6b7280','#9ca3af','#d1d5db','#1f2937','#4b5563','#e5e7eb']};
function plgParseData(t,header){
  const rows=String(t||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean).map(s=>s.split(/[,;\t]/).map(x=>x.trim()));
  if(!rows.length)throw new Error('Type some data, one line per bar: Label, value');
  let names=null;const first=rows[0];
  if(rows.length>1&&(header===undefined?first.slice(1).every(x=>x===''||isNaN(parseFloat(x))):header)){names=first.slice(1);rows.shift();}
  const labels=[],ser=[];let ns=0;rows.forEach(r=>{ns=Math.max(ns,r.length-1);});
  if(ns<1)throw new Error('Each line needs a label and a number, like: Jan, 120');
  for(let s=0;s<ns;s++)ser.push([]);
  rows.forEach(r=>{labels.push(r[0]);for(let s=0;s<ns;s++){const n=parseFloat(r[s+1]);ser[s].push(isFinite(n)?n:0);}});
  return {labels,ser,names:names||ser.map((_,i)=>'Series '+(i+1))};
}
function plgNiceMax(v){if(v<=0)return 1;const e=Math.pow(10,Math.floor(Math.log10(v))),f=v/e,n=f<=1?1:f<=2?2:f<=5?5:10;return n*e;}
function plgChart(v){
  const D=plgParseData(v.data,v.header),W=v.w,H=v.h,c=mkCanvas(W,H),x=cctx(c),pal=PLG_PAL[v.palette]||PLG_PAL.vivid;
  const dark=v.bg==='dark',tc=dark?'#f1f1f1':'#1f2937',gc=dark?'rgba(255,255,255,.14)':'rgba(0,0,0,.12)';
  if(v.bg==='white'){x.fillStyle='#fff';x.fillRect(0,0,W,H);}else if(dark){x.fillStyle='#16181d';x.fillRect(0,0,W,H);}
  const fs=Math.max(11,Math.round(Math.min(W,H)/38)),fam='system-ui,Segoe UI,Roboto,Arial,sans-serif';
  x.fillStyle=tc;x.textBaseline='alphabetic';
  let top=fs*1.6;if(v.title){x.font='700 '+Math.round(fs*1.6)+'px '+fam;x.textAlign='center';x.fillText(v.title,W/2,fs*2.1);top=fs*3.4;}
  const showLeg=v.legend&&(D.ser.length>1||v.type==='pie'||v.type==='donut');
  let right=showLeg?Math.min(W*0.28,fs*12):fs*1.5;
  if(showLeg){
    const items=(v.type==='pie'||v.type==='donut')?D.labels:D.names;x.font=fs+'px '+fam;x.textAlign='left';
    items.forEach((n,i)=>{const y=top+i*fs*1.7;x.fillStyle=pal[i%pal.length];x.fillRect(W-right+fs*.4,y,fs,fs);x.fillStyle=tc;x.fillText(String(n).slice(0,22),W-right+fs*1.9,y+fs*.9);});
  }
  const L=fs*5,B=fs*3.2,pw=W-L-right,ph=H-top-B;
  if(v.type==='pie'||v.type==='donut'){
    const vals=D.ser[0].map(q=>Math.max(0,q)),tot=vals.reduce((a,b)=>a+b,0)||1,cx=(W-right)/2,cy=top+(H-top-fs)/2,R=Math.min(W-right,H-top-fs*1.5)/2-fs;let a=-Math.PI/2;
    vals.forEach((q,i)=>{const da=q/tot*Math.PI*2;x.beginPath();x.moveTo(cx,cy);x.arc(cx,cy,R,a,a+da);x.closePath();x.fillStyle=pal[i%pal.length];x.fill();x.strokeStyle=dark?'#16181d':'#fff';x.lineWidth=Math.max(1,fs*.12);x.stroke();
      if(v.values&&q/tot>0.03){const m=a+da/2,rr=v.type==='donut'?R*0.78:R*0.65;x.fillStyle='#fff';x.font='700 '+fs+'px '+fam;x.textAlign='center';x.fillText(Math.round(q/tot*100)+'%',cx+Math.cos(m)*rr,cy+Math.sin(m)*rr+fs*.35);}a+=da;});
    if(v.type==='donut'){x.save();x.globalCompositeOperation='destination-out';x.beginPath();x.arc(cx,cy,R*0.52,0,7);x.fill();x.restore();if(v.bg!=='transparent'){}}
    return c;
  }
  const horiz=v.type==='hbar';let mx=0;D.ser.forEach(s=>s.forEach(q=>{mx=Math.max(mx,q);}));const nm=plgNiceMax(mx),n=D.labels.length,ns=D.ser.length;
  x.font=fs+'px '+fam;x.lineWidth=1;
  const ticks=5;
  for(let i=0;i<=ticks;i++){const val=nm*i/ticks,lab=(Math.abs(val)>=1000?Math.round(val).toLocaleString():(+val.toFixed(2))+'');
    x.strokeStyle=gc;x.beginPath();
    if(horiz){const X=L+pw*i/ticks;x.moveTo(X,top);x.lineTo(X,top+ph);x.stroke();x.fillStyle=tc;x.textAlign='center';x.fillText(lab,X,top+ph+fs*1.4);}
    else{const Y=top+ph-ph*i/ticks;x.moveTo(L,Y);x.lineTo(L+pw,Y);x.stroke();x.fillStyle=tc;x.textAlign='right';x.fillText(lab,L-fs*.5,Y+fs*.35);}}
  const band=(horiz?ph:pw)/n;
  D.labels.forEach((lb,i)=>{x.fillStyle=tc;x.font=fs+'px '+fam;const t=String(lb).slice(0,16);
    if(horiz){x.textAlign='right';x.fillText(t,L-fs*.5,top+band*(i+.5)+fs*.35);}else{x.textAlign='center';x.fillText(t,L+band*(i+.5),top+ph+fs*1.4);}});
  if(v.type==='bar'||v.type==='hbar'){
    const gw=band*0.72,bw=gw/ns;
    D.ser.forEach((s,k)=>s.forEach((q,i)=>{const len=(horiz?pw:ph)*q/nm,o=band*i+(band-gw)/2+bw*k;x.fillStyle=pal[(ns>1?k:i)%pal.length];
      if(horiz){x.fillRect(L,top+o,len,bw*0.92);if(v.values){x.fillStyle=tc;x.textAlign='left';x.font=fs*.9+'px '+fam;x.fillText(+q.toFixed(2)+'',L+len+fs*.3,top+o+bw*.5+fs*.3);}}
      else{x.fillRect(L+o,top+ph-len,bw*0.92,len);if(v.values){x.fillStyle=tc;x.textAlign='center';x.font=fs*.9+'px '+fam;x.fillText(+q.toFixed(2)+'',L+o+bw*.46,top+ph-len-fs*.4);}}}));
  }else{
    D.ser.forEach((s,k)=>{const col=pal[k%pal.length],pts=s.map((q,i)=>[L+band*(i+.5),top+ph-ph*q/nm]);
      if(v.type==='area'){x.beginPath();x.moveTo(pts[0][0],top+ph);pts.forEach(p=>x.lineTo(p[0],p[1]));x.lineTo(pts[pts.length-1][0],top+ph);x.closePath();x.globalAlpha=.25;x.fillStyle=col;x.fill();x.globalAlpha=1;}
      x.beginPath();pts.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.strokeStyle=col;x.lineWidth=Math.max(2,fs*.2);x.lineJoin='round';x.stroke();
      pts.forEach((p,i)=>{x.beginPath();x.arc(p[0],p[1],Math.max(3,fs*.3),0,7);x.fillStyle=col;x.fill();if(v.values){x.fillStyle=tc;x.textAlign='center';x.font=fs*.9+'px '+fam;x.fillText(+s[i].toFixed(2)+'',p[0],p[1]-fs*.7);}});});
  }
  x.strokeStyle=tc;x.globalAlpha=.5;x.lineWidth=1.2;x.beginPath();x.moveTo(L,top);x.lineTo(L,top+ph);x.lineTo(L+pw,top+ph);x.stroke();x.globalAlpha=1;
  return c;
}
plgReg({id:'chart',name:'Chart Maker',cat:'Generate Content',desc:'Bar, column, line, area, pie and donut charts from data you type or paste. One line per item: Label, value. Add more columns for more series.',
  params:[{id:'title',label:'Title',type:'text',value:'Sales by month'},{id:'data',label:'Data',type:'area',value:'Month, 2025, 2026\nJan, 120, 150\nFeb, 160, 190\nMar, 140, 210\nApr, 210, 260\nMay, 250, 300',rows:7},pgS('type','Chart','bar',[['bar','Columns'],['hbar','Bars'],['line','Lines'],['area','Area'],['pie','Pie'],['donut','Donut']]),pgS('palette','Colours','vivid',[['vivid','Vivid'],['ocean','Ocean'],['sunset','Sunset'],['earth','Earth'],['mono','Grey']]),pgS('bg','Background','white',[['white','White'],['dark','Dark'],['transparent','Transparent']]),pgK('header','First line is a header (series names)',true),pgK('values','Show values',true),pgK('legend','Show legend',true),pgR('w','Width',320,2400,1200,'px',20),pgR('h','Height',240,2000,750,'px',20)],
  render:v=>plgChart(v),layerName:v=>v.title||'Chart',run(){plgGenDialog(this);}});

/* ---------- 3D Elements: shapes rendered with a small ray marcher ---------- */
const P3=Math;
function plgSdf(shape,x,y,z){
  switch(shape){
    case 'sphere':return P3.hypot(x,y,z)-0.9;
    case 'cube':{const r=0.16,qx=P3.abs(x)-0.62+r,qy=P3.abs(y)-0.62+r,qz=P3.abs(z)-0.62+r;return P3.hypot(P3.max(qx,0),P3.max(qy,0),P3.max(qz,0))+P3.min(P3.max(qx,qy,qz),0)-r;}
    case 'torus':{const q=P3.hypot(x,z)-0.66;return P3.hypot(q,y)-0.3;}
    case 'cylinder':{const r=0.08,dx=P3.hypot(x,z)-0.6+r,dy=P3.abs(y)-0.75+r;return P3.min(P3.max(dx,dy),0)+P3.hypot(P3.max(dx,0),P3.max(dy,0))-r;}
    case 'capsule':{const yy=y-P3.max(-0.55,P3.min(0.55,y));return P3.hypot(x,yy,z)-0.38;}
    case 'cone':{ /* round cone: radius 0.62 at the bottom, 0.06 at the top */
      const r1=0.62,r2=0.06,h=1.25,qx=P3.hypot(x,z),yy=y+0.62,b=(r1-r2)/h,a=P3.sqrt(1-b*b),k=qx*-b+yy*a;
      if(k<0)return P3.hypot(qx,yy)-r1;if(k>a*h)return P3.hypot(qx,yy-h)-r2;return qx*a+yy*b-r1;}
    default:return P3.hypot(x,y,z)-0.9;}
}
function plgRender3D(v,preview){
  const out=preview?P3.min(v.size,200):v.size,ss=preview?1:2,N=out*ss,c=mkCanvas(N,N),x=cctx(c),id=x.createImageData(N,N),d=id.data;
  const rx=v.rx*P3.PI/180,ry=v.ry*P3.PI/180,rz=v.rz*P3.PI/180,cx=P3.cos(rx),sx=P3.sin(rx),cy=P3.cos(ry),sy=P3.sin(ry),cz=P3.cos(rz),sz=P3.sin(rz);
  const inv=(px,py,pz)=>{ /* inverse of Rz*Ry*Rx : apply Rz^-1 then Ry^-1 then Rx^-1 */
    let a=px*cz+py*sz,b=-px*sz+py*cz,e=pz;
    let a2=a*cy-e*sy,e2=a*sy+e*cy;
    return [a2,b*cx+e2*sx,-b*sx+e2*cx];};
  const f=(px,py,pz)=>{const q=inv(px,py,pz);return plgSdf(v.shape,q[0],q[1],q[2]);};
  const col=plgHex(v.color),la=v.light*P3.PI/180,L=[P3.cos(la)*0.6,-0.65,-P3.sin(la)*0.6-0.45],ll=P3.hypot(L[0],L[1],L[2]);L[0]/=ll;L[1]/=ll;L[2]/=ll;
  const gl=v.gloss/100,sp=8+gl*120,fov=0.42,ro=[0,0,-3.3];
  for(let j=0;j<N;j++)for(let i=0;i<N;i++){
    const u=((i+.5)/N*2-1)*fov*1.3,w=-((j+.5)/N*2-1)*fov*1.3;let rd=[u,w,1];const rl=P3.hypot(rd[0],rd[1],rd[2]);rd=[rd[0]/rl,rd[1]/rl,rd[2]/rl];
    const bx=ro[0],by=ro[1],bz=ro[2],bb=bx*rd[0]+by*rd[1]+bz*rd[2],cc=bx*bx+by*by+bz*bz-2.4,disc=bb*bb-cc;
    if(disc<0)continue;
    let t=-bb-P3.sqrt(disc),hit=false;const tmax=-bb+P3.sqrt(disc);
    for(let s=0;s<70&&t<tmax;s++){const px=bx+rd[0]*t,py=by+rd[1]*t,pz=bz+rd[2]*t,dd=f(px,py,pz);if(dd<0.0008){hit=true;break;}t+=dd;}
    if(!hit)continue;
    const px=bx+rd[0]*t,py=by+rd[1]*t,pz=bz+rd[2]*t,e=0.0015;
    let nx=f(px+e,py,pz)-f(px-e,py,pz),ny=f(px,py+e,pz)-f(px,py-e,pz),nz=f(px,py,pz+e)-f(px,py,pz-e);const nl=P3.hypot(nx,ny,nz)||1;nx/=nl;ny/=nl;nz/=nl;
    const df=P3.max(0,nx*L[0]+ny*L[1]+nz*L[2]),amb=0.28+0.12*ny*-1*0+0.1*(1-ny)/2;
    const hx=L[0]-rd[0],hy=L[1]-rd[1],hz=L[2]-rd[2],hl=P3.hypot(hx,hy,hz)||1,spc=P3.pow(P3.max(0,(nx*hx+ny*hy+nz*hz)/hl),sp)*gl;
    const fr=P3.pow(1-P3.max(0,-(nx*rd[0]+ny*rd[1]+nz*rd[2])),3)*0.25;
    const rr=2*(nx*rd[0]+ny*rd[1]+nz*rd[2]),ry_=rd[1]-rr*ny,env=0.5+0.5*ry_,refl=gl*0.35*P3.max(0,env)*(0.4+0.6*env);
    const k=amb+df*0.82;
    const o=(j*N+i)*4;
    d[o]=P3.min(255,col[0]*k+255*(spc+refl*0.6)+fr*180);d[o+1]=P3.min(255,col[1]*k+255*(spc+refl*0.6)+fr*180);d[o+2]=P3.min(255,col[2]*k+255*(spc+refl*0.7)+fr*200);d[o+3]=255;
  }
  x.putImageData(id,0,0);
  let res=c;if(ss>1){res=mkCanvas(out,out);const rx_=cctx(res);rx_.imageSmoothingQuality='high';rx_.drawImage(c,0,0,out,out);}
  if(v.shadow){const sc=mkCanvas(out,out),sx_=cctx(sc);sx_.fillStyle='rgba(0,0,0,.45)';sx_.beginPath();sx_.ellipse(out/2,out*0.86,out*0.26,out*0.05,0,0,7);sx_.fill();
    const fin=mkCanvas(out,out),fx=cctx(fin);fx.filter='blur('+Math.round(out*0.018)+'px)';fx.drawImage(sc,0,0);fx.filter='none';fx.drawImage(res,0,0);return fin;}
  return res;
}
plgReg({id:'elements3d',name:'3D Elements',cat:'Image Elements',desc:'Shiny 3D shapes you can turn, colour and light: sphere, cube, torus, cylinder, capsule and cone. Drawn on your device, no downloads.',
  params:[pgS('shape','Shape','torus',[['sphere','Sphere'],['cube','Rounded cube'],['torus','Torus'],['cylinder','Cylinder'],['capsule','Capsule'],['cone','Cone']]),pgC('color','Colour','#ff4f8b'),pgR('rx','Turn up/down',-180,180,-25,'°'),pgR('ry','Turn left/right',-180,180,30,'°'),pgR('rz','Roll',-180,180,0,'°'),pgR('light','Light direction',-180,180,-40,'°'),pgR('gloss','Shininess',0,100,70,'%'),pgR('size','Size',256,1536,768,'px',64),pgK('shadow','Soft ground shadow',true)],
  render:(v,pv)=>plgRender3D(v,pv),layerName:v=>'3D '+v.shape,run(){plgGenDialog(this);}});

/* ---------- Flags & Countries ---------- */
const FLG={};
const flBand=(x,w,h,cols,vert)=>cols.forEach((c,i)=>{x.fillStyle=c;if(vert)x.fillRect(w*i/cols.length-.5,0,w/cols.length+1,h);else x.fillRect(0,h*i/cols.length-.5,w,h/cols.length+1);});
function flStar(x,cx,cy,R,col,rot,pts,ratio){pts=pts||5;ratio=ratio||0.382;x.beginPath();for(let i=0;i<pts*2;i++){const r=i%2?R*ratio:R,a=(rot||-P3.PI/2)+i*P3.PI/pts;x[i?'lineTo':'moveTo'](cx+P3.cos(a)*r,cy+P3.sin(a)*r);}x.closePath();x.fillStyle=col;x.fill();}
const flCross=(x,w,h,cx,col,t)=>{x.fillStyle=col;x.fillRect(0,h/2-t/2,w,t);x.fillRect(cx-t/2,0,t,h);};
const FLAGS=[
 ['gh','Ghana',(x,w,h)=>{flBand(x,w,h,['#CE1126','#FCD116','#006B3F']);flStar(x,w/2,h/2,h*.17,'#000');}],
 ['ng','Nigeria',(x,w,h)=>flBand(x,w,h,['#008751','#fff','#008751'],true)],
 ['ci','Cote d’Ivoire',(x,w,h)=>flBand(x,w,h,['#F77F00','#fff','#009E60'],true)],
 ['sn','Senegal',(x,w,h)=>{flBand(x,w,h,['#00853F','#FDEF42','#E31B23'],true);flStar(x,w/2,h/2,h*.17,'#00853F');}],
 ['ml','Mali',(x,w,h)=>flBand(x,w,h,['#14B53A','#FCD116','#CE1126'],true)],
 ['gn','Guinea',(x,w,h)=>flBand(x,w,h,['#CE1126','#FCD116','#009460'],true)],
 ['cm','Cameroon',(x,w,h)=>{flBand(x,w,h,['#007A5E','#CE1126','#FCD116'],true);flStar(x,w/2,h/2,h*.17,'#FCD116');}],
 ['bj','Benin',(x,w,h)=>{x.fillStyle='#008751';x.fillRect(0,0,w*.4,h);x.fillStyle='#FCD116';x.fillRect(w*.4,0,w*.6,h/2);x.fillStyle='#E8112D';x.fillRect(w*.4,h/2,w*.6,h/2);}],
 ['tg','Togo',(x,w,h)=>{const c=['#006A4E','#FFCE00','#006A4E','#FFCE00','#006A4E'];flBand(x,w,h,c);x.fillStyle='#D21034';x.fillRect(0,0,h*.6,h*.6);flStar(x,h*.3,h*.3,h*.18,'#fff');}],
 ['bf','Burkina Faso',(x,w,h)=>{flBand(x,w,h,['#EF2B2D','#009E49']);flStar(x,w/2,h/2,h*.2,'#FCD116');}],
 ['ma','Morocco',(x,w,h)=>{x.fillStyle='#C1272D';x.fillRect(0,0,w,h);x.strokeStyle='#006233';x.lineWidth=h*.035;const cx=w/2,cy=h/2,R=h*.2;x.beginPath();for(let i=0;i<5;i++){const a=-P3.PI/2+i*4*P3.PI/5;x[i?'lineTo':'moveTo'](cx+P3.cos(a)*R,cy+P3.sin(a)*R);}x.closePath();x.stroke();}],
 ['de','Germany',(x,w,h)=>flBand(x,w,h,['#000','#DD0000','#FFCE00'])],
 ['fr','France',(x,w,h)=>flBand(x,w,h,['#0055A4','#fff','#EF4135'],true)],
 ['it','Italy',(x,w,h)=>flBand(x,w,h,['#009246','#fff','#CE2B37'],true)],
 ['ie','Ireland',(x,w,h)=>flBand(x,w,h,['#169B62','#fff','#FF883E'],true)],
 ['nl','Netherlands',(x,w,h)=>flBand(x,w,h,['#AE1C28','#fff','#21468B'])],
 ['be','Belgium',(x,w,h)=>flBand(x,w,h,['#000','#FDDA24','#EF3340'],true)],
 ['pl','Poland',(x,w,h)=>flBand(x,w,h,['#fff','#DC143C'])],
 ['ua','Ukraine',(x,w,h)=>flBand(x,w,h,['#0057B7','#FFD700'])],
 ['ru','Russia',(x,w,h)=>flBand(x,w,h,['#fff','#0039A6','#D52B1E'])],
 ['at','Austria',(x,w,h)=>flBand(x,w,h,['#ED2939','#fff','#ED2939'])],
 ['ch','Switzerland',(x,w,h)=>{x.fillStyle='#DA291C';x.fillRect(0,0,w,h);x.fillStyle='#fff';const t=h*.2,l=h*.6;x.fillRect(w/2-t/2,h/2-l/2,t,l);x.fillRect(w/2-l/2,h/2-t/2,l,t);}],
 ['se','Sweden',(x,w,h)=>{x.fillStyle='#006AA7';x.fillRect(0,0,w,h);x.fillStyle='#FECC00';x.fillRect(0,h*.4,w,h*.2);x.fillRect(w*.3125,0,h*.2,h);}],
 ['no','Norway',(x,w,h)=>{x.fillStyle='#BA0C2F';x.fillRect(0,0,w,h);flCross(x,w,h,w*.36,'#fff',h*.25);flCross(x,w,h,w*.36,'#00205B',h*.125);}],
 ['dk','Denmark',(x,w,h)=>{x.fillStyle='#C8102E';x.fillRect(0,0,w,h);x.fillStyle='#fff';x.fillRect(0,h*.43,w,h*.14);x.fillRect(w*.3,0,h*.14,h);}],
 ['fi','Finland',(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);x.fillStyle='#003580';x.fillRect(0,h*.375,w,h*.25);x.fillRect(w*.3,0,h*.25,h);}],
 ['jp','Japan',(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);x.fillStyle='#BC002D';x.beginPath();x.arc(w/2,h/2,h*.3,0,7);x.fill();}],
 ['cn','China',(x,w,h)=>{x.fillStyle='#DE2910';x.fillRect(0,0,w,h);flStar(x,w*.17,h*.25,h*.15,'#FFDE00');[[.34,.1],[.4,.2],[.4,.35],[.34,.45]].forEach(([a,b])=>flStar(x,w*a,h*b*1.0+h*.05,h*.05,'#FFDE00',P3.atan2(h*.25-(h*b+h*.05),w*.17-w*a)+P3.PI));}],
 ['in','India',(x,w,h)=>{flBand(x,w,h,['#FF9933','#fff','#138808']);x.strokeStyle='#000080';x.lineWidth=h*.012;const cx=w/2,cy=h/2,R=h*.15;x.beginPath();x.arc(cx,cy,R,0,7);x.stroke();for(let i=0;i<24;i++){const a=i*P3.PI/12;x.beginPath();x.moveTo(cx,cy);x.lineTo(cx+P3.cos(a)*R,cy+P3.sin(a)*R);x.stroke();}}],
 ['br','Brazil',(x,w,h)=>{x.fillStyle='#009C3B';x.fillRect(0,0,w,h);x.fillStyle='#FFDF00';x.beginPath();x.moveTo(w*.5,h*.1);x.lineTo(w*.92,h*.5);x.lineTo(w*.5,h*.9);x.lineTo(w*.08,h*.5);x.closePath();x.fill();x.fillStyle='#002776';x.beginPath();x.arc(w/2,h/2,h*.25,0,7);x.fill();}],
 ['jm','Jamaica',(x,w,h)=>{x.fillStyle='#009B3A';x.fillRect(0,0,w,h);x.fillStyle='#000';x.beginPath();x.moveTo(0,0);x.lineTo(w/2,h/2);x.lineTo(0,h);x.closePath();x.moveTo(w,0);x.lineTo(w/2,h/2);x.lineTo(w,h);x.closePath();x.fill();x.fillStyle='#FED100';x.lineWidth=h*.16;x.strokeStyle='#FED100';x.beginPath();x.moveTo(0,0);x.lineTo(w,h);x.moveTo(w,0);x.lineTo(0,h);x.stroke();}],
 ['ca','Canada',(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);x.fillStyle='#D52B1E';x.fillRect(0,0,w/4,h);x.fillRect(w*.75,0,w/4,h);
   const P=[[0,-1],[.12,-.7],[.3,-.78],[.25,-.35],[.55,-.5],[.5,-.3],[.9,-.1],[.8,.05],[.9,.3],[.35,.25],[.4,.5],[.05,.4],[.05,.9],[-.05,.9],[-.05,.4],[-.4,.5],[-.35,.25],[-.9,.3],[-.8,.05],[-.9,-.1],[-.5,-.3],[-.55,-.5],[-.25,-.35],[-.3,-.78],[-.12,-.7]],s=h*.38;x.beginPath();P.forEach((p,i)=>x[i?'lineTo':'moveTo'](w/2+p[0]*s*.95,h/2+p[1]*s));x.closePath();x.fill();}],
 ['uk','United Kingdom',(x,w,h)=>{x.fillStyle='#012169';x.fillRect(0,0,w,h);x.lineCap='butt';x.strokeStyle='#fff';x.lineWidth=h*.2;x.beginPath();x.moveTo(0,0);x.lineTo(w,h);x.moveTo(w,0);x.lineTo(0,h);x.stroke();x.strokeStyle='#C8102E';x.lineWidth=h*.07;x.beginPath();x.moveTo(0,0);x.lineTo(w,h);x.moveTo(w,0);x.lineTo(0,h);x.stroke();flCross(x,w,h,w/2,'#fff',h*.33);flCross(x,w,h,w/2,'#C8102E',h*.2);}],
 ['us','United States',(x,w,h)=>{for(let i=0;i<13;i++){x.fillStyle=i%2?'#fff':'#B22234';x.fillRect(0,h*i/13,w,h/13+.5);}const cw=w*.4,ch=h*7/13;x.fillStyle='#3C3B6E';x.fillRect(0,0,cw,ch);
   for(let r=0;r<9;r++){const n=r%2?5:6;for(let k=0;k<n;k++){flStar(x,cw*((r%2?(k*2+2):(k*2+1))/12),ch*(r+1)/10,h*.026,'#fff');}}}]
];
FLAGS.forEach(f=>FLG[f[0]]=f);
function plgFlag(v){const f=FLG[v.flag]||FLAGS[0],W=v.w,H=Math.round(W*(v.ratio==='1:1'?1:v.ratio==='5:3'?3/5:2/3)),c=mkCanvas(W,H),x=cctx(c);x.save();f[2](x,W,H);x.restore();
  if(v.border){x.strokeStyle='rgba(0,0,0,.35)';x.lineWidth=Math.max(1,W*.004);x.strokeRect(0,0,W,H);}
  if(v.gloss){const g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,'rgba(255,255,255,.28)');g.addColorStop(.45,'rgba(255,255,255,0)');g.addColorStop(1,'rgba(0,0,0,.18)');x.fillStyle=g;x.fillRect(0,0,W,H);}
  return c;}
plgReg({id:'flags',name:'Flags & Countries',cat:'Image Elements',desc:'Clean flags in any size, '+FLAGS.length+' countries. Flags that carry a coat of arms or fine detail are drawn without it, so they are simplified.',
  params:[pgS('flag','Country','gh',FLAGS.map(f=>[f[0],f[1]])),pgR('w','Width',160,2400,900,'px',20),pgS('ratio','Shape','3:2',[['3:2','3:2'],['5:3','5:3'],['1:1','Square']]),pgK('border','Thin outline',true),pgK('gloss','Soft shine',false)],
  render:v=>plgFlag(v),layerName:v=>(FLG[v.flag]||FLAGS[0])[1]+' flag',run(){plgGenDialog(this);}});

/* ---------- Emoji ---------- */
const EMOJI={Smileys:'😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😋😎🤩🥳😏😢😭😤😡🤯😱🥶🥵🤔🤗🤫🙄😴🤒🤕🤠🥺😈👻💀🤖👽',Hands:'👍👎👏🙌🤝🙏💪👋🤙✌️🤞🤟👌🤌☝️👆👇👉👈✊👊🖐️✋🫶❤️🧡💛💚💙💜🖤🤍💔💖💯',Animals:'🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🐔🐧🐦🦅🦉🦋🐝🐞🐢🐍🦎🐙🦀🐠🐬🐳🦈🐘🦒🦓🐎🐄🐑',Food:'🍎🍌🍇🍓🍉🍍🥭🍑🍒🥝🍅🥑🌽🥕🍔🍟🍕🌭🥪🌮🍣🍜🍝🍩🍪🎂🍰🍫🍿☕🍺🍷🥂🍹',Travel:'🚗🚕🚌🚑🚒🚓🏎️🚲🏍️✈️🚀🚁⛵🚢🚂🏠🏢🏰🗼🗽⛰️🌋🏝️🌅🌈☀️🌙⭐🌟⚡🔥💧❄️🌊',Objects:'📱💻⌨️🖥️📷🎥📺🎧🎤🎸🥁🎮🎯🏆🥇⚽🏀🏈⚾🎾💡🔑🔒🔔📌📎✏️📚💰💳🎁🎈🎉🎊',Symbols:'✅❌⚠️❓❗➕➖➡️⬅️⬆️⬇️🔄🔝🆕🆓🆗🅿️♻️✔️💬💭🔴🟠🟡🟢🔵🟣⚫⚪🔶🔷🔺'};
function plgEmojiList(s){return Array.from(new Intl.Segmenter?new Intl.Segmenter('en',{granularity:'grapheme'}).segment(s):[...s]).map(x=>x.segment||x);}
function plgEmojiCanvas(ch,size){
  const c=mkCanvas(size*2,size*2),x=cctx(c);x.font=Math.round(size*1.5)+'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji","Twemoji Mozilla",sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(ch,size,size*1.06);
  const id=x.getImageData(0,0,c.width,c.height),dd=id.data;let x0=c.width,y0=c.height,x1=-1,y1=-1;
  for(let y=0;y<c.height;y++)for(let X=0;X<c.width;X++)if(dd[(y*c.width+X)*4+3]>8){if(X<x0)x0=X;if(X>x1)x1=X;if(y<y0)y0=y;if(y>y1)y1=y;}
  if(x1<0)return null;const o=mkCanvas(x1-x0+1,y1-y0+1);cctx(o).drawImage(c,-x0,-y0);return o;
}
plgReg({id:'emoji',name:'Emoji',cat:'Image Elements',desc:'Pick an emoji and add it as a layer you can scale. It is drawn with the emoji font of your device, so its style depends on your phone or computer.',
  run(){
    const cats=Object.keys(EMOJI);let cat=cats[0];
    modalOpen('Emoji','<div class="plg-emj"><div class="row" id="em-tabs">'+cats.map(c=>'<button data-ec="'+c+'">'+c+'</button>').join('')+'</div><div id="em-grid" class="em-grid"></div><label class="plg-r"><span>Size</span><select id="em-sz"><option value="256">256 px</option><option value="512" selected>512 px</option><option value="1024">1024 px</option></select></label></div>',[{label:'Close'}],root=>{
      const draw=()=>{root.querySelector('#em-grid').innerHTML=plgEmojiList(EMOJI[cat]).map(e=>'<button class="em-b" data-em="'+e+'">'+e+'</button>').join('');root.querySelectorAll('#em-tabs button').forEach(b=>b.classList.toggle('primary',b.dataset.ec===cat));};
      root.addEventListener('click',e=>{const t=e.target.closest('[data-ec]');if(t){cat=t.dataset.ec;draw();return;}const b=e.target.closest('[data-em]');if(!b)return;
        const c=plgEmojiCanvas(b.dataset.em,+root.querySelector('#em-sz').value);if(!c){toast('This device has no emoji font for that symbol.');return;}
        plgNewLayer(c,'Emoji '+b.dataset.em);plgUsed('emoji');toast('Emoji added');});
      draw();},{wide:true});
  }});
{const st=document.createElement('style');st.textContent='.em-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:4px;margin:10px 0;max-height:48vh;overflow:auto}.em-b{font-size:26px;line-height:1;padding:6px 0;background:transparent;border:1px solid transparent;border-radius:6px;cursor:pointer}.em-b:hover{background:#ffffff1a;border-color:#ffffff30}.pal-row{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.pal-sw{width:74px;text-align:center;font-size:11px;cursor:pointer}.pal-sw i{display:block;height:54px;border-radius:8px;border:1px solid #ffffff30;margin-bottom:4px}';document.head.appendChild(st);}

/* ---------- Palette extractor (k-means colours of the picture) ---------- */
function plgPalette(src,k){
  const s=Math.min(1,120/Math.max(src.width,src.height)),w=Math.max(1,Math.round(src.width*s)),h=Math.max(1,Math.round(src.height*s)),c=mkCanvas(w,h);cctx(c).drawImage(src,0,0,w,h);
  const d=cctx(c).getImageData(0,0,w,h).data,pts=[];for(let i=0;i<d.length;i+=4)if(d[i+3]>128)pts.push([d[i],d[i+1],d[i+2]]);
  if(!pts.length)return [];
  const cen=[pts[0].slice()],dist=p=>Math.min(...cen.map(q=>(p[0]-q[0])**2+(p[1]-q[1])**2+(p[2]-q[2])**2));
  while(cen.length<k&&cen.length<pts.length){let bi=0,bd=-1;pts.forEach((p,i)=>{if(i%3)return;const dd=dist(p);if(dd>bd){bd=dd;bi=i;}});if(bd<=0)break;cen.push(pts[bi].slice());}
  let cnt=[];
  for(let it=0;it<12;it++){const sum=cen.map(()=>[0,0,0,0]);pts.forEach(p=>{let b=0,bd=1e9;cen.forEach((q,i)=>{const dd=(p[0]-q[0])**2+(p[1]-q[1])**2+(p[2]-q[2])**2;if(dd<bd){bd=dd;b=i;}});const q=sum[b];q[0]+=p[0];q[1]+=p[1];q[2]+=p[2];q[3]++;});
    cnt=sum.map(q=>q[3]);sum.forEach((q,i)=>{if(q[3])cen[i]=[q[0]/q[3],q[1]/q[3],q[2]/q[3]];});}
  return cen.map((q,i)=>({c:q.map(Math.round),n:cnt[i]||0})).sort((a,b)=>b.n-a.n).map(o=>({hex:'#'+o.c.map(v=>v.toString(16).padStart(2,'0')).join(''),share:o.n/pts.length}));
}
plgReg({id:'palette',name:'Palette Extractor',cat:'Other Plugins',desc:'Finds the main colours of your picture. Click a colour to use it as the foreground colour.',
  run(){
    if(!doc){toast('Open a design first');return;}
    let k=6;const src=flatCanvas(1,null);
    modalOpen('Palette Extractor','<label class="plg-r"><span>Colours</span><input type="range" id="pl-k" min="3" max="12" value="6"><em id="pl-kv">6</em></label><div class="pal-row" id="pl-row"></div><div class="muted">Click a colour to make it your foreground colour.</div>',
     [{label:'Close'},{label:'Copy codes',cb:()=>{const t=plgPalette(src,k).map(c=>c.hex).join(' ');try{navigator.clipboard.writeText(t);toast('Copied '+t);}catch(e){toast(t);}return false;}},{label:'Add as layer',primary:true,cb:()=>{
        const p=plgPalette(src,k),c=mkCanvas(p.length*160,200),x=cctx(c);p.forEach((q,i)=>{x.fillStyle=q.hex;x.fillRect(i*160,0,160,200);x.fillStyle=plgHex(q.hex).reduce((a,b)=>a+b)>380?'#000':'#fff';x.font='bold 22px sans-serif';x.textAlign='center';x.fillText(q.hex.toUpperCase(),i*160+80,110);});
        plgNewLayer(c,'Palette');plgUsed('palette');}}],
     root=>{const draw=()=>{const p=plgPalette(src,k);root.querySelector('#pl-row').innerHTML=p.map(q=>'<div class="pal-sw" data-h="'+q.hex+'"><i style="background:'+q.hex+'"></i>'+q.hex.toUpperCase()+'<br>'+Math.round(q.share*100)+'%</div>').join('');};
       root.querySelector('#pl-k').addEventListener('input',e=>{k=+e.target.value;root.querySelector('#pl-kv').textContent=k;draw();});
       root.addEventListener('click',e=>{const s=e.target.closest('[data-h]');if(s){S.fg=s.dataset.h;setSwatches();toast('Foreground colour '+s.dataset.h.toUpperCase());}});draw();});
  }});

/* ---------- Batch Edit Tool ---------- */
plgReg({id:'batch',name:'Batch Edit Tool',cat:'Other Plugins',desc:'Resize, convert and tweak many pictures at once, then download them in one ZIP file.',
  run(){
    let files=[];
    modalOpen('Batch Edit Tool','<div class="row"><button class="primary" id="bt-pick">Choose pictures...</button><span class="muted" id="bt-n">No pictures chosen</span><input type="file" id="bt-in" accept="image/*" multiple hidden></div>'
     +'<label class="plg-r"><span>Longest side</span><select id="bt-sz"><option value="0">Keep size</option><option value="3840">3840 px</option><option value="2560">2560 px</option><option value="1920">1920 px</option><option value="1280">1280 px</option><option value="1080">1080 px</option><option value="800">800 px</option><option value="512">512 px</option></select></label>'
     +'<label class="plg-r"><span>Format</span><select id="bt-fm"><option value="jpeg">JPG</option><option value="png">PNG</option><option value="webp">WebP</option></select></label>'
     +'<label class="plg-r"><span>Quality</span><input type="range" id="bt-q" min="40" max="100" value="88"><em>%</em></label>'
     +'<label class="plg-r"><span>Brightness</span><input type="range" id="bt-b" min="-50" max="50" value="0"></label>'
     +'<label class="plg-r"><span>Contrast</span><input type="range" id="bt-c" min="-50" max="50" value="0"></label>'
     +'<label class="plg-r"><span></span><label class="opt"><input type="checkbox" id="bt-g"> Black and white</label></label><div class="muted" id="bt-st"></div>',
     [{label:'Close'},{label:'Process and download',primary:true,cb:async()=>{
        if(!files.length){toast('Choose some pictures first');return false;}
        const mx=+document.getElementById('bt-sz').value,fm=document.getElementById('bt-fm').value,q=+document.getElementById('bt-q').value/100,br=+document.getElementById('bt-b').value,co=+document.getElementById('bt-c').value,gr=document.getElementById('bt-g').checked,st=document.getElementById('bt-st'),out=[];
        const ext=fm==='jpeg'?'jpg':fm,mime='image/'+fm;
        for(let i=0;i<files.length;i++){
          st.textContent='Working on '+(i+1)+' of '+files.length+': '+files[i].name;await new Promise(r=>setTimeout(r,10));
          try{
            const bm=await createImageBitmap(files[i]);let w=bm.width,h=bm.height;if(mx&&Math.max(w,h)>mx){const k=mx/Math.max(w,h);w=Math.max(1,Math.round(w*k));h=Math.max(1,Math.round(h*k));}
            let c=mkCanvas(bm.width,bm.height);cctx(c).drawImage(bm,0,0);if(w!==bm.width)c=resampleCanvas(c,w,h);
            if(br||co||gr){const x=cctx(c),id=x.getImageData(0,0,w,h),d=id.data,cf=1+co/100,add=br*2.55;for(let p=0;p<d.length;p+=4){let r=d[p],g=d[p+1],b=d[p+2];if(gr){r=g=b=.299*r+.587*g+.114*b;}d[p]=(r-128)*cf+128+add;d[p+1]=(g-128)*cf+128+add;d[p+2]=(b-128)*cf+128+add;}x.putImageData(id,0,0);}
            if(fm==='jpeg'){const f=mkCanvas(w,h),fx=cctx(f);fx.fillStyle='#fff';fx.fillRect(0,0,w,h);fx.drawImage(c,0,0);c=f;}
            const blob=await new Promise(r=>c.toBlob(r,mime,q));out.push({name:files[i].name.replace(/\.[^.]+$/,'')+'.'+ext,data:new Uint8Array(await blob.arrayBuffer())});
          }catch(e){console.error(e);out.push(null);}
        }
        const ok=out.filter(Boolean);if(!ok.length){toast('None of the pictures could be read');return false;}
        const used={};ok.forEach(f=>{const n=f.name;if(used[n]){const k=used[n]++;f.name=n.replace(/(\.[^.]+)$/,'_'+k+'$1');}else used[n]=1;});
        if(ok.length===1)saveBlob(new Blob([ok[0].data],{type:mime}),ok[0].name);else saveBlob(zipMany(ok),'batch-edit.zip');
        plgUsed('batch');toast(ok.length+' picture'+(ok.length>1?'s':'')+' saved'+(ok.length<files.length?' ('+(files.length-ok.length)+' could not be read)':''));
      }}],
     root=>{root.querySelector('#bt-pick').onclick=()=>root.querySelector('#bt-in').click();root.querySelector('#bt-in').onchange=e=>{files=[...e.target.files];root.querySelector('#bt-n').textContent=files.length?files.length+' picture'+(files.length>1?'s':'')+' chosen':'No pictures chosen';};});
  }});

/* ---------- shortcuts to features the app already has ---------- */
plgReg({id:'cameraraw',name:'Camera Raw Studio',cat:'Resources',desc:'Opens the Camera Raw editor for exposure, colour, detail and local adjustments on the active layer.',run(){if(!doc){toast('Open a photo first');return;}ACT.cameraRaw();plgUsed('cameraraw');}});
plgReg({id:'stock',name:'Free Stock Photos',cat:'Resources',desc:'Opens the KESS Store photo tab: built-in pictures first, then free-licence photos from the web (needs internet).',run(){openStore('photos');plgUsed('stock');}});
