/* ===== Preferences (Photoshop style) and Save As with a location picker ===== */
THEMES.Light={'--bg':'#e9e9ec','--panel':'#f4f4f6','--panel2':'#ffffff','--panel3':'#dcdce2','--line':'#c4c4cc','--line2':'#b0b0ba','--fg':'#1f1f24','--muted':'#666672','--canvasbg':'#c9c9cf','--ruler':'#e2e2e8',dark:0};
const CANVAS_BG={'Dark gray':'','Black':'#000000','Medium gray':'#585858','Light gray':'#b4b4b8','White':'#ffffff'};
const UNIT_PPU=()=>{const d=(doc&&doc.dpi)||72;return {px:1,in:d,cm:d/2.54,mm:d/25.4,pt:d/72};};
function applyPrefs2(){
  const r=document.documentElement.style,th=THEMES[PREFS.theme||'Darkest']||THEMES.Darkest;
  r.setProperty('--canvasbg',PREFS.canvasBg?PREFS.canvasBg:th['--canvasbg']);
  if(PREFS.accent){r.setProperty('--accent',PREFS.accent);r.setProperty('--accent2',PREFS.accent);}else{r.removeProperty('--accent');r.removeProperty('--accent2');}
  const c1=PREFS.chk1||'#cfcfcf',c2=PREFS.chk2||'#ffffff',cs=PREFS.chkSize||16,st=document.getElementById('stage');
  if(st)st.style.background='conic-gradient('+c1+' 25%,'+c2+' 0 50%,'+c1+' 0 75%,'+c2+' 0) 0 0/'+cs+'px '+cs+'px';
  S.previewMax=PREFS.previewMax||900;S.gridStep=PREFS.gridStep||100;S.gridSub=PREFS.gridSub||1;S.gridCol=PREFS.gridCol||'#78a0ff';S.guideCol=PREFS.guideCol||'#19c2d8';
  if(PREFS.auto!==undefined)S.auto=!!PREFS.auto;if(PREFS.snap!==undefined)S.snap=!!PREFS.snap;
  if(PREFS.brushSize)S.brush.size=PREFS.brushSize;if(PREFS.brushHard!==undefined)S.brush.hard=PREFS.brushHard/100;
  if(PREFS.saveFmt)S.saveFmt=PREFS.saveFmt;
  startAutosave();
  if(doc){redraw();drawRulers();}
}
let asTimer=0;
function startAutosave(){clearInterval(asTimer);const m=PREFS.autosave||0;if(m>0)asTimer=setInterval(async()=>{try{if(doc&&doc.modified&&!document.querySelector('#modal:not([hidden])')){await doSaveProject();}}catch(e){}},m*60000);}
{const _ap=applyPrefs;applyPrefs=function(){_ap();applyPrefs2();};}
/* mouse wheel: zoom or scroll, with speed */
vp.addEventListener('wheel',e=>{
  if(!doc)return;
  const zoomMode=e.ctrlKey||e.metaKey||e.altKey||PREFS.wheelZoom;
  if(!zoomMode)return;
  e.preventDefault();e.stopImmediatePropagation();
  const r=vp.getBoundingClientRect(),sp=(PREFS.zoomSpeed||2)*0.005;
  zoomAt(S.zoom*Math.exp(-e.deltaY*sp),e.clientX-r.left,e.clientY-r.top);
},{passive:false,capture:true});
/* toasts can be switched off */
{const _t=toast;toast=function(m){if(PREFS.toasts===false&&!/(could not|cannot|can't|failed|not available|select|make a|locked)/i.test(String(m)))return;_t(m);};}
/* brush cursor with crosshair */
{const _d=drawToolOver;drawToolOver=function(o,z){_d(o,z);if(PREFS.cursor==='cross'&&hover&&doc&&brushLike(S.tool)){o.save();o.strokeStyle='#fff';o.lineWidth=1/z;o.shadowColor='#000';o.shadowBlur=2/z;o.beginPath();o.moveTo(hover.x-8/z,hover.y);o.lineTo(hover.x+8/z,hover.y);o.moveTo(hover.x,hover.y-8/z);o.lineTo(hover.x,hover.y+8/z);o.stroke();o.restore();}};}
/* unit-aware rulers */
function rulerUnitSteps(z,ppu){const t=[0.01,0.02,0.05,0.1,0.2,0.5,1,2,5,10,20,50,100,200,500,1000,2000,5000,10000];for(const s of t)if(s*ppu*z>=60)return s;return 20000;}
function drawRuler(cv,horiz){
  const dpr=window.devicePixelRatio||1,r=cv.getBoundingClientRect();
  if(r.width<2||r.height<2)return;
  const W=Math.round(r.width*dpr),H=Math.round(r.height*dpr);
  if(cv.width!==W||cv.height!==H){cv.width=W;cv.height=H;}
  const x=cv.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);
  const cs=getComputedStyle(document.documentElement),dark=(THEMES[PREFS.theme||'Darkest']||{}).dark!==0;
  x.fillStyle=cs.getPropertyValue('--ruler').trim()||'#3a3a3a';x.fillRect(0,0,r.width,r.height);
  if(!doc)return;
  const unit=PREFS.unit||'px',ppu=UNIT_PPU()[unit]||1,su=rulerUnitSteps(S.zoom,ppu),step=su*ppu,off=horiz?S.px:S.py,len=horiz?r.width:r.height;
  x.strokeStyle=dark?'#8a8a8a':'#777';x.fillStyle=dark?'#b5b5b5':'#444';x.font='10px system-ui,sans-serif';x.lineWidth=1;x.beginPath();
  const a=Math.floor((-off/S.zoom)/step)*step,b=(len-off)/S.zoom;
  for(let v=a;v<=b;v+=step){
    const p=Math.round(off+v*S.zoom)+0.5;
    if(horiz){x.moveTo(p,r.height);x.lineTo(p,0);}else{x.moveTo(r.width,p);x.lineTo(0,p);}
    for(let k=1;k<10;k++){const q=Math.round(off+(v+step*k/10)*S.zoom)+0.5,h=k===5?r.height*0.45:r.height*0.22;if(step*S.zoom/10<4)continue;
      if(horiz){x.moveTo(q,r.height);x.lineTo(q,r.height-h);}else{x.moveTo(r.width,q);x.lineTo(r.width-h,q);}}
  }
  x.stroke();
  const fmt=v=>{const n=v/ppu;return (Math.abs(n)>=100||Number.isInteger(+n.toFixed(4))?String(Math.round(n*100)/100):n.toFixed(2).replace(/0+$/,'').replace(/\.$/,''));};
  for(let v=a;v<=b;v+=step){const p=off+v*S.zoom,t=fmt(v);
    if(horiz)x.fillText(t,p+3,10);else{x.save();x.translate(10,p+3);x.rotate(-Math.PI/2);x.textAlign='right';x.fillText(t,0,0);x.restore();}}
  x.strokeStyle='#222';x.beginPath();
  if(horiz){x.moveTo(0,r.height-.5);x.lineTo(r.width,r.height-.5);}else{x.moveTo(r.width-.5,0);x.lineTo(r.width-.5,r.height);}
  x.stroke();
}
/* ===== the Preferences window ===== */
function prefsPages(){
  const T=(k,label,def,hint)=>({t:'bool',k,label,def,hint}),Sel=(k,label,opts,def)=>({t:'sel',k,label,opts,def}),R=(k,label,min,max,def,unit,step)=>({t:'rng',k,label,min,max,def,unit,step}),C=(k,label,def)=>({t:'col',k,label,def});
  return [
   ['general','General',[T('wheelZoom','Mouse wheel zooms (otherwise it scrolls)',false),R('zoomSpeed','Zoom speed',1,6,2,'',1),T('toasts','Show small status messages',true,'Warnings and errors are always shown.'),{t:'btns',b:[['Keyboard Shortcuts...','keys'],['Reset All Preferences','reset']]}]],
   ['interface','Interface',[{t:'themes'},Sel('ui','Text size',[[12,'Small'],[13,'Medium'],[15,'Large']],13),Sel('canvasBg','Canvas background',Object.entries(CANVAS_BG).map(([n,v])=>[v,n]),''),C('accent','Highlight colour','#2d8ceb'),T('scrollbars','Show scroll bars',true),{t:'act',label:'Show rulers',k:'rulers'}]],
   ['workspace','Workspace',[{t:'ws'}]],
   ['tools','Tools',[T('auto','Move tool selects the layer you click',true),T('snap','Snap to guides and grid',true),R('brushSize','Default brush size',1,2500,40,' px',1),R('brushHard','Default brush hardness',0,100,60,'%',1),Sel('cursor','Brush cursor',[['normal','Brush outline'],['cross','Outline with crosshair']],'normal')]],
   ['hist','History & Cache',[R('hist','History states',20,200,50,'',1),{t:'btns',b:[['Purge Histories','pg-undo'],['Purge Clipboard','pg-clip'],['Purge All','pg-all']]}]],
   ['files','File Handling',[T('askWhere','Ask where to save files (Save As window)',true,'Uses the browser or system save window when it is available.'),Sel('autosave','Auto-save to this device',[[0,'Off'],[1,'Every minute'],[2,'Every 2 minutes'],[5,'Every 5 minutes'],[10,'Every 10 minutes'],[30,'Every 30 minutes']],0),Sel('saveFmt','Default Save As format',SAVE_FORMATS.map(f=>[f[0],f[1]]),'psd')]],
   ['perf','Performance',[Sel('previewMax','Live preview quality (filters and adjustments)',[[600,'Fast (600 px)'],[900,'Balanced (900 px)'],[1400,'Sharper (1400 px)'],[2000,'Best (2000 px)']],900),{t:'info'}]],
   ['units','Units & Rulers',[Sel('unit','Ruler units',[['px','Pixels'],['in','Inches'],['cm','Centimetres'],['mm','Millimetres'],['pt','Points']],'px'),{t:'note',text:'Inches, centimetres, millimetres and points use the print resolution of the document (see Image > Image Size).'}]],
   ['grid','Guides & Grid',[R('gridStep','Gridline every',10,500,100,' px',10),R('gridSub','Subdivisions',1,10,1,'',1),C('gridCol','Grid colour','#78a0ff'),C('guideCol','Guide colour','#19c2d8'),{t:'act',label:'Show grid',k:'grid'}]],
   ['trans','Transparency',[R('chkSize','Checkerboard size',6,40,16,' px',2),C('chk1','Checkerboard colour 1','#cfcfcf'),C('chk2','Checkerboard colour 2','#ffffff')]],
   ['type','Type',[Sel('txtFont','Default font for new text',(typeof FONTS!=='undefined'?FONTS.map(f=>[f.n||f,f.n||f]):[['Montserrat','Montserrat']]).slice(0,400),'Montserrat'),R('txtSize','Default text size (0 = automatic)',0,800,0,' px',2),T('txtBold','New text starts bold',true)]]
  ];
}
function openPrefs(tab){
  const pages=prefsPages();tab=tab||'general';
  const val=(it)=>PREFS[it.k]===undefined?it.def:PREFS[it.k];
  const body=id=>{
    const pg=pages.find(p=>p[0]===id)||pages[0];
    return '<h3 class="pfh">'+pg[1]+'</h3>'+pg[2].map(it=>{
      if(it.t==='bool')return '<label class="pfr"><input type="checkbox" data-pk="'+it.k+'" '+(val(it)?'checked':'')+'><span>'+esc(it.label)+'</span></label>'+(it.hint?'<div class="muted pfhint">'+esc(it.hint)+'</div>':'');
      if(it.t==='sel')return '<label class="pfr"><span>'+esc(it.label)+'</span><select data-pk="'+it.k+'">'+it.opts.map(o=>'<option value="'+esc(String(o[0]))+'"'+(String(val(it))===String(o[0])?' selected':'')+'>'+esc(o[1])+'</option>').join('')+'</select></label>';
      if(it.t==='rng'){const v=val(it);return '<label class="pfr"><span>'+esc(it.label)+'</span><input type="range" data-pk="'+it.k+'" min="'+it.min+'" max="'+it.max+'" step="'+(it.step||1)+'" value="'+v+'"><output>'+v+(it.unit||'')+'</output></label>';}
      if(it.t==='col')return '<label class="pfr"><span>'+esc(it.label)+'</span><input type="color" data-pk="'+it.k+'" value="'+val(it)+'"><button data-pkreset="'+it.k+'">Default</button></label>';
      if(it.t==='btns')return '<div class="row">'+it.b.map(b=>'<button data-pb="'+b[1]+'">'+esc(b[0])+'</button>').join('')+'</div>';
      if(it.t==='themes')return '<div class="h">Colour theme</div><div class="themes">'+Object.keys(THEMES).map(n=>'<button class="thm'+((PREFS.theme||'Darkest')===n?' on':'')+'" data-th="'+n+'" style="background:'+THEMES[n]['--panel']+';color:'+THEMES[n]['--fg']+'">'+n+'</button>').join('')+'</div>';
      if(it.t==='act'){const on=it.k==='rulers'?S.rulers:S.grid;return '<label class="pfr"><input type="checkbox" data-pa="'+it.k+'" '+(on?'checked':'')+'><span>'+esc(it.label)+'</span></label>';}
      if(it.t==='ws'){const cur=PREFS.workspace||'Essentials';return '<div class="h">Workspace</div><div class="themes">'+Object.keys(WORKSPACES).concat(Object.keys(userWs())).map(n=>'<button class="thm'+(cur===n?' on':'')+'" data-ws="'+esc(n)+'">'+esc(n)+'</button>').join('')+'</div><div class="row"><button data-pb="wsnew">New Workspace...</button><button data-pb="wsreset">Reset Current Workspace</button></div><p class="muted">Each workspace arranges the panels and picks a starting tool. Switch quickly with the workspace button at the top right.</p>';}
      if(it.t==='info'){const mem=navigator.deviceMemory?navigator.deviceMemory+' GB device memory':'device memory not reported',cores=navigator.hardwareConcurrency?navigator.hardwareConcurrency+' processor threads':'';return '<div class="muted pfhint">This device: '+mem+(cores?', '+cores:'')+'. Lower the live preview quality if filters feel slow on a phone.</div>';}
      if(it.t==='note')return '<p class="muted">'+esc(it.text)+'</p>';return '';
    }).join('');
  };
  modalOpen('Preferences','<div class="prefs"><nav class="pfnav">'+pages.map(p=>'<button data-pg="'+p[0]+'" class="'+(p[0]===tab?'on':'')+'">'+p[1]+'</button>').join('')+'</nav><div class="pfbody2" id="pfb">'+body(tab)+'</div></div>',[{label:'Done',primary:true}],root=>{
    const show=id=>{tab=id;root.querySelectorAll('.pfnav button').forEach(b=>b.classList.toggle('on',b.dataset.pg===id));$('#pfb',root).innerHTML=body(id);};
    root.addEventListener('click',e=>{
      const n=e.target.closest('[data-pg]');if(n){show(n.dataset.pg);return;}
      const th=e.target.closest('[data-th]');if(th){PREFS.theme=th.dataset.th;savePrefs();applyPrefs();show('interface');return;}
      const ws=e.target.closest('[data-ws]');if(ws){applyWorkspace(ws.dataset.ws);show('workspace');return;}
      const rs=e.target.closest('[data-pkreset]');if(rs){delete PREFS[rs.dataset.pkreset];savePrefs();applyPrefs();show(tab);return;}
      const b=e.target.closest('[data-pb]');if(!b)return;const a=b.dataset.pb;
      if(a==='keys'){closeModal();setTimeout(openShortcuts,30);}
      else if(a==='reset'){Object.keys(PREFS).forEach(x=>delete PREFS[x]);try{localStorage.removeItem('lk_prefs');}catch(e2){}applyPrefs();applyWorkspace('Essentials',true);show(tab);toast('Preferences reset');}
      else if(a.startsWith('pg-'))purge(a.slice(3)==='undo'?'undo':a.slice(3));
      else if(a==='wsnew'){closeModal();setTimeout(saveWorkspaceAs,30);}
      else if(a==='wsreset')applyWorkspace(WORKSPACES[PREFS.workspace||'Essentials']?(PREFS.workspace||'Essentials'):'Essentials');
    });
    const setPref=(t)=>{const k=t.dataset.pk;if(!k)return;let v=t.type==='checkbox'?t.checked:t.type==='range'?+t.value:t.value;
      const it=pages.flatMap(p=>p[2]).find(x=>x.k===k);if(it&&it.t==='sel'&&typeof it.def==='number')v=+v;
      PREFS[k]=v;savePrefs();
      if(t.type==='range'){const o=t.nextElementSibling;if(o)o.textContent=t.value+((it&&it.unit)||'');}
      if(k==='ui')document.body.style.fontSize=v+'px';
      if(k==='hist')S.histMax=clamp(v,20,200);
      applyPrefs2();if(k==='scrollbars'||k==='unit'||k==='gridStep'||k==='gridSub'||k==='gridCol'){if(doc){applyView();redraw();}}
    };
    root.addEventListener('input',e=>{if(e.target.dataset.pk&&(e.target.type==='range'||e.target.type==='color'))setPref(e.target);});
    root.addEventListener('change',e=>{const t=e.target;if(t.dataset.pk)setPref(t);else if(t.dataset.pa){if(t.dataset.pa==='rulers')ACT.rulers();else ACT.grid();}});
  },{wide:true});
}
ACT.prefs=()=>openPrefs('general');
{
  const M=MENUS.find(m=>m.label==='Edit'),i=M.items.findIndex(x=>x.label==='Preferences');
  const pr=sub('Preferences',[['general','General...'],['interface','Interface...'],['workspace','Workspace...'],['tools','Tools...'],['hist','History & Cache...'],['files','File Handling...'],['perf','Performance...'],['units','Units & Rulers...'],['grid','Guides & Grid...'],['trans','Transparency...'],['type','Type...']].map(a=>al(a[1],a[0]==='general'?'Ctrl+K':'',()=>openPrefs(a[0]))),{dis:()=>false});
  if(i>=0)M.items[i]=pr;else M.items.push(pr);
}
let LASTFH=null;
/* ===== Save As: choose where to save ===== */
{
  const _sb=saveBlob;
  saveBlob=async function(blob,name){
    if(PREFS.askWhere!==false&&typeof window.showSaveFilePicker==='function'){
      try{
        const ext=(name.match(/\.([a-z0-9]+)$/i)||[])[1]||'bin',type=blob.type||'application/octet-stream';
        const h=await window.showSaveFilePicker({suggestedName:name,types:[{description:ext.toUpperCase()+' file',accept:{[type]:['.'+ext]}}]});
        const w=await h.createWritable();await w.write(blob);await w.close();LASTFH=h;toast('Saved as '+(h.name||name));return;
      }catch(err){
        if(err&&err.name==='AbortError'){toast('Save cancelled');return;}
        // not allowed in this window (for example inside a frame): fall back to the normal download
      }
    }
    return _sb(blob,name);
  };
  const _osa=openSaveAs;
  openSaveAs=function(copy){_osa(copy);
    const foot=document.querySelector('#modal #mbody');if(!foot||document.getElementById('sa-where'))return;
    const can=typeof window.showSaveFilePicker==='function';
    const d=document.createElement('div');d.id='sa-where';d.className='muted';d.style.marginTop='8px';
    d.innerHTML=can?'<label class="row"><input type="checkbox" id="sa-ask" '+(PREFS.askWhere!==false?'checked':'')+'> Choose where to save (opens your system save window)</label>':'Your browser saves to its Downloads folder. In Chrome or Edge, turn on <b>Ask where to save each file</b> in the browser settings to choose the folder each time. The installed Windows app asks every time.';
    foot.appendChild(d);const a=document.getElementById('sa-ask');if(a)a.onchange=()=>{PREFS.askWhere=a.checked;savePrefs();};
  };
}
applyPrefs2();
