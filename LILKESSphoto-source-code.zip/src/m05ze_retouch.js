/* ===== Retouch Studio ===== */
const RT0={smooth:40,keep:35,tone:30,red:30,fs:0,eyes:0,teeth:0,dark:0,lips:0,lipHue:350,glow:0,sharp:0,skinOnly:1};
function rtSkin(d,n){const m=new Float32Array(n);for(let k=0,i=0;k<n;k++,i+=4){const R=d[i],G=d[i+1],B=d[i+2],cb=128-0.168736*R-0.331264*G+0.5*B,cr=128+0.5*R-0.418688*G-0.081312*B;
  const a=Math.min(1,Math.max(0,(cb-72)/5),Math.max(0,(132-cb)/5)),b=Math.min(Math.max(0,(cr-128)/5),Math.max(0,(178-cr)/5),1);m[k]=Math.min(a,b);}return m;}
function rtBlurMask(m,w,h,r){if(r<1)return m;const t=new Uint8ClampedArray(w*h*4);for(let k=0;k<w*h;k++){const v=m[k]*255;t[k*4]=v;t[k*4+1]=v;t[k*4+2]=v;t[k*4+3]=255;}boxBlur(t,w,h,r,2);const o=new Float32Array(w*h);for(let k=0;k<w*h;k++)o[k]=t[k*4]/255;return o;}
/* paint: Float32 mask 0..1 or null (nothing painted). returns new ImageData */
function rtProcess(img,p,paint,scale){
  const w=img.width,h=img.height,n=w*h,d=new Uint8ClampedArray(img.data),R=Math.max(1,Math.round(scale*Math.max(w,h)/ (scale<1?1:1)*0+Math.max(w,h)/260));
  const skin=rtBlurMask(rtSkin(img.data,n),w,h,1);
  // area for global effects: painted area if any, intersect skin if "skin only"
  const area=new Float32Array(n);for(let k=0;k<n;k++){let a=paint?paint[k]:1;if(p.skinOnly)a*=skin[k];area[k]=a;}
  const mixIn=(res,mask)=>{for(let i=0,k=0;i<d.length;i+=4,k++){const m=mask[k];if(m<=0.003)continue;for(let q=0;q<3;q++)d[i+q]+=(res[i+q]-d[i+q])*m;}};
  const painted=paint||null;const pm=painted||new Float32Array(n);
  // 1 smoothing with texture keep (frequency separation)
  if(p.smooth>0){const bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(2,R),3);const bl2=new Uint8ClampedArray(d);boxBlur(bl2,w,h,Math.max(1,Math.round(R*0.35)),2);
    const res=new Uint8ClampedArray(d.length),amt=p.smooth/100,keep=p.keep/100;
    for(let i=0;i<d.length;i+=4){const L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],Lb=0.299*bl[i]+0.587*bl[i+1]+0.114*bl[i+2],df=L-Lb,e=Math.exp(-(df*df)/(2*22*22));
      for(let q=0;q<3;q++){const smooth=bl[i+q]*(1-keep*0.0)+(d[i+q]-bl2[i+q])*keep;res[i+q]=d[i+q]+((bl2[i+q]*0+bl[i+q]+(d[i+q]-bl2[i+q])*keep)-d[i+q])*amt*e;}}
    mixIn(res,area);}
  // 2 even skin tone: pull chroma toward large-scale average
  if(p.tone>0){const bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(3,R*3),3);const res=new Uint8ClampedArray(d.length),a=p.tone/100;
    for(let i=0;i<d.length;i+=4){const L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],Lb=0.299*bl[i]+0.587*bl[i+1]+0.114*bl[i+2];for(let q=0;q<3;q++)res[i+q]=d[i+q]+((bl[i+q]-Lb+L)-d[i+q])*a*0.85;}
    mixIn(res,area);}
  // 3 reduce redness
  if(p.red>0){const res=new Uint8ClampedArray(d),a=p.red/100;for(let i=0;i<d.length;i+=4){const r=d[i],g=d[i+1],b=d[i+2],ex=r-(g+b)/2;if(ex>14){const k=Math.min(1,(ex-14)/50)*a*0.7;res[i]=r-(r-(g+b)/2-10)*k;}}mixIn(res,area);}
  // 4 face slim not possible without landmarks (honest) ; soft glow
  if(p.glow>0){const bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(3,R*4),3);const res=new Uint8ClampedArray(d.length),a=p.glow/100;for(let i=0;i<d.length;i+=4)for(let q=0;q<3;q++)res[i+q]=255-(255-d[i+q])*(255-bl[i+q]*a)/255;mixIn(res,area);}
  // painted-only effects
  if(painted){
    if(p.eyes>0){const bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(1,R*0.6),2);const res=new Uint8ClampedArray(d),a=p.eyes/100;
      for(let i=0;i<d.length;i+=4){const L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],mx=Math.max(d[i],d[i+1],d[i+2]),mn=Math.min(d[i],d[i+1],d[i+2]),sat=mx?1-mn/mx:0,wh=Math.max(0,1-sat*2.2)*Math.min(1,Math.max(0,(L-90)/90));
        for(let q=0;q<3;q++){const c=d[i+q]+(255-d[i+q])*wh*a*0.6;res[i+q]=c+(d[i+q]-bl[i+q])*a*0.8*(1-wh);}}mixIn(res,painted);}
    if(p.teeth>0){const res=new Uint8ClampedArray(d),a=p.teeth/100;
      for(let i=0;i<d.length;i+=4){const r=d[i],g=d[i+1],b=d[i+2],L=(r+g+b)/3,yel=Math.max(0,(r+g)/2-b);if(L>110){const y=Math.min(1,yel/60);res[i+2]=Math.min(255,b+yel*0.8*a*y);const k=1+a*0.12*Math.min(1,(L-110)/100);res[i]=Math.min(255,r*k-yel*0.15*a);res[i+1]=Math.min(255,g*k);res[i+2]=Math.min(255,res[i+2]*k);}}mixIn(res,painted);}
    if(p.dark>0){const bl=new Uint8ClampedArray(d);boxBlur(bl,w,h,Math.max(2,R*1.5),3);const res=new Uint8ClampedArray(d),a=p.dark/100;
      for(let i=0;i<d.length;i+=4){const L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];const lift=Math.max(0,(150-L))/150*a*0.65;for(let q=0;q<3;q++)res[i+q]=d[i+q]+(255-d[i+q])*lift*0.55+(bl[i+q]-d[i+q])*a*0.4;}mixIn(res,painted);}
    if(p.lips>0){const res=new Uint8ClampedArray(d),a=p.lips/100,hh=p.lipHue;
      for(let i=0;i<d.length;i+=4){const r=d[i],g=d[i+1],b=d[i+2],L=(0.299*r+0.587*g+0.114*b);const hs=hsl2rgb(hh,0.55,Math.min(0.62,Math.max(0.28,L/255)));if(hs){for(let q=0;q<3;q++)res[i+q]=d[i+q]*(1-0.8)+hs[q]*0.8;}}mixIn(res,painted.map?painted.map(v=>v*a):painted);}
  }
  if(p.sharp>0){const u=unsharp(new ImageData(new Uint8ClampedArray(d),w,h),p.sharp*3,1.2,0,{scale:1});mixIn(u.data,painted||area);}
  return new ImageData(d,w,h);
}
function hsl2rgb_h(h,s,l){h=((h%360)+360)%360/360;const f=(p,q,t)=>{if(t<0)t+=1;if(t>1)t-=1;return t<1/6?p+(q-p)*6*t:t<.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p;};const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q;return [f(p,q,h+1/3)*255,f(p,q,h)*255,f(p,q,h-1/3)*255];}
function hsl2rgb(h,s,l){return hsl2rgb_h(h,s,l);}
defFx('retouchauto','retouch','Auto Retouch (skin)',[P('smooth','Smooth skin',0,100,40),P('keep','Keep texture',0,100,35),P('tone','Even skin tone',0,100,30),P('red','Reduce redness',0,100,30),P('glow','Soft glow',0,100,0)],(img,p,c)=>rtProcess(img,Object.assign({},RT0,p,{skinOnly:1,eyes:0,teeth:0,dark:0,lips:0,sharp:0}),null,(c&&c.scale)||1));
defFx('evenskin','retouch','Even Skin Tone',[P('tone','Amount',0,100,60)],(img,p,c)=>rtProcess(img,Object.assign({},RT0,{smooth:0,tone:p.tone,red:0}),null,(c&&c.scale)||1));
defFx('redness','retouch','Reduce Redness',[P('red','Amount',0,100,60)],(img,p,c)=>rtProcess(img,Object.assign({},RT0,{smooth:0,tone:0,red:p.red}),null,(c&&c.scale)||1));
defFx('softglow2','retouch','Portrait Glow',[P('glow','Amount',0,100,40)],(img,p,c)=>rtProcess(img,Object.assign({},RT0,{smooth:0,tone:0,red:0,glow:p.glow,skinOnly:0}),null,(c&&c.scale)||1));
ACT.retouch=function(){
  if(!doc){toast('Create or open a design first');return;}flush();const l=active();if(!l){toast('Select a photo layer first');return;}
  if(l.type==='adjust'){toast('Select a photo layer');return;}
  const base=flatLayer(l),W=base.width,H=base.height,k=Math.min(1,640/Math.max(W,H)),w=Math.round(W*k),h=Math.round(H*k);
  const sc0=mkCanvas(w,h);cctx(sc0).drawImage(base,0,0,w,h);const src=cctx(sc0).getImageData(0,0,w,h);
  const mc=mkCanvas(w,h),mx=cctx(mc);let p=Object.assign({},RT0),brush={size:40,erase:false},raf=0,paintedAny=false,showMask=true;
  const sl=(key,label,min,max)=>'<label class="sl"><span>'+label+'</span><input type="range" data-rk="'+key+'" min="'+min+'" max="'+max+'" value="'+p[key]+'"><input type="number" class="nv" data-rk="'+key+'" min="'+min+'" max="'+max+'" value="'+p[key]+'"></label>';
  modalOpen('Retouch Studio','<div class="rts"><div class="rts-side"><details open><summary>Skin (applies to skin tones)</summary>'+sl('smooth','Smooth skin',0,100)+sl('keep','Keep texture',0,100)+sl('tone','Even skin tone',0,100)+sl('red','Reduce redness',0,100)+sl('glow','Portrait glow',0,100)+'<label class="opt"><input type="checkbox" id="rt-skin" checked> Limit to skin tones</label></details><details open><summary>Paint over the area, then use</summary>'+sl('eyes','Brighten eyes',0,100)+sl('teeth','Whiten teeth',0,100)+sl('dark','Lighten dark circles',0,100)+sl('lips','Lip colour',0,100)+sl('lipHue','Lip hue',0,360)+sl('sharp','Sharpen details',0,100)+'</details><details open><summary>Brush (paints where to retouch)</summary>'+'<label class="sl"><span>Size</span><input type="range" id="rt-bs" min="5" max="200" value="40"></label><div class="row"><button id="rt-b1" class="on">Paint</button><button id="rt-b2">Erase</button><button id="rt-clr">Clear</button></div><label class="opt"><input type="checkbox" id="rt-show" checked> Show painted area</label><label class="opt"><input type="checkbox" id="rt-prev" checked> Preview</label><p class="muted">Nothing painted = skin settings apply to every skin tone in the picture. Eyes, teeth, dark circles, lips and sharpen only work on the area you paint.</p></details></div><div class="rts-c"><canvas id="rt-c"></canvas><canvas id="rt-m"></canvas></div></div>',
   [{label:'Cancel'},{label:'Apply',primary:true,cb:()=>{const t=paintTarget('Retouch');if(!t)return;
      const full=cctx(base).getImageData(0,0,W,H),mf=mkCanvas(W,H);cctx(mf).drawImage(mc,0,0,W,H);const md=cctx(mf).getImageData(0,0,W,H).data;let pm=null;if(paintedAny){pm=new Float32Array(W*H);for(let i=0;i<pm.length;i++)pm[i]=md[i*4+3]/255;}
      const out=rtProcess(full,p,pm,1),oc=mkCanvas(W,H);cctx(oc).putImageData(out,0,0);paintDoc(t,oc,{op:1,blend:'source-over'});commit('Retouch Studio');refreshLayers();redraw();toast('Retouch applied');}}],
   body=>{
    const cv=body.querySelector('#rt-c'),cx=cv.getContext('2d'),ov=body.querySelector('#rt-m'),ox=ov.getContext('2d');cv.width=ov.width=w;cv.height=ov.height=h;
    const maskArr=()=>{if(!paintedAny)return null;const d=mx.getImageData(0,0,w,h).data,m=new Float32Array(w*h);for(let i=0;i<m.length;i++)m[i]=d[i*4+3]/255;return m;};
    const draw=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{
      if(body.querySelector('#rt-prev').checked){try{cx.putImageData(rtProcess(src,p,maskArr(),k),0,0);}catch(e){console.error(e);}}else cx.putImageData(src,0,0);
      ox.clearRect(0,0,w,h);if(showMask&&paintedAny){ox.globalAlpha=0.35;ox.drawImage(mc,0,0);ox.globalCompositeOperation='source-in';ox.fillStyle='#ff3b6b';ox.fillRect(0,0,w,h);ox.globalCompositeOperation='source-over';ox.globalAlpha=1;}});};
    body.addEventListener('input',e=>{const t=e.target;if(t.dataset.rk){const v=+t.value;p[t.dataset.rk]=v;body.querySelectorAll('[data-rk="'+t.dataset.rk+'"]').forEach(o=>{if(o!==t)o.value=v;});draw();}else if(t.id==='rt-bs')brush.size=+t.value;});
    body.querySelector('#rt-skin').onchange=e=>{p.skinOnly=e.target.checked?1:0;draw();};
    body.querySelector('#rt-prev').onchange=draw;body.querySelector('#rt-show').onchange=e=>{showMask=e.target.checked;draw();};
    body.querySelector('#rt-b1').onclick=()=>{brush.erase=false;body.querySelector('#rt-b1').classList.add('on');body.querySelector('#rt-b2').classList.remove('on');};
    body.querySelector('#rt-b2').onclick=()=>{brush.erase=true;body.querySelector('#rt-b2').classList.add('on');body.querySelector('#rt-b1').classList.remove('on');};
    body.querySelector('#rt-clr').onclick=()=>{mx.clearRect(0,0,w,h);paintedAny=false;draw();};
    let last=null;const pos=e=>{const r=ov.getBoundingClientRect();return [(e.clientX-r.left)*w/r.width,(e.clientY-r.top)*h/r.height];};
    const dab=(a,b)=>{mx.save();mx.globalCompositeOperation=brush.erase?'destination-out':'source-over';mx.strokeStyle=mx.fillStyle='#000';mx.lineCap=mx.lineJoin='round';mx.lineWidth=brush.size*k;mx.beginPath();mx.moveTo(a[0],a[1]);mx.lineTo(b[0],b[1]);mx.stroke();mx.restore();if(!brush.erase)paintedAny=true;};
    ov.addEventListener('pointerdown',e=>{ov.setPointerCapture(e.pointerId);last=pos(e);dab(last,[last[0]+0.01,last[1]]);draw();});
    ov.addEventListener('pointermove',e=>{if(!last)return;const q=pos(e);dab(last,q);last=q;draw();});
    ov.addEventListener('pointerup',()=>{last=null;});
    draw();
   },{wide:true});
};
