/* ===== Templates: Birthday ===== */
TEMPLATES.push(
{name:'Kids balloon party',cat:'Birthday',tags:'birthday kids balloons party child',w:1080,h:1350,build(){
  tGrad('#38bdf8','#e0f2fe',180);
  tDots(14,'#ffffff',11,[0,0,1,.5],.05,.16,.55);
  tBalloon(.18,.2,.2,'#ef4444');tBalloon(.34,.14,.17,'#facc15');tBalloon(.82,.18,.21,'#a855f7');tBalloon(.66,.12,.16,'#22c55e');tBalloon(.5,.2,.15,'#f97316');
  tConfetti(40,['#ef4444','#facc15','#22c55e','#a855f7','#f97316'],5,[0,.3,1,1],{op:.9});
  tText('HAPPY\nBIRTHDAY',0.5,0.52,{font:'Erica One',size:165,bold:false,color:'#ff3d71',lh:1,stroke:'#ffffff',sw:14,shadow:20,shadowColor:'#0c4a6e55'});
  tShape('round',0.5,0.78,0.78,0.15,'#ffffff',{name:'Name tag',p:{radius:60}});
  tText("EMMA IS TURNING 5!",0.5,0.78,{font:'Outfit',size:74,color:'#0369a1'});
  tText('Saturday 14 June  •  3 PM\nBouncy castle, cake and games\n12 Garden Road',0.5,0.91,{font:'Outfit',size:40,bold:false,color:'#0c4a6e',lh:1.35});
}},
{name:'Elegant gold birthday',cat:'Birthday',tags:'birthday elegant gold black luxury adult',w:1080,h:1350,build(){
  tRadial('#2a2310','#050505',.5,.4,.8);
  tFrame(.5,.5,.88,1.1,'#d4af37',4);tFrame(.5,.5,.84,1.05,'#d4af37',1.5);
  tText('You are invited to celebrate',0.5,0.17,{font:'Instrument Serif',size:54,bold:false,italic:true,color:'#e8d9a0'});
  tText('Happy',0.5,0.3,{font:'Great Vibes',size:230,bold:false,color:'#d4af37',shadow:16,shadowColor:'#000000'});
  tText('BIRTHDAY',0.5,0.45,{font:'Italiana',size:150,bold:false,color:'#f5ecc8'});
  tRule(.5,.54,.4,'#d4af37',3);
  tText('SOPHIA',0.5,0.63,{font:'Gloock',size:120,bold:false,color:'#d4af37'});
  tText('SATURDAY 20 SEPTEMBER 2026\n7 PM  •  THE GRAND HALL',0.5,0.78,{font:'Outfit',size:42,color:'#f5ecc8',lh:1.5,bold:false});
  tText('Dress code: black tie  •  RSVP 000 000 0000',0.5,0.9,{font:'Instrument Serif',size:40,bold:false,italic:true,color:'#d4af37'});
  tStar(.5,.095,.035,'#d4af37');
}},
{name:'First birthday',cat:'Birthday',tags:'1st one baby first birthday pastel',w:1080,h:1350,build(){
  tGrad('#fff4e6','#ffe3d3',180);
  tShape('ellipse',.5,.5,1.1,1.1,'#ffd6c2',{name:'Glow'}).opacity=.5;
  tDots(10,'#fdba74',3,[.05,.05,.95,.95],.03,.07,.4);
  tText('Baby\'s',0.5,0.14,{font:'Nothing You Could Do',size:100,bold:false,color:'#c2410c'});
  tText('ONE',0.5,0.36,{font:'Gloock',size:410,bold:false,color:'#ea580c',shadow:0});
  tText('FIRST BIRTHDAY',0.5,0.62,{font:'Outfit',size:84,color:'#9a3412'});
  tStar(.15,.55,.06,'#fbbf24');tStar(.86,.3,.05,'#fb7185');tStar(.82,.62,.04,'#fbbf24');
  tShape('round',0.5,0.8,0.72,0.12,'#ea580c',{name:'Date pill',p:{radius:60}});
  tText('SUNDAY 5 JULY  •  2 PM',0.5,0.8,{font:'Outfit',size:50,color:'#ffffff'});
  tText('Join us for cake, balloons & fun\nat Grandma\'s house',0.5,0.92,{font:'Outfit',size:40,bold:false,color:'#9a3412',lh:1.35});
}},
{name:'Neon 21st',cat:'Birthday',tags:'21st neon birthday party night 18th 30th',w:1080,h:1350,build(){
  tGrad('#12002b','#2b0057',160);
  tShape('ellipse',.5,.38,.8,.8,null,{name:'Neon ring',p:{stroke:'#22d3ee',sw:6,nofill:true}}).fx={shadow:{on:true,color:'#22d3ee',op:1,angle:0,dist:0,size:30,blend:'source-over',spread:0,noise:0,knock:true}};
  tText('21',0.5,0.4,{font:'Tektur',size:620,bold:true,color:'#ffffff',shadow:50,shadowColor:'#ff2fb3'});
  tText('TURNING',0.5,0.14,{font:'Outfit',size:80,color:'#22d3ee',shadow:24,shadowColor:'#22d3ee'});
  tText('LET\'S GET LIT',0.5,0.72,{font:'Bricolage Grotesque',size:110,color:'#ff2fb3',shadow:30,shadowColor:'#ff2fb3'});
  tText('FRIDAY 12 DECEMBER  •  10 PM\nROOFTOP LOUNGE  •  DJ + OPEN BAR',0.5,0.84,{font:'Outfit',size:44,color:'#ffffff',lh:1.5,bold:false});
  tConfetti(26,['#22d3ee','#ff2fb3','#a78bfa'],9,[0,.02,1,.98],{op:.8});
}},
{name:'Sweet 16 pink',cat:'Birthday',tags:'girl pink sweet 16 birthday pastel princess',w:1080,h:1350,build(){
  tGrad('#fbcfe8','#f9a8d4',180);
  tShape('ellipse',.5,.5,.95,.95,'#ffffff',{name:'Arch'}).opacity=.35;
  tCustom('crown',.5,.17,.2,.14,'#f59e0b',{name:'Crown'});
  tText('Sweet',0.5,0.29,{font:'Pacifico',size:190,bold:false,color:'#be185d',shadow:10,shadowColor:'#ffffff'});
  tText('16',0.5,0.5,{font:'Gloock',size:380,bold:false,color:'#ffffff',shadow:30,shadowColor:'#be185d88'});
  tText('Ava\'s birthday bash',0.5,0.72,{font:'Dancing Script',size:100,color:'#9d174d'});
  tText('SATURDAY 8 AUGUST  •  6 PM\nPool party + dinner  •  Dress in pink',0.5,0.85,{font:'Outfit',size:42,color:'#831843',lh:1.5,bold:false});
  tCustom('heart',.12,.6,.07,.07,'#ec4899',{name:'Heart'});tCustom('heart',.88,.62,.05,.05,'#ec4899',{name:'Heart'});tCustom('heart',.84,.2,.06,.06,'#f472b6',{name:'Heart'});
}},
{name:'Birthday boy blue',cat:'Birthday',tags:'boy blue birthday kids superhero',w:1080,h:1350,build(){
  tGrad('#0b3a8c','#0a1f52',180);
  tCustom('burst',.5,.36,1.0,1.0,'#1d4ed8',{name:'Burst'});
  tCustom('burst',.5,.36,.72,.72,'#2563eb',{name:'Burst 2'});
  tText('BIRTHDAY',0.5,0.27,{font:'Big Shoulders Display',size:250,bold:true,color:'#fde047',stroke:'#0a1f52',sw:10});
  tText('BOY!',0.5,0.45,{font:'Erica One',size:380,bold:false,color:'#ffffff',stroke:'#0a1f52',sw:16,shadow:20,shadowColor:'#00000066'});
  tText('LUCAS IS 7',0.5,0.67,{font:'Big Shoulders Display',size:140,color:'#fde047'});
  tShape('rect',0.5,0.82,1,0.14,'#fde047',{name:'Band'});
  tText('SAT 10 MAY  •  2 PM  •  SKATE PARK',0.5,0.82,{font:'Outfit',size:50,color:'#0a1f52'});
  tText('RSVP 000 000 0000',0.5,0.94,{font:'Outfit',size:40,color:'#ffffff',bold:false});
  tStar(.12,.1,.07,'#fde047');tStar(.88,.12,.06,'#fde047');
}},
{name:'Birthday invitation card',cat:'Birthday',tags:'invitation invite card birthday cream',w:1240,h:1754,build(){
  tSolid('#fbf3e4');
  tFrame(.5,.5,.9,.93*1754/1240*.9,'#b45309',3);
  tDots(8,'#f59e0b',2,[.1,.05,.9,.2],.03,.06,.35);
  tText('YOU\'RE',0.5,0.2,{font:'Instrument Serif',size:150,bold:false,italic:true,color:'#7c2d12'});
  tText('INVITED',0.5,0.3,{font:'Gloock',size:230,bold:false,color:'#b45309'});
  tText('to celebrate the birthday of',0.5,0.4,{font:'Instrument Serif',size:60,bold:false,italic:true,color:'#7c2d12'});
  tText('Michael',0.5,0.5,{font:'Great Vibes',size:260,bold:false,color:'#7c2d12'});
  tRule(.5,.6,.3,'#b45309',3);
  tText('SATURDAY  •  18 JULY  •  4 PM',0.5,0.67,{font:'Outfit',size:60,color:'#7c2d12'});
  tText('The Rose Garden Pavilion\n45 Park Avenue, Accra',0.5,0.76,{font:'Outfit',size:52,bold:false,color:'#7c2d12',lh:1.4});
  tText('Food  •  Music  •  Cake',0.5,0.83,{font:'Instrument Serif',size:64,bold:false,italic:true,color:'#b45309'});
  tText('RSVP to 000 000 0000',0.5,0.89,{font:'Outfit',size:42,color:'#7c2d12'});
}},
{name:'Happy birthday story',cat:'Birthday',tags:'story instagram birthday wish',w:1080,h:1920,build(){
  tGrad('#ff9a3c','#ff3d81',160);
  tDots(12,'#ffffff',4,[0,0,1,1],.05,.14,.18);
  tBalloon(.22,.22,.24,'#fde047');tBalloon(.8,.18,.22,'#22d3ee');tBalloon(.52,.12,.18,'#ffffff');
  tConfetti(50,['#ffffff','#fde047','#22d3ee','#a855f7'],8,[0,.3,1,1],{op:.9});
  tText('Happy',0.5,0.42,{font:'Pacifico',size:230,bold:false,color:'#ffffff',shadow:24,shadowColor:'#9d174d88'});
  tText('BIRTHDAY',0.5,0.56,{font:'Big Shoulders Display',size:260,color:'#ffffff'});
  tShape('round',0.5,0.69,0.7,0.12,'#ffffff',{name:'Name pill',p:{radius:70}});
  tText('YOUR NAME',0.5,0.69,{font:'Outfit',size:84,color:'#e11d48'});
  tText('Wishing you joy, love and endless cake!',0.5,0.79,{font:'Instrument Serif',size:70,bold:false,italic:true,color:'#ffffff'});
}},
{name:'50th milestone',cat:'Birthday',tags:'50th fifty milestone gold green adult birthday',w:1080,h:1350,build(){
  tGrad('#053b2c','#02130e',170);
  tFrame(.5,.5,.9,1.12,'#e0b84a',3);
  tText('50',0.5,0.34,{font:'Gloock',size:700,bold:false,color:'#e0b84a',shadow:20,shadowColor:'#000000'});
  tText('FABULOUS & FIFTY',0.5,0.62,{font:'Outfit',size:84,color:'#f6efd0'});
  tRule(.5,.68,.3,'#e0b84a',3);
  tText('Join us to celebrate\nRobert\'s 50th birthday',0.5,0.76,{font:'Instrument Serif',size:78,bold:false,italic:true,color:'#f6efd0',lh:1.2});
  tText('FRIDAY 3 OCTOBER  •  7 PM  •  THE LODGE',0.5,0.88,{font:'Outfit',size:40,color:'#e0b84a'});
  tStar(.12,.1,.05,'#e0b84a');tStar(.88,.9,.05,'#e0b84a');
}},
{name:'Birthday cake wish',cat:'Birthday',tags:'cake happy birthday square post',w:1080,h:1080,build(){
  tGrad('#ffe4ec','#ffc2d4',180);
  tDots(14,'#ffffff',6,[0,0,1,1],.04,.1,.6);
  tText('Make a wish!',0.5,0.13,{font:'Pacifico',size:130,bold:false,color:'#be185d'});
  tCake(.5,.5,.55*1080/1080*1.0);
  tText('HAPPY BIRTHDAY',0.5,0.83,{font:'Big Shoulders Display',size:150,color:'#9d174d'});
  tText('to someone very special',0.5,0.93,{font:'Instrument Serif',size:54,bold:false,italic:true,color:'#be185d'});
  tConfetti(26,['#f43f5e','#fbbf24','#38bdf8','#a78bfa'],12,[0,0,1,1],{op:.85});
}}
);
