/* ===== artboards as folders in the Layers panel (like Photoshop) ===== */
const bl=()=>(doc&&doc.extra&&doc.extra.boards)||[];
function bid(b){return b.id||(b.id='b'+Date.now().toString(36)+Math.floor(Math.random()*1e5).toString(36));}
function layerBoard(l){
  const L=bl();if(!L.length||!l)return null;
  if(l.bd){const b=L.find(x=>x.id===l.bd);if(b)return b;}
  const q=layerBounds(l),cx=(q.x0+q.x1)/2,cy=(q.y0+q.y1)/2;
  for(let i=L.length-1;i>=0;i--){const b=L[i];if(cx>=b.x&&cx<=b.x+b.w&&cy>=b.y&&cy<=b.y+b.h)return b;}
  return null;
}
function activeBoard(prevActive){
  const L=bl();if(!L.length)return null;
  if(L[S.bsel])return L[S.bsel];
  const a=prevActive||active(),b=a&&layerBoard(a);return b||L[L.length-1];
}
(function(){
  const _al=addLayer;
  addLayer=function(o){
    o=o||{};const prev=doc&&active(),l=_al(o),L=bl();
    if(L.length&&l){
      let b=null;
      if(l.type!=='raster'&&o.x!=null){const q=layerBounds(l),cx=(q.x0+q.x1)/2,cy=(q.y0+q.y1)/2;b=L.find(k=>cx>=k.x&&cx<=k.x+k.w&&cy>=k.y&&cy<=k.y+k.h)||null;}
      if(!b){b=activeBoard(prev);if(b&&l.type!=='raster'&&o.x==null){l.x=b.x+b.w/2;l.y=b.y+b.h/2;}}
      if(b){l.bd=bid(b);S.bsel=L.indexOf(b);}
    }
    return l;
  };
  const _sl=selectLayer;
  selectLayer=function(id){
    const l=doc&&doc.layers.find(x=>x.id===id),b=l&&layerBoard(l),L=bl();
    if(b)S.bsel=L.indexOf(b);
    _sl(id);
  };
  const EYEI='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYEO='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" opacity=".5"><path d="M3 3l18 18M10 6a9 9 0 0 1 2-.2c6 0 10 7 10 7a17 17 0 0 1-3 3.6M6.5 6.6A17 17 0 0 0 2 12s4 7 10 7a9 9 0 0 0 4-1"/></svg>';
  const ABI='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M7 3v18M17 3v18M3 7h18M3 17h18"/></svg>';
  function header(b,i,members){
    const el=document.createElement('div');
    const vis=members.length?members.some(l=>l.visible):true;
    el.className='brow'+(S.bsel===i?' on':'');el.dataset.bi=i;el.dataset.bdid=bid(b);
    el.innerHTML='<button class="bcar" data-ba="col" title="'+(b.collapsed?'Open':'Close')+' artboard" aria-label="Open or close artboard">'+(b.collapsed?'&#9656;':'&#9662;')+'</button>'
      +'<span class="bico">'+ABI+'</span><span class="nm">'+esc(b.name)+'</span><em class="bct">'+members.length+'</em>'
      +'<button class="eye" data-ba="vis" title="Show or hide the whole artboard" aria-label="Show or hide artboard">'+(vis?EYEI:EYEO)+'</button>';
    return el;
  }
  const _rl=refreshLayers;
  refreshLayers=function(){
    _rl();
    const L=bl(),box=$('#layerlist');if(!box||!doc||!L.length)return;
    const rows=[...box.querySelectorAll('.lrow')],groups=new Map(L.map(b=>[b,[]])),loose=[];
    for(const r of rows){const l=doc.layers.find(x=>x.id===+r.dataset.id),b=layerBoard(l);r.dataset.bd=b?bid(b):'';if(b){groups.get(b).push(r);r.classList.add('inb');}else loose.push(r);}
    const frag=document.createDocumentFragment();
    loose.forEach(r=>frag.appendChild(r));
    for(let i=L.length-1;i>=0;i--){
      const b=L[i],rs=groups.get(b);
      frag.appendChild(header(b,i,rs.map(r=>doc.layers.find(x=>x.id===+r.dataset.id))));
      if(!b.collapsed)rs.forEach(r=>frag.appendChild(r));
    }
    box.innerHTML='';box.appendChild(frag);
  };
  const box=$('#layerlist');
  box.addEventListener('click',e=>{
    const h=e.target.closest('.brow');if(!h||!doc)return;
    const L=bl(),i=+h.dataset.bi,b=L[i];if(!b)return;
    const a=e.target.closest('[data-ba]');
    if(a&&a.dataset.ba==='col'){b.collapsed=!b.collapsed;refreshLayers();return;}
    if(a&&a.dataset.ba==='vis'){flush();const mem=boardMembers(b),vis=mem.some(l=>l.visible);mem.forEach(l=>{l.visible=!vis;});commit('Artboard visibility');redraw();return;}
    if(e.target.tagName==='INPUT')return;
    S.bsel=i;refreshLayers();if(S.tool==='artboard')renderOpts();redraw();
  },true);
  box.addEventListener('dblclick',e=>{
    const nm=e.target.closest('.brow .nm');if(!nm)return;e.stopPropagation();
    const h=nm.closest('.brow'),b=bl()[+h.dataset.bi];if(!b)return;
    const inp=document.createElement('input');inp.type='text';inp.value=b.name;nm.replaceWith(inp);inp.focus();inp.select();
    const done=()=>{b.name=inp.value.trim()||b.name;commit('Rename artboard');refreshLayers();if(S.tool==='artboard')renderOpts();redraw();};
    inp.addEventListener('blur',done,{once:true});inp.addEventListener('keydown',k=>{k.stopPropagation();if(k.key==='Enter')inp.blur();});
  },true);
  // artboard rows light up when a layer or board is picked on the canvas too
  const _bhd=TOOLS.artboard.down;
  TOOLS.artboard.down=function(p,e){const r=_bhd.call(this,p,e);refreshLayers();return r;};
})();
