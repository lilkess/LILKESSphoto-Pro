/* ===== QR code encoder (byte mode, versions 1-40, ECC L/M/Q/H) and the QR Code Maker plugin ===== */
const QR_ECC_PER_BLOCK=[[-1,7,10,15,20,26,18,20,24,30,18,20,24,26,30,22,24,28,30,28,28,28,28,30,30,26,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],
 [-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28],
 [-1,13,22,18,26,18,24,18,22,20,24,28,26,24,20,30,24,28,28,26,30,28,30,30,30,30,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],
 [-1,17,28,22,16,22,28,26,26,24,28,24,28,22,24,24,30,28,28,26,28,30,24,30,30,30,30,28,30,30,30,30,30,30,30,30,30,30,30,30,30]];
const QR_BLOCKS=[[-1,1,1,1,1,1,2,2,2,2,4,4,4,4,4,6,6,6,6,7,8,8,9,9,10,12,12,12,13,14,15,16,17,18,19,19,20,21,22,24,25],
 [-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49],
 [-1,1,1,2,2,4,4,6,6,8,8,8,10,12,16,12,17,16,18,21,20,23,23,25,27,29,34,34,35,38,40,43,45,48,51,53,56,59,62,65,68],
 [-1,1,1,2,4,4,4,5,6,8,8,11,11,16,16,18,16,19,21,25,25,25,34,30,32,35,37,40,42,45,48,51,54,57,60,63,66,70,74,77,81]];
const QR_FMT={L:1,M:0,Q:3,H:2};
function qrRawModules(v){let r=(16*v+128)*v+64;if(v>=2){const n=Math.floor(v/7)+2;r-=(25*n-10)*n-55;if(v>=7)r-=36;}return r;}
function qrDataCodewords(v,e){return Math.floor(qrRawModules(v)/8)-QR_ECC_PER_BLOCK[e][v]*QR_BLOCKS[e][v];}
const QR_EXP=new Uint8Array(512),QR_LOG=new Uint8Array(256);
{let x=1;for(let i=0;i<255;i++){QR_EXP[i]=x;QR_LOG[x]=i;x<<=1;if(x&256)x^=0x11d;}for(let i=255;i<512;i++)QR_EXP[i]=QR_EXP[i-255];}
const qrMul=(a,b)=>a&&b?QR_EXP[QR_LOG[a]+QR_LOG[b]]:0;
function qrRsDiv(deg){const r=new Array(deg).fill(0);r[deg-1]=1;let root=1;for(let i=0;i<deg;i++){for(let j=0;j<deg;j++){r[j]=qrMul(r[j],root);if(j+1<deg)r[j]^=r[j+1];}root=qrMul(root,2);}return r;}
function qrRsRem(data,div){const r=new Array(div.length).fill(0);for(const b of data){const f=b^r.shift();r.push(0);div.forEach((c,i)=>{r[i]^=qrMul(c,f);});}return r;}
function qrAlign(v){if(v===1)return [];const n=Math.floor(v/7)+2,st=v===32?26:Math.ceil((v*4+4)/(n*2-2))*2,r=[6];for(let p=v*4+10;r.length<n;p-=st)r.splice(1,0,p);return r;}
function qrEncode(text,eccName,minVer,forceMask){
  const e={L:0,M:1,Q:2,H:3}[eccName||'M'],bytes=Array.from(new TextEncoder().encode(text));
  let ver=Math.max(1,minVer||1),used=0;
  for(;;ver++){if(ver>40)throw new Error('That text is too long for a QR code. Use fewer characters or a lower error correction.');const cap=qrDataCodewords(ver,e)*8,cb=ver<10?8:16;used=4+cb+bytes.length*8;if(used<=cap)break;}
  const bits=[],put=(v,n)=>{for(let i=n-1;i>=0;i--)bits.push(v>>>i&1);};
  put(4,4);put(bytes.length,ver<10?8:16);bytes.forEach(b=>put(b,8));
  const cap=qrDataCodewords(ver,e)*8;put(0,Math.min(4,cap-bits.length));while(bits.length%8)bits.push(0);
  for(let pad=0xEC;bits.length<cap;pad^=0xEC^0x11)put(pad,8);
  const data=[];for(let i=0;i<bits.length;i+=8){let b=0;for(let j=0;j<8;j++)b=b<<1|bits[i+j];data.push(b);}
  const nb=QR_BLOCKS[e][ver],ecl=QR_ECC_PER_BLOCK[e][ver],raw=Math.floor(qrRawModules(ver)/8),ns=nb-raw%nb,sl=Math.floor(raw/nb),div=qrRsDiv(ecl),blocks=[];
  for(let i=0,k=0;i<nb;i++){const dat=data.slice(k,k+sl-ecl+(i<ns?0:1));k+=dat.length;const ec=qrRsRem(dat,div);if(i<ns)dat.push(0);blocks.push(dat.concat(ec));}
  const all=[];for(let i=0;i<blocks[0].length;i++)blocks.forEach((b,j)=>{if(i!==sl-ecl||j>=ns)all.push(b[i]);});
  const size=ver*4+17,M=[],F=[];for(let i=0;i<size;i++){M.push(new Array(size).fill(false));F.push(new Array(size).fill(false));}
  const set=(x,y,d)=>{M[y][x]=d;F[y][x]=true;};
  for(let i=0;i<size;i++){set(6,i,i%2===0);set(i,6,i%2===0);}
  const finder=(cx,cy)=>{for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const d=Math.max(Math.abs(dx),Math.abs(dy)),x=cx+dx,y=cy+dy;if(x>=0&&x<size&&y>=0&&y<size)set(x,y,d!==2&&d!==4);}};
  finder(3,3);finder(size-4,3);finder(3,size-4);
  const al=qrAlign(ver);for(let i=0;i<al.length;i++)for(let j=0;j<al.length;j++){if((i===0&&j===0)||(i===0&&j===al.length-1)||(i===al.length-1&&j===0))continue;for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)set(al[i]+dx,al[j]+dy,Math.max(Math.abs(dx),Math.abs(dy))!==1);}
  const fmt=(mask)=>{const d=QR_FMT[eccName||'M']<<3|mask;let r=d;for(let i=0;i<10;i++)r=r<<1^((r>>>9)*0x537);const bitsF=(d<<10|r)^0x5412;
    const g=i=>(bitsF>>>i&1)!==0;
    for(let i=0;i<=5;i++)set(8,i,g(i));set(8,7,g(6));set(8,8,g(7));set(7,8,g(8));for(let i=9;i<15;i++)set(14-i,8,g(i));
    for(let i=0;i<8;i++)set(size-1-i,8,g(i));for(let i=8;i<15;i++)set(8,size-15+i,g(i));set(8,size-8,true);};
  fmt(0);
  if(ver>=7){let r=ver;for(let i=0;i<12;i++)r=r<<1^((r>>>11)*0x1F25);const bitsV=ver<<12|r;for(let i=0;i<18;i++){const b=(bitsV>>>i&1)!==0,a=size-11+i%3,c=Math.floor(i/3);set(a,c,b);set(c,a,b);}}
  const cw=all;let bi=0;
  for(let right=size-1;right>=1;right-=2){if(right===6)right=5;for(let vert=0;vert<size;vert++)for(let j=0;j<2;j++){const x=right-j,up=((right+1)&2)===0,y=up?size-1-vert:vert;if(!F[y][x]&&bi<cw.length*8){M[y][x]=(cw[bi>>>3]>>>(7-(bi&7))&1)!==0;bi++;}}}
  const maskFn=[(x,y)=>(x+y)%2===0,(x,y)=>y%2===0,(x,y)=>x%3===0,(x,y)=>(x+y)%3===0,(x,y)=>(Math.floor(x/3)+Math.floor(y/2))%2===0,(x,y)=>x*y%2+x*y%3===0,(x,y)=>(x*y%2+x*y%3)%2===0,(x,y)=>((x+y)%2+x*y%3)%2===0];
  const apply=m=>{for(let y=0;y<size;y++)for(let x=0;x<size;x++)if(!F[y][x]&&maskFn[m](x,y))M[y][x]=!M[y][x];};
  const penalty=()=>{let res=0;
    for(let y=0;y<size;y++){let run=1;for(let x=1;x<size;x++){if(M[y][x]===M[y][x-1]){run++;if(run===5)res+=3;else if(run>5)res++;}else run=1;}}
    for(let x=0;x<size;x++){let run=1;for(let y=1;y<size;y++){if(M[y][x]===M[y-1][x]){run++;if(run===5)res+=3;else if(run>5)res++;}else run=1;}}
    for(let y=0;y<size-1;y++)for(let x=0;x<size-1;x++){const c=M[y][x];if(c===M[y][x+1]&&c===M[y+1][x]&&c===M[y+1][x+1])res+=3;}
    const pat=[1,0,1,1,1,0,1],chk=(get)=>{for(let i=0;i+10<=size;i++){let a=true,b=true;for(let k=0;k<7;k++){const q=get(i+k)?1:0;if(q!==pat[k])a=false;if(q!==pat[6-k])b=false;}
      const w=(from)=>{for(let k=0;k<4;k++){const idx=from+k;if(idx<0||idx>=size)continue;if(get(idx))return false;}return true;};
      if(a&&(w(i+7)||w(i-4)))res+=40;if(b&&(w(i+7)||w(i-4)))res+=40;}};
    for(let y=0;y<size;y++)chk(x=>M[y][x]);for(let x=0;x<size;x++)chk(y=>M[y][x]);
    let dark=0;for(const r of M)for(const q of r)if(q)dark++;const tot=size*size,k=Math.ceil(Math.abs(dark*20-tot*10)/tot)-1;res+=k*10;return res;};
  let best=0,bp=1e9;for(let m=0;m<8;m++){apply(m);fmt(m);const p=penalty();if(p<bp){bp=p;best=m;}apply(m);}
  if(forceMask!=null)best=forceMask;apply(best);fmt(best);
  return {size,ver,modules:M,mask:best};
}
function plgQR(v){
  const q=qrEncode(v.text||' ',v.ecc),m=Math.max(0,v.margin),px=v.module,tot=(q.size+m*2)*px,c=mkCanvas(tot,tot),x=cctx(c);
  if(!v.transparent){x.fillStyle=v.bg;x.fillRect(0,0,tot,tot);}
  x.fillStyle=v.fg;
  const isFinder=(i,j)=>(i<7&&j<7)||(i>=q.size-7&&j<7)||(i<7&&j>=q.size-7);
  for(let j=0;j<q.size;j++)for(let i=0;i<q.size;i++){
    if(!q.modules[j][i])continue;const X=(i+m)*px,Y=(j+m)*px;
    if(v.style==='dots'&&!isFinder(i,j)){x.beginPath();x.arc(X+px/2,Y+px/2,px*0.43,0,7);x.fill();}
    else if(v.style==='round'&&!isFinder(i,j)){const r=px*0.32;x.beginPath();x.roundRect?x.roundRect(X,Y,px,px,r):x.rect(X,Y,px,px);x.fill();}
    else x.fillRect(X,Y,px+(v.style==='square'?0.5:0),px+(v.style==='square'?0.5:0));
  }
  c.qr=q;return c;
}
plgReg({id:'qrcode',name:'QR Code Maker',cat:'Generate Content',desc:'Makes a QR code for a web address, text, Wi-Fi or phone number. Works offline. Always test the code with your phone camera before you print it.',
  params:[{id:'text',label:'Text or link',type:'area',value:'https://example.com',rows:3},pgS('ecc','Error correction','M',[['L','Low (7%)'],['M','Medium (15%)'],['Q','Quartile (25%)'],['H','High (30%)']]),pgR('module','Module size',2,40,12,'px'),pgR('margin','Quiet zone',0,10,4,'modules'),pgS('style','Style','square',[['square','Square'],['round','Rounded'],['dots','Dots']]),pgC('fg','Colour','#000000'),pgC('bg','Background','#ffffff'),pgK('transparent','Transparent background',false)],
  render:v=>plgQR(v),layerName:v=>'QR code',run(){plgGenDialog(this);}});
