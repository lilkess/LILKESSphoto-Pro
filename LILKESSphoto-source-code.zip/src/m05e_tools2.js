/* ===== the rest of the Photoshop toolbox ===== */
const exa=k=>{const e=doc.extra||(doc.extra={});return e[k]||(e[k]=[]);};
S.mlog=[];S.objMode='rect';S.frameKind='rect';S.bge={tol:30};S.colrep={tol:40};S.tmask={size:0};S.rot=0;S.qm=false;S.hsrc=0;S.patId='dots';
S.bs={tip:'round',angle:0,round:100,spacing:10,scatter:0,jitter:0};
const SIZE_OPT=()=>rng('Size','o-asize',4,1500,S.aux.size);
const polyHit=(pts,p)=>{let c=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const a=pts[i],b=pts[j];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)c=!c;}return c;};

/* ---------- shared helpers ---------- */
function paintableLayer(){
  const l=active();
  if(!l||pxLocked(l)){toast('Select an unlocked photo or paint layer first');return null;}
  if(l.smart||l.type==='adjust'){toast('Rasterize this layer first');return null;}
  if(l.type==='text'||l.type==='shape'){rasterize(l);toast('Layer converted to pixels');renderProps();}
  return l;
}
function strokeStart(name,p,e,opt){
  const l=paintableLayer();if(!l)return null;
  const lp=toLocal(l,p),d={k:'x',tool:name,l,tg:l.canvas,last:lp,pf:pressureFactor(e),sel:null,before:null,pts:[lp],dpts:[p]};
  if(S.sel&&!(opt&&opt.nosel)){d.sel=selAlphaCanvasLocal(l);d.before=cloneCanvas(l.canvas);}
  Object.assign(d,opt||{});drag=d;return d;
}
function strokeRun(d,a,b,rad,fn){
  const sp=Math.max(1,rad*0.25),n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/sp));
  for(let i=1;i<=n;i++){const t=i/n;fn(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t);}
  restrictSeg(d,a,b,rad);d.last=b;touch(d.l);
}
/* blend a circle of pixels toward a source (ImageData of the same size as the layer) */
function circBlend(l,src,x,y,r,str,fn){
  const c=l.canvas,ctx=cctx(c),x0=Math.max(0,Math.floor(x-r)),y0=Math.max(0,Math.floor(y-r)),x1=Math.min(c.width,Math.ceil(x+r)),y1=Math.min(c.height,Math.ceil(y+r)),w=x1-x0,h=y1-y0;
  if(w<2||h<2)return;
  const id=ctx.getImageData(x0,y0,w,h),d=id.data;
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
    const dist=Math.hypot(i+x0-x,j+y0-y)/r;if(dist>=1)continue;
    const f=Math.pow(1-dist*dist,1.3)*str,k=(j*w+i)*4;
    fn(d,k,f,((j+y0)*c.width+(i+x0))*4,i+x0,j+y0);
  }
  ctx.putImageData(id,x0,y0);
}
const brushRad=d=>Math.max(0.5,S.brush.size*d.pf/2/d.l.s);
const brushOpts=()=>rng('Size','o-bsize',1,2500,S.brush.size)+rng('Opacity','o-bflow',1,100,S.brush.flow*100);

/* ---------- Pencil ---------- */
function pencilSeg(d,a,b){
  const r=Math.max(0.5,S.brush.size*d.pf/2/d.l.s),ctx=cctx(d.tg);ctx.fillStyle=rgbaStr(S.fg,S.brush.flow);
  strokeRun(d,a,b,r,(x,y)=>{const s=Math.max(1,Math.round(r*2));ctx.fillRect(Math.round(x-s/2),Math.round(y-s/2),s,s);});
}
TOOLS.pencil={opts:brushOpts,down(p,e){const d=strokeStart('pencil',p,e);if(d)pencilSeg(d,d.last,d.last);},
  move(p,e){const d=drag;d.pf=pressureFactor(e);pencilSeg(d,d.last,toLocal(d.l,p));},up(){commit('Pencil');}};

/* ---------- Color Replacement ---------- */
TOOLS.colrep={opts:()=>brushOpts()+rng('Tolerance','o-crtol',5,120,S.colrep.tol),
  down(p,e){const d=strokeStart('colrep',p,e);if(d)this.seg(d,d.last,d.last);},
  move(p,e){const d=drag;d.pf=pressureFactor(e);this.seg(d,d.last,toLocal(d.l,p));},
  seg(d,a,b){
    const fg=hexRgb(S.fg),fh=rgb2hsl(fg[0],fg[1],fg[2]),r=brushRad(d),tol=S.colrep.tol;
    strokeRun(d,a,b,r,(x,y)=>{
      const c=d.l.canvas,ref=cctx(c).getImageData(clamp(Math.round(x),0,c.width-1),clamp(Math.round(y),0,c.height-1),1,1).data;
      circBlend(d.l,null,x,y,r,S.brush.flow,(px,k,f)=>{
        if(px[k+3]<8)return;
        if(Math.abs(px[k]-ref[0])+Math.abs(px[k+1]-ref[1])+Math.abs(px[k+2]-ref[2])>tol*3)return;
        const h=rgb2hsl(px[k],px[k+1],px[k+2]),n=hsl2rgb(fh[0],fh[1]*Math.min(1,0.4+h[1]*1.2),h[2]);
        for(let q=0;q<3;q++)px[k+q]+=(n[q]-px[k+q])*Math.min(1,f*1.4);
      });
    });
  },up(){commit('Color replacement');}};

/* ---------- Mixer Brush ---------- */
TOOLS.mixer={opts:()=>brushOpts()+'<span class="opt muted">Paints with your colour and drags the colours underneath along.</span>',
  down(p,e){const d=strokeStart('mixer',p,e);if(!d)return;const f=hexRgb(S.fg);d.load=[f[0],f[1],f[2]];this.seg(d,d.last,d.last);},
  move(p,e){const d=drag;d.pf=pressureFactor(e);this.seg(d,d.last,toLocal(d.l,p));},
  seg(d,a,b){
    const r=brushRad(d);
    strokeRun(d,a,b,r,(x,y)=>{
      const c=d.l.canvas,cx=clamp(Math.round(x),0,c.width-1),cy=clamp(Math.round(y),0,c.height-1),u=cctx(c).getImageData(cx,cy,1,1).data;
      if(u[3]>10)for(let q=0;q<3;q++)d.load[q]+=(u[q]-d.load[q])*0.22;
      circBlend(d.l,null,x,y,r,S.brush.flow*0.55,(px,k,f)=>{for(let q=0;q<3;q++)px[k+q]+=(d.load[q]-px[k+q])*f;px[k+3]=Math.min(255,px[k+3]+f*255);});
    });
  },up(){commit('Mixer brush');}};

/* ---------- Pattern Stamp ---------- */
TOOLS.pstamp={opts:()=>brushOpts()+'<label class="opt">Pattern '+sel('o-pat',PATTERNS,S.patId)+'</label>',
  down(p,e){const d=strokeStart('pstamp',p,e);if(!d)return;const t=PATTERN_TILE(S.patId);d.tile=cctx(t).getImageData(0,0,t.width,t.height);this.seg(d,d.last,d.last);},
  move(p,e){const d=drag;d.pf=pressureFactor(e);this.seg(d,d.last,toLocal(d.l,p));},
  seg(d,a,b){
    const r=brushRad(d),T=d.tile;
    strokeRun(d,a,b,r,(x,y)=>circBlend(d.l,null,x,y,r,S.brush.flow,(px,k,f,_,gx,gy)=>{
      const q=(((gy%T.height)+T.height)%T.height*T.width+((gx%T.width)+T.width)%T.width)*4;
      for(let c=0;c<3;c++)px[k+c]+=(T.data[q+c]-px[k+c])*f;px[k+3]+=(255-px[k+3])*f;
    }));
  },up(){commit('Pattern stamp');}};

/* ---------- History Brush / Art History Brush ---------- */
function histSource(l){
  const h=hist[S.hsrc!=null?Math.min(S.hsrc,hist.length-1):0],q=h&&h.layers.find(x=>x.id===l.id);
  return q&&q.canvas.width===l.canvas.width&&q.canvas.height===l.canvas.height?q.canvas:null;
}
function histBrush(name,art){
  TOOLS[name]={opts:()=>brushOpts()+'<span class="opt muted">Paints back from the History panel state marked as source (the first state by default).</span>',
    down(p,e){const d=strokeStart(name,p,e);if(!d)return;const s=histSource(d.l);if(!s){toast('No earlier state for this layer to paint from');drag=null;return;}
      d.srcC=s;d.src=cctx(s).getImageData(0,0,s.width,s.height);this.seg(d,d.last,d.last);},
    move(p,e){const d=drag;d.pf=pressureFactor(e);this.seg(d,d.last,toLocal(d.l,p));},
    seg(d,a,b){
      const r=brushRad(d),W=d.l.canvas.width,ctx=cctx(d.tg);
      strokeRun(d,a,b,r,(x,y)=>{
        if(!art)circBlend(d.l,d.src,x,y,r,S.brush.flow,(px,k,f,si)=>{for(let c=0;c<4;c++)px[k+c]+=(d.src.data[si+c]-px[k+c])*Math.min(1,f*1.5);});
        else for(let n=0;n<5;n++){
          const a2=Math.random()*6.283,rr=Math.random()*r*0.8,sx=clamp(Math.round(x+Math.cos(a2)*rr),0,W-1),sy=clamp(Math.round(y+Math.sin(a2)*rr),0,d.l.canvas.height-1),q=(sy*W+sx)*4;
          ctx.save();ctx.fillStyle='rgba('+d.src.data[q]+','+d.src.data[q+1]+','+d.src.data[q+2]+','+(0.55*S.brush.flow)+')';ctx.translate(x+Math.cos(a2)*rr,y+Math.sin(a2)*rr);ctx.rotate(Math.random()*3.14);
          ctx.beginPath();ctx.ellipse(0,0,r*0.34,r*0.12,0,0,7);ctx.fill();ctx.restore();
        }
      });
    },up(){commit(art?'Art history brush':'History brush');}};
}
histBrush('histbrush',false);histBrush('arthist',true);

/* ---------- Background Eraser ---------- */
TOOLS.bgerase={opts:()=>rng('Size','o-esize',1,2500,S.eraser.size)+rng('Tolerance','o-betol',2,120,S.bge.tol),
  down(p,e){const d=strokeStart('bgerase',p,e);if(!d)return;const c=d.l.canvas,u=cctx(c).getImageData(clamp(Math.round(d.last.x),0,c.width-1),clamp(Math.round(d.last.y),0,c.height-1),1,1).data;d.ref=[u[0],u[1],u[2]];this.seg(d,d.last,d.last);},
  move(p,e){const d=drag;d.pf=pressureFactor(e);this.seg(d,d.last,toLocal(d.l,p));},
  seg(d,a,b){
    const r=Math.max(0.5,S.eraser.size*d.pf/2/d.l.s),tol=S.bge.tol*3;
    strokeRun(d,a,b,r,(x,y)=>circBlend(d.l,null,x,y,r,1,(px,k,f)=>{
      const dd=Math.abs(px[k]-d.ref[0])+Math.abs(px[k+1]-d.ref[1])+Math.abs(px[k+2]-d.ref[2]);
      if(dd<tol)px[k+3]*=1-Math.min(1,f*2.2)*(1-dd/tol*0.5);
    }));
  },up(){commit('Background eraser');}};

/* ---------- Remove / Spot Healing (content-aware fill under the stroke) ---------- */
function strokeMask(d){
  const l=d.l,m=mkCanvas(l.canvas.width,l.canvas.height),x=cctx(m),r=S.aux.size/l.s;
  x.strokeStyle=x.fillStyle='#fff';x.lineCap=x.lineJoin='round';x.lineWidth=r;
  x.beginPath();d.pts.forEach((q,i)=>i?x.lineTo(q.x,q.y):x.moveTo(q.x,q.y));if(d.pts.length===1)x.arc(d.pts[0].x,d.pts[0].y,r/2,0,7);x.stroke();if(d.pts.length===1)x.fill();
  if(S.sel){x.globalCompositeOperation='destination-in';x.drawImage(selAlphaCanvasLocal(l),0,0);}
  return m;
}
function overStroke(o,z,color){
  const d=drag;if(!d||!d.dpts)return;
  o.save();o.strokeStyle=color;o.lineWidth=S.aux.size;o.lineCap=o.lineJoin='round';o.beginPath();d.dpts.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));
  if(d.dpts.length===1)o.lineTo(d.dpts[0].x+0.01,d.dpts[0].y);o.stroke();o.restore();
}
function eraseTool(name,label,opts){
  TOOLS[name]={opts:()=>SIZE_OPT()+'<span class="opt muted">Paint over what you want gone. It is filled in from the surroundings.</span>',
    down(p,e){strokeStart(name,p,e,{nosel:true});},
    move(p){const d=drag;d.pts.push(toLocal(d.l,p));d.dpts.push(p);redraw();},
    over(o,z){overStroke(o,z,'rgba(255,60,60,.45)');},
    up(d){
      const l=d.l,m=strokeMask(d);toast('Filling in...');
      setTimeout(()=>{try{const out=cut_inpaint(l.canvas,m,opts||{});const x=cctx(l.canvas);x.clearRect(0,0,l.canvas.width,l.canvas.height);x.drawImage(out,0,0);touch(l);commit(label);}catch(err){toast('Could not fill that area');redraw();}},30);
    }};
}
eraseTool('remove','Remove',{});eraseTool('spot','Spot healing',{margin:1.2,feather:2});

/* ---------- Healing Brush ---------- */
function paintMaskBBox(d,r){
  const l=d.l;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  d.pts.forEach(q=>{x0=Math.min(x0,q.x);y0=Math.min(y0,q.y);x1=Math.max(x1,q.x);y1=Math.max(y1,q.y);});
  x0=Math.max(0,Math.floor(x0-r));y0=Math.max(0,Math.floor(y0-r));x1=Math.min(l.canvas.width,Math.ceil(x1+r));y1=Math.min(l.canvas.height,Math.ceil(y1+r));
  return {x:x0,y:y0,w:x1-x0,h:y1-y0};
}
TOOLS.heal={opts:()=>SIZE_OPT()+'<button data-act="setSrc">'+(S.srcPt?'Change source':'Set source')+'</button><span class="opt muted">Tap Set source, tap a clean spot, then paint over the blemish.</span>',
  down(p,e){
    const l=paintableLayer();if(!l)return;const lp=toLocal(l,p);
    if(S.settingSrc||!S.srcPt||S.srcPt.id!==l.id){S.srcPt={x:lp.x,y:lp.y,id:l.id};S.settingSrc=false;toast('Source set. Now paint over the blemish.');renderOpts();redraw();return;}
    strokeStart('heal',p,e,{nosel:true,off:{x:S.srcPt.x-lp.x,y:S.srcPt.y-lp.y}});
  },
  move(p){const d=drag;d.pts.push(toLocal(d.l,p));d.dpts.push(p);redraw();},
  over(o,z){overStroke(o,z,'rgba(80,200,140,.45)');},
  up(d){
    const l=d.l,r=S.aux.size/2/l.s,bb=paintMaskBBox(d,r);if(bb.w<2||bb.h<2){redraw();return;}
    const m=strokeMask(d),mm=mkCanvas(bb.w,bb.h);cctx(mm).drawImage(m,bb.x,bb.y,bb.w,bb.h,0,0,bb.w,bb.h);
    try{cut_healPatch(l.canvas,{x:bb.x+d.off.x,y:bb.y+d.off.y,w:bb.w,h:bb.h},bb.x,bb.y,mm);touch(l);commit('Healing brush');}catch(err){toast('Could not heal there');}
  }};

/* ---------- Patch and Content-Aware Move (draw a region, then drag it) ---------- */
function regionTool(name,hint,apply){
  TOOLS[name]={opts:()=>'<span class="opt muted">'+hint+'</span>',
    down(p){
      const R=S.reg;
      if(R&&R.tool===name&&R.closed&&polyHit(R.pts,p)){R.dx=0;R.dy=0;drag={k:'x',tool:name,mode:'move',start:p};return;}
      S.reg={tool:name,pts:[p],closed:false,dx:0,dy:0};drag={k:'x',tool:name,mode:'draw'};
    },
    move(p){const d=drag,R=S.reg;if(d.mode==='draw')R.pts.push(p);else{R.dx=p.x-d.start.x;R.dy=p.y-d.start.y;}redraw();},
    up(d){
      const R=S.reg;
      if(d.mode==='draw'){if(R.pts.length<5)S.reg=null;else R.closed=true;}
      else{const m=Math.hypot(R.dx,R.dy)>2;const rr=R;S.reg=null;if(m)apply(rr);}
      redraw();
    },
    over(o,z){
      const R=S.reg;if(!R)return;
      o.save();o.lineWidth=1.4/z;o.setLineDash([6/z,4/z]);o.strokeStyle='#fff';
      o.beginPath();R.pts.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));if(R.closed)o.closePath();o.stroke();
      if(R.closed&&(R.dx||R.dy)){o.strokeStyle='#4b9eff';o.beginPath();R.pts.forEach((q,i)=>i?o.lineTo(q.x+R.dx,q.y+R.dy):o.moveTo(q.x+R.dx,q.y+R.dy));o.closePath();o.stroke();}
      o.restore();
    },
    key(c){if(c==='Escape'){S.reg=null;redraw();return true;}return false;}};
}
function regionLocal(R,l){
  const pts=R.pts.map(q=>toLocal(l,q));let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  pts.forEach(q=>{x0=Math.min(x0,q.x);y0=Math.min(y0,q.y);x1=Math.max(x1,q.x);y1=Math.max(y1,q.y);});
  const bb={x:Math.max(0,Math.floor(x0)),y:Math.max(0,Math.floor(y0))};bb.w=Math.min(l.canvas.width,Math.ceil(x1))-bb.x;bb.h=Math.min(l.canvas.height,Math.ceil(y1))-bb.y;
  const m=mkCanvas(Math.max(1,bb.w),Math.max(1,bb.h)),x=cctx(m);x.fillStyle='#fff';x.beginPath();pts.forEach((q,i)=>i?x.lineTo(q.x-bb.x,q.y-bb.y):x.moveTo(q.x-bb.x,q.y-bb.y));x.closePath();x.fill();
  const a=toLocal(l,R.pts[0]),b=toLocal(l,{x:R.pts[0].x+R.dx,y:R.pts[0].y+R.dy});
  return {bb,mask:m,off:{x:b.x-a.x,y:b.y-a.y},pts};
}
regionTool('patch','Draw around the area to fix, then drag it onto a clean area.',R=>{
  const l=paintableLayer();if(!l)return;const g=regionLocal(R,l);if(g.bb.w<2||g.bb.h<2)return;
  try{cut_healPatch(l.canvas,{x:g.bb.x+g.off.x,y:g.bb.y+g.off.y,w:g.bb.w,h:g.bb.h},g.bb.x,g.bb.y,g.mask);touch(l);commit('Patch');}catch(err){toast('Could not patch there');}
});
regionTool('cam','Draw around an object, then drag it to a new place. The gap is filled in.',R=>{
  const l=paintableLayer();if(!l)return;const g=regionLocal(R,l);if(g.bb.w<2||g.bb.h<2)return;
  toast('Moving...');
  setTimeout(()=>{
    try{
      const piece=mkCanvas(g.bb.w,g.bb.h),px=cctx(piece);px.drawImage(l.canvas,g.bb.x,g.bb.y,g.bb.w,g.bb.h,0,0,g.bb.w,g.bb.h);px.globalCompositeOperation='destination-in';px.drawImage(g.mask,0,0);
      const hole=mkCanvas(l.canvas.width,l.canvas.height),hx=cctx(hole);hx.drawImage(g.mask,g.bb.x,g.bb.y);
      hx.globalCompositeOperation='destination-out';hx.drawImage(g.mask,g.bb.x+g.off.x,g.bb.y+g.off.y);
      const out=cut_inpaint(l.canvas,hole,{});const x=cctx(l.canvas);x.clearRect(0,0,out.width,out.height);x.drawImage(out,0,0);
      x.drawImage(piece,Math.round(g.bb.x+g.off.x),Math.round(g.bb.y+g.off.y));touch(l);commit('Content-aware move');
    }catch(err){toast('Could not move that');}
  },30);
});

/* ---------- Red Eye ---------- */
TOOLS.redeye={opts:()=>SIZE_OPT()+'<span class="opt muted">Tap the red pupil.</span>',
  down(p){const l=paintableLayer();if(!l)return;const lp=toLocal(l,p);cut_redEye(l.canvas,lp.x,lp.y,Math.max(6,S.aux.size/2/l.s),1);touch(l);commit('Red eye');}};

/* ---------- Object Selection / Quick Selection / Magnetic Lasso / single row, column ---------- */
TOOLS.objsel={opts:()=>selModeBtns()+'<label class="opt">Mode '+sel('o-objm',[['rect','Rectangle'],['lasso','Lasso']],S.objMode)+'</label><span class="opt muted">Drag around an object. Tap once to pick the main subject.</span>',
  down(p,e){drag={k:'x',tool:'objsel',p0:p,p1:p,pts:[p],mode:selModeOf(e)};},
  move(p){const d=drag;d.p1=p;d.pts.push(p);redraw();},
  up(d){
    const w=Math.abs(d.p1.x-d.p0.x),h=Math.abs(d.p1.y-d.p0.y);
    if(w<8&&h<8){ACT.selSubject();return;}
    const sm=S.selMode;S.selMode=d.mode;
    if(S.objMode==='lasso'&&d.pts.length>4)selectFromRegion({poly:d.pts});else selectFromRegion({rect:{x:Math.min(d.p0.x,d.p1.x),y:Math.min(d.p0.y,d.p1.y),w,h}});
    setTimeout(()=>{S.selMode=sm;},400);redraw();
  },
  over(o,z){const d=drag;if(!d||d.tool!=='objsel')return;o.save();o.strokeStyle='#fff';o.lineWidth=1.4/z;o.setLineDash([5/z,4/z]);
    if(S.objMode==='lasso'){o.beginPath();d.pts.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));o.stroke();}else o.strokeRect(Math.min(d.p0.x,d.p1.x),Math.min(d.p0.y,d.p1.y),Math.abs(d.p1.x-d.p0.x),Math.abs(d.p1.y-d.p0.y));o.restore();}};
TOOLS.quicksel={opts:()=>SIZE_OPT()+'<span class="opt muted">Paint over the thing you want. Hold Alt to take away from the selection.</span>',
  down(p,e){const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return;}ensureRaster(l);
    drag={k:'x',tool:'quicksel',l,pts:[toLocal(l,p)],dpts:[p],sub:!!(e&&e.altKey)||S.selMode==='sub'};},
  move(p){const d=drag;d.pts.push(toLocal(d.l,p));d.dpts.push(p);redraw();},
  over(o,z){overStroke(o,z,'rgba(80,160,255,.35)');},
  up(d){
    const l=d.l,prev=(S.qs&&S.qs.lid===l.id&&S.sel)?S.qs.alpha:null;toast('Selecting...');
    setTimeout(()=>{try{
      const r=cut_quickSelect(l.canvas,d.pts,S.aux.size/2/l.s,{prev,mode:d.sub?'sub':'add'});
      S.qs={lid:l.id,alpha:r.alpha};setSelection(layerToDocCanvas(l,cut_alphaToCanvas(r.alpha,r.w,r.h)),'new');
    }catch(err){toast('Could not select that');}},30);
  }};
TOOLS.magnetic={opts:()=>selModeBtns()+'<span class="opt muted">Tap along the edge of the object. Tap the first point or press Enter to finish.</span>',
  down(p,e){
    let M=S.mag;
    if(!M||!M.on){render();M=S.mag={on:true,anchor:p,path:[p],prev:[],mode:selModeOf(e),field:null};try{M.field=cut_edgeCostField(view);}catch(err){}return;}
    if(M.path.length>8&&pdist(p,M.path[0])<12/S.zoom){this.finish();return;}
    let seg;try{seg=cut_magneticPath(view,M.anchor,p,{field:M.field});}catch(err){seg=[p];}
    M.path.push(...seg);M.anchor=p;M.prev=[];redraw();
  },
  hover(p){const M=S.mag;if(!M||!M.on)return;const t=performance.now();if(M.t&&t-M.t<70)return;M.t=t;try{M.prev=cut_magneticPath(view,M.anchor,p,{field:M.field});}catch(err){M.prev=[];}},
  finish(){const M=S.mag;if(!M||!M.on)return;S.mag=null;if(M.path.length>3)selFromPathFn(c=>{c.beginPath();M.path.forEach((q,i)=>i?c.lineTo(q.x,q.y):c.moveTo(q.x,q.y));c.closePath();c.fill();},M.mode);redraw();},
  dbl(){this.finish();},
  key(c){if(c==='Enter'){this.finish();return true;}if(c==='Escape'){S.mag=null;redraw();return true;}return false;},
  leave(){S.mag=null;},
  over(o,z){const M=S.mag;if(!M||!M.on)return;o.save();o.strokeStyle='#fff';o.lineWidth=1.4/z;o.beginPath();M.path.concat(M.prev).forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));o.stroke();
    o.fillStyle='#19c2d8';o.fillRect(M.path[0].x-4/z,M.path[0].y-4/z,8/z,8/z);o.restore();}};
TOOLS.rowmarq={opts:()=>selModeBtns()+'<span class="opt muted">Tap to select one row of pixels across the picture.</span>',
  down(p,e){const y=clamp(Math.floor(p.y),0,doc.h-1);selFromPathFn(c=>c.fillRect(0,y,doc.w,1),selModeOf(e));}};
TOOLS.colmarq={opts:()=>selModeBtns()+'<span class="opt muted">Tap to select one column of pixels from top to bottom.</span>',
  down(p,e){const x=clamp(Math.floor(p.x),0,doc.w-1);selFromPathFn(c=>c.fillRect(x,0,1,doc.h),selModeOf(e));}};

/* ---------- Perspective Crop ---------- */
TOOLS.persp={opts:()=>'<span class="opt muted">Tap the four corners: top-left, top-right, bottom-right, bottom-left. Drag a corner to adjust.</span><button class="primary" data-act="perspApply">Apply</button><button data-act="perspReset">Reset</button>',
  down(p){
    const P=S.persp||(S.persp=[]);let bi=-1;P.forEach((q,i)=>{if(pdist(p,q)<20/S.zoom)bi=i;});
    if(bi>=0){drag={k:'x',tool:'persp',i:bi};return;}
    if(P.length<4){P.push(p);redraw();}
  },
  move(p){S.persp[drag.i]=p;redraw();},up(){redraw();},
  key(c){if(c==='Enter'&&S.persp&&S.persp.length===4){ACT.perspApply();return true;}if(c==='Escape'){S.persp=null;redraw();return true;}return false;},
  leave(){S.persp=null;},
  over(o,z){const P=S.persp;if(!P||!P.length)return;o.save();o.strokeStyle='#f2b134';o.lineWidth=1.6/z;o.beginPath();P.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));if(P.length===4)o.closePath();o.stroke();
    P.forEach((q,i)=>{o.fillStyle='#fff';o.fillRect(q.x-5/z,q.y-5/z,10/z,10/z);o.fillStyle='#000';o.font=(12/z)+'px sans-serif';o.fillText(i+1,q.x+8/z,q.y-8/z);});o.restore();}};
ACT.perspReset=()=>{S.persp=null;if(doc)redraw();};
ACT.perspApply=D(()=>{
  const P=S.persp;if(!P||P.length<4){toast('Tap the four corners first');return;}
  const src=mkCanvas(doc.w,doc.h);compose(cctx(src),1);const sd=cctx(src).getImageData(0,0,doc.w,doc.h),SW=doc.w,SH=doc.h;
  const len=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  let W=Math.round(Math.max(len(P[0],P[1]),len(P[3],P[2]))),H=Math.round(Math.max(len(P[0],P[3]),len(P[1],P[2])));
  const k=Math.min(1,4096/Math.max(W,H));W=Math.max(8,Math.round(W*k));H=Math.max(8,Math.round(H*k));
  const [x0,x1,x2,x3]=P.map(q=>q.x),[y0,y1,y2,y3]=P.map(q=>q.y);
  const dx1=x1-x2,dx2=x3-x2,dx3=x0-x1+x2-x3,dy1=y1-y2,dy2=y3-y2,dy3=y0-y1+y2-y3;
  let g=0,h=0;const den=dx1*dy2-dx2*dy1;if(Math.abs(dx3)>1e-9||Math.abs(dy3)>1e-9){g=(dx3*dy2-dx2*dy3)/den;h=(dx1*dy3-dx3*dy1)/den;}
  const a=x1-x0+g*x1,b=x3-x0+h*x3,c=x0,d=y1-y0+g*y1,e=y3-y0+h*y3,f=y0;
  const out=new ImageData(W,H),od=out.data,sdd=sd.data;
  for(let j=0;j<H;j++)for(let i=0;i<W;i++){
    const u=(i+.5)/W,v=(j+.5)/H,w=g*u+h*v+1,sx=(a*u+b*v+c)/w-.5,sy=(d*u+e*v+f)/w-.5,ix=Math.floor(sx),iy=Math.floor(sy),fx=sx-ix,fy=sy-iy,o=(j*W+i)*4;
    for(let ch=0;ch<4;ch++){
      const px=(xx,yy)=>sdd[(clamp(yy,0,SH-1)*SW+clamp(xx,0,SW-1))*4+ch];
      od[o+ch]=(px(ix,iy)*(1-fx)+px(ix+1,iy)*fx)*(1-fy)+(px(ix,iy+1)*(1-fx)+px(ix+1,iy+1)*fx)*fy;
    }
  }
  doc.layers=[];doc.w=W;doc.h=H;doc.guides=[];S.sel=null;S.persp=null;
  const nl=addLayer({name:'Perspective crop',type:'image',w:W,h:H,x:W/2,y:H/2});cctx(nl.canvas).putImageData(out,0,0);
  resizeStage();commit('Perspective crop');S.autoFit=true;fitView();toast('Cropped and straightened. The layers were merged into one.');
});

/* ---------- Slices ---------- */
TOOLS.slice={opts:()=>'<button data-act="exportSlices">Export slices</button><span class="opt muted">Drag to cut the picture into pieces you can export one by one. '+(doc?exa('slices').length:0)+' slices.</span>',
  down(p){drag={k:'x',tool:'slice',p0:p,p1:p};},move(p){drag.p1=p;redraw();},
  up(d,p){const w=Math.abs(p.x-d.p0.x),h=Math.abs(p.y-d.p0.y);if(w>4&&h>4){exa('slices').push({x:Math.round(Math.min(p.x,d.p0.x)),y:Math.round(Math.min(p.y,d.p0.y)),w:Math.round(w),h:Math.round(h)});commit('Slice');renderOpts();}redraw();},
  over(o,z){const d=drag;if(d&&d.tool==='slice'){o.save();o.strokeStyle='#f2b134';o.lineWidth=1.5/z;o.setLineDash([5/z,4/z]);o.strokeRect(Math.min(d.p0.x,d.p1.x),Math.min(d.p0.y,d.p1.y),Math.abs(d.p1.x-d.p0.x),Math.abs(d.p1.y-d.p0.y));o.restore();}}};
TOOLS.slicesel={opts:()=>'<button data-act="exportSlices">Export slices</button><button data-act="sliceDel">Delete slice</button><span class="opt muted">Tap a slice to select it. Drag it to move it.</span>',
  down(p){const L=exa('slices');let i=-1;L.forEach((s,k)=>{if(p.x>=s.x&&p.x<=s.x+s.w&&p.y>=s.y&&p.y<=s.y+s.h)i=k;});S.slsel=i;if(i>=0)drag={k:'x',tool:'slicesel',s:L[i],last:p,moved:false};redraw();},
  move(p){const d=drag;d.s.x+=p.x-d.last.x;d.s.y+=p.y-d.last.y;d.last=p;d.moved=true;redraw();},
  up(d){if(d.moved){d.s.x=Math.round(d.s.x);d.s.y=Math.round(d.s.y);commit('Move slice');}},
  key(c){if(c==='Delete'||c==='Backspace'){ACT.sliceDel();return true;}return false;}};
ACT.sliceDel=D(()=>{const L=exa('slices');if(S.slsel>=0&&L[S.slsel]){L.splice(S.slsel,1);S.slsel=-1;commit('Delete slice');renderOpts();redraw();}});
ACT.exportSlices=D(async()=>{
  const L=exa('slices');if(!L.length){toast('Draw some slices first');return;}
  const src=mkCanvas(doc.w,doc.h);compose(cctx(src),1);
  for(let i=0;i<L.length;i++){
    const s=L[i],c=mkCanvas(s.w,s.h);cctx(c).drawImage(src,s.x,s.y,s.w,s.h,0,0,s.w,s.h);
    const blob=await new Promise(r=>c.toBlob(r,'image/png'));await saveBlob(blob,(doc.name||'design')+'_slice'+(i+1)+'.png');
  }
});

/* ---------- Frame and Artboard ---------- */
function rectDragTool(name,optsHtml,make){
  TOOLS[name]={opts:optsHtml,down(p){drag={k:'x',tool:name,p0:p,p1:p};},move(p){drag.p1=p;redraw();},
    up(d,p){const w=Math.abs(p.x-d.p0.x),h=Math.abs(p.y-d.p0.y);make(w<8||h<8?{x:doc.w*0.2,y:doc.h*0.2,w:doc.w*0.6,h:doc.h*0.6}:{x:Math.min(p.x,d.p0.x),y:Math.min(p.y,d.p0.y),w,h});},
    over(o,z){const d=drag;if(d&&d.tool===name){o.save();o.strokeStyle='#f2b134';o.lineWidth=1.5/z;o.setLineDash([6/z,4/z]);o.strokeRect(Math.min(d.p0.x,d.p1.x),Math.min(d.p0.y,d.p1.y),Math.abs(d.p1.x-d.p0.x),Math.abs(d.p1.y-d.p0.y));o.restore();}}};
}
rectDragTool('frame',()=>'<label class="opt">Shape '+sel('o-fk',[['rect','Rectangle'],['ellipse','Ellipse']],S.frameKind)+'</label><span class="opt muted">Drag a frame, then choose a picture to fill it.</span>',r=>{
  const l=addLayer({name:'Frame',type:'shape',w:10,h:10,x:r.x+r.w/2,y:r.y+r.h/2,above:true,props:{kind:S.frameKind,fill:'#d3d3d3',stroke:'#9a9a9a',sw:2,radius:0,w:r.w,h:r.h,flip:false,nofill:false,sides:6,cid:null}});
  renderShape(l);commit('Frame');setTool('move');setTimeout(()=>pickFile('clip'),60);
});
rectDragTool('artboard',()=>'<span class="opt muted">Drag to add a white board layer you can design on top of.</span>',r=>{
  const n=doc.layers.filter(q=>/^Artboard/.test(q.name)).length+1;
  const l=addLayer({name:'Artboard '+n,type:'shape',w:10,h:10,x:r.x+r.w/2,y:r.y+r.h/2,above:true,props:{kind:'rect',fill:'#ffffff',stroke:'#cccccc',sw:1,radius:0,w:r.w,h:r.h,flip:false,nofill:false,sides:6,cid:null}});
  renderShape(l);commit('Artboard');setTool('move');
});

/* ---------- Color Sampler, Ruler, Note, Count ---------- */
function sampleAt(x,y){render();const q=vctx.getImageData(clamp(Math.floor(x),0,doc.w-1),clamp(Math.floor(y),0,doc.h-1),1,1).data;return [q[0],q[1],q[2],q[3]];}
TOOLS.sampler={opts:()=>'<button data-act="samplerClear">Clear samplers</button><span class="opt muted">Tap up to four spots. Their colours show in the Info panel.</span>',
  down(p){const L=exa('samplers');if(L.length>=4)L.shift();L.push({x:Math.round(p.x),y:Math.round(p.y)});commit('Colour sampler');if(typeof renderInfo==='function')renderInfo();redraw();}};
ACT.samplerClear=D(()=>{doc.extra=doc.extra||{};doc.extra.samplers=[];commit('Clear samplers');redraw();});
TOOLS.ruler={opts:()=>'<span class="opt">'+(S.ruler?'L: '+S.ruler.len.toFixed(1)+' px   A: '+S.ruler.ang.toFixed(1)+'°':'Drag a line to measure')+'</span><button data-act="rulerStraighten">Straighten</button><button data-act="rulerClear">Clear</button>',
  down(p){drag={k:'x',tool:'ruler',p0:p,p1:p};},
  move(p,e){const d=drag;let q=p;if(e&&e.shiftKey){const a=Math.atan2(p.y-d.p0.y,p.x-d.p0.x),sn=Math.round(a/(Math.PI/4))*Math.PI/4,L=pdist(p,d.p0);q={x:d.p0.x+Math.cos(sn)*L,y:d.p0.y+Math.sin(sn)*L};}
    d.p1=q;S.ruler=rulerInfo(d.p0,q);redraw();renderOpts();},
  up(d){if(S.ruler&&S.ruler.len>2){S.mlog.push(Object.assign({n:S.mlog.length+1},S.ruler));if(typeof renderMlog==='function')renderMlog();}else S.ruler=null;renderOpts();redraw();},
  over(o,z){const R=S.ruler;if(!R)return;o.save();o.strokeStyle='#fff';o.lineWidth=1.4/z;o.beginPath();o.moveTo(R.x1,R.y1);o.lineTo(R.x2,R.y2);o.stroke();o.strokeStyle='#000';o.setLineDash([4/z,4/z]);o.stroke();o.restore();}};
function rulerInfo(a,b){return {x1:a.x,y1:a.y,x2:b.x,y2:b.y,len:pdist(a,b),ang:-Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI,dx:b.x-a.x,dy:b.y-a.y};}
ACT.rulerClear=()=>{S.ruler=null;renderOpts();if(doc)redraw();};
ACT.rulerStraighten=D(()=>{
  const R=S.ruler;if(!R){toast('Measure a line along something that should be level');return;}
  let a=-R.ang;if(a>90)a-=180;if(a<-90)a+=180;const rad=-a*Math.PI/180*-1;
  const cx=doc.w/2,cy=doc.h/2,ang=a*Math.PI/180,c=Math.cos(-ang),s=Math.sin(-ang);
  for(const l of doc.layers){const dx=l.x-cx,dy=l.y-cy;l.x=cx+dx*c-dy*s;l.y=cy+dx*s+dy*c;l.r-=ang;l._mc=null;l._fc=null;}
  S.ruler=null;commit('Straighten');renderOpts();redraw();toast('Straightened. Use the Crop tool to trim the corners.');
});
TOOLS.note={opts:()=>'<span class="opt muted">Tap to leave a note on the picture. Tap a note to edit it.</span>',
  down(p){
    const L=exa('notes'),i=L.findIndex(n=>pdist(n,p)<14/S.zoom);
    askText('Note','Note text',i>=0?L[i].text:'',v=>{
      if(i>=0){if(v.trim())L[i].text=v;else L.splice(i,1);}else if(v.trim())L.push({x:Math.round(p.x),y:Math.round(p.y),text:v,by:'You'});
      commit('Note');if(typeof renderNotes==='function')renderNotes();redraw();},true);
  }};
TOOLS.count={opts:()=>'<span class="opt">Count: '+(doc?exa('counts').length:0)+'</span><button data-act="countClear">Clear</button><span class="opt muted">Tap each item. Alt + tap removes one.</span>',
  down(p,e){const L=exa('counts'),i=L.findIndex(n=>pdist(n,p)<12/S.zoom);if(i>=0||(e&&e.altKey)){if(i>=0)L.splice(i,1);}else L.push({x:Math.round(p.x),y:Math.round(p.y)});commit('Count');renderOpts();redraw();}};
ACT.countClear=D(()=>{doc.extra=doc.extra||{};doc.extra.counts=[];commit('Clear count');renderOpts();redraw();});
function drawDocMarks(o,z){
  const ex=doc.extra;if(!ex)return;
  o.save();o.lineWidth=1.4/z;
  (ex.samplers||[]).forEach((s,i)=>{o.strokeStyle='#fff';o.beginPath();o.moveTo(s.x-9/z,s.y);o.lineTo(s.x+9/z,s.y);o.moveTo(s.x,s.y-9/z);o.lineTo(s.x,s.y+9/z);o.stroke();o.fillStyle='#19c2d8';o.font=bold(11/z);o.fillText(i+1,s.x+6/z,s.y-6/z);});
  (ex.counts||[]).forEach((s,i)=>{o.fillStyle='#ff4fa3';o.beginPath();o.arc(s.x,s.y,9/z,0,7);o.fill();o.fillStyle='#fff';o.font=bold(10/z);o.textAlign='center';o.textBaseline='middle';o.fillText(i+1,s.x,s.y);o.textAlign='left';o.textBaseline='alphabetic';});
  (ex.notes||[]).forEach(s=>{o.fillStyle='#ffe066';o.strokeStyle='#8a6d00';o.fillRect(s.x-8/z,s.y-8/z,16/z,14/z);o.strokeRect(s.x-8/z,s.y-8/z,16/z,14/z);o.beginPath();o.moveTo(s.x-4/z,s.y-3/z);o.lineTo(s.x+4/z,s.y-3/z);o.moveTo(s.x-4/z,s.y+1/z);o.lineTo(s.x+3/z,s.y+1/z);o.stroke();});
  if(S.tool==='slice'||S.tool==='slicesel')(ex.slices||[]).forEach((s,i)=>{o.strokeStyle=i===S.slsel?'#ff4fa3':'#f2b134';o.strokeRect(s.x,s.y,s.w,s.h);o.fillStyle=o.strokeStyle;o.font=bold(12/z);o.fillText(i+1,s.x+4/z,s.y+14/z);});
  o.restore();
}
const bold=px=>'bold '+px+'px sans-serif';

/* ---------- Type: vertical text and type masks ---------- */
function typeDownV(p,vert){
  const hit=[...doc.layers].reverse().find(l=>l.type==='text'&&l.visible&&pointInLayer(l,p));
  if(hit){selectLayer(hit.id);setTab('props');focusText();return;}
  const pr=TEXT0();pr.vert=vert;pr.align='center';pr.text=vert?'Vertical':'Your text';
  const l=addLayer({name:'Text',type:'text',w:10,h:10,x:p.x,y:p.y,above:true,props:pr});
  renderText(l);commit('Type');setTool('move');setTab('props');focusText();
}
TOOLS.vtext={down(p){typeDownV(p,true);},opts:()=>'<span class="opt muted">Tap the canvas to add upright text, one letter above the next.</span>'};
function typeMask(vert){
  return {opts:()=>rng('Size','o-tmsize',10,800,S.tmask.size||(doc?Math.round(doc.w/10):100))+'<span class="opt muted">Tap the canvas, type the words. They become a selection.</span>',
    down(p){
      askText('Type mask','Text for the selection','Text',v=>{
        if(!v.trim())return;const pr=TEXT0();pr.text=v;pr.vert=vert;pr.color='#ffffff';pr.size=S.tmask.size||pr.size;pr.sw=0;pr.shadow=0;
        const tl={props:pr,canvas:mkCanvas(4,4),ver:0,mask:null};renderText(tl);
        const n=selNew();n.ctx.drawImage(tl.canvas,Math.round(p.x-tl.canvas.width/2),Math.round(p.y-tl.canvas.height/2));setSelection(n.c,'new');toast('Selection made from the text');
      },true);
    }};
}
TOOLS.tmask=typeMask(false);TOOLS.vtmask=typeMask(true);
ACT.vertToggle=D(()=>textProp('vert'));

/* ---------- Rotate View ---------- */
function viewToDoc(vx,vy){const z=S.zoom,r=S.rot||0,c=Math.cos(-r),s=Math.sin(-r),dx=vx-S.px,dy=vy-S.py;return {x:(dx*c-dy*s)/z,y:(dx*s+dy*c)/z};}
function setRot(r){
  const rc=vp.getBoundingClientRect(),cx=rc.width/2,cy=rc.height/2,dp=viewToDoc(cx,cy);
  S.rot=r;const z=S.zoom,c=Math.cos(r),s=Math.sin(r);S.px=cx-(c*dp.x*z-s*dp.y*z);S.py=cy-(s*dp.x*z+c*dp.y*z);S.autoFit=false;applyView();
}
TOOLS.rotview={opts:()=>'<span class="opt muted">Drag to turn the canvas like paper on a desk.</span><button data-act="rotReset">Reset view</button>',
  down(p,e){const rc=vp.getBoundingClientRect(),cx=rc.left+rc.width/2,cy=rc.top+rc.height/2;drag={k:'x',tool:'rotview',cx,cy,a0:Math.atan2(e.clientY-cy,e.clientX-cx),r0:S.rot||0};},
  move(p,e){const d=drag;let r=d.r0+Math.atan2(e.clientY-d.cy,e.clientX-d.cx)-d.a0;if(e.shiftKey){const sn=Math.PI/12;r=Math.round(r/sn)*sn;}setRot(r);},
  up(){},dbl(){setRot(0);}};
ACT.rotReset=()=>{if(doc)setRot(0);};

/* ---------- Quick Mask ---------- */
function quickMaskOn(){
  const c=mkCanvas(doc.w,doc.h),x=cctx(c);x.fillStyle='#ff0000';
  if(S.sel){x.fillRect(0,0,doc.w,doc.h);x.globalCompositeOperation='destination-out';x.drawImage(S.sel.c,0,0);}
  S.qmc=c;S.qm=true;
}
function quickMaskOff(){
  const n=selNew(),x=n.ctx;x.fillStyle='#fff';x.fillRect(0,0,doc.w,doc.h);x.globalCompositeOperation='destination-out';x.drawImage(S.qmc,0,0);
  const d=cctx(S.qmc).getImageData(0,0,doc.w,doc.h).data;let any=false;for(let i=3;i<d.length;i+=4)if(d[i]>8){any=true;break;}
  S.qm=false;S.qmc=null;S.sel=null;if(any)setSelection(n.c,'new');else redraw();
}
ACT.quickMask=D(()=>{if(S.qm)quickMaskOff();else{quickMaskOn();if(!['brush','eraser','pencil'].includes(S.tool))pickTool('brush',0);toast('Quick Mask on. Paint black to mask, white to unmask. Press Q again for the selection.');}
  const b=$('#qmbtn');if(b)b.classList.toggle('on',S.qm);redraw();});
function drawQuickMask(o){if(!S.qmc)return;o.save();o.globalAlpha=.5;o.drawImage(S.qmc,0,0);o.restore();}
const _paintDown=paintDown;
paintDown=function(p,e,erase){
  if(!S.qm)return _paintDown(p,e,erase);
  const add=(lumHex(S.fg)<128)!==erase;drag={k:'x',tool:'qpaint',add,last:p};qmSeg(drag,p,p);
};
TOOLS.qpaint={move(p){qmSeg(drag,drag.last,p);},up(){redraw();}};
function qmSeg(d,a,b){
  const x=cctx(S.qmc),prm=S.brush,r=prm.size/2;
  x.save();x.globalCompositeOperation=d.add?'source-over':'destination-out';
  const n=Math.max(1,Math.ceil(pdist(a,b)/Math.max(1,r*0.2)));
  for(let i=1;i<=n;i++){const t=i/n,px=a.x+(b.x-a.x)*t,py=a.y+(b.y-a.y)*t;
    const g=x.createRadialGradient(px,py,r*prm.hard*0.9,px,py,r);g.addColorStop(0,'rgba(255,0,0,1)');g.addColorStop(1,'rgba(255,0,0,0)');x.fillStyle=g;x.fillRect(px-r,py-r,r*2,r*2);}
  x.restore();d.last=b;redraw();
}

/* ---------- Screen mode ---------- */
S.screen=0;
ACT.screenMode=()=>{
  S.screen=(S.screen+1)%3;
  const hide=S.screen>0;document.body.classList.toggle('hide-ui',hide);
  try{if(S.screen===2&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen();else if(S.screen===0&&document.fullscreenElement)document.exitFullscreen();}catch(err){}
  toast(['Standard screen mode','Full screen mode. Press F to change.','Full screen, no panels. Press F to come back.'][S.screen]);
  setTimeout(()=>{if(doc&&S.autoFit)fitView();else if(doc)drawRulers();},40);
};

/* ---------- brush tips, spacing, scatter (Brush Settings panel) ---------- */
function tipPath(c,tip,r){
  switch(tip){
    case 'square':c.rect(-r,-r,2*r,2*r);break;
    case 'diamond':c.moveTo(0,-r);c.lineTo(r,0);c.lineTo(0,r);c.lineTo(-r,0);c.closePath();break;
    case 'star':for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,k=i%2?0.45:1;i?c.lineTo(Math.cos(a)*r*k,Math.sin(a)*r*k):c.moveTo(Math.cos(a)*r*k,Math.sin(a)*r*k);}c.closePath();break;
    case 'leaf':c.moveTo(-r,0);c.quadraticCurveTo(0,-r*1.1,r,0);c.quadraticCurveTo(0,r*1.1,-r,0);break;
    case 'chalk':for(let i=0;i<14;i++){const a=Math.random()*6.283,q=Math.sqrt(Math.random())*r;c.moveTo(Math.cos(a)*q+r*0.18,Math.sin(a)*q);c.arc(Math.cos(a)*q,Math.sin(a)*q,r*0.13,0,7);}break;
    case 'splat':for(let i=0;i<7;i++){const a=Math.random()*6.283,q=Math.random()*r*0.7,rr=r*(0.15+Math.random()*0.3);c.moveTo(Math.cos(a)*q+rr,Math.sin(a)*q);c.arc(Math.cos(a)*q,Math.sin(a)*q,rr,0,7);}break;
    default:c.arc(0,0,r,0,7);
  }
}
const _stamp=stamp;
stamp=function(ctx,x,y,r,hard,rgb,a,erase){
  const b=S.bs;
  if(b.scatter>0){x+=(Math.random()-.5)*2*b.scatter/100*r*3;y+=(Math.random()-.5)*2*b.scatter/100*r*3;}
  if(b.jitter>0)r*=Math.max(0.1,1-Math.random()*b.jitter/100);
  if(b.tip==='round'&&b.round>=100)return _stamp(ctx,x,y,r,hard,rgb,a,erase);
  ctx.save();ctx.globalCompositeOperation=erase?'destination-out':'source-over';
  ctx.translate(x,y);ctx.rotate(b.angle*Math.PI/180);ctx.scale(1,Math.max(0.05,b.round/100));
  ctx.fillStyle='rgba('+(erase?'0,0,0':rgb.join(','))+','+a+')';ctx.beginPath();tipPath(ctx,b.tip,r);ctx.fill();ctx.restore();
};

/* ---------- Sponge and option handlers ---------- */
S.retouch.sponge='desat';
$('#opts').addEventListener('input',e=>{
  const t=e.target,v=t.type==='checkbox'?t.checked:t.value;
  switch(t.id){
    case 'o-crtol':S.colrep.tol=+v;break;case 'o-betol':S.bge.tol=+v;break;
    case 'o-pat':S.patId=v;break;case 'o-objm':S.objMode=v;break;case 'o-fk':S.frameKind=v;break;
    case 'o-tmsize':S.tmask.size=+v;break;case 'o-sponge':S.retouch.sponge=v;break;
    case 'o-sides':S.shape.sides=+v;break;case 'o-cid':S.shape.cid=v;break;
  }
});
function shapeExtraOpts(){
  if(S.shape.kind==='polygon')return rng('Sides','o-sides',3,16,S.shape.sides||6);
  if(S.shape.kind==='custom')return '<label class="opt">Shape '+sel('o-cid',VEC_SHAPES.map(s=>[s.id,s.name]),S.shape.cid||'heart')+'</label>';
  return '';
}
S.shape.sides=6;S.shape.cid='heart';
