/* ===== Fonts: installed fonts on PC/phone, availability check, add by name ===== */
const _fcv=document.createElement('canvas').getContext('2d');
function fontAvail(name){
  if(!name)return false;
  const t='mmmmmmmmmmlliWwQ@#1234 ǺÅ',q='"'+name+'"';let ok=false;
  for(const base of ['monospace','serif','sans-serif']){_fcv.font='72px '+base;const w0=_fcv.measureText(t).width;_fcv.font='72px '+q+','+base;if(Math.abs(_fcv.measureText(t).width-w0)>0.01){ok=true;break;}}
  return ok;
}
const SYS_PROBE=('Arial,Arial Black,Arial Narrow,Arial Rounded MT Bold,Bahnschrift,Baskerville,Bell MT,Berlin Sans FB,Bernard MT Condensed,Bodoni MT,Book Antiqua,Bookman Old Style,Bradley Hand ITC,Britannic Bold,Broadway,Brush Script MT,Calibri,Calibri Light,Californian FB,Calisto MT,Cambria,Cambria Math,Candara,Cascadia Code,Cascadia Mono,Centaur,Century,Century Gothic,Century Schoolbook,Chiller,Colonna MT,Comic Sans MS,Consolas,Constantia,Cooper Black,Copperplate Gothic,Corbel,Courier,Courier New,Curlz MT,Dubai,Ebrima,Edwardian Script ITC,Elephant,Engravers MT,Eras ITC,Felix Titling,Footlight MT Light,Forte,Franklin Gothic Book,Franklin Gothic Demi,Franklin Gothic Medium,Freestyle Script,French Script MT,Gabriola,Gadugi,Garamond,Georgia,Gigi,Gill Sans MT,Gloucester MT,Goudy Old Style,Haettenschweiler,Harlow Solid Italic,Harrington,High Tower Text,HoloLens MDL2 Assets,Impact,Imprint MT Shadow,Informal Roman,Ink Free,Javanese Text,Jokerman,Juice ITC,Kristen ITC,Kunstler Script,Leelawadee UI,Lucida Bright,Lucida Calligraphy,Lucida Console,Lucida Fax,Lucida Handwriting,Lucida Sans,Lucida Sans Typewriter,Lucida Sans Unicode,Magneto,Maiandra GD,Malgun Gothic,Marlett,Matura MT Script Capitals,Microsoft Himalaya,Microsoft JhengHei,Microsoft New Tai Lue,Microsoft PhagsPa,Microsoft Sans Serif,Microsoft Tai Le,Microsoft YaHei,Microsoft Yi Baiti,MingLiU-ExtB,Mistral,Modern No. 20,Mongolian Baiti,Monotype Corsiva,MS Gothic,MS Outlook,MS PGothic,MS Reference Sans Serif,MS Reference Specialty,MS UI Gothic,MT Extra,MV Boli,Myanmar Text,Niagara Engraved,Niagara Solid,Nirmala UI,OCR A Extended,Old English Text MT,Onyx,Palace Script MT,Palatino Linotype,Papyrus,Parchment,Perpetua,Perpetua Titling MT,Playbill,Poor Richard,Pristina,Rage Italic,Ravie,Rockwell,Rockwell Condensed,Rockwell Extra Bold,Script MT Bold,Segoe MDL2 Assets,Segoe Print,Segoe Script,Segoe UI,Segoe UI Black,Segoe UI Emoji,Segoe UI Light,Segoe UI Semibold,Segoe UI Symbol,Showcard Gothic,SimSun,Sitka Text,Snap ITC,Stencil,Sylfaen,Symbol,Tahoma,Tempus Sans ITC,Times New Roman,Trebuchet MS,Tw Cen MT,Twentieth Century,Verdana,Viner Hand ITC,Vivaldi,Vladimir Script,Webdings,Wide Latin,Wingdings,Wingdings 2,Wingdings 3,'
 +'American Typewriter,Andale Mono,Apple Chancery,Apple Color Emoji,Apple SD Gothic Neo,Avenir,Avenir Next,Avenir Next Condensed,Big Caslon,Bradley Hand,Chalkboard,Chalkboard SE,Chalkduster,Cochin,Copperplate,Didot,DIN Alternate,DIN Condensed,Futura,Geneva,Gill Sans,Helvetica,Helvetica Neue,Herculanum,Hoefler Text,Lucida Grande,Marker Felt,Menlo,Monaco,Noteworthy,Optima,Palatino,Papyrus,Phosphate,PingFang SC,Rockwell,Savoye LET,SignPainter,Skia,Snell Roundhand,Superclarendon,Thonburi,Times,Trattatello,Zapfino,SF Pro Display,SF Pro Text,SF Mono,New York,Charter,Iowan Old Style,Baskerville Old Face,Hiragino Sans,Hiragino Mincho ProN,'
 +'Roboto,Roboto Condensed,Roboto Mono,Roboto Slab,Noto Sans,Noto Serif,Noto Sans Mono,Noto Color Emoji,Droid Sans,Droid Serif,Droid Sans Mono,Cutive Mono,Coming Soon,Dancing Script,Carrois Gothic SC,Source Sans Pro,Samsung Sans,SamsungOne,Google Sans,Product Sans,Ubuntu,Ubuntu Mono,Cantarell,DejaVu Sans,DejaVu Serif,DejaVu Sans Mono,Liberation Sans,Liberation Serif,Liberation Mono,FreeSans,FreeSerif,Open Sans,Lato,Fira Sans,Fira Code,Source Code Pro,Inter,Montserrat,Poppins,Playfair Display,Oswald,Raleway,Merriweather,Nunito,Bebas Neue,Lobster,Pacifico,Anton,Abril Fatface,Cinzel,Great Vibes,Permanent Marker,Amatic SC,Caveat,Comfortaa,Josefin Sans,Quicksand,Rubik,Work Sans,Mulish,Karla,Cabin,Arimo,Tinos,Cousine,'
 +'Aptos,Aptos Display,Aptos Serif,Aptos Mono,Grandview,Skeena,Tenorite,Seaford,Sagona,Bierstadt,Source Serif Pro,Univers,Trade Gothic,Frutiger,Myriad Pro,Minion Pro,Adobe Garamond Pro,Adobe Caslon Pro,Adobe Jenson Pro,Proxima Nova,Gotham,Helvetica Light,Futura PT,Brandon Grotesque,Museo,Lucida Sans Demibold,Calibri Bold,Constantia Bold,Corbel Light,Candara Light,Gungsuh,Batang,Dotum,Gulim,Meiryo,Yu Gothic,Yu Mincho,SimHei,KaiTi,FangSong,NSimSun,Microsoft JhengHei UI,Arial Unicode MS,Tahoma Bold,Kalinga,Mangal,Latha,Raavi,Shruti,Tunga,Vrinda,Gautami,Kartika,Iskoola Pota,Plantagenet Cherokee,Aharoni,David,FrankRuehl,Gisha,Levenim MT,Miriam,Narkisim,Rod,Simplified Arabic,Traditional Arabic,Andalus,Aldhabi,Sakkal Majalla,Urdu Typesetting,Estrangelo Edessa,Euphemia,Nyala,Shonar Bangla,Utsaah,Vani,DaunPenh,DokChampa,Kokila,Aparajita,Angsana New,Browallia New,Cordia New,DilleniaUPC,EucrosiaUPC,FreesiaUPC,IrisUPC,JasmineUPC,KodchiangUPC,LilyUPC,Tahoma Regular').split(',');
const FONT_NAMES_KEY='lk_font_names';
function addLocalName(n,persist){
  if(!n||FONT_LOCAL.includes(n)||FONT_USER.includes(n))return false;
  FONT_LOCAL.push(n);if(persist){try{const a=JSON.parse(localStorage.getItem(FONT_NAMES_KEY)||'[]');if(!a.includes(n)){a.push(n);localStorage.setItem(FONT_NAMES_KEY,JSON.stringify(a));}}catch(e){}}return true;
}
function detectInstalledFonts(){
  let found=0;const seen=new Set();
  for(const n of SYS_PROBE){if(!n||seen.has(n))continue;seen.add(n);
    if(FONT_CAT_OF[n]&&FONT_CAT_OF[n]!=='System')continue;       // web fonts are listed in their own groups
    if(fontAvail(n)&&addLocalName(n,false))found++;}
  try{JSON.parse(localStorage.getItem(FONT_NAMES_KEY)||'[]').forEach(n=>{if(fontAvail(n))addLocalName(n,false);});}catch(e){}
  FONT_LOCAL.sort((a,b)=>a.localeCompare(b));
  return found;
}
/* full list from the system when the browser allows it (Chrome/Edge on a computer, the Windows app) */
const _llf=loadLocalFonts;
loadLocalFonts=async function(quiet){
  if(!window.queryLocalFonts){if(!quiet)toast('This browser cannot list every installed font. The common ones were found automatically; use "Add font by name" for others.');return false;}
  try{
    const list=await window.queryLocalFonts(),fams=new Set();
    for(const f of list){fams.add(f.family);if(f.fullName&&f.fullName!==f.family&&!/^(.*)\s(Regular|Bold|Italic|Bold Italic|Oblique)$/i.test(f.fullName))fams.add(f.fullName);}
    [...fams].sort((a,b)=>a.localeCompare(b)).forEach(n=>{if(!FONT_CAT_OF[n]||FONT_CAT_OF[n]==='System')addLocalName(n,false);});
    FONT_LOCAL.sort((a,b)=>a.localeCompare(b));
    try{localStorage.setItem('lk_localfonts_ok','1');}catch(e){}
    if(!quiet)toast(FONT_LOCAL.length+' installed fonts available');refreshFontSelects();return true;
  }catch(e){if(!quiet)toast('Permission to read installed fonts was not given. The common installed fonts were still found.');return false;}
};
async function autoLocalFonts(){
  detectInstalledFonts();refreshFontSelects();
  if(window.queryLocalFonts){
    let granted=false;try{const st=await navigator.permissions.query({name:'local-fonts'});granted=st.state==='granted';}catch(e){granted=/electron/i.test(navigator.userAgent);}
    if(granted)await loadLocalFonts(true);
  }
}
setTimeout(autoLocalFonts,900);
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>setTimeout(()=>{detectInstalledFonts();refreshFontSelects();},1500));
/* picker: add by name + dim fonts that are not loaded */
{
  const _ofp=openFontPicker;
  openFontPicker=function(current,onPick){
    _ofp(current,onPick);
    const top=document.querySelector('#modal .fp-top');if(!top||top.querySelector('#fp-add'))return;
    const add=document.createElement('button');add.id='fp-add';add.textContent='Add font by name…';top.appendChild(add);
    add.onclick=()=>{askText('Add installed font','Type the exact name of a font installed on this device (for example: Segoe UI Light)','',n=>{n=(n||'').trim();if(!n)return;
      if(!fontAvail(n)){toast('"'+n+'" was not found on this device. Check the spelling, or use Upload font.');return;}
      addLocalName(n,true);FONT_LOCAL.sort((a,b)=>a.localeCompare(b));refreshFontSelects();toast('"'+n+'" added');onPick(n);});};
    const mark=()=>{const list=document.querySelector('#modal #fp-list');if(!list){clearInterval(tm);return;}
      list.querySelectorAll('.fp-it').forEach(it=>{const n=it.dataset.f,s=it.querySelector('.fp-s');if(!s||!s.dataset.on)return;const miss=!(FONT_SYSTEM.has(n)||FONT_USER.includes(n)||FONT_LOCAL.includes(n)||fontAvail(n));it.classList.toggle('fp-miss',miss);if(miss)it.title='Not loaded yet: needs an internet connection, or this font is missing';});};
    const tm=setInterval(mark,800);
  };
}
