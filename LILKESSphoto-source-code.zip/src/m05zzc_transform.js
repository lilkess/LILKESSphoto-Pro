/* ===== Free transform: 8 handles, live W/H readout, numeric Transform panel; Live Shape feather ===== */
const XF_DIRS=[[-1,-1],[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0]];
const XF_K={shift:false,alt:false};
let XF_CUR=null,XF_LABEL=null;
S.xfOwn=true;if(S.xfKeep==null)S.xfKeep=false;
document.addEventListener('pointermove',e=>{XF_K.shift=e.shiftKey;XF_K.alt=e.altKey;},true);
document.addEventListener('pointerdown',e=>{XF_K.shift=e.shiftKey;XF_K.alt=e.altKey;},true);
const xfHalf=l=>(l.type==='shape'&&l.props)?[Math.max(1,l.props.w)/2,Math.max(1,l.props.h)/2]:[l.canvas.width/2,l.canvas.height/2];
function xfPts(l){const [hw,hh]=xfHalf(l),c=Math.cos(l.r),s=Math.sin(l.r);
  return XF_DIRS.map(([a,b])=>{const u=a*hw*l.s,v=b*hh*l.s;return {hx:a,hy:b,x:l.x+u*c-v*s,y:l.y+u*s+v*c};});}
function xfRot(l){const [,hh]=xfHalf(l),v=-(hh*l.s+40/S.zoom),c=Math.cos(l.r),s=Math.sin(l.r);return {x:l.x-v*s,y:l.y+v*c};}
handleAt=function(p){
  const l=active();if(!l||!l.visible||S.tool!=='move'||l.type==='adjust')return null;
  const r=xfRot(l);if(Math.hypot(p.x-r.x,p.y-r.y)<22/S.zoom)return 'rotate';
  let best=null,bd=1e9;
  for(const q of xfPts(l)){const d=Math.hypot(p.x-q.x,p.y-q.y),tol=(q.hx&&q.hy?22:16)/S.zoom;if(d<tol&&d<bd){bd=d;best=q;}}
  return best?('xf:'+best.hx+','+best.hy):null;
};
function xfScaleCanvas(src,w,h,final){
  w=Math.max(1,Math.round(w));h=Math.max(1,Math.round(h));
  if(final){try{return resampleCanvas(src,w,h);}catch(e){}}
  const c=mkCanvas(w,h),x=cctx(c);x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(src,0,0,w,h);return c;
}
function xfStart(d){
  const l=d.l;
  if(l.type==='shape'||l.type==='text')bake(l);
  const [hw,hh]=xfHalf(l),[hx,hy]=d.mode.slice(3).split(',').map(Number);
  d.xf={l,x0:l.x,y0:l.y,s0:l.s,r0:l.r,hw,hh,hx,hy,c0:l.canvas,m0:l.mask,k0:l.mk&&l.mk.base,o0:l.orig,final:null};
  const c=Math.cos(l.r),s=Math.sin(l.r),dx=d.p0.x-l.x,dy=d.p0.y-l.y;
  d.xf.u0=(dx*c+dy*s)/l.s;d.xf.v0=(-dx*s+dy*c)/l.s;
  XF_CUR=d.xf;
}
function xfMove(p){
  const d=drag,X=d.xf,l=d.l,c=Math.cos(X.r0),s=Math.sin(X.r0),dx=p.x-X.x0,dy=p.y-X.y0;
  const u=(dx*c+dy*s)/X.s0,v=(-dx*s+dy*c)/X.s0,{hw,hh,hx,hy}=X;
  const ue=hx*hw+(u-X.u0),ve=hy*hh+(v-X.v0),alt=XF_K.alt,keep=S.xfKeep||XF_K.shift||l.type==='text';
  let L=-hw,R=hw,T=-hh,B=hh;
  if(hx===1)R=ue;if(hx===-1)L=ue;if(hy===1)B=ve;if(hy===-1)T=ve;
  if(alt){if(hx){const m=Math.max(1,Math.abs(ue));L=-m;R=m;}if(hy){const m=Math.max(1,Math.abs(ve));T=-m;B=m;}}
  const MIN=2;
  if(R-L<MIN){if(hx===-1)L=R-MIN;else R=L+MIN;}if(B-T<MIN){if(hy===-1)T=B-MIN;else B=T+MIN;}
  if(keep){
    const fx=(R-L)/(2*hw),fy=(B-T)/(2*hh);let f=hx&&hy?(Math.abs(fx-1)>=Math.abs(fy-1)?fx:fy):hx?fx:fy;
    f=Math.max(f,MIN/Math.min(2*hw,2*hh));const nw=2*hw*f,nh=2*hh*f;
    if(alt||!hx){L=-nw/2;R=nw/2;}else if(hx===1){L=-hw;R=L+nw;}else{R=hw;L=R-nw;}
    if(alt||!hy){T=-nh/2;B=nh/2;}else if(hy===1){T=-hh;B=T+nh;}else{B=hh;T=B-nh;}
  }
  const nw=R-L,nh=B-T,cu=(L+R)/2,cv=(T+B)/2;
  l.x=X.x0+(cu*c-cv*s)*X.s0;l.y=X.y0+(cu*s+cv*c)*X.s0;
  X.nw=nw;X.nh=nh;
  if(l.type==='shape'){l.props.w=nw;l.props.h=nh;renderShape(l);}
  else if(l.type==='text'){l.s=X.s0*nw/(2*hw);}
  else{
    l.canvas=xfScaleCanvas(X.c0,nw*1,nh*1,false);
    if(X.m0){l.mask=xfScaleCanvas(X.m0,l.canvas.width,l.canvas.height,false);l.mver++;l._mc=null;}
    l.ver++;
  }
  d.tip={w:nw*X.s0,h:nh*X.s0};d.cur=p;d.moved=true;
  redraw();
}
/* final high-quality pass after the drag, from the original pixels (no stacked blur) */
function xfFinish(){
  const X=XF_CUR;if(!X||X.done)return;X.done=true;const l=X.l;XF_CUR=null;
  XF_LABEL=X.nw!=null?'Resize':null;
  if(X.nw==null||l.type==='shape'||l.type==='text')return;
  xfRasterFinal(l,X.c0,X.m0,X.k0,X.o0,X.nw,X.nh);
}
function xfRasterFinal(l,c0,m0,k0,o0,nw,nh){
  const w=Math.max(1,Math.round(nw)),h=Math.max(1,Math.round(nh));
  if(l.smart&&o0){l.orig=xfScaleCanvas(o0,w,h,true);smartRebuild(l);}
  else l.canvas=xfScaleCanvas(c0,w,h,true);
  if(m0){if(l.mk&&k0){l.mk.base=xfScaleCanvas(k0,w,h,true);l.mask=xfScaleCanvas(m0,w,h,true);mkRebuild(l);}else l.mask=xfScaleCanvas(m0,w,h,true);l.mver++;l._mc=null;}
  l.ver++;l.pv=null;l.pvv++;
}
{
  const _mm=moveMove;
  moveMove=function(p){
    const d=drag;
    if(d&&typeof d.mode==='string'&&d.mode.startsWith('xf:')){
      if(!d.moved&&Math.hypot(p.x-d.p0.x,p.y-d.p0.y)*S.zoom<3)return;
      if(!d.xf)xfStart(d);xfMove(p);return;
    }
    _mm(p);
    if(d&&d.mode==='rotate'&&d.moved){d.tip={a:d.l.r*180/Math.PI};d.cur=p;}
  };
  const _bk=bake;
  bake=function(l){
    if(XF_CUR&&XF_CUR.l===l)xfFinish();
    if(l.type==='shape'&&l.props&&l.props.feather)l.props.feather=+(l.props.feather*l.s).toFixed(1);
    _bk(l);
  };
  const _cm=commit;
  commit=function(label){
    if(label==='Move'&&XF_LABEL){label=XF_LABEL;XF_LABEL=null;}
    return _cm.apply(this,arguments.length?[label]:[]);
  };
  const _do=drawOver;
  drawOver=function(){
    _do();
    const l=doc&&active();if(!l||S.tool!=='move'||!l.visible||l.type==='adjust'||(drag&&drag.k==='paint'))return;
    const o=octx,z=S.zoom,pts=xfPts(l),rh=xfRot(l);
    o.save();o.strokeStyle='#4b9eff';o.lineWidth=1.5/z;o.beginPath();
    [0,2,4,6].forEach((i,k)=>k?o.lineTo(pts[i].x,pts[i].y):o.moveTo(pts[i].x,pts[i].y));o.closePath();o.stroke();
    o.beginPath();o.moveTo(pts[1].x,pts[1].y);o.lineTo(rh.x,rh.y);o.stroke();
    o.fillStyle='#4b9eff';o.beginPath();o.arc(rh.x,rh.y,8/z,0,7);o.fill();
    const hs=11/z;o.fillStyle='#fff';o.strokeStyle='#2a6fd6';o.lineWidth=1.2/z;
    pts.forEach(q=>{o.fillRect(q.x-hs/2,q.y-hs/2,hs,hs);o.strokeRect(q.x-hs/2,q.y-hs/2,hs,hs);});
    o.fillStyle='#4b9eff';o.beginPath();o.arc(l.x,l.y,3/z,0,7);o.fill();
    if(drag&&drag.tip&&drag.cur){
      const t=drag.tip,lines=t.w!=null?['W: '+Math.round(t.w)+' px','H: '+Math.round(t.h)+' px']:[Math.round(t.a*10)/10+'°'];
      const fs=13/z,pad=6/z,bx=drag.cur.x+18/z,by=drag.cur.y+18/z;
      o.font=fs+'px ui-monospace,Menlo,Consolas,monospace';
      const tw=Math.max(...lines.map(x=>o.measureText(x).width))+pad*2,th=lines.length*fs*1.25+pad*1.4;
      o.fillStyle='rgba(12,12,14,.92)';o.fillRect(bx,by,tw,th);o.strokeStyle='#666';o.lineWidth=1/z;o.strokeRect(bx,by,tw,th);
      o.fillStyle='#f2f2f2';o.textBaseline='top';lines.forEach((x,i)=>o.fillText(x,bx+pad,by+pad*0.8+i*fs*1.25));
    }
    o.restore();
  };
}
/* ---------- numeric transform (Properties) ---------- */
function xfBounds(l){const pts=xfPts(l).filter((q,i)=>i%2===0),X=pts.map(q=>q.x),Y=pts.map(q=>q.y);return {x:Math.min(...X),y:Math.min(...Y),w:Math.max(...X)-Math.min(...X),h:Math.max(...Y)-Math.min(...Y)};}
function xfSetSize(l,wDoc,hDoc){
  if(l.type==='shape'||l.type==='text')bake(l);
  const [hw,hh]=xfHalf(l);let nw=Math.max(2,wDoc/l.s),nh=Math.max(2,hDoc/l.s);
  if(l.type==='shape'){l.props.w=nw;l.props.h=nh;renderShape(l);}
  else if(l.type==='text'){l.s*=nw/(2*hw);}
  else xfRasterFinal(l,l.canvas,l.mask,l.mk&&l.mk.base,l.orig,nw,nh);
}
function xfGroup(l){
  const [hw,hh]=xfHalf(l),W=hw*2*l.s,H=hh*2*l.s,b=xfBounds(l),r=Math.round(l.r*1800/Math.PI)/10;
  const f=(id,lab,v,u)=>'<label class="xfl"><span>'+lab+'</span><input type="number" id="xf-'+id+'" step="0.01" value="'+(Math.round(v*100)/100)+'"><em>'+u+'</em></label>';
  const d=document.createElement('div');d.id='p-xfp';d.className='pgroup';
  d.innerHTML='<h4>Transform</h4><div class="xfg">'+f('w','W',W,'px')+f('x','X',b.x,'px')+f('h','H',H,'px')+f('y','Y',b.y,'px')+'</div>'
   +'<label class="opt"><input type="checkbox" id="xf-keep"'+(S.xfKeep?' checked':'')+'> Keep aspect ratio</label>'
   +f('a','Angle',r,'°')
   +'<p class="muted">Drag a square handle to resize (Shift keeps proportions, Alt resizes from the centre), the round handle to rotate.</p>';
  return d;
}
{
  const st=document.createElement('style');
  st.textContent='.xfg{display:grid;grid-template-columns:1fr 1fr;gap:6px 10px}.xfl{display:flex;align-items:center;gap:6px;font-size:12px}.xfl span{width:14px;opacity:.7}.xfl input{flex:1;min-width:0;width:100%}.xfl em{font-style:normal;opacity:.6;font-size:11px}';
  document.head.appendChild(st);
  const _rp=renderProps;
  renderProps=function(){
    _rp();const root=document.getElementById('tab-props');if(!root||!doc)return;
    const old=document.getElementById('p-xfp');if(old)old.remove();
    const l=active();if(!l||l.type==='adjust'||S.tool!=='move')return;
    root.insertBefore(xfGroup(l),root.firstChild);
    const lf=document.getElementById('p-lfs');if(lf)lf.remove();
    if(l.type==='shape')root.insertBefore(liveShapeGroup(l),root.children[1]||null);
  };
  document.addEventListener('change',e=>{
    const t=e.target;if(!t||!t.id||t.id.slice(0,3)!=='xf-')return;
    const l=active();if(!l)return;
    if(t.id==='xf-keep'){S.xfKeep=t.checked;return;}
    if(posLocked(l)){toast('This layer is locked');renderProps();return;}
    const v=parseFloat(t.value);if(!isFinite(v)){renderProps();return;}
    const [hw,hh]=xfHalf(l),W=hw*2*l.s,H=hh*2*l.s,b=xfBounds(l);
    if(t.id==='xf-w'||t.id==='xf-h'){
      let nw=t.id==='xf-w'?v:W,nh=t.id==='xf-h'?v:H;
      if(S.xfKeep||l.type==='text'){if(t.id==='xf-w')nh=H*v/W;else nw=W*v/H;}
      if(nw<1||nh<1){renderProps();return;}
      xfSetSize(l,nw,nh);commit('Resize');
    }else if(t.id==='xf-x'){l.x+=v-b.x;commit('Move');}
    else if(t.id==='xf-y'){l.y+=v-b.y;commit('Move');}
    else if(t.id==='xf-a'){l.r=v*Math.PI/180;commit('Rotate');}
    redraw();renderProps();
  });
}
/* ---------- Live Shape: Density + Feather, live and reversible ---------- */
const shpPad=p=>p&&p.feather>0?Math.ceil(p.feather*1.5)+2:0;
{
  const _sd=shapeDims;
  shapeDims=function(p){const d=_sd(p);d.pad+=shpPad(p);return d;};
  const _rs=renderShape;
  renderShape=function(l){_rs(l);const p=l.props;if(p&&(p.feather>0||(p.dens!=null&&p.dens<100)))shpSoft(l);};
}
function shpSoft(l){
  const p=l.props,c=l.canvas,w=c.width,h=c.height,x=cctx(c),id=x.getImageData(0,0,w,h),d=id.data,n=w*h;
  const k=p.dens==null?1:Math.max(0,Math.min(1,p.dens/100));
  if(p.feather>0){
    const sg=fthRadiusToSigma(p.feather),pl=[0,1,2,3].map(()=>new Float32Array(n));
    for(let i=0;i<n;i++){const a=d[i*4+3]/255;pl[0][i]=d[i*4]/255*a;pl[1][i]=d[i*4+1]/255*a;pl[2][i]=d[i*4+2]/255*a;pl[3][i]=a;}
    const b=pl.map(q=>fthGauss(q,w,h,sg));
    for(let i=0;i<n;i++){const a=b[3][i];d[i*4+3]=Math.round(Math.min(1,a)*k*255);if(a>1e-4){d[i*4]=Math.min(255,Math.round(b[0][i]/a*255));d[i*4+1]=Math.min(255,Math.round(b[1][i]/a*255));d[i*4+2]=Math.min(255,Math.round(b[2][i]/a*255));}}
  }else for(let i=0;i<n;i++)d[i*4+3]=Math.round(d[i*4+3]*k);
  x.putImageData(id,0,0);
}
function liveShapeGroup(l){
  const p=l.props,mx=Math.max(60,Math.round(Math.max(p.w,p.h)/2)),d=document.createElement('div');d.id='p-lfs';d.className='pgroup';
  d.innerHTML='<h4>Live Shape: vector mask</h4>'
   +fthRow('shape','dens','Density',p.dens==null?100:p.dens,100,100,'%')
   +fthRow('shape','feather','Feather',p.feather||0,mx,Math.max(400,mx*2),'px','Softens the edge of the shape itself. The shape stays editable: lower the Feather to sharpen it again.');
  return d;
}
{
  const _fa=fthApply;
  fthApply=function(scope,key,v,live){
    if(scope!=='shape')return _fa(scope,key,v,live);
    const l=active();if(!l||l.type!=='shape')return;const p=l.props,k=key==='dens'?'dens':'feather';
    if(p[k]===v&&live!=='force')return;p[k]=v;
    const run=()=>{renderShape(l);redraw();};if(live==='now')run();else fthSched(run);
  };
  const _fc=fthCommit;
  fthCommit=function(scope,key,v){
    if(scope!=='shape')return _fc(scope,key,v);
    fthFlush();clearTimeout(FTH_COMMIT);commit(key==='dens'?'Shape density '+v+'%':'Shape feather '+v+' px');
  };
}
