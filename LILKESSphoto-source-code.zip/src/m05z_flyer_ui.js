/* ===== Import Flyer as Template: wizard + builder ===== */
let FI=null;
const FI_HEX=c=>'#'+c.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')).join('');
function fiPickFile(){
  return new Promise(res=>{
    const i=document.createElement('input');i.type='file';i.accept='image/*';i.style.display='none';document.body.appendChild(i);
    i.onchange=()=>{const f=i.files[0];i.remove();res(f||null);};i.addEventListener('cancel',()=>{i.remove();res(null);});i.click();
  });
}
ACT.importFlyer=async function(){
  const f=await fiPickFile();if(!f)return;
  try{const c=await fileToCanvas(f,2600);fiOpen(c,(f.name||'Flyer').replace(/\.[^.]+$/,''));}
  catch(err){toast('That file could not be opened as a picture');}
};
window.__fiOpenCanvas=(c,n)=>fiOpen(c,n||'Flyer');
function fiOpen(canvas,name){
  const W=canvas.width,H=canvas.height,fd=cctx(canvas).getImageData(0,0,W,H);
  FI={name,canvas,W,H,fd,items:[],seq:1,sel:null,mode:'select',picShape:'rect',opt:{bg:true,shapes:true,ref:true},A:null,shape:null};
  toast('Analysing the flyer...');
  setTimeout(()=>{
    try{fiAnalyze();}catch(err){console.error(err);toast('Analysis failed: '+err.message);FI.items=[];FI.shape={items:[],lab:null};}
    fiDialog();
  },30);
}
function fiClean(texts){ // analysis-size picture with the given text boxes painted out
  const A=FI.A,id=new ImageData(new Uint8ClampedArray(A.data),A.w,A.h),m=new Uint8Array(A.w*A.h);
  texts.forEach(t=>{const b={x:t.box.x/A.sc,y:t.box.y/A.sc,w:t.box.w/A.sc,h:t.box.h/A.sc,ink:t.inkRGB};const tm=fa_textMask(id,b,3);for(let i=0;i<m.length;i++)if(tm[i])m[i]=1;});
  const d=fa_boxMax(m,A.w,A.h,1,1);
  return texts.length?fa_inpaint(id,d):id;
}
function fiMakeTextItem(t,sc){
  const hex=FI_HEX(t.ink),lineH=t.h/Math.max(1,t.lines);
  return {id:FI.seq++,type:'text',box:{x:t.x*sc,y:t.y*sc,w:t.w*sc,h:t.h*sc},lines:t.lines||1,align:t.align||'center',color:hex,inkRGB:t.ink,bgRGB:t.bg,text:'',font:'Outfit',bold:(t.ratio||0)>0.3,caps:false,checked:false,lineH:lineH*sc};
}
function fiAnalyze(){
  const A=fa_prep(FI.canvas);FI.A=A;
  const txt=fa_findText(A);
  FI.items=FI.items.filter(i=>i.manual);
  txt.forEach(t=>FI.items.push(fiMakeTextItem(t,A.sc)));
  fiReshape();
}
function fiReshape(){
  const A=FI.A,texts=FI.items.filter(i=>i.type==='text'),clean=fiClean(texts),tb=texts.map(t=>({x:t.box.x/A.sc,y:t.box.y/A.sc,w:t.box.w/A.sc,h:t.box.h/A.sc}));
  FI.cleanA=clean;
  const res=fa_findShapes(A,clean.data,tb,{});
  FI.shape=res;
  FI.items=FI.items.filter(i=>i.type!=='shape'||i.manual);
  res.items.forEach((s,k)=>{
    const g=s.fit.grad,fill=g?g.stops[0].c:s.fit.color;
    FI.items.push({id:FI.seq++,type:'shape',sid:s.id,isBg:s.isBg,kind:s.kind,radius:(s.radius||0),box:{x:s.box.x*A.sc,y:s.box.y*A.sc,w:s.box.w*A.sc,h:s.box.h*A.sc},grad:g,fill:s.fit.color,checked:true,rms:s.fit.rms,area:s.area,name:s.isBg?'Background':(s.kind==='cutout'?'Shape (traced)':KIND_NAMES[s.kind]||'Shape')});
  });
}
/* ---------- dialog ---------- */
function fiCss(g){if(!g)return null;const st=[...g.stops].sort((a,b)=>a.o-b.o).map(s=>s.c+' '+Math.round(s.o*100)+'%').join(',');return g.kind==='radial'?'radial-gradient(circle,'+st+')':'linear-gradient('+(g.angle)+'deg,'+st+')';}
function fiItemHtml(it,n){
  const num='<b class="fi-n" style="background:'+({text:'#2d8ceb',shape:'#3fb950',pic:'#f0883e',ushape:'#3fb950'}[it.type])+'">'+n+'</b>';
  if(it.type==='text')return '<div class="fi-it" data-id="'+it.id+'"><label class="fi-top">'+num+'<input type="checkbox" data-k="checked"'+(it.checked?' checked':'')+'> Text'+(it.manual?' (added by you)':'')+'<span style="flex:1"></span><button class="fi-x" data-del="'+it.id+'" title="Remove from list">&times;</button></label>'
   +'<canvas class="fi-th" data-th="'+it.id+'"></canvas><textarea data-k="text" rows="'+Math.min(3,it.lines)+'" placeholder="Type the words you see in the picture (leave empty to keep them as part of the picture)">'+esc(it.text)+'</textarea>'
   +'<div class="fi-r"><select data-k="font" title="Font">'+fontOptionsHtml(it.font)+'</select><input type="color" data-k="color" value="'+it.color+'" title="Text colour"><label><input type="checkbox" data-k="bold"'+(it.bold?' checked':'')+'> Bold</label><label><input type="checkbox" data-k="caps"'+(it.caps?' checked':'')+'> CAPS</label><select data-k="align" title="Alignment">'+['left','center','right'].map(a=>'<option'+(it.align===a?' selected':'')+'>'+a+'</option>').join('')+'</select></div></div>';
  if(it.type==='shape')return '<div class="fi-it" data-id="'+it.id+'"><label class="fi-top">'+num+'<input type="checkbox" data-k="checked"'+(it.checked?' checked':'')+'> '+(it.isBg?'Background gradient':esc(it.name)+(it.kind==='cutout'?' (irregular, traced as an editable vector shape)':''))+'<span style="flex:1"></span><button class="fi-x" data-del="'+it.id+'">&times;</button></label><div class="fi-sw" style="background:'+(fiCss(it.grad)||it.fill)+'"></div><small class="muted">'+(it.grad?(it.grad.kind==='radial'?'Radial':'Linear')+' gradient, '+it.grad.stops.length+' colours':'Solid colour')+' &middot; fit error '+it.rms.toFixed(1)+'</small></div>';
  if(it.type==='ushape')return '<div class="fi-it" data-id="'+it.id+'"><label class="fi-top">'+num+'<input type="checkbox" data-k="checked"'+(it.checked?' checked':'')+'> Shape you drew ('+it.kind+')<span style="flex:1"></span><button class="fi-x" data-del="'+it.id+'">&times;</button></label><small class="muted">Colour or gradient is read from the picture when you build.</small></div>';
  return '<div class="fi-it" data-id="'+it.id+'"><label class="fi-top">'+num+'<input type="checkbox" data-k="checked"'+(it.checked?' checked':'')+'> Picture you marked ('+it.kind+')<span style="flex:1"></span><button class="fi-x" data-del="'+it.id+'">&times;</button></label><canvas class="fi-th" data-th="'+it.id+'"></canvas></div>';
}
function fiDialog(){
  const body='<div class="fi"><div class="fi-l"><div class="fi-tools"><button data-m="select" class="on">Select</button><button data-m="text">+ Text box</button><button data-m="pic">+ Picture</button><select id="fi-ps" title="Picture shape"><option value="rect">Rectangle</option><option value="round">Rounded</option><option value="ellipse">Circle / oval</option></select><button data-m="ushape">+ Shape</button></div><div class="fi-cvw"><canvas id="fi-cv"></canvas></div><p class="muted fi-hint" id="fi-hint"></p></div>'
   +'<div class="fi-rr"><div class="fi-opts"><label><input type="checkbox" id="fi-o-bg" checked> Rebuild background and shapes as editable gradients</label><label><input type="checkbox" id="fi-o-ref" checked> Keep the original flyer as a hidden reference layer</label></div><div class="fi-list" id="fi-list"></div></div></div>';
  modalOpen('Import flyer as template',body,[
    {label:'Cancel'},
    {label:'Read text (needs internet)',close:false,cb:()=>{fiOCR();return false;}},
    {label:'Build editable template',primary:true,close:false,cb:()=>{fiBuildClick();return false;}}],
    root=>{fiMount(root);},{wide:true});
}
function fiMount(root){
  const cv=$('#fi-cv'),box=cv.parentNode;
  const maxW=Math.min(560,window.innerWidth*0.5),maxH=Math.min(640,window.innerHeight*0.62);
  const k=Math.min(maxW/FI.W,maxH/FI.H);FI.k=k;cv.width=Math.round(FI.W*k);cv.height=Math.round(FI.H*k);
  fiDraw();fiList();fiHint();
  root.addEventListener('click',e=>{
    const m=e.target.closest('[data-m]');if(m){FI.mode=m.dataset.m;root.querySelectorAll('[data-m]').forEach(b=>b.classList.toggle('on',b===m));fiHint();return;}
    const d=e.target.closest('[data-del]');if(d){FI.items=FI.items.filter(i=>i.id!==+d.dataset.del);fiList();fiDraw();return;}
    const it=e.target.closest('.fi-it');if(it&&!e.target.closest('input,select,textarea,button')){FI.sel=+it.dataset.id;fiDraw();root.querySelectorAll('.fi-it').forEach(x=>x.classList.toggle('sel',x===it));}
  });
  const upd=e=>{
    const t=e.target,k=t.dataset&&t.dataset.k,row=t.closest('.fi-it');if(!k||!row)return;
    const it=FI.items.find(i=>i.id===+row.dataset.id);if(!it)return;
    it[k]=t.type==='checkbox'?t.checked:t.value;
    if(k==='text'&&e.type==='input'){const cb=row.querySelector('[data-k=checked]');it.checked=it.text.trim().length>0;cb.checked=it.checked;}
    fiDraw();
  };
  root.addEventListener('input',upd);root.addEventListener('change',upd);
  $('#fi-ps').onchange=e=>{FI.picShape=e.target.value;};
  $('#fi-o-bg').onchange=e=>{FI.opt.bg=e.target.checked;FI.items.forEach(i=>{if(i.type==='shape')i.checked=e.target.checked;});fiList();fiDraw();};
  $('#fi-o-ref').onchange=e=>{FI.opt.ref=e.target.checked;};
  // drawing and selecting on the preview
  let drag=null;
  const pt=e=>{const r=cv.getBoundingClientRect();return {x:(e.clientX-r.left)/r.width*FI.W,y:(e.clientY-r.top)/r.height*FI.H};};
  cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);const p=pt(e);
    if(FI.mode==='select'){let best=null,ba=1e18;FI.items.forEach(i=>{const b=i.box;if(p.x>=b.x&&p.y>=b.y&&p.x<=b.x+b.w&&p.y<=b.y+b.h&&b.w*b.h<ba){ba=b.w*b.h;best=i;}});
      FI.sel=best?best.id:null;fiDraw();if(best){const el=document.querySelector('.fi-it[data-id="'+best.id+'"]');document.querySelectorAll('.fi-it').forEach(x=>x.classList.toggle('sel',x===el));if(el)el.scrollIntoView({block:'nearest'});}return;}
    drag={x0:p.x,y0:p.y,x1:p.x,y1:p.y};});
  cv.addEventListener('pointermove',e=>{if(!drag)return;const p=pt(e);drag.x1=p.x;drag.y1=p.y;fiDraw(drag);});
  cv.addEventListener('pointerup',e=>{if(!drag)return;const d=drag;drag=null;const b={x:Math.min(d.x0,d.x1),y:Math.min(d.y0,d.y1),w:Math.abs(d.x1-d.x0),h:Math.abs(d.y1-d.y0)};
    if(b.w<8||b.h<8){fiDraw();return;}fiAddRegion(b);});
}
function fiHint(){const h={select:'Click a box to find it in the list. Tick the things you want as separate editable layers.',text:'Drag a box around the words that were missed. The colour and size are read from the picture.',pic:'Drag around a photo to make it its own picture layer.',ushape:'Drag around a plain coloured shape (banner, button, circle) to rebuild it as an editable shape.'}[FI.mode];const e=$('#fi-hint');if(e)e.textContent=h;}
function fiAddRegion(b){
  const A=FI.A;
  if(FI.mode==='text'){
    // snap the box to the lettering inside it
    const sb={x:Math.round(b.x/A.sc),y:Math.round(b.y/A.sc),w:Math.round(b.w/A.sc),h:Math.round(b.h/A.sc)};
    let st=fa_inkStats(A.data,A.w,A.h,sb);
    let tb=sb;
    if(st){let x0=1e9,y0=1e9,x1=-1,y1=-1;for(let y=Math.max(0,sb.y);y<Math.min(A.h,sb.y+sb.h);y++)for(let x=Math.max(0,sb.x);x<Math.min(A.w,sb.x+sb.w);x++){const i=(y*A.w+x)*4;if(fa_dist(A.data[i],A.data[i+1],A.data[i+2],st.bg)>60){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}}
      if(x1>x0&&y1>y0)tb={x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};}
    const ring=st?st.bg:fa_ring(A.data,A.w,A.h,sb,3),lum=0.3*ring[0]+0.59*ring[1]+0.11*ring[2];
    const ink=st?st.ink:(lum<128?[255,255,255]:[20,20,20]);
    const it=fiMakeTextItem({x:tb.x,y:tb.y,w:tb.w,h:tb.h,ink,bg:ring,lines:st?st.lines:1,ratio:st?st.ratio:0.3,align:'center'},A.sc);it.manual=true;FI.items.push(it);FI.sel=it.id;
    fiReshape();
  }else if(FI.mode==='pic'){FI.items.push({id:FI.seq++,type:'pic',manual:true,kind:FI.picShape,box:b,checked:true});}
  else if(FI.mode==='ushape'){FI.items.push({id:FI.seq++,type:'ushape',manual:true,kind:FI.picShape,box:b,checked:true});}
  fiList();fiDraw();
}
function fiDraw(drag){
  const cv=$('#fi-cv');if(!cv)return;const x=cv.getContext('2d'),k=FI.k;x.clearRect(0,0,cv.width,cv.height);x.drawImage(FI.canvas,0,0,cv.width,cv.height);
  let n=0;
  FI.items.forEach(it=>{n++;const b=it.box,col={text:'#2d8ceb',shape:'#3fb950',ushape:'#3fb950',pic:'#f0883e'}[it.type],on=it.checked,sel=FI.sel===it.id;
    x.lineWidth=sel?3:1.5;x.strokeStyle=col;x.setLineDash(on?[]:[5,4]);x.globalAlpha=on||sel?1:0.7;
    if(it.type==='shape'&&it.isBg){x.setLineDash([2,3]);x.strokeRect(1,1,cv.width-2,cv.height-2);}
    else if(it.kind==='ellipse'){x.beginPath();x.ellipse((b.x+b.w/2)*k,(b.y+b.h/2)*k,b.w*k/2,b.h*k/2,0,0,7);x.stroke();}
    else x.strokeRect(b.x*k,b.y*k,b.w*k,b.h*k);
    x.setLineDash([]);x.globalAlpha=1;
    if(!(it.type==='shape'&&it.isBg)){x.fillStyle=col;x.fillRect(b.x*k,b.y*k-1,16,14);x.fillStyle='#fff';x.font='bold 11px sans-serif';x.fillText(n,b.x*k+3,b.y*k+10);}
  });
  if(drag){x.strokeStyle='#fff';x.setLineDash([4,3]);x.strokeRect(Math.min(drag.x0,drag.x1)*k,Math.min(drag.y0,drag.y1)*k,Math.abs(drag.x1-drag.x0)*k,Math.abs(drag.y1-drag.y0)*k);x.setLineDash([]);}
}
function fiList(){
  const L=$('#fi-list');if(!L)return;
  const order=[...FI.items.map((it,i)=>[it,i+1])];
  L.innerHTML=order.map(a=>fiItemHtml(a[0],a[1])).join('')||'<p class="muted">Nothing was found automatically. Use the + buttons to mark text, pictures and shapes.</p>';
  L.querySelectorAll('canvas[data-th]').forEach(c=>{
    const it=FI.items.find(i=>i.id===+c.dataset.th);if(!it)return;const b=it.box,k=Math.min(1,300/b.w,64/b.h);c.width=Math.max(4,Math.round(b.w*k));c.height=Math.max(4,Math.round(b.h*k));cctx(c).drawImage(FI.canvas,b.x,b.y,b.w,b.h,0,0,c.width,c.height);});
  const t=FI.items.filter(i=>i.type==='text').length,s=FI.items.filter(i=>i.type==='shape').length;
  const hdr=document.getElementById('fi-sum');if(hdr)hdr.remove();
  L.insertAdjacentHTML('afterbegin','<p class="muted" id="fi-sum">Found '+t+' text area'+(t===1?'':'s')+' and '+s+' flat or gradient region'+(s===1?'':'s')+'. Everything that is not ticked stays inside the picture layers. Type the words next to each text box.</p>');
}
async function fiOCR(){
  const todo=FI.items.filter(i=>i.type==='text'&&!i.text.trim());if(!todo.length){toast('Nothing left to read');return;}
  try{
    toast('Loading the text reader...');
    if(!window.Tesseract)await new Promise((res,rej)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';s.onload=res;s.onerror=()=>rej(new Error('offline'));document.head.appendChild(s);});
    const wk=await Tesseract.createWorker('eng');let n=0;
    for(const it of todo){n++;toast('Reading text '+n+' of '+todo.length+'...');
      const b=it.box,pad=6,c=mkCanvas(b.w+pad*2,b.h+pad*2),x=cctx(c);x.fillStyle=FI_HEX(it.bgRGB);x.fillRect(0,0,c.width,c.height);x.drawImage(FI.canvas,b.x,b.y,b.w,b.h,pad,pad,b.w,b.h);
      const r=await wk.recognize(c),t=(r.data.text||'').replace(/\n{2,}/g,'\n').trim();if(t){it.text=t;it.checked=true;}}
    await wk.terminate();fiList();toast('Done. Check the words against the picture.');
  }catch(err){toast('The text reader needs an internet connection. Please type the words instead.');}
}
/* ---------- building the editable design ---------- */
async function fiBuildClick(){
  const b=document.querySelector('#mfoot .primary');if(b){b.disabled=true;b.textContent='Building...';}
  try{await fiBuild();closeModal();}
  catch(err){console.error(err);toast('Build failed: '+err.message);if(b){b.disabled=false;b.textContent='Build editable template';}}
}
function fiShapeMask(it,lab,id){ // analysis-size Uint8 mask of a shape item
  const A=FI.A,m=new Uint8Array(A.w*A.h);for(let i=0;i<m.length;i++)if(lab[i]===id)m[i]=1;return m;
}
function fiRegionMask(it){ // analysis-size mask of a user-marked region
  const A=FI.A,m=new Uint8Array(A.w*A.h),b=it.box,x0=b.x/A.sc,y0=b.y/A.sc,w=b.w/A.sc,h=b.h/A.sc;
  const rad=it.kind==='round'?Math.min(w,h)*0.18:0;
  for(let y=Math.max(0,Math.floor(y0));y<Math.min(A.h,Math.ceil(y0+h));y++)for(let x=Math.max(0,Math.floor(x0));x<Math.min(A.w,Math.ceil(x0+w));x++){
    let inside=true;
    if(it.kind==='ellipse'){const dx=(x+0.5-x0-w/2)/(w/2),dy=(y+0.5-y0-h/2)/(h/2);inside=dx*dx+dy*dy<=1;}
    else if(rad>0){const cx=Math.min(Math.max(x+0.5,x0+rad),x0+w-rad),cy=Math.min(Math.max(y+0.5,y0+rad),y0+h-rad);inside=Math.hypot(x+0.5-cx,y+0.5-cy)<=rad;}
    if(inside)m[y*A.w+x]=1;}
  return m;
}
function fiMaskAlphaCanvas(mask,w,h,W,H,grow){ // upscale an analysis mask to full size with soft edges
  let m=mask;if(grow)m=fa_boxMax(mask,w,h,grow,grow);
  const c=mkCanvas(w,h),x=cctx(c),im=x.createImageData(w,h);for(let i=0;i<m.length;i++){im.data[i*4+3]=m[i]?255:0;im.data[i*4]=im.data[i*4+1]=im.data[i*4+2]=255;}x.putImageData(im,0,0);
  const o=mkCanvas(W,H),ox=cctx(o);ox.imageSmoothingEnabled=true;ox.imageSmoothingQuality='high';ox.drawImage(c,0,0,W,H);return o;
}
function fiLayerFrom(srcCanvas,alphaCanvas,box,name,type){
  const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),x1=Math.min(FI.W,Math.ceil(box.x+box.w)),y1=Math.min(FI.H,Math.ceil(box.y+box.h)),w=Math.max(1,x1-x0),h=Math.max(1,y1-y0);
  const l=addLayer({name,type:type||'image',w,h,x:x0+w/2,y:y0+h/2,select:false}),x=cctx(l.canvas);
  x.drawImage(srcCanvas,x0,y0,w,h,0,0,w,h);if(alphaCanvas){x.globalCompositeOperation='destination-in';x.drawImage(alphaCanvas,x0,y0,w,h,0,0,w,h);x.globalCompositeOperation='source-over';}
  touch(l);return l;
}
function fiMakeText(it){
  const W=FI.W,p={text:it.text.replace(/\s+$/,''),font:it.font||'Outfit',size:Math.max(8,it.lineH*0.95),bold:!!it.bold,italic:false,caps:!!it.caps,color:it.color,align:it.align||'center',lh:1.1,stroke:'#000000',sw:0,shadow:0,shadowColor:'#000000',ls:0};
  const nl=p.text.split('\n').length,b=it.box;
  const l=addLayer({name:p.text.split('\n')[0].slice(0,24)||'Text',type:'text',w:10,h:10,x:b.x+b.w/2,y:b.y+b.h/2,props:p,select:false});
  renderText(l);
  for(let k=0;k<3;k++){const pad=Math.ceil(p.size*0.12+p.sw+p.shadow*1.6+4+Math.max(0,p.ls)*p.size/100),inkW=Math.max(4,l.canvas.width-2*pad);p.size=clamp(p.size*b.w/inkW,6,1500);renderText(l);}
  if(nl>1){const cap=0.72*p.size;p.lh=clamp((b.h-cap)/((nl-1)*p.size),0.8,2.4);renderText(l);}
  const pad=Math.ceil(p.size*0.12+p.sw+p.shadow*1.6+4+Math.max(0,p.ls)*p.size/100);
  l.y=b.y+b.h/2;
  l.x=p.align==='left'?b.x-pad+l.canvas.width/2:p.align==='right'?b.x+b.w+pad-l.canvas.width/2:b.x+b.w/2;
  return l;
}
async function fiBuild(){
  const F=FI,W=F.W,H=F.H,A=F.A,sc=A.sc;
  const texts=F.items.filter(i=>i.type==='text'&&i.checked&&i.text.trim());
  // make sure the chosen fonts are ready so the sizes fit properly
  if(document.fonts&&document.fonts.load)await Promise.all(texts.map(t=>document.fonts.load((t.bold?'700':'400')+' 40px "'+t.font+'"','Aa').catch(()=>0)));
  // 1) paint the retyped words out of the picture
  let cleanFull=F.fd;
  if(texts.length){
    const m=new Uint8Array(W*H);
    texts.forEach(t=>{const pad=Math.max(3,Math.round(t.lineH*0.15)),tm=fa_textMask(F.fd,Object.assign({},t.box,{ink:t.inkRGB}),pad);for(let i=0;i<m.length;i++)if(tm[i])m[i]=1;});
    const grow=Math.max(1,Math.round(sc*0.8));
    cleanFull=fa_inpaint(F.fd,fa_boxMax(m,W,H,grow,grow));
  }
  // 2) work out which pixels each editable piece owns (analysis resolution)
  const aw=A.w,ah=A.h,own=new Uint8Array(aw*ah);
  const unchecked=F.items.filter(i=>i.type==='text'&&!(i.checked&&i.text.trim()));
  const keepOut=new Uint8Array(aw*ah);unchecked.forEach(t=>{const b=t.box,x0=Math.max(0,Math.floor(b.x/sc)-2),y0=Math.max(0,Math.floor(b.y/sc)-2),x1=Math.min(aw,Math.ceil((b.x+b.w)/sc)+2),y1=Math.min(ah,Math.ceil((b.y+b.h)/sc)+2);for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)keepOut[y*aw+x]=1;});
  const userPics=F.items.filter(i=>i.type==='pic'&&i.checked),userShapes=F.items.filter(i=>i.type==='ushape'&&i.checked);
  const carve=new Uint8Array(aw*ah);
  userPics.concat(userShapes).forEach(i=>{const m=fiRegionMask(i);i._m=m;for(let k=0;k<m.length;k++)if(m[k])carve[k]=1;});
  const shapeItems=F.items.filter(i=>i.type==='shape'&&i.checked&&F.shape&&F.shape.lab);
  shapeItems.forEach(s=>{const m=fiShapeMask(s,F.shape.lab,s.sid);for(let k=0;k<m.length;k++)if(m[k]&&!keepOut[k]&&!carve[k])own[k]=1;s._m=m;});
  // user shapes: read their colour from the picture
  userShapes.forEach(u=>{const lab=new Int32Array(aw*ah),m=u._m;for(let k=0;k<m.length;k++)if(m[k])lab[k]=1;const bb={x0:Math.floor(u.box.x/sc),y0:Math.floor(u.box.y/sc),x1:Math.min(aw-1,Math.ceil((u.box.x+u.box.w)/sc)),y1:Math.min(ah-1,Math.ceil((u.box.y+u.box.h)/sc))};
    u._fit=fa_modelFit(F.cleanA.data,aw,ah,lab,1,bb);});
  // shapes that sit on a photo (not on the background): fill the hole they leave in the picture so moving or deleting them looks natural
  const bgIt=shapeItems.find(s=>s.isBg),holes=[];
  shapeItems.forEach(s=>{
    if(s.isBg)return;let photo=true;
    if(bgIt&&bgIt._m){const dil=fa_boxMax(s._m,aw,ah,3,3);let ring=0,onbg=0;for(let k=0;k<dil.length;k++)if(dil[k]&&!s._m[k]){ring++;if(bgIt._m[k])onbg++;}photo=ring>0&&onbg/ring<0.5;}
    s._photo=photo;if(photo){holes.push(s);for(let k=0;k<s._m.length;k++)if(s._m[k]&&!keepOut[k]&&!carve[k])own[k]=0;}
  });
  if(holes.length){
    const hm=new Uint8Array(W*H);
    holes.forEach(s=>{const ac=fiMaskAlphaCanvas(s._m,aw,ah,W,H,0),d=cctx(ac).getImageData(0,0,W,H).data;for(let i=0;i<hm.length;i++)if(d[i*4+3]>110)hm[i]=1;});
    const g2=Math.max(1,Math.round(sc*1.2));cleanFull=fa_inpaint(cleanFull,fa_boxMax(hm,W,H,g2,g2));
  }
  const cleanC=mkCanvas(W,H);cctx(cleanC).putImageData(cleanFull,0,0);
  // 3) the residual (photos and anything not rebuilt) in connected pieces
  const R=new Uint8Array(aw*ah);for(let k=0;k<R.length;k++)R[k]=(own[k]||carve[k])?0:1;
  const RC=fa_boxMax(R,aw,ah,1,1);const Rc=fa_erode(RC,aw,ah,1,1);
  const cc=fa_cc(Rc,aw,ah,true);
  const pieces=cc.comps.filter(c=>c.area>=aw*ah*0.006).sort((a,b)=>b.area-a.area),dust=new Uint8Array(aw*ah);
  const big=new Set(pieces.map(p=>p.id));
  for(let k=0;k<R.length;k++)if(R[k]&&!big.has(cc.lab[k]))dust[k]=1;
  // 4) assemble the document
  startDoc(F.name,W,H,72);
  const refL=addLayer({name:'Original flyer (reference)',type:'image',w:W,h:H,select:false});cctx(refL.canvas).drawImage(F.canvas,0,0);touch(refL);
  const counts={text:0,shape:0,pic:0,grad:0};
  // background and shapes
  const bgItem=shapeItems.find(s=>s.isBg);
  if(bgItem){const g=bgItem.grad,l=addLayer({name:'Background gradient',type:'shape',w:10,h:10,x:W/2,y:H/2,select:false,props:{kind:'rect',fill:bgItem.fill,stroke:'#000000',sw:0,radius:0,w:W,h:H,flip:false,nofill:false,grad:g?JSON.parse(JSON.stringify(g)):null}});renderShape(l);counts.shape++;if(g)counts.grad++;}
  
  // photo pieces
  let pn=0;
  const picNames=[];
  pieces.forEach(c=>{
    const m=new Uint8Array(aw*ah);for(let k=0;k<m.length;k++)if(cc.lab[k]===c.id)m[k]=1;
    const ac=fiMaskAlphaCanvas(m,aw,ah,W,H,1);pn++;
    fiLayerFrom(cleanC,ac,{x:Math.max(0,(c.x0-3)*sc),y:Math.max(0,(c.y0-3)*sc),w:(c.x1-c.x0+7)*sc,h:(c.y1-c.y0+7)*sc},pieces.length>1?'Picture '+pn:'Picture','image');counts.pic++;
  });
  if(dust.some&&Array.prototype.some.call(dust,v=>v)){const ac=fiMaskAlphaCanvas(dust,aw,ah,W,H,1);fiLayerFrom(cleanC,ac,{x:0,y:0,w:W,h:H},'Small details','image');}
  // pictures the user marked
  userPics.forEach((u,i)=>{const ac=fiMaskAlphaCanvas(u._m,aw,ah,W,H,0);fiLayerFrom(cleanC,ac,u.box,'Picture (marked) '+(i+1),'image');counts.pic++;});
  // other flat/gradient shapes, largest first
  shapeItems.filter(s=>!s.isBg).sort((a,b)=>b.area-a.area).forEach(s=>{
    if(s.kind==='cutout'){
      const ac=fiMaskAlphaCanvas(s._m,aw,ah,W,H,0);let traced=false;
      try{const pth=vec_traceAlpha(ac,{tol:1.6});
        if(pth&&pth.subs&&pth.subs.length){const l=pathToShapeLayer(pth,{name:s.name,fill:s.fill,stroke:'#000000',sw:0});l.props.grad=s.grad?JSON.parse(JSON.stringify(s.grad)):null;renderShape(l);doc.layers.push(doc.layers.splice(doc.layers.indexOf(l),1)[0]);counts.shape++;if(l.props.grad)counts.grad++;traced=true;}}catch(err){console.warn(err);}
      if(!traced){const ac2=fiMaskAlphaCanvas(s._m,aw,ah,W,H,1);fiLayerFrom(cleanC,ac2,s.box,'Cutout piece','image');counts.pic++;}
      return;}
    const b=s.box,g=s.grad?JSON.parse(JSON.stringify(s.grad)):null;
    const l=addLayer({name:s.name,type:'shape',w:10,h:10,x:b.x+b.w/2,y:b.y+b.h/2,select:false,props:{kind:s.kind,fill:s.fill,stroke:'#000000',sw:0,radius:s.kind==='round'?Math.round(s.radius*sc):0,w:b.w,h:b.h,flip:false,nofill:false,grad:g}});
    renderShape(l);counts.shape++;if(g)counts.grad++;});
  userShapes.forEach(u=>{const f=u._fit,b=u.box,g=f&&f.grad?JSON.parse(JSON.stringify(f.grad)):null;
    const l=addLayer({name:'Shape (marked)',type:'shape',w:10,h:10,x:b.x+b.w/2,y:b.y+b.h/2,select:false,props:{kind:u.kind,fill:f?f.color:'#888888',stroke:'#000000',sw:0,radius:u.kind==='round'?Math.round(Math.min(b.w,b.h)*0.18):0,w:b.w,h:b.h,flip:false,nofill:false,grad:g}});renderShape(l);counts.shape++;if(g)counts.grad++;});
  // text on top, in reading order
  texts.sort((a,b)=>a.box.y-b.box.y||a.box.x-b.box.x).forEach(t=>{fiMakeText(t);counts.text++;});
  finishDoc();
  refL.locked=true;refL.visible=!F.opt.ref?false:false;
  if(!F.opt.ref){const i=doc.layers.indexOf(refL);if(i>=0)doc.layers.splice(i,1);}
  doc.active=doc.layers[doc.layers.length-1].id;
  commit('Import flyer as template');
  hideWelcome();refreshAll();redraw();fitView&&fitView();
  // how close is the rebuild?
  let diff=-1;
  try{const a=flatCanvas(1),sx=cctx(a).getImageData(0,0,W,H).data,o=F.fd.data;let s=0,n=0;for(let i=0;i<sx.length;i+=64){s+=Math.abs(sx[i]-o[i])+Math.abs(sx[i+1]-o[i+1])+Math.abs(sx[i+2]-o[i+2]);n+=3;}diff=100-s/n/2.55;}catch(e){}
  window.__fiLast={counts,diff};
  toast('Built '+counts.text+' text, '+counts.shape+' shape ('+counts.grad+' gradient) and '+counts.pic+' picture layers'+(diff>=0?'. Matches the original about '+Math.round(diff)+'%':'')+'. The original is saved as a hidden reference layer.');
}
{
  const F=MENUS.find(m=>m.label==='File');
  if(F){const i=F.items.findIndex(x=>x&&x.label==='Place image...');F.items.splice(i+1,0,mi('Import flyer as template...','','importFlyer'));}
}
/* ---- replace a picture layer's content, keeping its size, position and cut-out shape ---- */
ACT.replacePic=async function(){
  const l=active();if(!l||l.type!=='image'){toast('Select a picture layer first');return;}
  const f=await fiPickFile();if(!f)return;
  try{
    const c=await fileToCanvas(f,3000),old=cloneCanvas(l.canvas),W=l.canvas.width,H=l.canvas.height,x=cctx(l.canvas);
    flush();x.clearRect(0,0,W,H);
    const k=Math.max(W/c.width,H/c.height),dw=c.width*k,dh=c.height*k;
    x.drawImage(c,(W-dw)/2,(H-dh)/2,dw,dh);
    x.globalCompositeOperation='destination-in';x.drawImage(old,0,0);x.globalCompositeOperation='source-over';
    touch(l);commit('Replace picture');renderProps();refreshLayers();redraw();toast('Picture replaced. It keeps the same shape and position.');
  }catch(err){toast('That file could not be opened as a picture');}
};
{
  const _rp6=renderProps;
  renderProps=function(){
    _rp6();
    const l=doc&&active();if(!l||l.type!=='image')return;
    const box=$('#tab-props'),p=box.querySelector('p.muted');
    const html='<div class="h">Picture</div><div class="row"><button class="primary" data-act="replacePic">Replace picture...</button></div>';
    if(p)p.insertAdjacentHTML('beforebegin',html);else box.insertAdjacentHTML('afterbegin',html);
  };
}
