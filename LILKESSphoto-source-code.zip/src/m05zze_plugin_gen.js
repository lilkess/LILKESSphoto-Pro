/* ===== Built-in plugins, part 2: generators (they add a new layer) ===== */
function plgNewLayer(c,name,blend){
  if(!doc)newBlank('Plugin design',Math.max(512,c.width),Math.max(512,c.height),72,'#ffffff');
  const l=addLayer({name,type:'image',w:c.width,h:c.height,above:true});cctx(l.canvas).drawImage(c,0,0);
  if(blend)l.blend=blend;
  const k=Math.min(1,doc.w*0.8/c.width,doc.h*0.8/c.height);l.s=k;commit(name);refreshLayers();renderProps();redraw();return l;
}
const plgHex=h=>{h=String(h||'#000').replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return [n>>16&255,n>>8&255,n&255];};
const plgHsl=(h,s,l)=>{h=((h%360)+360)%360/360;const f=n=>{const k=(n+h*12)%12,a=s*Math.min(l,1-l);return l-a*Math.max(-1,Math.min(k-3,9-k,1));};return [f(0)*255,f(8)*255,f(4)*255];};
/* a generic dialog for generators: preview canvas, controls, "Add as layer" */
function plgGenDialog(def){
  const vals={};def.params.forEach(p=>vals[p.id]=p.value);
  const ctl=def.params.map(p=>{
    if(p.type==='select')return '<label class="plg-r"><span>'+esc(p.label)+'</span><select data-pp="'+p.id+'">'+p.options.map(op=>'<option value="'+esc(op[0])+'"'+(op[0]===p.value?' selected':'')+'>'+esc(op[1])+'</option>').join('')+'</select></label>';
    if(p.type==='check')return '<label class="plg-r"><span></span><label class="opt"><input type="checkbox" data-pp="'+p.id+'"'+(p.value?' checked':'')+'> '+esc(p.label)+'</label></label>';
    if(p.type==='color')return '<label class="plg-r"><span>'+esc(p.label)+'</span><input type="color" data-pp="'+p.id+'" value="'+p.value+'" style="flex:none;width:48px;height:28px"></label>';
    if(p.type==='text')return '<label class="plg-r"><span>'+esc(p.label)+'</span><input type="text" data-pp="'+p.id+'" value="'+esc(p.value)+'" style="flex:1;min-width:0"></label>';
    if(p.type==='area')return '<label class="plg-r" style="align-items:flex-start"><span>'+esc(p.label)+'</span><textarea data-pp="'+p.id+'" rows="'+(p.rows||6)+'" style="flex:1;min-width:0">'+esc(p.value)+'</textarea></label>';
    return '<label class="plg-r"><span>'+esc(p.label)+'</span><input type="range" data-pp="'+p.id+'" min="'+p.min+'" max="'+p.max+'" step="'+(p.step||1)+'" value="'+p.value+'"><input type="number" class="nv" data-pn="'+p.id+'" min="'+p.min+'" max="'+p.max+'" step="'+(p.step||1)+'" value="'+p.value+'"><em>'+(p.unit||'')+'</em></label>';}).join('');
  let last=null;
  modalOpen(def.name,'<div class="plg-dlg"><div class="plg-pv"><canvas id="plg-pv" width="320" height="240"></canvas><div class="muted" id="plg-ms"></div></div><div class="plg-ct">'+(def.desc?'<p class="muted">'+esc(def.desc)+'</p>':'')+ctl+(def.extra?def.extra:'')+'</div></div>',
   [{label:'Close'},{label:def.addLabel||'Add as layer',primary:true,cb:()=>{
      try{const c=last||def.render(Object.assign({},vals),false);const l=plgNewLayer(c,def.layerName?def.layerName(vals):def.name,def.blend);plgUsed(def.id);if(def.after)def.after(l,vals);toast(def.name+' added as a new layer');}
      catch(e){console.error(e);toast('Could not create it: '+(e.message||e));return false;}}}],
   root=>{
     const cv=root.querySelector('#plg-pv'),ms=root.querySelector('#plg-ms');let t=0;
     const draw=()=>{const t0=performance.now();try{const c=def.render(Object.assign({},vals),true);last=null;const k=Math.min(1,460/Math.max(c.width,c.height));cv.width=Math.max(1,Math.round(c.width*k));cv.height=Math.max(1,Math.round(c.height*k));const x=cctx(cv);x.imageSmoothingQuality='high';x.drawImage(c,0,0,cv.width,cv.height);ms.textContent=c.width+' x '+c.height+' px  ·  '+Math.round(performance.now()-t0)+' ms';}catch(e){console.error(e);ms.textContent='Could not draw: '+(e.message||e);}};
     const sched=()=>{clearTimeout(t);t=setTimeout(draw,90);};
     const rd=e=>{const x=e.target,id=x.dataset.pp||x.dataset.pn;if(!id)return;
       if(x.type==='checkbox')vals[id]=x.checked;else if(x.tagName==='SELECT'||x.type==='color'||x.type==='text'||x.tagName==='TEXTAREA')vals[id]=x.value;else{vals[id]=+x.value;const o=root.querySelector('[data-pp="'+id+'"][type=range]'),n=root.querySelector('[data-pn="'+id+'"]');if(o&&x!==o)o.value=x.value;if(n&&x!==n)n.value=x.value;}
       sched();};
     root.addEventListener('input',rd);root.addEventListener('change',rd);
     if(def.mount)def.mount(root,vals,sched);
     draw();
   },{wide:true});
}
const pgR=(id,label,min,max,value,unit,step)=>({id,label,min,max,value,unit,step,type:'range'});
const pgS=(id,label,value,options)=>({id,label,value,options,type:'select'});
const pgC=(id,label,value)=>({id,label,value,type:'color'});
const pgK=(id,label,value)=>({id,label,value,type:'check'});

/* ---------- Progen Flares ---------- */
function plgFlare(v){
  const S0=v.size,c=mkCanvas(S0,S0),x=cctx(c),id=x.createImageData(S0,S0),d=id.data;
  const cx=S0*v.x/100,cy=S0*v.y/100,sg=S0*v.core/100*0.25+2,col=plgHsl(v.hue,v.sat/100,.6),ic=S0/2;
  const sc=v.sat?col:[255,255,255];
  const streaks=[];for(let i=0;i<v.streaks;i++)streaks.push(v.rot*Math.PI/180+i*Math.PI/Math.max(1,v.streaks));
  const L=S0*v.length/100*0.5,sw=Math.max(1.2,S0*0.004),ghosts=[];
  for(let i=0;i<v.ghosts;i++){const k=-0.35+i*(1.5/Math.max(1,v.ghosts)),gx=cx+(ic-cx)*(1+k*1.6),gy=cy+(ic-cy)*(1+k*1.6),gr=S0*(0.02+((i*37)%7)*0.012);ghosts.push([gx,gy,gr,plgHsl(v.hue+i*25,.7,.55)]);}
  const ring=S0*v.ring/100*0.3;
  for(let y=0;y<S0;y++)for(let X=0;X<S0;X++){
    const dx=X-cx,dy=y-cy,r2=dx*dx+dy*dy,r=Math.sqrt(r2);
    let I=Math.exp(-r2/(2*sg*sg))*1.1+0.28/(1+(r/(sg*3.2))*(r/(sg*3.2)))*.55;
    let sr=0,sgc=0,sb=0;
    for(const a of streaks){const ca=Math.cos(a),sa=Math.sin(a),t=dx*ca+dy*sa,pp=-dx*sa+dy*ca;I+=Math.exp(-pp*pp/(2*sw*sw))*Math.exp(-Math.abs(t)/L)*.9;}
    if(ring>1){const q=r-ring;I+=Math.exp(-q*q/(2*(S0*0.006)*(S0*0.006)))*.35;}
    let R=I*sc[0],G=I*sc[1],B=I*sc[2];
    const core=Math.exp(-r2/(2*(sg*.45)*(sg*.45)));R+=core*255;G+=core*255;B+=core*255;
    for(const g of ghosts){const gx=X-g[0],gy=y-g[1],q=Math.exp(-(gx*gx+gy*gy)/(2*g[2]*g[2]))*.35;R+=q*g[3][0];G+=q*g[3][1];B+=q*g[3][2];}
    const o=(y*S0+X)*4;d[o]=Math.min(255,R*v.power/100);d[o+1]=Math.min(255,G*v.power/100);d[o+2]=Math.min(255,B*v.power/100);d[o+3]=255;
  }
  if(v.transparent){for(let i=0;i<d.length;i+=4){const a=Math.max(d[i],d[i+1],d[i+2]);if(a>0){d[i]=Math.min(255,d[i]*255/a);d[i+1]=Math.min(255,d[i+1]*255/a);d[i+2]=Math.min(255,d[i+2]*255/a);}d[i+3]=a;}}
  x.putImageData(id,0,0);return c;
}
plgReg({id:'flares',name:'Progen Flares',cat:'Image Elements',desc:'Procedural lens flares: glow, streaks, ring and ghost spots. Added as a screen-blend layer so only the light shows.',
  params:[pgR('x','Light X',0,100,35,'%'),pgR('y','Light Y',0,100,35,'%'),pgR('size','Layer size',256,1536,768,'px',64),pgR('core','Glow size',2,100,28,'%'),pgR('hue','Colour',0,360,38,'°'),pgR('sat','Colour amount',0,100,70,'%'),pgR('streaks','Streaks',0,12,4,''),pgR('length','Streak length',5,100,60,'%'),pgR('rot','Rotation',0,180,15,'°'),pgR('ring','Ring',0,100,40,'%'),pgR('ghosts','Ghost spots',0,8,4,''),pgR('power','Brightness',20,250,100,'%'),pgK('transparent','Transparent background (instead of black + screen)',false)],
  render:v=>plgFlare(v),blend:'screen',run(){plgGenDialog(this);}});

/* ---------- Zeus: electric lightning ---------- */
function plgRand(seed){let s=seed>>>0||1;return()=>{s^=s<<13;s>>>=0;s^=s>>>17;s^=s<<5;s>>>=0;return s/4294967296;};}
function plgBolt(r,x0,y0,x1,y1,disp,out,depth,branch){
  if(depth===0||disp<1.2){out.push([x0,y0,x1,y1,branch]);return;}
  const mx=(x0+x1)/2,my=(y0+y1)/2,dx=x1-x0,dy=y1-y0,len=Math.hypot(dx,dy)||1,nx=-dy/len,ny=dx/len,o=(r()-.5)*disp,px=mx+nx*o,py=my+ny*o;
  plgBolt(r,x0,y0,px,py,disp/2,out,depth-1,branch);plgBolt(r,px,py,x1,y1,disp/2,out,depth-1,branch);
}
function plgZeus(v){
  const W=v.w,H=v.h,c=mkCanvas(W,H),x=cctx(c),r=plgRand(v.seed),pal={blue:['#3a7bff','#bcd6ff'],purple:['#9d4bff','#e3c9ff'],white:['#ffffff','#ffffff'],green:['#22e07a','#c9ffe0'],red:['#ff3b3b','#ffd0d0'],gold:['#ffb320','#fff1c2']}[v.color];
  const segs=[];
  for(let i=0;i<v.bolts;i++){
    let a,b;
    if(v.dir==='down'){a=[W*(0.3+r()*0.4),0];b=[W*(0.2+r()*0.6),H];}
    else if(v.dir==='across'){a=[0,H*(0.3+r()*0.4)];b=[W,H*(0.2+r()*0.6)];}
    else{const ang=r()*Math.PI*2,len=Math.min(W,H)*0.46;a=[W/2,H/2];b=[W/2+Math.cos(ang)*len,H/2+Math.sin(ang)*len];}
    const mainSegs=[];plgBolt(r,a[0],a[1],b[0],b[1],Math.hypot(b[0]-a[0],b[1]-a[1])*0.28*v.chaos/50,mainSegs,7,0);
    mainSegs.forEach(s=>segs.push(s));
    const nb=Math.round(v.branches/100*10);
    for(let j=0;j<nb;j++){
      const s=mainSegs[Math.floor(r()*mainSegs.length)],ang=Math.atan2(s[3]-s[1],s[2]-s[0])+(r()-.5)*1.5,len=Math.hypot(b[0]-a[0],b[1]-a[1])*(0.1+r()*0.22);
      plgBolt(r,s[2],s[3],s[2]+Math.cos(ang)*len,s[3]+Math.sin(ang)*len,len*0.3,segs,5,1);
    }
  }
  x.lineCap='round';x.lineJoin='round';
  const th=v.thick*Math.max(W,H)/1500;
  const stroke=(w,col,blur,alpha,onlyMain)=>{x.save();x.strokeStyle=col;x.shadowColor=pal[0];x.shadowBlur=blur;x.globalAlpha=alpha;x.lineWidth=w;x.beginPath();segs.forEach(s=>{if(onlyMain&&s[4])return;x.moveTo(s[0],s[1]);x.lineTo(s[2],s[3]);});x.stroke();x.restore();};
  const gl=v.glow/100;
  stroke(th*9,pal[0],th*40*gl,.16*gl);stroke(th*5,pal[0],th*22*gl,.4);stroke(th*2.4,pal[1],th*9*gl,.9);stroke(th*1,'#ffffff',th*3,1);
  return c;
}
plgReg({id:'zeus',name:'Zeus Electric Effects',cat:'Effects',desc:'Draws lightning with branches and a glow. Change the seed for a different bolt each time.',
  params:[pgR('w','Width',256,2400,1080,'px',8),pgR('h','Height',256,2400,1080,'px',8),pgS('dir','Direction','down',[['down','Top to bottom'],['across','Left to right'],['burst','Burst from the centre']]),pgR('bolts','Bolts',1,8,2,''),pgR('branches','Branching',0,100,60,'%'),pgR('chaos','Jaggedness',10,100,50,'%'),pgR('thick','Thickness',1,12,4,''),pgR('glow','Glow',0,200,100,'%'),pgS('color','Colour','blue',[['blue','Electric blue'],['purple','Purple'],['white','White'],['green','Green'],['red','Red'],['gold','Gold']]),pgR('seed','Seed',1,9999,42,'')],
  extra:'<div class="row"><button id="zs-r">Random seed</button></div>',mount(root,vals,sched){root.querySelector('#zs-r').onclick=()=>{vals.seed=1+Math.floor(Math.random()*9998);const a=root.querySelector('[data-pp=seed][type=range]'),b=root.querySelector('[data-pn=seed]');if(a)a.value=vals.seed;if(b)b.value=vals.seed;sched();};},
  render:v=>plgZeus(v),blend:'screen',run(){plgGenDialog(this);}});
