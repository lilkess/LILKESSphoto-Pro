/* ===== Photoshop PSD engine: layers, masks, editable text, layer styles ===== */

/* ---------- binary cursor ---------- */
function psdCur(u8,p){return {u8,dv:new DataView(u8.buffer,u8.byteOffset,u8.byteLength),p:p||0};}
const cu32=c=>{const v=c.dv.getUint32(c.p);c.p+=4;return v;};
const ci32=c=>{const v=c.dv.getInt32(c.p);c.p+=4;return v;};
const cu16=c=>{const v=c.dv.getUint16(c.p);c.p+=2;return v;};
const cf64=c=>{const v=c.dv.getFloat64(c.p);c.p+=8;return v;};
const cstr=(c,n)=>{let s='';for(let i=0;i<n;i++)s+=String.fromCharCode(c.u8[c.p+i]);c.p+=n;return s;};
function cUnicode(c){
  const n=cu32(c);let s='';for(let i=0;i<n;i++){s+=String.fromCharCode(c.dv.getUint16(c.p+i*2));}c.p+=n*2;
  return s.replace(/\0+$/,'');
}
function cKey(c){const n=cu32(c);return cstr(c,n===0?4:n);}

/* ---------- descriptors (Photoshop's key/value structures) ---------- */
function readDesc(c){
  cUnicode(c);const cls=cKey(c),cnt=cu32(c),o={_cls:cls};
  for(let i=0;i<cnt;i++){const k=cKey(c);o[k]=readDescValue(c);}
  return o;
}
function readDescValue(c){
  const t=cstr(c,4);
  switch(t){
    case 'Objc':case 'GlbO':return readDesc(c);
    case 'VlLs':{const n=cu32(c),a=[];for(let i=0;i<n;i++)a.push(readDescValue(c));return a;}
    case 'doub':return cf64(c);
    case 'UntF':{cstr(c,4);return cf64(c);}
    case 'TEXT':return cUnicode(c);
    case 'enum':{cKey(c);return cKey(c);}
    case 'long':return ci32(c);
    case 'comp':{const hi=cu32(c),lo=cu32(c);return hi*4294967296+lo;}
    case 'bool':return c.u8[c.p++]!==0;
    case 'tdta':{const n=cu32(c),b=c.u8.slice(c.p,c.p+n);c.p+=n;return b;}
    case 'alis':{const n=cu32(c);c.p+=n;return null;}
    case 'type':case 'GlbC':case 'Clss':{cUnicode(c);cKey(c);return null;}
    case 'obj ':{const n=cu32(c);for(let i=0;i<n;i++){const k=cstr(c,4);if(k==='prop'){cUnicode(c);cKey(c);cKey(c);}else if(k==='Clss'){cUnicode(c);cKey(c);}else if(k==='Enmr'){cUnicode(c);cKey(c);cKey(c);cKey(c);}else if(k==='rele'){cUnicode(c);cKey(c);cu32(c);}else if(k==='Idnt'||k==='indx'){cu32(c);}else if(k==='name'){cUnicode(c);cKey(c);cUnicode(c);}else throw new Error('ref');}return null;}
    default:throw new Error('desc '+t);
  }
}
/* writer: a tiny builder. values are {t:'Objc',cls,items:[[key,value]...]} etc. */
const dO=(cls,items)=>({t:'Objc',cls,items});
const dD=v=>({t:'doub',v}),dU=(u,v)=>({t:'UntF',u,v}),dT=s=>({t:'TEXT',v:s}),dE=(ty,v)=>({t:'enum',ty,v}),dL=v=>({t:'long',v}),dB=v=>({t:'bool',v}),dR=b=>({t:'tdta',v:b}),dV=a=>({t:'VlLs',a});
class PW{
  constructor(){this.a=[];}
  u8(v){this.a.push(v&255);}
  u16(v){this.a.push(v>>8&255,v&255);}
  u32(v){this.a.push(v>>>24&255,v>>16&255,v>>8&255,v&255);}
  i32(v){this.u32(v>>>0);}
  f64(v){const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,v);for(let i=0;i<8;i++)this.a.push(b.getUint8(i));}
  str(s){for(let i=0;i<s.length;i++)this.a.push(s.charCodeAt(i)&255);}
  bytes(u){for(let i=0;i<u.length;i++)this.a.push(u[i]);}
  uni(s){this.u32(s.length+1);for(let i=0;i<s.length;i++)this.u16(s.charCodeAt(i));this.u16(0);}
  key(k){if(k.length===4){this.u32(0);this.str(k);}else{this.u32(k.length);this.str(k);}}
  desc(cls,items){this.uni('');this.key(cls);this.u32(items.length);for(const it of items){this.key(it[0]);this.val(it[1]);}}
  val(v){
    this.str(v.t);
    switch(v.t){
      case 'Objc':this.desc(v.cls,v.items);break;
      case 'VlLs':this.u32(v.a.length);v.a.forEach(x=>this.val(x));break;
      case 'doub':this.f64(v.v);break;
      case 'UntF':this.str(v.u);this.f64(v.v);break;
      case 'TEXT':this.uni(v.v);break;
      case 'enum':this.key(v.ty);this.key(v.v);break;
      case 'long':this.i32(v.v);break;
      case 'bool':this.u8(v.v?1:0);break;
      case 'tdta':this.u32(v.v.length);this.bytes(v.v);break;
    }
  }
}

/* ---------- EngineData (the text engine's own format) ---------- */
class Fl{constructor(v){this.v=v;}}
function engineParse(u8){
  let p=0;const n=u8.length;
  const ws=()=>{while(p<n&&(u8[p]===32||u8[p]===9||u8[p]===10||u8[p]===13||u8[p]===0))p++;};
  function str(){ // after '('
    const out=[];
    while(p<n&&u8[p]!==41){let b=u8[p++];if(b===92){b=u8[p++];if(b===114)b=13;else if(b===110)b=10;else if(b===116)b=9;}out.push(b);}
    p++;
    if(out[0]===0xfe&&out[1]===0xff){let s='';for(let i=2;i+1<out.length;i+=2)s+=String.fromCharCode(out[i]<<8|out[i+1]);return s;}
    return String.fromCharCode(...out);
  }
  function val(){
    ws();const b=u8[p];
    if(b===60&&u8[p+1]===60){p+=2;const o={};
      for(;;){ws();if(p>=n)break;if(u8[p]===62&&u8[p+1]===62){p+=2;break;}
        if(u8[p]!==47){p++;continue;}p++;let k='';while(p<n&&!/[\s\/\[\]()<>]/.test(String.fromCharCode(u8[p])))k+=String.fromCharCode(u8[p++]);
        o[k]=val();}
      return o;}
    if(b===91){p++;const a=[];for(;;){ws();if(p>=n)break;if(u8[p]===93){p++;break;}a.push(val());}return a;}
    if(b===40){p++;return str();}
    if(b===47){p++;let k='';while(p<n&&!/[\s\/\[\]()<>]/.test(String.fromCharCode(u8[p])))k+=String.fromCharCode(u8[p++]);return '/'+k;}
    let t='';while(p<n&&!/[\s\/\[\]()<>]/.test(String.fromCharCode(u8[p])))t+=String.fromCharCode(u8[p++]);
    if(t==='true')return true;if(t==='false')return false;if(t==='null')return null;
    const f=parseFloat(t);return isNaN(f)?t:f;
  }
  return val();
}
function engineSerialize(root){
  const out=[];const push=s=>{for(let i=0;i<s.length;i++)out.push(s.charCodeAt(i)&255);};
  const num=v=>{if(v instanceof Fl){const s=(+v.v).toFixed(6).replace(/0+$/,'').replace(/\.$/,'.0');return s.indexOf('.')<0?s+'.0':s;}return String(v);};
  function ser(v,ind){
    if(v instanceof Fl)return push(num(v));
    if(typeof v==='number')return push(String(v));
    if(typeof v==='boolean')return push(v?'true':'false');
    if(typeof v==='string'){
      out.push(40,0xfe,0xff);
      for(let i=0;i<v.length;i++){const ch=v.charCodeAt(i);for(const b of [ch>>8&255,ch&255]){if(b===40||b===41||b===92)out.push(92);out.push(b);}}
      out.push(41);return;
    }
    if(Array.isArray(v)){
      if(v.every(x=>typeof x!=='object'||x instanceof Fl)){push('[');v.forEach(x=>{push(' ');ser(x,ind);});push(' ]');return;}
      push('[\n');v.forEach(x=>{push(ind+'\t');ser(x,ind+'\t');push('\n');});push(ind+']');return;
    }
    push('<<\n');
    for(const k of Object.keys(v)){
      const x=v[k];
      if(x&&typeof x==='object'&&!(x instanceof Fl)&&!Array.isArray(x)){push(ind+'\t/'+k+'\n'+ind+'\t');ser(x,ind+'\t');push('\n');}
      else{push(ind+'\t/'+k+' ');ser(x,ind+'\t');push('\n');}
    }
    push(ind+'>>');
  }
  push('\n\n');ser(root,'');
  return new Uint8Array(out);
}

/* ---------- fonts ---------- */
const PS_FONT_NAMES={
  'Montserrat':['Montserrat-Regular','Montserrat-Bold','Montserrat-Italic','Montserrat-BoldItalic'],
  'Anton':['Anton-Regular','Anton-Regular','Anton-Regular','Anton-Regular'],
  'Bebas Neue':['BebasNeue-Regular','BebasNeue-Regular','BebasNeue-Regular','BebasNeue-Regular'],
  'Oswald':['Oswald-Regular','Oswald-Bold','Oswald-Regular','Oswald-Bold'],
  'Playfair Display':['PlayfairDisplay-Regular','PlayfairDisplay-Bold','PlayfairDisplay-Italic','PlayfairDisplay-BoldItalic'],
  'Pacifico':['Pacifico-Regular','Pacifico-Regular','Pacifico-Regular','Pacifico-Regular'],
  'Lobster':['Lobster-Regular','Lobster-Regular','Lobster-Regular','Lobster-Regular'],
  'Dancing Script':['DancingScript-Regular','DancingScript-Bold','DancingScript-Regular','DancingScript-Bold'],
  'Permanent Marker':['PermanentMarker-Regular','PermanentMarker-Regular','PermanentMarker-Regular','PermanentMarker-Regular'],
  'Roboto Slab':['RobotoSlab-Regular','RobotoSlab-Bold','RobotoSlab-Regular','RobotoSlab-Bold'],
  'Arial':['ArialMT','Arial-BoldMT','Arial-ItalicMT','Arial-BoldItalicMT'],
  'Georgia':['Georgia','Georgia-Bold','Georgia-Italic','Georgia-BoldItalic'],
  'Impact':['Impact','Impact','Impact','Impact'],
  'Verdana':['Verdana','Verdana-Bold','Verdana-Italic','Verdana-BoldItalic'],
  'Courier New':['CourierNewPSMT','CourierNewPS-BoldMT','CourierNewPS-ItalicMT','CourierNewPS-BoldItalicMT']
};
function psFontName(p){
  const i=(p.bold?1:0)+(p.italic?2:0);
  if(p.psdFont&&psdFontFamily(p.psdFont)===p.font)return p.psdFont;
  const t=PS_FONT_NAMES[p.font];
  return t?t[i]:(String(p.font||'Arial').replace(/\s+/g,'')+(p.bold?'-Bold':'')+(p.italic&&!p.bold?'-Italic':''));
}
function psdFontFamily(ps){
  const key=String(ps||'').toLowerCase().replace(/(boldital|bolditalic|semibold|extrabold|extralight|bold|italic|oblique|regular|black|medium|light|thin|heavy|condensed)/g,'').replace(/[^a-z0-9]/g,'').replace(/(mt|ps|std|pro)$/,'');
  for(const f of FONTS){if(f.toLowerCase().replace(/[^a-z0-9]/g,'')===key)return f;}
  for(const f of FONTS){const k=f.toLowerCase().replace(/[^a-z0-9]/g,'');if(key&&(key.startsWith(k)||k.startsWith(key)))return f;}
  return null;
}
const psdIsBold=n=>/bold|black|heavy/i.test(n||''),psdIsItalic=n=>/italic|oblique/i.test(n||'');

/* ---------- text layer <-> TySh ---------- */
function textFromTySh(blk){
  const c=psdCur(blk,0);
  cu16(c);const xf=[];for(let i=0;i<6;i++)xf.push(cf64(c));
  cu16(c);cu32(c);const d=readDesc(c);
  const eng=d.EngineData?engineParse(d.EngineData):null;
  let text=String(d['Txt ']||'').replace(/\r\n?/g,'\n').replace(/\u0003/g,'\n');
  const props={text:text,font:'Arial',size:48,bold:false,italic:false,caps:false,color:'#000000',align:'left',lh:1.15,stroke:'#000000',sw:0,shadow:0,shadowColor:'#000000'};
  const sc=Math.hypot(xf[0],xf[1])||1,rot=Math.atan2(xf[1],xf[0]);
  if(eng&&eng.EngineDict){
    const ed=eng.EngineDict,res=eng.ResourceDict||eng.DocumentResources||{};
    try{
      const sr=ed.StyleRun,ra=sr.RunArray||[],rl=sr.RunLengthArray||[];
      let bi=0,bl=-1;rl.forEach((n,i)=>{if(n>bl){bl=n;bi=i;}});
      const sd=(ra[bi]&&ra[bi].StyleSheet&&ra[bi].StyleSheet.StyleSheetData)||{};
      const fs=res.FontSet&&res.FontSet[sd.Font||0];const fname=fs&&fs.Name||'';
      props.psdFont=fname;props.font=psdFontFamily(fname)||'Arial';
      props.bold=!!sd.FauxBold||psdIsBold(fname);props.italic=!!sd.FauxItalic||psdIsItalic(fname);
      props.size=Math.max(4,Math.round((sd.FontSize||12)*sc*10)/10);
      props.caps=sd.FontCaps===2;
      const col=sd.FillColor&&sd.FillColor.Values;
      if(col&&col.length>=4)props.color=rgbHex(col[1]*255,col[2]*255,col[3]*255);
      else if(col&&col.length===1)props.color=rgbHex(col[0]*255,col[0]*255,col[0]*255);
      if(sd.AutoLeading===false&&sd.Leading&&sd.FontSize)props.lh=clamp(sd.Leading/sd.FontSize,0.6,3);
      const pa=ed.ParagraphRun&&ed.ParagraphRun.RunArray&&ed.ParagraphRun.RunArray[0];
      const j=pa&&pa.ParagraphSheet&&pa.ParagraphSheet.Properties&&pa.ParagraphSheet.Properties.Justification;
      props.align=j===1||j===4?'right':j===2||j===5?'center':'left';
    }catch(err){}
    // strip the trailing paragraph mark the engine adds
    if(typeof ed.Editor&&ed.Editor&&typeof ed.Editor.Text==='string'&&!text)props.text=ed.Editor.Text.replace(/\r/g,'\n').replace(/\n$/,'');
  }
  return {props,rot,xf};
}
function engineDataFor(p,fontPS){
  const txt=String(p.text||'').replace(/\r\n?|\n/g,'\r')+'\r',len=txt.length;
  const col=hexRgb(p.color||'#000000'),just=p.align==='right'?1:p.align==='center'?2:0;
  const size=new Fl(p.size||48),lead=new Fl((p.size||48)*(p.lh||1.15));
  const sheet={Font:0,FontSize:size,FauxBold:false,FauxItalic:false,AutoLeading:false,Leading:lead,HorizontalScale:new Fl(1),VerticalScale:new Fl(1),Tracking:0,AutoKerning:true,BaselineShift:new Fl(0),FontCaps:p.caps?2:0,FontBaseline:0,Underline:false,Strikethrough:false,Ligatures:true,DLigatures:false,BaselineDirection:2,Tsume:new Fl(0),StyleRunAlignment:2,Language:0,NoBreak:false,FillColor:{Type:1,Values:[new Fl(1),new Fl(col[0]/255),new Fl(col[1]/255),new Fl(col[2]/255)]},StrokeColor:{Type:1,Values:[new Fl(1),new Fl(0),new Fl(0),new Fl(0)]},FillFlag:true,StrokeFlag:false,FillFirst:true,YUnderline:1,OutlineWidth:new Fl(1),CharacterDirection:0,HindiNumbers:false,Kashida:1,DiacriticPos:2};
  const para={Justification:just,FirstLineIndent:new Fl(0),StartIndent:new Fl(0),EndIndent:new Fl(0),SpaceBefore:new Fl(0),SpaceAfter:new Fl(0),AutoHyphenate:true,HyphenatedWordSize:6,PreHyphen:2,PostHyphen:2,ConsecutiveHyphens:8,Zone:new Fl(36),WordSpacing:[new Fl(.8),new Fl(1),new Fl(1.33)],LetterSpacing:[new Fl(0),new Fl(0),new Fl(0)],GlyphSpacing:[new Fl(1),new Fl(1),new Fl(1)],AutoLeading:new Fl(1.2),LeadingType:0,Hanging:false,Burasagari:false,KinsokuOrder:0,EveryLineComposer:false};
  const fontSet=[{Name:fontPS,Script:0,FontType:1,Synthetic:0}];
  const sets={
    KinsokuSet:[{Name:'PhotoshopKinsokuHard',NoStart:'、。，．・：；？！ー―’”）〕］｝〉》」』】ヽヾゝゞ々ぁぃぅぇぉっゃゅょゎァィゥェォッャュョヮヵヶ゛゜?!)]},.　',NoEnd:'‘“（〔［｛〈《「『【([{',Keep:'―‥',Hanging:'、。.,'},{Name:'PhotoshopKinsokuSoft',NoStart:'、。，．・：；？！’”）〕］｝〉》」』】ヽヾゝゞ々',NoEnd:'‘“（〔［｛〈《「『【',Keep:'―‥',Hanging:'、。.,'}],
    MojiKumiSet:[{InternalName:'Photoshop6MojiKumiSet1'},{InternalName:'Photoshop6MojiKumiSet2'},{InternalName:'Photoshop6MojiKumiSet3'},{InternalName:'Photoshop6MojiKumiSet4'}],
    TheNormalStyleSheet:0,TheNormalParagraphSheet:0,
    ParagraphSheetSet:[{Name:'Normal RGB',DefaultStyleSheet:0,Properties:para}],
    StyleSheetSet:[{Name:'Normal RGB',StyleSheetData:sheet}],
    FontSet:fontSet,SuperscriptSize:new Fl(.583),SuperscriptPosition:new Fl(.333),SubscriptSize:new Fl(.583),SubscriptPosition:new Fl(.333),SmallCapSize:new Fl(.7)
  };
  const adj={Axis:[new Fl(1),new Fl(0),new Fl(1)],XY:[new Fl(0),new Fl(0)]};
  return engineSerialize({
    EngineDict:{
      Editor:{Text:txt},
      ParagraphRun:{DefaultRunData:{ParagraphSheet:{DefaultStyleSheet:0,Properties:{}},Adjustments:adj},RunArray:[{ParagraphSheet:{DefaultStyleSheet:0,Properties:para},Adjustments:adj}],RunLengthArray:[len],IsJoinable:1},
      StyleRun:{DefaultRunData:{StyleSheet:{StyleSheetData:{}}},RunArray:[{StyleSheet:{StyleSheetData:sheet}}],RunLengthArray:[len],IsJoinable:2},
      GridInfo:{GridIsOn:false,ShowGrid:false,GridSize:new Fl(18),GridLeading:new Fl(22),GridColor:{Type:1,Values:[new Fl(0),new Fl(0),new Fl(0),new Fl(1)]},GridLeadingFillColor:{Type:1,Values:[new Fl(0),new Fl(0),new Fl(0),new Fl(1)]},AlignLineHeightToGridFlags:false},
      AntiAlias:4,UseFractionalGlyphWidths:true,
      Rendered:{Version:1,Shapes:{WritingDirection:0,Children:[{ShapeType:0,Procession:0,Lines:{WritingDirection:0,Children:[]},Cookie:{Photoshop:{ShapeType:0,PointBase:[new Fl(0),new Fl(0)],Base:{ShapeType:0,TransformPoint0:[new Fl(1),new Fl(0)],TransformPoint1:[new Fl(0),new Fl(1)],TransformPoint2:[new Fl(0),new Fl(0)]}}}}]}}
    },
    ResourceDict:sets,
    DocumentResources:sets
  });
}
/* the TySh block bytes for a text layer. info={tx,ty,s,r,bounds:[l,t,r,b] (local)} */
function tyShBlock(p,info){
  const w=new PW(),fontPS=psFontName(p),s=info.s,r=info.r;
  w.u16(1);[s*Math.cos(r),s*Math.sin(r),-s*Math.sin(r),s*Math.cos(r),info.tx,info.ty].forEach(v=>w.f64(v));
  w.u16(50);w.u32(16);
  const b=info.bounds,bo=n=>dO(n,[['Left',dU('#Pxl',b[0])],['Top ',dU('#Pxl',b[1])],['Rght',dU('#Pxl',b[2])],['Btom',dU('#Pxl',b[3])]]);
  w.desc('TxLr',[['Txt ',dT(String(p.text||'').replace(/\r\n?|\n/g,'\r'))],['textGridding',dE('textGridding','None')],['Ornt',dE('Ornt','Hrzn')],['AntA',dE('Annt','antiAliasSharp')],['bounds',bo('bounds')],['boundingBox',bo('boundingBox')],['TextIndex',dL(0)],['EngineData',dR(engineDataFor(p,fontPS))]]);
  w.u16(1);w.u32(16);
  w.desc('warp',[['warpStyle',dE('warpStyle','warpNone')],['warpValue',dD(0)],['warpPerspective',dD(0)],['warpPerspectiveOther',dD(0)],['warpRotate',dE('Ornt','Hrzn')]]);
  b.forEach(v=>w.f64(v));
  return Uint8Array.from(w.a);
}

/* ---------- layer styles <-> lfx2 ---------- */
const BLN_IN={Nrml:'source-over',Dslv:'source-over',Drkn:'darken',Mltp:'multiply',CBrn:'color-burn',linearBurn:'multiply',Lghtn:'lighten',Scrn:'screen',CDdg:'color-dodge',linearDodge:'lighter',Ovrl:'overlay',SftL:'soft-light',HrdL:'hard-light',vividLight:'hard-light',linearLight:'hard-light',pinLight:'hard-light',hardMix:'hard-light',Dfrn:'difference',Xclu:'exclusion','H   ':'hue',Strt:'saturation','Clr ':'color',Lmns:'luminosity'};
const BLN_OUT={};Object.keys(BLN_IN).forEach(k=>{if(!BLN_OUT[BLN_IN[k]]&&k!=='Dslv'&&k!=='linearBurn'&&k!=='vividLight'&&k!=='linearLight'&&k!=='pinLight'&&k!=='hardMix')BLN_OUT[BLN_IN[k]]=k;});
const bIn=k=>BLN_IN[k]||'source-over',bOut=b=>BLN_OUT[b]||'Nrml';
const rgbOf=d=>d?rgbHex(d['Rd  ']||0,d['Grn ']||0,d['Bl  ']||0):'#000000';
const GRADT_IN={'Lnr ':'linear',Rdl:'radial',Angl:'angle',Rflc:'reflected',Dmnd:'diamond'},GRADT_OUT={linear:'Lnr ',radial:'Rdl ',angle:'Angl',reflected:'Rflc',diamond:'Dmnd'};
function gradFromDesc(g,Gradient){
  const cs=[],os=[];
  (g.Clrs||[]).forEach(s=>cs.push({p:clamp((s.Lctn||0)/4096,0,1),c:rgbOf(s['Clr ']),m:clamp((s.Mdpn==null?50:s.Mdpn)/100,.05,.95)}));
  (g.Trns||[]).forEach(s=>os.push({p:clamp((s.Lctn||0)/4096,0,1),a:clamp((s.Opct==null?100:s.Opct)/100,0,1),m:clamp((s.Mdpn==null?50:s.Mdpn)/100,.05,.95)}));
  if(cs.length<2)return null;if(os.length<2){os.length=0;os.push({p:0,a:1,m:.5},{p:1,a:1,m:.5});}
  return {name:g['Nm  ']||'Gradient',type:'solid',smooth:100,rough:50,seed:1,cs,os};
}
function fxFromDesc(d){
  const fx={},sc=(d['Scl ']==null?100:d['Scl '])/100;
  const g=k=>d[k]&&d[k].enab!==false?d[k]:null;
  let o=g('DrSh');if(o)fx.shadow={on:true,color:rgbOf(o['Clr ']),op:clamp((o.Opct==null?75:o.Opct)/100,0,1),blend:bIn(o['Md  ']),angle:o.lagl==null?120:o.lagl,dist:(o.Dstn==null?5:o.Dstn)*sc,spread:o.Ckmt||0,size:(o.blur==null?5:o.blur)*sc,noise:o.Nose||0,knock:o.layerConceals!==false};
  o=g('IrSh');if(o)fx.ishadow={on:true,color:rgbOf(o['Clr ']),op:clamp((o.Opct==null?75:o.Opct)/100,0,1),blend:bIn(o['Md  ']),angle:o.lagl==null?120:o.lagl,dist:(o.Dstn==null?5:o.Dstn)*sc,choke:o.Ckmt||0,size:(o.blur==null?5:o.blur)*sc,noise:o.Nose||0};
  o=g('OrGl');if(o)fx.glow={on:true,color:rgbOf(o['Clr ']),op:clamp((o.Opct==null?75:o.Opct)/100,0,1),blend:bIn(o['Md  ']),size:(o.blur==null?5:o.blur)*sc,spread:o.Ckmt||0,noise:o.Nose||0};
  o=g('IrGl');if(o)fx.iglow={on:true,color:rgbOf(o['Clr ']),op:clamp((o.Opct==null?75:o.Opct)/100,0,1),blend:bIn(o['Md  ']),size:(o.blur==null?5:o.blur)*sc,choke:o.Ckmt||0,source:o.glwS==='SrcC'?'center':'edge',noise:o.Nose||0};
  o=g('ebbl');if(o)fx.bevel={on:true,style:o.bvlS==='OtrB'?'outer':o.bvlS==='Embs'?'emboss':o.bvlS==='PlEb'?'pillow':'inner',technique:o.bvlT==='SfBL'?'smooth':'chisel',depth:o.srgR==null?100:o.srgR,dir:o.bvlD==='Out '?'down':'up',size:(o.blur==null?5:o.blur)*sc,soften:(o.Sftn||0)*sc,angle:o.lagl==null?120:o.lagl,altitude:o.Lald==null?30:o.Lald,hiColor:rgbOf(o.hglC),hiOp:clamp((o.hglO==null?75:o.hglO)/100,0,1),hiBlend:bIn(o.hglM),shColor:rgbOf(o.sdwC),shOp:clamp((o.sdwO==null?75:o.sdwO)/100,0,1),shBlend:bIn(o.sdwM)};
  o=g('ChFX');if(o)fx.satin={on:true,color:rgbOf(o['Clr ']),op:clamp((o.Opct==null?50:o.Opct)/100,0,1),blend:bIn(o['Md  ']),angle:o.lagl==null?19:o.lagl,dist:(o.Dstn==null?11:o.Dstn)*sc,size:(o.blur==null?14:o.blur)*sc,invert:o.Invr!==false};
  o=g('SoFi');if(o)fx.overlay={on:true,color:rgbOf(o['Clr ']),op:clamp((o.Opct==null?100:o.Opct)/100,0,1),blend:bIn(o['Md  '])};
  o=g('GrFl');if(o){const gm=o.Grad?gradFromDesc(o.Grad):null;if(gm){fx.grad={on:true,stops:gFlatten(gm),model:gm,style:GRADT_IN[o.Type]||'linear',angle:o.Angl==null?90:o.Angl,scale:o['Scl ']==null?100:o['Scl '],reverse:!!o.Rvrs,op:clamp((o.Opct==null?100:o.Opct)/100,0,1),blend:bIn(o['Md  '])};}}
  o=g('FrFX');if(o){fx.stroke={on:true,color:rgbOf(o['Clr ']),w:(o.Sz==null?3:o.Sz)*sc,pos:o.Styl==='InsF'?'inside':o.Styl==='CtrF'?'center':'outside',op:clamp((o.Opct==null?100:o.Opct)/100,0,1),blend:bIn(o['Md  ']),fillType:'color'};
    if(o.PntT==='GrFl'&&o.Grad){const gm=gradFromDesc(o.Grad);if(gm){fx.stroke.fillType='gradient';fx.stroke.stops=gFlatten(gm);fx.stroke.style=GRADT_IN[o.Type]||'linear';fx.stroke.angle=o.Angl==null?90:o.Angl;fx.stroke.scale=o['Scl ']==null?100:o['Scl '];}}}
  return Object.keys(fx).length?fx:null;
}
const rgbD=hex=>{const c=hexRgb(hex||'#000000');return dO('RGBC',[['Rd  ',dD(c[0])],['Grn ',dD(c[1])],['Bl  ',dD(c[2])]]);};
const cpt=(h,v)=>dO('CrPt',[['Hrzn',dD(h)],['Vrtc',dD(v)]]);
const contourD=()=>dO('ShpC',[['Nm  ',dT('Linear')],['Crv ',dV([cpt(0,0),cpt(255,255)])]]);
const dPrc=v=>dU('#Prc',v),dPx=v=>dU('#Pxl',v),dAng=v=>dU('#Ang',v);
function gradDescOf(model){
  const cs=[...model.cs].sort((a,b)=>a.p-b.p),os=[...model.os].sort((a,b)=>a.p-b.p);
  return dO('Grdn',[['Nm  ',dT(model.name||'Custom')],['GrdF',dE('GrdF','CstS')],['Intr',dD(4096)],
    ['Clrs',dV(cs.map(s=>dO('Clrt',[['Clr ',rgbD(gcol(s))],['Type',dE('Clry','UsrS')],['Lctn',dL(Math.round(s.p*4096))],['Mdpn',dL(Math.round((s.m==null?.5:s.m)*100))]])))],
    ['Trns',dV(os.map(s=>dO('TrnS',[['Opct',dPrc(Math.round(s.a*100))],['Lctn',dL(Math.round(s.p*4096))],['Mdpn',dL(Math.round((s.m==null?.5:s.m)*100))]])))]]);
}
function lfx2Block(fx){
  const items=[['Scl ',dPrc(100)],['masterFXSwitch',dB(true)]],on=k=>fx[k]&&fx[k].on;
  const common=(o,more)=>[['enab',dB(true)],['present',dB(true)],['showInDialog',dB(true)]].concat(more);
  let o;
  if(on('shadow')){o=fx.shadow;items.push(['DrSh',dO('DrSh',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Clr ',rgbD(o.color)],['Opct',dPrc(Math.round((o.op==null?.6:o.op)*100))],['uglg',dB(false)],['lagl',dAng(o.angle==null?120:o.angle)],['Dstn',dPx(o.dist||0)],['Ckmt',dPx(o.spread||0)],['blur',dPx(o.size||0)],['Nose',dPrc(o.noise||0)],['AntA',dB(false)],['TrnS',contourD()],['layerConceals',dB(o.knock!==false)]]))]);}
  if(on('ishadow')){o=fx.ishadow;items.push(['IrSh',dO('IrSh',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Clr ',rgbD(o.color)],['Opct',dPrc(Math.round((o.op==null?.7:o.op)*100))],['uglg',dB(false)],['lagl',dAng(o.angle==null?120:o.angle)],['Dstn',dPx(o.dist||0)],['Ckmt',dPx(o.choke||0)],['blur',dPx(o.size||0)],['Nose',dPrc(o.noise||0)],['AntA',dB(false)],['TrnS',contourD()]]))]);}
  if(on('glow')){o=fx.glow;items.push(['OrGl',dO('OrGl',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Clr ',rgbD(o.color)],['Opct',dPrc(Math.round((o.op==null?.75:o.op)*100))],['GlwT',dE('BETE','SfBL')],['Ckmt',dPx(o.spread||0)],['blur',dPx(o.size||0)],['Nose',dPrc(o.noise||0)],['ShdN',dPrc(0)],['AntA',dB(false)],['Inpr',dPrc(50)],['TrnS',contourD()]]))]);}
  if(on('iglow')){o=fx.iglow;items.push(['IrGl',dO('IrGl',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Clr ',rgbD(o.color)],['Opct',dPrc(Math.round((o.op==null?.75:o.op)*100))],['GlwT',dE('BETE','SfBL')],['glwS',dE('IGSr',o.source==='center'?'SrcC':'SrcE')],['Ckmt',dPx(o.choke||0)],['blur',dPx(o.size||0)],['Nose',dPrc(o.noise||0)],['ShdN',dPrc(0)],['AntA',dB(false)],['Inpr',dPrc(50)],['TrnS',contourD()]]))]);}
  if(on('bevel')){o=fx.bevel;items.push(['ebbl',dO('ebbl',common(o,[['hglM',dE('BlnM',bOut(o.hiBlend))],['hglC',rgbD(o.hiColor)],['hglO',dPrc(Math.round((o.hiOp==null?.75:o.hiOp)*100))],['sdwM',dE('BlnM',bOut(o.shBlend))],['sdwC',rgbD(o.shColor)],['sdwO',dPrc(Math.round((o.shOp==null?.75:o.shOp)*100))],['bvlT',dE('bvlT',o.technique==='chisel'?'PrBL':'SfBL')],['bvlS',dE('BESl',({outer:'OtrB',emboss:'Embs',pillow:'PlEb'})[o.style]||'InrB')],['uglg',dB(false)],['lagl',dAng(o.angle==null?120:o.angle)],['Lald',dAng(o.altitude==null?30:o.altitude)],['srgR',dPrc(o.depth==null?100:o.depth)],['blur',dPx(o.size||0)],['bvlD',dE('BESs',o.dir==='down'?'Out ':'In  ')],['TrnS',contourD()],['antialiasGloss',dB(false)],['Sftn',dPx(o.soften||0)],['useShape',dB(false)],['useTexture',dB(false)]]))]);}
  if(on('satin')){o=fx.satin;items.push(['ChFX',dO('ChFX',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Clr ',rgbD(o.color)],['AntA',dB(true)],['Invr',dB(o.invert!==false)],['Opct',dPrc(Math.round((o.op==null?.5:o.op)*100))],['lagl',dAng(o.angle==null?19:o.angle)],['Dstn',dPx(o.dist||0)],['blur',dPx(o.size||0)],['MpgS',contourD()]]))]);}
  if(on('overlay')){o=fx.overlay;items.push(['SoFi',dO('SoFi',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Clr ',rgbD(o.color)],['Opct',dPrc(Math.round((o.op==null?1:o.op)*100))]]))]);}
  if(on('grad')){o=fx.grad;const gm=fxToGrad(o);items.push(['GrFl',dO('GrFl',common(o,[['Md  ',dE('BlnM',bOut(o.blend))],['Opct',dPrc(Math.round((o.op==null?1:o.op)*100))],['Grad',gradDescOf(gm)],['Angl',dAng(o.angle==null?90:o.angle)],['Type',dE('GrdT',GRADT_OUT[o.style]||'Lnr ')],['Rvrs',dB(!!o.reverse)],['Dthr',dB(false)],['Algn',dB(true)],['Scl ',dPrc(o.scale==null?100:o.scale)],['Ofst',dO('Pnt ',[['Hrzn',dPrc(0)],['Vrtc',dPrc(0)]])]]))]);}
  if(on('stroke')){o=fx.stroke;items.push(['FrFX',dO('FrFX',common(o,[['Styl',dE('FStl',o.pos==='inside'?'InsF':o.pos==='center'?'CtrF':'OutF')],['PntT',dE('FrFl','SClr')],['Md  ',dE('BlnM',bOut(o.blend))],['Opct',dPrc(Math.round((o.op==null?1:o.op)*100))],['Sz  ',dPx(o.w||0)],['Clr ',rgbD(o.color)]]))]);}
  const w=new PW();w.u32(0);w.u32(16);w.desc('null',items);
  return Uint8Array.from(w.a);
}
const hasPsdFx=fx=>!!(fx&&['shadow','ishadow','glow','iglow','bevel','satin','overlay','grad','stroke'].some(k=>fx[k]&&fx[k].on));

/* ---------- reader ---------- */
const PSD_X={diss:'source-over',lbrn:'multiply',lddg:'lighter',vLit:'hard-light',lLit:'hard-light',pLit:'hard-light',hMix:'hard-light','pass':'source-over'};
readPSD=async function(ab){
  const PSD_IN2=Object.assign({},PSD_IN,PSD_X);
  const u8=new Uint8Array(ab),dv=new DataView(ab);let p=0;
  const u16=()=>{const v=dv.getUint16(p);p+=2;return v;},i16=()=>{const v=dv.getInt16(p);p+=2;return v;};
  const u32=()=>{const v=dv.getUint32(p);p+=4;return v;},i32=()=>{const v=dv.getInt32(p);p+=4;return v;};
  const str4=()=>{const s=String.fromCharCode(u8[p],u8[p+1],u8[p+2],u8[p+3]);p+=4;return s;};
  if(u8.length<30||str4()!=='8BPS')throw new Error('notpsd');
  const ver=u16();if(ver===2)throw new Error('psb');if(ver!==1)throw new Error('notpsd');
  p+=6;const chans=u16(),H=u32(),W=u32(),depth=u16(),mode=u16();
  if(mode!==3&&mode!==1)throw new Error('mode');
  if(depth!==8&&depth!==16)throw new Error('depth');
  {const a=u32();p+=a;}
  let dpi=72;
  {const irLen=u32(),irEnd=p+irLen;
    while(p+12<=irEnd){
      if(str4()!=='8BIM')break;const id=u16();const nl=u8[p];p+=1+nl;if((1+nl)%2)p++;const len=u32();
      if(id===0x03ed&&len>=4){const h=dv.getUint32(p)/65536;if(h>=1&&h<=2400)dpi=Math.round(h);}
      p+=len+(len%2);
    }
    p=irEnd;}
  const lmLen=u32(),lmEnd=p+lmLen,recs=[];let skipped=0;
  if(lmLen>0){
    const liLen=u32();
    if(liLen>0){
      const cnt=Math.abs(i16());
      for(let i=0;i<cnt;i++){
        const r={top:i32(),left:i32(),bottom:i32(),right:i32()},nch=u16();r.ch=[];
        for(let k=0;k<nch;k++)r.ch.push({id:i16(),len:u32()});
        str4();r.bm=str4();r.op=u8[p++]/255;r.clip=u8[p++];const fl=u8[p++];r.visible=!(fl&2);p++;
        const exLen=u32(),exEnd=p+exLen;
        const mLen=u32(),mStart=p;
        if(mLen>=20){r.mask={top:i32(),left:i32(),bottom:i32(),right:i32(),def:u8[p],flags:u8[p+1]};}
        p=mStart+mLen;
        {const bl=u32();p+=bl;}
        const nl=u8[p];let nm='';for(let k=0;k<nl;k++)nm+=String.fromCharCode(u8[p+1+k]);r.name=nm;p+=1+nl;p+=(4-((1+nl)%4))%4;
        r.sect=0;
        while(p+12<=exEnd){
          const sig=str4(),key=str4(),len=u32(),ds=p;void sig;
          try{
            if(key==='luni'){const n=dv.getUint32(ds);let s='';for(let k=0;k<n;k++)s+=String.fromCharCode(dv.getUint16(ds+4+k*2));r.name=s.replace(/\0+$/,'');}
            else if(key==='lsct'||key==='lsdk')r.sect=dv.getUint32(ds);
            else if(key==='iOpa')r.fill=u8[ds]/255;
            else if(key==='TySh'){r.isText=true;r.tysh=u8.slice(ds,ds+len);}
            else if(key==='lfx2'){const c=psdCur(u8.slice(ds,ds+len),8);r.fxd=readDesc(c);}
          }catch(err){}
          p=ds+len;
        }
        p=exEnd;recs.push(r);
      }
      for(const r of recs){
        const w=r.right-r.left,h=r.bottom-r.top,planes={};
        for(const c of r.ch){
          const start=p+2,comp=dv.getUint16(p),len=c.len-2;
          if(c.id>=-1&&c.id<=2&&w>0&&h>0)planes[c.id]=await decodePlane(u8,start,len,comp,w,h,depth);
          else if(c.id===-2&&r.mask){const mw=r.mask.right-r.mask.left,mh=r.mask.bottom-r.mask.top;if(mw>0&&mh>0)planes[-2]=await decodePlane(u8,start,len,comp,mw,mh,depth);}
          p+=c.len;
        }
        r.planes=planes;
      }
    }
  }
  p=lmEnd;
  const layers=[],stack=[];
  for(let i=recs.length-1;i>=0;i--){
    const r=recs[i];
    if(r.sect===3){stack.pop();continue;}
    if(r.sect===1||r.sect===2){stack.push({vis:r.visible,op:r.op});continue;}
    const w=r.right-r.left,h=r.bottom-r.top;
    if(w<=0||h<=0||!r.planes||!r.planes[0]){skipped++;continue;}
    const cv=mkCanvas(w,h),ctx=cctx(cv),id=ctx.createImageData(w,h),d=id.data,P=r.planes;
    const R=P[0],G=mode===1?P[0]:(P[1]||P[0]),B=mode===1?P[0]:(P[2]||P[0]),A=P[-1];
    for(let k=0;k<w*h;k++){const o=k*4;d[o]=R[k];d[o+1]=G[k];d[o+2]=B[k];d[o+3]=A?A[k]:255;}
    ctx.putImageData(id,0,0);
    let maskCv=null;
    if(r.mask&&P[-2]&&!(r.mask.flags&2)){
      const mk=r.mask,mw=mk.right-mk.left,mh=mk.bottom-mk.top;
      maskCv=mkCanvas(w,h);const mx=cctx(maskCv),mid=mx.createImageData(w,h),md=mid.data;
      for(let y=0;y<h;y++)for(let x=0;x<w;x++){
        const ax=r.left+x-mk.left,ay=r.top+y-mk.top;
        let mv=(ax>=0&&ay>=0&&ax<mw&&ay<mh)?P[-2][ay*mw+ax]:mk.def;
        if(mk.flags&4)mv=255-mv;
        const o=(y*w+x)*4;md[o]=md[o+1]=md[o+2]=255;md[o+3]=mv;
      }
      mx.putImageData(mid,0,0);
    }
    const L={name:r.name||'Layer',x:r.left+w/2,y:r.top+h/2,canvas:cv,mask:maskCv,
      opacity:r.op*stack.reduce((a,g)=>a*g.op,1),visible:r.visible&&stack.every(g=>g.vis),blend:PSD_IN2[r.bm]||'source-over',text:!!r.isText,fill:r.fill==null?1:r.fill,clip:r.clip===1,fx:null,tp:null};
    if(r.fxd){try{L.fx=fxFromDesc(r.fxd);}catch(err){}}
    if(r.tysh){try{L.tp=textFromTySh(r.tysh);}catch(err){L.tp=null;}}
    layers.push(L);
  }
  layers.reverse();
  if(!layers.length){
    const comp=dv.getUint16(p);p+=2;const bps=depth/8,n=W*H,pl=[];
    if(comp===0){for(let c=0;c<chans;c++){const raw=u8.subarray(p+c*n*bps,p+(c+1)*n*bps);pl.push(bps===1?raw:raw.filter((v,i2)=>i2%2===0));}}
    else if(comp===1){
      const counts=new Uint16Array(chans*H);for(let i=0;i<chans*H;i++)counts[i]=dv.getUint16(p+i*2);
      let q=p+chans*H*2;const rb=W*bps;
      for(let c=0;c<chans;c++){const raw=new Uint8Array(rb*H);q=unpackRows(u8,q,counts,c*H,H,rb,raw,0);pl.push(bps===1?raw:raw.filter((v,i2)=>i2%2===0));}
    }else throw new Error('compression');
    const cv=mkCanvas(W,H),ctx=cctx(cv),id=ctx.createImageData(W,H),d=id.data;
    for(let k=0;k<n;k++){const o=k*4;d[o]=pl[0][k];d[o+1]=mode===1?pl[0][k]:pl[1][k];d[o+2]=mode===1?pl[0][k]:pl[2][k];d[o+3]=(mode===3&&chans>=4)?pl[3][k]:255;}
    ctx.putImageData(id,0,0);
    layers.push({name:'Background',x:W/2,y:H/2,canvas:cv,mask:null,opacity:1,visible:true,blend:'source-over',text:false,fill:1,clip:false,fx:null,tp:null});
  }
  return {w:W,h:H,dpi,layers,skipped};
};
openPSD=async function(ab,fname){
  try{
    const r=await readPSD(ab);
    if(r.w*r.h>90e6){toast('That file is too large for this device');return;}
    startDoc((fname||'PSD').replace(/\.psd$/i,''),r.w,r.h,r.dpi||72);
    doc.srcFmt='psd';
    let nText=0,nFx=0;
    for(const L of r.layers){
      let l;
      if(L.tp&&L.tp.props&&L.tp.props.text){
        const tp=L.tp.props;
        l=addLayer({name:L.name,type:'text',w:10,h:10,x:L.x,y:L.y,select:false,props:tp});
        renderText(l);l.x=L.x;l.y=L.y;l.r=L.tp.rot||0;nText++;
      }else{
        l=addLayer({name:L.name,type:'image',w:L.canvas.width,h:L.canvas.height,x:L.x,y:L.y,select:false});
        cctx(l.canvas).drawImage(L.canvas,0,0);
      }
      l.opacity=L.opacity;l.blend=L.blend;l.visible=L.visible;l.fillOp=L.fill;l.clip=!!L.clip;
      if(L.mask&&l.type==='image')l.mask=L.mask;
      if(L.fx){l.fx=L.fx;nFx++;l.fxv=1;}
      touch(l);
    }
    finishDoc();setTool('move');setTab('layers');
    const t=[];if(nText)t.push(nText+' editable text layer'+(nText===1?'':'s'));if(nFx)t.push(nFx+' with layer styles');
    toast('Opened '+r.layers.length+' layer'+(r.layers.length===1?'':'s')+(t.length?' ('+t.join(', ')+')':'')+(r.skipped?'. '+r.skipped+' adjustment or empty layers were skipped.':''));
  }catch(err){
    console.error(err);
    const m=err&&err.message;
    toast(m==='psb'?'Large PSB files are not supported yet':m==='mode'?'Only RGB and grayscale PSD files are supported yet':m==='depth'?'Only 8-bit and 16-bit PSD files are supported yet':m==='notpsd'?'That does not look like a PSD file':'This PSD could not be opened');
  }
};

/* ---------- writer ---------- */
function layerRawCanvas(l){
  const c=mkCanvas(doc.w,doc.h);
  drawLayerEx(cctx(c),Object.assign({},l,{opacity:1,blend:'source-over',fx:null,mask:null,fillOp:1,clip:false,_mc:null,_fc:null}),{nofx:true});
  return c;
}
function layerMaskPlane(l,x0,y0,w,h){
  const c=mkCanvas(doc.w,doc.h),x=cctx(c);
  x.save();x.translate(l.x,l.y);x.rotate(l.r);x.scale(l.s,l.s);x.drawImage(l.mask,-l.canvas.width/2,-l.canvas.height/2,l.canvas.width,l.canvas.height);x.restore();
  const d=x.getImageData(x0,y0,w,h).data,pl=new Uint8Array(w*h);
  for(let i=0;i<w*h;i++)pl[i]=d[i*4+3];
  return pl;
}
function psdBlock(bw,key,bytes){
  const pad=(4-bytes.length%4)%4;
  bw.str('8BIM');bw.str(key);bw.u32(bytes.length+pad);bw.bytes(bytes);for(let i=0;i<pad;i++)bw.u8(0);
}
buildPSD=function(o){
  o=o||{};const wantText=o.text!==false,wantFx=o.fx!==false;
  const W=doc.w,H=doc.h,bw=new BW(1<<22);
  const lay=doc.layers.filter(l=>l.type!=='adjust');
  const skippedAdj=doc.layers.length-lay.length;
  bw.str('8BPS');bw.u16(1);for(let i=0;i<6;i++)bw.u8(0);bw.u16(3);bw.u32(H);bw.u32(W);bw.u16(8);bw.u16(3);
  bw.u32(0); // colour mode data
  {const dpi=doc.dpi||72;bw.u32(28);bw.str('8BIM');bw.u16(0x03ed);bw.u16(0);bw.u32(16);bw.u32(dpi*65536);bw.u16(1);bw.u16(1);bw.u32(dpi*65536);bw.u16(1);bw.u16(1);}
  const lmPos=bw.p;bw.u32(0);
  const liPos=bw.p;bw.u32(0);
  bw.i16(lay.length);
  const items=lay.map((l,idx)=>{
    const raw=layerRawCanvas(l),d=cctx(raw).getImageData(0,0,W,H).data;
    let x0=W,y0=H,x1=-1,y1=-1;
    for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(d[(y*W+x)*4+3]>0){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
    const it={l,idx,top:0,left:0,bottom:0,right:0,chans:[],ids:[-1,0,1,2],local:null};
    if(x1<0){it.chans=[0,1,2,3].map(()=>new Uint8Array([0,0]));return it;}
    const w=x1-x0+1,h=y1-y0+1,pl=[0,1,2,3].map(()=>new Uint8Array(w*h));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const q=((y+y0)*W+x+x0)*4,k=y*w+x;pl[0][k]=d[q+3];pl[1][k]=d[q];pl[2][k]=d[q+1];pl[3][k]=d[q+2];}
    it.top=y0;it.left=x0;it.bottom=y1+1;it.right=x1+1;it.chans=pl.map(q=>rleChannel(q,w,h));
    if(l.mask){it.ids=[-1,0,1,2,-2];it.chans.push(rleChannel(layerMaskPlane(l,x0,y0,w,h),w,h));it.hasMask=true;}
    return it;
  });
  for(const it of items){
    const l=it.l;
    bw.i32(it.top);bw.i32(it.left);bw.i32(it.bottom);bw.i32(it.right);bw.u16(it.ids.length);
    it.ids.forEach((id,k)=>{bw.i16(id);bw.u32(it.chans[k].length);});
    bw.str('8BIM');bw.str(PSD_OUT[l.blend]||'norm');
    bw.u8(Math.round(clamp(l.opacity,0,1)*255));bw.u8(l.clip?1:0);bw.u8(l.visible?0:2);bw.u8(0);
    const ex=new BW(1<<12);
    if(it.hasMask){ex.u32(20);ex.i32(it.top);ex.i32(it.left);ex.i32(it.bottom);ex.i32(it.right);ex.u8(255);ex.u8(0);ex.u16(0);}else ex.u32(0);
    ex.u32(0); // blending ranges
    const nm=(l.name||'Layer').slice(0,120),asc=nm.replace(/[^\x20-\x7e]/g,'_').slice(0,31);
    const pasLen=Math.ceil((1+asc.length)/4)*4;
    ex.u8(asc.length);ex.str(asc);for(let k=1+asc.length;k<pasLen;k++)ex.u8(0);
    {const u=new PW();u.u32(nm.length);for(let k=0;k<nm.length;k++)u.u16(nm.charCodeAt(k));u.u16(0);psdBlock(ex,'luni',Uint8Array.from(u.a));}
    {const u=new PW();u.u32(it.idx+1);psdBlock(ex,'lyid',Uint8Array.from(u.a));}
    if(l.type==='text'&&l.props&&wantText){
      try{
        const p=l.props,cv=l.canvas,bb=alphaBBox(cv)||{x:0,y:0,w:cv.width,h:cv.height};
        const lw=bb.w,lh=bb.h,cx=bb.x+bb.w/2-cv.width/2,cy=bb.y+bb.h/2-cv.height/2; // content centre in local units, relative to the layer centre
        const ox=(p.align==='right'?cx+lw/2:p.align==='center'?cx:cx-lw/2),oy=cy-lh/2+(p.size||48)*0.8;
        const s=l.s||1,r=l.r||0,cs=Math.cos(r),sn=Math.sin(r);
        const tx=l.x+s*(cs*ox-sn*oy),ty=l.y+s*(sn*ox+cs*oy);
        const bounds=[cx-lw/2-ox,cy-lh/2-oy,cx+lw/2-ox,cy+lh/2-oy];
        psdBlock(ex,'TySh',tyShBlock(p,{tx,ty,s,r,bounds}));
      }catch(err){console.error(err);}
    }
    if(wantFx&&hasPsdFx(l.fx)){try{psdBlock(ex,'lfx2',lfx2Block(l.fx));}catch(err){console.error(err);}}
    if(l.fillOp!=null&&l.fillOp<1){const u=new PW();u.u8(Math.round(clamp(l.fillOp,0,1)*255));u.u8(0);u.u8(0);u.u8(0);psdBlock(ex,'iOpa',Uint8Array.from(u.a));}
    bw.u32(ex.p);bw.bytes(ex.b.subarray(0,ex.p));
  }
  for(const it of items)for(const ch of it.chans)bw.bytes(ch);
  let liLen=bw.p-liPos-4;if(liLen%2){bw.u8(0);liLen++;}
  bw.patch32(liPos,liLen);
  bw.u32(0);
  bw.patch32(lmPos,bw.p-lmPos-4);
  const fc=mkCanvas(W,H),fx=cctx(fc);fx.fillStyle='#fff';fx.fillRect(0,0,W,H);compose(fx,1);
  const fd=fx.getImageData(0,0,W,H).data;
  bw.u16(0);
  for(let c=0;c<3;c++){const pl=new Uint8Array(W*H);for(let k=0;k<W*H;k++)pl[k]=fd[k*4+c];bw.bytes(pl);}
  const out=bw.b.slice(0,bw.p);out.skippedAdj=skippedAdj;
  if(skippedAdj)toast(skippedAdj+' adjustment layer'+(skippedAdj===1?'':'s')+' could not be saved in the PSD. Their look is only in the flattened preview.');
  return out;
};
buildPSDAsync=function(o){return Promise.resolve(buildPSD(o));};
function buildPSDAsync(o){return Promise.resolve(buildPSD(o));}
