/* ===== Edit menu, Photoshop style: undo states, fade, paste special, fill, stroke, content-aware, transform, search, preferences ===== */

/* ---------- preferences (stored on this device) ---------- */
const PREFS=(()=>{try{return JSON.parse(localStorage.getItem('lk_prefs')||'{}')||{};}catch(e){return {};}})();
function savePrefs(){try{localStorage.setItem('lk_prefs',JSON.stringify(PREFS));}catch(e){}}
const THEMES={
  'Darkest':{'--bg':'#1e1e1e','--panel':'#2b2b2b','--panel2':'#323232','--panel3':'#3c3c3c','--line':'#161616','--line2':'#474747','--fg':'#e6e6e6','--muted':'#9b9b9b','--canvasbg':'#1a1a1a','--ruler':'#2f2f2f',dark:1},
  'Dark':{'--bg':'#2d2d2d','--panel':'#3a3a3a','--panel2':'#424242','--panel3':'#4e4e4e','--line':'#1f1f1f','--line2':'#585858','--fg':'#ececec','--muted':'#aaaaaa','--canvasbg':'#2a2a2a','--ruler':'#3d3d3d',dark:1},
  'Medium':{'--bg':'#3f3f3f','--panel':'#505050','--panel2':'#595959','--panel3':'#656565','--line':'#2a2a2a','--line2':'#6a6a6a','--fg':'#f0f0f0','--muted':'#bcbcbc','--canvasbg':'#3a3a3a','--ruler':'#4c4c4c',dark:1}
};
function applyPrefs(){
  const th=THEMES[PREFS.theme||'Darkest']||THEMES.Darkest,r=document.documentElement.style;
  Object.keys(th).forEach(k=>{if(k[0]==='-')r.setProperty(k,th[k]);});
  r.setProperty('color-scheme',th.dark?'dark':'light');
  document.body.style.fontSize=(PREFS.ui||13)+'px';
  S.histMax=clamp(PREFS.hist||50,20,200);
  redraw();
}
applyPrefs();

/* ---------- small dialog helpers ---------- */
const eRng=(id,label,min,max,val,step,unit)=>'<label class="fld erow">'+esc(label)+'<input type="range" id="'+id+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+val+'"><output id="'+id+'_v">'+val+(unit||'')+'</output></label>';
function eBind(root,fn,units){
  const upd=()=>{$$('input[type=range]',root).forEach(r=>{const o=$('#'+r.id+'_v',root);if(o)o.textContent=r.value+((units&&units[r.id])||(r.dataset.u||''));});};
  root.oninput=root.onchange=()=>{upd();fn(root);};upd();
}
const eNum=id=>+($('#'+id).value);
const blendSel=(id,v)=>'<select id="'+id+'">'+BLEND_OPTS.map(b=>'<option value="'+b[0]+'"'+(b[0]===(v||'source-over')?' selected':'')+'>'+b[1]+'</option>').join('')+'</select>';
function needDoc(){if(!doc){toast('Create or open a design first');return false;}flush();return true;}

/* ---------- undo, redo, toggle, fade ---------- */
ACT.toggleState=()=>{
  if(!needDoc())return;
  if(S._tg&&S._tg.at===hi){const to=S._tg.back;S._tg={at:to,back:hi};jumpTo(to);}
  else if(hi>0){S._tg={at:hi-1,back:hi};jumpTo(hi-1);}
};
function openFade(){
  if(!needDoc())return;
  const l=active();if(!l||hi<1){toast('Nothing to fade');return;}
  const ps=hist[hi-1].layers.find(q=>q.id===l.id);
  if(!ps||ps.canvas.width!==l.canvas.width||ps.canvas.height!==l.canvas.height||ps.ver===l.ver){toast('Fade works right after a filter or a paint stroke on the same layer');return;}
  const prev=cloneCanvas(ps.canvas),cur=cloneCanvas(l.canvas);let done=false;
  const run=root=>{
    const c=l.canvas,x=cctx(c);x.save();x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='source-over';x.globalAlpha=1;x.clearRect(0,0,c.width,c.height);
    x.drawImage(prev,0,0);x.globalAlpha=eNum('fd-o')/100;x.globalCompositeOperation=$('#fd-b').value;x.drawImage(cur,0,0);x.restore();touch(l);
  };
  const undoIt=()=>{if(done)return;const x=cctx(l.canvas);x.clearRect(0,0,l.canvas.width,l.canvas.height);x.drawImage(cur,0,0);touch(l);};
  modalOpen('Fade','<div class="muted" style="margin-bottom:8px">Blend the last change with how the layer looked before it.</div>'+eRng('fd-o','Opacity',0,100,100,1,'%')+'<label class="fld erow">Mode'+blendSel('fd-b')+'</label>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{done=true;modalCancel=null;commit('Fade');}}],root=>{modalCancel=undoIt;eBind(root,run);},{side:true});
}
ACT.fade=openFade;

/* ---------- copy merged, paste special ---------- */
ACT.copyMerged=()=>{
  if(!needDoc())return;
  const c=flatCanvas(1,null);
  if(S.sel){const x=cctx(c);x.globalCompositeOperation='destination-in';x.drawImage(S.sel.c,0,0);}
  const b=alphaBBox(c);if(!b){toast('Nothing to copy');return;}
  const out=mkCanvas(b.w,b.h);cctx(out).drawImage(c,b.x,b.y,b.w,b.h,0,0,b.w,b.h);
  S.clip={canvas:out,x:b.x+b.w/2,y:b.y+b.h/2};toast('Copied merged');
};
function pasteMasked(outside){
  if(!needDoc())return;
  if(!S.clip){toast('Nothing copied yet');return;}
  if(!S.sel){ACT.pasteInPlace();return;}
  const c=S.clip,b=S.sel.bbox,n=addLayer({name:'Pasted layer',w:c.canvas.width,h:c.canvas.height,x:outside?c.x:b.x+b.w/2,y:outside?c.y:b.y+b.h/2,above:true});
  cctx(n.canvas).drawImage(c.canvas,0,0);
  const sa=selAlphaCanvasLocal(n),m=mkCanvas(n.canvas.width,n.canvas.height),mx=cctx(m);
  if(outside){mx.fillStyle='#fff';mx.fillRect(0,0,m.width,m.height);mx.globalCompositeOperation='destination-out';}
  mx.drawImage(sa,0,0);n.mask=m;touch(n);
  commit(outside?'Paste outside':'Paste into');
}
ACT.pasteInto=()=>pasteMasked(false);
ACT.pasteOutside=()=>pasteMasked(true);

/* ---------- the layer to paint on ---------- */
function paintTarget(name){
  let l=active();if(!l){toast('Select a layer first');return null;}
  if(pxLocked(l)){toast('This layer is locked');return null;}
  if(l.type==='adjust'){toast('Select a photo or paint layer');return null;}
  if(l.type==='text'||l.type==='shape'||l.smart)l=addLayer({name:name||'Fill',above:true});
  return l;
}
/* draw a document-sized picture onto a layer with a blend mode, opacity and optional alpha lock */
function paintDoc(l,pic,o){
  o=o||{};
  let src=pic;
  if(S.sel){src=cloneCanvas(pic);const x=cctx(src);x.globalCompositeOperation='destination-in';x.drawImage(S.sel.c,0,0);}
  if(o.keepAlpha){src=cloneCanvas(src);const fl=flatLayer(l),x=cctx(src);x.globalCompositeOperation='destination-in';x.drawImage(fl,0,0);}
  withLocal(l,ctx=>{ctx.globalAlpha=o.op==null?1:o.op;ctx.globalCompositeOperation=o.blend||'source-over';ctx.drawImage(src,0,0);});
}

/* ---------- Fill ---------- */
function fillContents(kind,color,pat){
  const c=mkCanvas(doc.w,doc.h),x=cctx(c);
  if(kind==='fg')x.fillStyle=S.fg;else if(kind==='bg')x.fillStyle=S.bg;else if(kind==='color')x.fillStyle=color||'#808080';
  else if(kind==='black')x.fillStyle='#000';else if(kind==='gray')x.fillStyle='#808080';else x.fillStyle='#fff';
  if(kind==='pattern'){x.drawImage(patternCanvas(pat||S.patId,doc.w,doc.h,100),0,0);}else x.fillRect(0,0,doc.w,doc.h);
  return c;
}
function openFillDialog(){
  if(!needDoc())return;
  modalOpen('Fill','<div class="saform">'
    +'<label class="fld erow">Contents<select id="fl-k"><option value="fg">Foreground Color</option><option value="bg">Background Color</option><option value="color">Color...</option><option value="pattern">Pattern</option><option value="black">Black</option><option value="gray">50% Gray</option><option value="white">White</option><option value="ca">Content-Aware</option></select></label>'
    +'<label class="fld erow" id="fl-cw" hidden>Colour<input type="color" id="fl-c" value="'+S.fg+'"></label>'
    +'<label class="fld erow" id="fl-pw" hidden>Pattern<select id="fl-p">'+PATTERNS.map(p=>'<option value="'+p[0]+'"'+(p[0]===S.patId?' selected':'')+'>'+esc(p[1])+'</option>').join('')+'</select></label>'
    +'<div class="h" style="margin-top:10px">Blending</div><label class="fld erow">Mode'+blendSel('fl-b')+'</label>'
    +eRng('fl-o','Opacity',1,100,100,1,'%')
    +'<label class="row"><input type="checkbox" id="fl-t"> Preserve Transparency</label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const k=$('#fl-k').value,op=eNum('fl-o')/100,blend=$('#fl-b').value,keep=$('#fl-t').checked;
      if(k==='ca'){setTimeout(()=>contentAwareFill(),30);return;}
      const l=paintTarget('Fill');if(!l)return;
      paintDoc(l,fillContents(k,$('#fl-c').value,$('#fl-p').value),{op,blend,keepAlpha:keep});
      commit('Fill');
    }}],root=>{
      const sync=()=>{const k=$('#fl-k').value;$('#fl-cw').hidden=k!=='color';$('#fl-pw').hidden=k!=='pattern';};
      eBind(root,sync);sync();
    });
}
ACT.fillDialog=openFillDialog;

/* ---------- Stroke (selection outline) ---------- */
function edt2(g,w,h){
  const INF=1e20,n=Math.max(w,h),f=new Float32Array(n),d=new Float32Array(n),v=new Int32Array(n),z=new Float32Array(n+1);
  const line=len=>{
    let k=0;v[0]=0;z[0]=-INF;z[1]=INF;
    for(let q=1;q<len;q++){
      let s=((f[q]+q*q)-(f[v[k]]+v[k]*v[k]))/(2*q-2*v[k]);
      while(s<=z[k]){k--;s=((f[q]+q*q)-(f[v[k]]+v[k]*v[k]))/(2*q-2*v[k]);}
      k++;v[k]=q;z[k]=s;z[k+1]=INF;
    }
    k=0;for(let q=0;q<len;q++){while(z[k+1]<q)k++;d[q]=(q-v[k])*(q-v[k])+f[v[k]];}
  };
  for(let x=0;x<w;x++){for(let y=0;y<h;y++)f[y]=g[y*w+x];line(h);for(let y=0;y<h;y++)g[y*w+x]=d[y];}
  for(let y=0;y<h;y++){for(let x=0;x<w;x++)f[x]=g[y*w+x];line(w);for(let x=0;x<w;x++)g[y*w+x]=d[x];}
  return g;
}
/* a document-sized picture of the selection outline, width px, at inside / center / outside */
function strokeRing(width,pos,color){
  const b=S.sel.bbox,pad=Math.ceil(width)+3,x0=Math.max(0,b.x-pad),y0=Math.max(0,b.y-pad),x1=Math.min(doc.w,b.x+b.w+pad),y1=Math.min(doc.h,b.y+b.h+pad),w=x1-x0,h=y1-y0;
  const md=cctx(S.sel.c).getImageData(x0,y0,w,h).data,INF=1e20,A=new Float32Array(w*h),B=new Float32Array(w*h);
  for(let i=0;i<w*h;i++){const inside=md[i*4+3]>=128;A[i]=inside?0:INF;B[i]=inside?INF:0;}
  edt2(A,w,h);edt2(B,w,h);
  const lo=pos==='inside'?-width:pos==='center'?-width/2:0,hi2=pos==='inside'?0:pos==='center'?width/2:width;
  const out=mkCanvas(doc.w,doc.h),ox=cctx(out),id=ox.createImageData(w,h),d=id.data,col=hexRgb(color);
  for(let i=0;i<w*h;i++){
    const inside=md[i*4+3]>=128,s=inside?-(Math.sqrt(B[i])-0.5):(Math.sqrt(A[i])-0.5);
    const a=clamp(s-lo+0.5,0,1)*clamp(hi2-s+0.5,0,1);
    if(a>0){d[i*4]=col[0];d[i*4+1]=col[1];d[i*4+2]=col[2];d[i*4+3]=Math.round(a*255);}
  }
  ox.putImageData(id,x0,y0);return out;
}
function openStrokeDialog(){
  if(!needDoc())return;
  if(!S.sel){toast('Make a selection first, then stroke its edge');return;}
  modalOpen('Stroke','<div class="saform">'+eRng('st-w','Width',1,250,3,1,' px')
    +'<label class="fld erow">Color<input type="color" id="st-c" value="'+S.fg+'"></label>'
    +'<div class="h" style="margin-top:10px">Location</div><div class="row"><label><input type="radio" name="st-p" value="inside"> Inside</label> <label><input type="radio" name="st-p" value="center" checked> Center</label> <label><input type="radio" name="st-p" value="outside"> Outside</label></div>'
    +'<div class="h" style="margin-top:10px">Blending</div><label class="fld erow">Mode'+blendSel('st-b')+'</label>'+eRng('st-o','Opacity',1,100,100,1,'%')
    +'<label class="row"><input type="checkbox" id="st-t"> Preserve Transparency</label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const l=paintTarget('Stroke');if(!l)return;
      paintDoc(l,strokeRing(eNum('st-w'),$('input[name=st-p]:checked').value,$('#st-c').value),{op:eNum('st-o')/100,blend:$('#st-b').value,keepAlpha:$('#st-t').checked});
      commit('Stroke');
    }}],root=>eBind(root,()=>{}));
}
ACT.strokeDialog=openStrokeDialog;

/* ---------- Content-Aware Fill (PatchMatch inpainting) ---------- */
function patchInpaint(img,hole,w,h,R){
  /* img: Float32Array w*h*3 (colours), hole: Uint8Array; fills the hole with texture borrowed from the rest of the picture */
  const N=w*h,known=new Uint8Array(N);for(let i=0;i<N;i++)known[i]=hole[i]?0:1;
  /* 1) onion peel to get a smooth start */
  {
    let left=0;for(let i=0;i<N;i++)if(!known[i])left++;
    let guard=0;
    while(left>0&&guard++<4000){
      const add=[];
      for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(known[i])continue;
        let n=0,r=0,g=0,b=0;
        for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=w||yy>=h)continue;const j=yy*w+xx;if(known[j]){n++;r+=img[j*3];g+=img[j*3+1];b+=img[j*3+2];}}
        if(n)add.push([i,r/n,g/n,b/n]);}
      if(!add.length)break;
      for(const a of add){img[a[0]*3]=a[1];img[a[0]*3+1]=a[2];img[a[0]*3+2]=a[3];known[a[0]]=1;left--;}
    }
  }
  /* 2) valid source centres: whole patch inside the picture and clear of the hole */
  const valid=new Uint8Array(N),vlist=[];
  {
    const ii=new Int32Array((w+1)*(h+1));
    for(let y=0;y<h;y++){let row=0;for(let x=0;x<w;x++){row+=hole[y*w+x]?1:0;ii[(y+1)*(w+1)+x+1]=ii[y*(w+1)+x+1]+row;}}
    for(let y=R;y<h-R;y++)for(let x=R;x<w-R;x++){
      const a=ii[(y+R+1)*(w+1)+x+R+1]-ii[(y-R)*(w+1)+x+R+1]-ii[(y+R+1)*(w+1)+x-R]+ii[(y-R)*(w+1)+x-R];
      if(!a){valid[y*w+x]=1;vlist.push(y*w+x);}
    }
  }
  if(!vlist.length)return false;
  const hp=[];for(let i=0;i<N;i++)if(hole[i])hp.push(i);
  const nnf=new Int32Array(N),cost=new Float32Array(N);
  const cl=(v,a,b)=>v<a?a:v>b?b:v;
  const dist=(p,q,lim)=>{
    const px=p%w,py=(p/w)|0,qx=q%w,qy=(q/w)|0;let s=0;
    for(let dy=-R;dy<=R;dy++){
      const py2=cl(py+dy,0,h-1)*w,qy2=(qy+dy)*w;
      for(let dx=-R;dx<=R;dx++){
        const a=(py2+cl(px+dx,0,w-1))*3,b=(qy2+qx+dx)*3,d0=img[a]-img[b],d1=img[a+1]-img[b+1],d2=img[a+2]-img[b+2];
        s+=d0*d0+d1*d1+d2*d2;
      }
      if(s>=lim)return s;
    }
    return s;
  };
  let seed=12345;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  for(const p of hp){const q=vlist[(rnd()*vlist.length)|0];nnf[p]=q;cost[p]=dist(p,q,1e30);}
  const ITER=hp.length>60000?4:6,maxR=Math.max(w,h);
  for(let it=0;it<ITER;it++){
    const fwd=it%2===0,order=fwd?hp:hp.slice().reverse(),st=fwd?-1:1;
    for(const p of order){
      let best=nnf[p],bc=cost[p];
      const px=p%w,py=(p/w)|0;
      // propagation from the neighbours' matches
      for(const nb of [[st,0],[0,st]]){
        const nx=px+nb[0],ny=py+nb[1];if(nx<0||ny<0||nx>=w||ny>=h)continue;
        const np=ny*w+nx;if(!hole[np])continue;
        const m=nnf[np],mx=m%w-nb[0],my=((m/w)|0)-nb[1];
        if(mx<R||my<R||mx>=w-R||my>=h-R)continue;
        const q=my*w+mx;if(!valid[q])continue;
        const c=dist(p,q,bc);if(c<bc){bc=c;best=q;}
      }
      // random search around the best match
      const bx=best%w,by=(best/w)|0;
      for(let rad=maxR;rad>=1;rad=(rad/2)|0){
        const qx=cl(bx+((rnd()*2-1)*rad|0),R,w-R-1),qy=cl(by+((rnd()*2-1)*rad|0),R,h-R-1),q=qy*w+qx;
        if(!valid[q])continue;
        const c=dist(p,q,bc);if(c<bc){bc=c;best=q;}
      }
      nnf[p]=best;cost[p]=bc;
    }
    // vote: each hole pixel becomes the average of what the overlapping matches say it should be
    const acc=new Float32Array(N*3),cnt=new Float32Array(N);
    for(const p of hp){
      const px=p%w,py=(p/w)|0,m=nnf[p],mx=m%w,my=(m/w)|0;
      for(let dy=-R;dy<=R;dy++)for(let dx=-R;dx<=R;dx++){
        const tx=px+dx,ty=py+dy;if(tx<0||ty<0||tx>=w||ty>=h)continue;const t=ty*w+tx;if(!hole[t])continue;
        const s=((my+dy)*w+mx+dx)*3;acc[t*3]+=img[s];acc[t*3+1]+=img[s+1];acc[t*3+2]+=img[s+2];cnt[t]++;
      }
    }
    for(const t of hp){if(cnt[t]){img[t*3]=acc[t*3]/cnt[t];img[t*3+1]=acc[t*3+1]/cnt[t];img[t*3+2]=acc[t*3+2]/cnt[t];}}
  }
  return true;
}
function contentAwareFill(opts){
  if(!needDoc())return;
  if(!S.sel){toast('Select the area to fill first (for example with the Lasso)');return;}
  opts=opts||{};
  toast('Filling the selection...');
  setTimeout(()=>{
    try{
      const src=opts.all===false&&active()?flatLayer(active()):flatCanvas(1,null),mb=S.sel.bbox;
      const margin=Math.max(24,Math.round(Math.max(mb.w,mb.h)*0.7));
      const rx=Math.max(0,mb.x-margin),ry=Math.max(0,mb.y-margin),rw=Math.min(doc.w,mb.x+mb.w+margin)-rx,rh=Math.min(doc.h,mb.y+mb.h+margin)-ry;
      const k=Math.min(1,Math.sqrt(150000/(rw*rh))),w=Math.max(12,Math.round(rw*k)),h=Math.max(12,Math.round(rh*k));
      const sc=mkCanvas(w,h),sx=cctx(sc);sx.fillStyle='#808080';sx.fillRect(0,0,w,h);sx.drawImage(src,rx,ry,rw,rh,0,0,w,h);
      const mc=mkCanvas(w,h),mx=cctx(mc);mx.drawImage(S.sel.c,rx,ry,rw,rh,0,0,w,h);
      const sd=sx.getImageData(0,0,w,h).data,md=mx.getImageData(0,0,w,h).data,N=w*h,img=new Float32Array(N*3);
      let hole=new Uint8Array(N);
      for(let i=0;i<N;i++){img[i*3]=sd[i*4];img[i*3+1]=sd[i*4+1];img[i*3+2]=sd[i*4+2];if(md[i*4+3]>20)hole[i]=1;}
      const grown=hole.slice(),g=Math.max(1,Math.round(2*k)); // grow a little so the old edge does not leak in
      for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(hole[y*w+x])for(let dy=-g;dy<=g;dy++)for(let dx=-g;dx<=g;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<w&&yy<h)grown[yy*w+xx]=1;}
      const nh=grown.reduce((a,b)=>a+b,0);
      if(nh>N*0.85){toast('The selection covers almost the whole area. Choose a smaller area.');return;}
      const R=nh>20000?3:2;
      if(!patchInpaint(img,grown,w,h,R)){toast('Not enough surrounding picture to copy from. Select a smaller area.');return;}
      const oc=mkCanvas(w,h),ox=cctx(oc),od=ox.createImageData(w,h),o=od.data;
      for(let i=0;i<N;i++){o[i*4]=img[i*3];o[i*4+1]=img[i*3+1];o[i*4+2]=img[i*3+2];o[i*4+3]=255;}
      ox.putImageData(od,0,0);
      const big=mkCanvas(doc.w,doc.h),bx=cctx(big);bx.imageSmoothingQuality='high';bx.drawImage(oc,0,0,w,h,rx,ry,rw,rh);
      bx.globalCompositeOperation='destination-in';bx.drawImage(S.sel.c,0,0);
      const n=addLayer({name:'Content-Aware Fill',above:true});cctx(n.canvas).drawImage(big,0,0);touch(n);
      commit('Content-Aware Fill');
      toast('Filled on a new layer. Undo or hide it if you do not like it.');
    }catch(err){console.error(err);toast('Could not fill that area');}
  },40);
}
ACT.contentAwareFill=()=>contentAwareFill();

/* ---------- Content-Aware Scale (seam carving) ---------- */
function seamCarve(cv,newW,newH){
  const lum=(d,i)=>0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];
  const oneAxis=(src,target)=>{ // change the width of src (canvas) to target
    let w=src.width,h=src.height;if(target===w)return src;
    const diff=Math.abs(target-w),grow=target>w;
    let data=cctx(src).getImageData(0,0,w,h).data,cols=Array.from({length:w},(_,i)=>i);
    const rows=[]; // per seam: original column in each row
    let cur=data,cw=w;
    const orig=new Int32Array(h*w);for(let y=0;y<h;y++)for(let x=0;x<w;x++)orig[y*w+x]=x; // original column of each current pixel
    let om=orig;
    const seams=[];
    for(let s=0;s<diff;s++){
      const E=new Float32Array(cw*h);
      for(let y=0;y<h;y++)for(let x=0;x<cw;x++){
        const i=(y*cw+x)*4,l=x>0?(y*cw+x-1)*4:i,r=x<cw-1?(y*cw+x+1)*4:i,u=y>0?((y-1)*cw+x)*4:i,dn=y<h-1?((y+1)*cw+x)*4:i;
        E[y*cw+x]=Math.abs(lum(cur,l)-lum(cur,r))+Math.abs(lum(cur,u)-lum(cur,dn))+Math.abs(cur[l+3]-cur[r+3])*0.5+Math.abs(cur[u+3]-cur[dn+3])*0.5;
      }
      const M=new Float32Array(cw*h),from=new Int8Array(cw*h);
      for(let x=0;x<cw;x++)M[x]=E[x];
      for(let y=1;y<h;y++)for(let x=0;x<cw;x++){
        let best=M[(y-1)*cw+x],f=0;
        if(x>0&&M[(y-1)*cw+x-1]<best){best=M[(y-1)*cw+x-1];f=-1;}
        if(x<cw-1&&M[(y-1)*cw+x+1]<best){best=M[(y-1)*cw+x+1];f=1;}
        M[y*cw+x]=E[y*cw+x]+best;from[y*cw+x]=f;
      }
      let bx=0,bv=1e30;for(let x=0;x<cw;x++)if(M[(h-1)*cw+x]<bv){bv=M[(h-1)*cw+x];bx=x;}
      const seam=new Int32Array(h);let x=bx;for(let y=h-1;y>=0;y--){seam[y]=x;x+=from[y*cw+x];}
      const nd=new Uint8ClampedArray((cw-1)*h*4),nom=new Int32Array((cw-1)*h);
      for(let y=0;y<h;y++){
        const sx=seam[y];let o=0;
        for(let xx=0;xx<cw;xx++){if(xx===sx)continue;const si=(y*cw+xx)*4,di=(y*(cw-1)+o)*4;nd[di]=cur[si];nd[di+1]=cur[si+1];nd[di+2]=cur[si+2];nd[di+3]=cur[si+3];nom[y*(cw-1)+o]=om[y*cw+xx];o++;}
      }
      seams.push(Array.from(seam,(sx,y)=>om[y*cw+sx]));
      cur=nd;om=nom;cw--;
    }
    const out=mkCanvas(grow?w+diff:w-diff,h),ox=cctx(out);
    if(!grow){const id=ox.createImageData(cw,h);id.data.set(cur);ox.putImageData(id,0,0);return out;}
    const od=ox.createImageData(w+diff,h),o=od.data,mark=new Uint8Array(h*w);
    for(const sm of seams)for(let y=0;y<h;y++)mark[y*w+sm[y]]++;
    for(let y=0;y<h;y++){let q=0;
      for(let x=0;x<w;x++){
        const si=(y*w+x)*4;
        for(let t=0;t<=mark[y*w+x];t++){
          const di=(y*(w+diff)+q)*4;
          if(t===0){o[di]=data[si];o[di+1]=data[si+1];o[di+2]=data[si+2];o[di+3]=data[si+3];}
          else{const ni=(y*w+Math.min(w-1,x+1))*4;for(let c=0;c<4;c++)o[di+c]=(data[si+c]+data[ni+c])>>1;}
          q++;
        }
      }
    }
    ox.putImageData(od,0,0);return out;
  };
  let c=oneAxis(cv,newW);
  if(newH!==c.height){
    const t=mkCanvas(c.height,c.width),tx=cctx(t);tx.translate(0,0);tx.setTransform(0,1,1,0,0,0);tx.drawImage(c,0,0);
    const r=oneAxis(t,newH),o=mkCanvas(r.height,r.width),ox=cctx(o);ox.setTransform(0,1,1,0,0,0);ox.drawImage(r,0,0);c=o;
  }
  return c;
}
function openContentScale(){
  if(!needDoc())return;
  const l=active();if(!l||l.type==='adjust'){toast('Select a layer first');return;}
  if(pxLocked(l)){toast('This layer is locked');return;}
  if(l.mask){toast('Apply or delete the layer mask first');return;}
  modalOpen('Content-Aware Scale','<div class="muted" style="margin-bottom:8px">Resizes the layer and tries to keep the important parts (faces, objects) from stretching. Works best on photos.</div>'
    +eRng('cs-w','Width',50,150,100,1,'%')+eRng('cs-h','Height',50,150,100,1,'%'),
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const bb=alphaBBox(l.canvas);if(!bb){toast('That layer is empty');return;}
      const nw=Math.round(bb.w*eNum('cs-w')/100),nh=Math.round(bb.h*eNum('cs-h')/100);
      if(nw===bb.w&&nh===bb.h)return;
      toast('Scaling...');
      setTimeout(()=>{
        try{
          const crop=mkCanvas(bb.w,bb.h);cctx(crop).drawImage(l.canvas,bb.x,bb.y,bb.w,bb.h,0,0,bb.w,bb.h);
          const out=seamCarve(crop,nw,nh);
          const cx=bb.x+bb.w/2-l.canvas.width/2,cy=bb.y+bb.h/2-l.canvas.height/2;
          if(l.type==='text'||l.type==='shape'){l.type='image';l.props=null;}
          const s=l.s||1,cr=Math.cos(l.r||0),sn=Math.sin(l.r||0);
          l.x+=s*(cr*cx-sn*cy);l.y+=s*(sn*cx+cr*cy);l.canvas=out;touch(l);commit('Content-Aware Scale');renderProps();
        }catch(err){console.error(err);toast('Could not scale that layer');}
      },40);
    }}],root=>eBind(root,()=>{}));
}
ACT.contentScale=openContentScale;

/* ---------- Transform: numeric Scale, Rotate, Skew, Distort, Perspective, Warp ---------- */
function xfDrawTri(ctx,img,s,d){
  const den=s[0][0]*(s[1][1]-s[2][1])+s[1][0]*(s[2][1]-s[0][1])+s[2][0]*(s[0][1]-s[1][1]);if(Math.abs(den)<1e-9)return;
  const [sx0,sy0]=s[0],[sx1,sy1]=s[1],[sx2,sy2]=s[2],[dx0,dy0]=d[0],[dx1,dy1]=d[1],[dx2,dy2]=d[2];
  const a=(dx0*(sy1-sy2)+dx1*(sy2-sy0)+dx2*(sy0-sy1))/den,c=(dx0*(sx2-sx1)+dx1*(sx0-sx2)+dx2*(sx1-sx0))/den,e=(dx0*(sx1*sy2-sx2*sy1)+dx1*(sx2*sy0-sx0*sy2)+dx2*(sx0*sy1-sx1*sy0))/den;
  const b=(dy0*(sy1-sy2)+dy1*(sy2-sy0)+dy2*(sy0-sy1))/den,dd=(dy0*(sx2-sx1)+dy1*(sx0-sx2)+dy2*(sx1-sx0))/den,f=(dy0*(sx1*sy2-sx2*sy1)+dy1*(sx2*sy0-sx0*sy2)+dy2*(sx0*sy1-sx1*sy0))/den;
  const cx=(dx0+dx1+dx2)/3,cy=(dy0+dy1+dy2)/3;
  ctx.save();ctx.beginPath();
  d.forEach((p,i)=>{const vx=p[0]-cx,vy=p[1]-cy,L=Math.hypot(vx,vy)||1,X=p[0]+vx/L*0.7,Y=p[1]+vy/L*0.7;if(i)ctx.lineTo(X,Y);else ctx.moveTo(X,Y);});
  ctx.closePath();ctx.clip();ctx.setTransform(a,b,c,dd,e,f);ctx.drawImage(img,0,0);ctx.restore();
}
/* draw img into a quad (TL, TR, BR, BL) with perspective; offset moves the quad into the output canvas */
function xfQuad(img,q,N){
  const xs=q.map(p=>p[0]),ys=q.map(p=>p[1]),x0=Math.min.apply(null,xs),y0=Math.min.apply(null,ys),W=Math.max(2,Math.ceil(Math.max.apply(null,xs)-x0)),H=Math.max(2,Math.ceil(Math.max.apply(null,ys)-y0));
  const out=mkCanvas(W,H),ctx=cctx(out),P=q.map(p=>[p[0]-x0,p[1]-y0]);
  const [X0,Y0]=P[0],[X1,Y1]=P[1],[X2,Y2]=P[2],[X3,Y3]=P[3];
  const dx1=X1-X2,dx2=X3-X2,dx3=X0-X1+X2-X3,dy1=Y1-Y2,dy2=Y3-Y2,dy3=Y0-Y1+Y2-Y3;
  let g=0,hh=0;const den=dx1*dy2-dy1*dx2;
  if(Math.abs(dx3)>1e-9||Math.abs(dy3)>1e-9){g=(dx3*dy2-dy3*dx2)/den;hh=(dx1*dy3-dy1*dx3)/den;}
  const A=X1-X0+g*X1,B=X3-X0+hh*X3,Dd=Y1-Y0+g*Y1,E=Y3-Y0+hh*Y3;
  const map=(u,v)=>{const k=g*u+hh*v+1;return [(A*u+B*v+X0)/k,(Dd*u+E*v+Y0)/k];};
  const w=img.width,h=img.height;
  for(let j=0;j<N;j++)for(let i=0;i<N;i++){
    const u0=i/N,u1=(i+1)/N,v0=j/N,v1=(j+1)/N,p00=map(u0,v0),p10=map(u1,v0),p11=map(u1,v1),p01=map(u0,v1);
    const s00=[u0*w,v0*h],s10=[u1*w,v0*h],s11=[u1*w,v1*h],s01=[u0*w,v1*h];
    xfDrawTri(ctx,img,[s00,s10,s11],[p00,p10,p11]);xfDrawTri(ctx,img,[s00,s11,s01],[p00,p11,p01]);
  }
  return {canvas:out,x0,y0};
}
const WARP_STYLES=[['arc','Arc'],['arch','Arch'],['bulge','Bulge'],['flag','Flag'],['wave','Wave'],['fisheye','Fisheye'],['squeeze','Squeeze'],['rise','Rise'],['twist','Twist']];
function warpMap(st,b,u,v){
  switch(st){
    case 'arc':return [u,v+0.5*b*(u*u-1)];
    case 'arch':return [u,v+b*(u*u-1)*(1-v)/2];
    case 'flag':return [u,v+0.3*b*Math.sin(Math.PI*(u+1))];
    case 'wave':return [u,v+0.25*b*Math.sin(2*Math.PI*(u+1))];
    case 'rise':return [u/Math.max(0.25,1-0.6*b*(1-v)/2),v];
    case 'bulge':case 'fisheye':case 'squeeze':{
      const r=Math.hypot(u,v);if(r<1e-6||r>=1)return [u,v];
      const e=st==='squeeze'?-b:b,s=Math.pow(r,1+0.9*e);return [u/r*s,v/r*s];
    }
    case 'twist':{const r=Math.hypot(u,v);if(r>=1)return [u,v];const t=b*Math.PI*(1-r)*(1-r),c=Math.cos(t),s=Math.sin(t);return [u*c-v*s,u*s+v*c];}
  }
  return [u,v];
}
function xfWarp(src,style,bend,vert){
  const w=src.width,h=src.height,sd=cctx(src).getImageData(0,0,w,h).data,out=mkCanvas(w,h),ox=cctx(out),od=ox.createImageData(w,h),o=od.data;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const u=(x+0.5)/w*2-1,v=(y+0.5)/h*2-1;let m;
    if(vert){const t=warpMap(style,bend,v,u);m=[t[1],t[0]];}else m=warpMap(style,bend,u,v);
    const sx=(m[0]+1)/2*w-0.5,sy=(m[1]+1)/2*h-0.5;
    if(sx<-0.5||sy<-0.5||sx>w-0.5||sy>h-0.5)continue;
    const x0=Math.floor(sx),y0=Math.floor(sy),fx=sx-x0,fy=sy-y0,i=(y*w+x)*4;let a=0,r=0,g=0,bl=0;
    for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){
      const xx=clamp(x0+dx,0,w-1),yy=clamp(y0+dy,0,h-1),k=(yy*w+xx)*4,wt=(dx?fx:1-fx)*(dy?fy:1-fy),al=sd[k+3]*wt;
      a+=al;r+=sd[k]*al;g+=sd[k+1]*al;bl+=sd[k+2]*al;
    }
    if(a>0){o[i]=r/a;o[i+1]=g/a;o[i+2]=bl/a;o[i+3]=a;}
  }
  ox.putImageData(od,0,0);return out;
}
/* a dialog that previews on the layer, and bakes the result into its pixels (or just moves it when nothing needs baking) */
function xfDialog(title,body,compute,opts){
  if(!needDoc())return;
  const l=active();if(!l||l.type==='adjust'){toast('Select a layer first');return;}
  if(posLocked(l)||pxLocked(l)){toast('This layer is locked');return;}
  if(l.mask&&!(opts&&opts.simple)){toast('Apply or delete the layer mask first');return;}
  const orig={canvas:l.canvas,x:l.x,y:l.y,type:l.type,props:l.props,r:l.r,s:l.s,smart:l.smart};
  const src=cloneCanvas(l.canvas);let done=false;
  const restore=()=>{if(done)return;l.canvas=orig.canvas;l.x=orig.x;l.y=orig.y;l.type=orig.type;l.props=orig.props;l.r=orig.r;l.s=orig.s;touch(l);};
  const run=root=>{
    const r=compute(root,src,orig);if(!r)return;
    if(r.simple){l.canvas=orig.canvas;l.x=orig.x;l.y=orig.y;l.type=orig.type;l.props=orig.props;if(r.s!=null)l.s=r.s;if(r.r!=null)l.r=r.r;touch(l);return;}
    l.s=orig.s;l.r=orig.r;
    const cr=Math.cos(orig.r||0),sn=Math.sin(orig.r||0),s=orig.s||1;
    l.canvas=r.canvas;l.x=orig.x+s*(cr*r.cx-sn*r.cy);l.y=orig.y+s*(sn*r.cx+cr*r.cy);
    if(l.type==='text'||l.type==='shape'){l.type='image';l.props=null;}touch(l);
  };
  modalOpen(title,body,[{label:'Cancel'},{label:'OK',primary:true,cb:()=>{done=true;modalCancel=null;commit(title.replace(/\.\.\.$/,''));renderProps();}}],root=>{
    modalCancel=restore;eBind(root,run,opts&&opts.units);run(root);
  },{side:true});
}
const fromQuad=(src,q)=>{const w=src.width,h=src.height,r=xfQuad(src,q,18);return {canvas:r.canvas,cx:r.x0+r.canvas.width/2-0,cy:r.y0+r.canvas.height/2-0};};
ACT.xScale=()=>{
  if(!needDoc())return;const l=active();if(!l){toast('Select a layer first');return;}
  xfDialog('Scale...','<label class="row"><input type="checkbox" id="xs-l" checked> Keep proportions</label>'+eRng('xs-w','Width',10,400,100,1,'%')+eRng('xs-h','Height',10,400,100,1,'%'),(root,src,orig)=>{
    const link=$('#xs-l',root).checked,ww=$('#xs-w',root),hh=$('#xs-h',root);
    if(link){const ev=root._ev&&root._ev.target&&root._ev.target.id;if(ev==='xs-h')ww.value=hh.value;else hh.value=ww.value;$('#xs-w_v',root).textContent=ww.value+'%';$('#xs-h_v',root).textContent=hh.value+'%';}
    const kx=+ww.value/100,ky=+hh.value/100;
    if(kx===ky)return {simple:true,s:(orig.s||1)*kx};
    const w=src.width*kx,h=src.height*ky,out=mkCanvas(w,h);const x=cctx(out);x.imageSmoothingQuality='high';x.drawImage(src,0,0,w,h);return {canvas:out,cx:0,cy:0};
  },{simple:true});
  const root=$('#mbody');root.addEventListener('input',e=>{root._ev=e;},true);
};
ACT.xRotate=()=>xfDialog('Rotate...',eRng('xr-a','Angle',-180,180,0,0.5,'°'),(root,src,orig)=>({simple:true,r:(orig.r||0)+eNum('xr-a')*Math.PI/180}),{simple:true});
ACT.xSkew=()=>xfDialog('Skew...',eRng('xk-h','Horizontal',-60,60,0,1,'°')+eRng('xk-v','Vertical',-60,60,0,1,'°'),(root,src)=>{
  const th=Math.tan(eNum('xk-h')*Math.PI/180),tv=Math.tan(eNum('xk-v')*Math.PI/180),w=src.width,h=src.height;
  const pts=[[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]].map(p=>[p[0]+th*p[1],p[1]+tv*p[0]]);
  const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),W=Math.ceil(Math.max.apply(null,xs)-Math.min.apply(null,xs)),H=Math.ceil(Math.max.apply(null,ys)-Math.min.apply(null,ys));
  const out=mkCanvas(W,H),x=cctx(out);x.imageSmoothingQuality='high';x.translate(W/2,H/2);x.transform(1,tv,th,1,0,0);x.drawImage(src,-w/2,-h/2);
  return {canvas:out,cx:0,cy:0};
});
ACT.xDistort=()=>xfDialog('Distort...','<div class="muted">Move each corner, as a percentage of the layer size.</div>'
  +[['tl','Top left'],['tr','Top right'],['br','Bottom right'],['bl','Bottom left']].map(c=>'<div class="h" style="margin-top:6px">'+c[1]+'</div>'+eRng('xd-'+c[0]+'x','Across',-50,50,0,1,'%')+eRng('xd-'+c[0]+'y','Up / down',-50,50,0,1,'%')).join(''),(root,src)=>{
  const w=src.width,h=src.height,g=(k)=>eNum('xd-'+k)/100,q=[[-w/2+g('tlx')*w,-h/2+g('tly')*h],[w/2+g('trx')*w,-h/2+g('try')*h],[w/2+g('brx')*w,h/2+g('bry')*h],[-w/2+g('blx')*w,h/2+g('bly')*h]];
  const r=xfQuad(src,q,18);return {canvas:r.canvas,cx:r.x0+r.canvas.width/2,cy:r.y0+r.canvas.height/2};
});
ACT.xPerspective=()=>xfDialog('Perspective...',eRng('xp-h','Horizontal',-70,70,0,1,'%')+eRng('xp-v','Vertical',-70,70,0,1,'%'),(root,src)=>{
  const w=src.width,h=src.height,ph=eNum('xp-h')/100,pv=eNum('xp-v')/100;
  const q=[[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]];
  if(ph>0){q[0][0]+=ph*w/2;q[1][0]-=ph*w/2;}else{q[3][0]-=ph*w/2;q[2][0]+=ph*w/2;}
  if(pv>0){q[0][1]+=pv*h/2;q[3][1]-=pv*h/2;}else{q[1][1]-=pv*h/2;q[2][1]+=pv*h/2;}
  const r=xfQuad(src,q,18);return {canvas:r.canvas,cx:r.x0+r.canvas.width/2,cy:r.y0+r.canvas.height/2};
});
ACT.xWarp=()=>xfDialog('Warp...','<label class="fld erow">Style<select id="xw-s">'+WARP_STYLES.map(s=>'<option value="'+s[0]+'">'+s[1]+'</option>').join('')+'</select></label>'
  +'<div class="row"><label><input type="radio" name="xw-o" value="h" checked> Horizontal</label> <label><input type="radio" name="xw-o" value="v"> Vertical</label></div>'+eRng('xw-b','Bend',-100,100,50,1,'%'),(root,src)=>{
  let s=src;if(Math.max(src.width,src.height)>900){const k=900/Math.max(src.width,src.height);s=mkCanvas(src.width*k,src.height*k);cctx(s).drawImage(src,0,0,s.width,s.height);}
  const out=xfWarp(s,$('#xw-s',root).value,eNum('xw-b')/100,$('input[name=xw-o]:checked',root).value==='v');
  return {canvas:out,cx:0,cy:0};
});
ACT.xRot180=()=>{if(!needDoc())return;const l=active();if(!l)return;l.r+=Math.PI;touch(l);commit('Rotate 180');renderProps();};
ACT.xRotCW=()=>{if(!needDoc())return;const l=active();if(!l)return;l.r+=Math.PI/2;touch(l);commit('Rotate 90 CW');renderProps();};
ACT.xRotCCW=()=>{if(!needDoc())return;const l=active();if(!l)return;l.r-=Math.PI/2;touch(l);commit('Rotate 90 CCW');renderProps();};
ACT.transformAgain=()=>{ACT.transform();};

/* ---------- Search ---------- */
function allCommands(){
  const out=[];
  const walk=(items,path)=>items.forEach(it=>{
    if(it.sep)return;
    const g=it.items&&Object.getOwnPropertyDescriptor(it,'items'),sub=it.items&&!(g&&g.get);
    if(it.items&&(!g||!g.get))walk(it.items,path.concat([it.label]));
    else if(!it.items&&it.fn)out.push({it,path:path.concat([it.label]).join('  ›  '),label:it.label,key:it.key||''});
    void sub;
  });
  MENUS.forEach(m=>walk(m.items,[m.label]));
  return out;
}
function openSearch(){
  if(!doc&&false)return;
  const cmds=allCommands().concat(Object.keys(TOOLS).filter(k=>TOOLS[k]&&TOOLS[k].name).map(k=>({it:{fn:()=>setTool(k),dis:()=>!doc},path:'Tool  ›  '+TOOLS[k].name,label:TOOLS[k].name,key:''})));
  modalOpen('Search','<input type="search" id="se-q" placeholder="Search tools, menu commands and filters" autocomplete="off" style="width:100%"><div id="se-l" class="selist"></div>',[{label:'Close'}],root=>{
    const q=$('#se-q',root),list=$('#se-l',root);let shown=[];
    const paint=()=>{
      const words=q.value.toLowerCase().split(/\s+/).filter(Boolean);
      shown=cmds.filter(c=>words.every(w=>c.path.toLowerCase().indexOf(w)>=0)&&!(c.it.dis&&c.it.dis())).slice(0,40);
      list.innerHTML=shown.length?shown.map((c,i)=>'<button class="seit'+(i===0?' on':'')+'" data-i="'+i+'"><span>'+esc(c.path)+'</span>'+(c.key?'<kbd>'+esc(c.key.replace(/\+/g,' + '))+'</kbd>':'')+'</button>').join(''):'<div class="muted" style="padding:10px">Nothing found</div>';
    };
    const run=i=>{const c=shown[i];if(!c)return;closeModal();setTimeout(()=>c.it.fn(),30);};
    q.addEventListener('input',paint);
    q.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run(0);}});
    list.addEventListener('click',e=>{const b=e.target.closest('.seit');if(b)run(+b.dataset.i);});
    paint();q.focus();
  });
}
ACT.search=openSearch;

/* ---------- Find and Replace Text ---------- */
function openFindReplace(){
  if(!needDoc())return;
  modalOpen('Find and Replace Text','<div class="saform"><label class="fld erow">Find what<input type="text" id="fr-f" style="width:100%"></label><label class="fld erow">Change to<input type="text" id="fr-r" style="width:100%"></label>'
    +'<label class="row"><input type="checkbox" id="fr-c"> Case sensitive</label><label class="row"><input type="checkbox" id="fr-w"> Whole word</label><div id="fr-s" class="muted" style="margin-top:8px"></div></div>',
    [{label:'Find Next',close:false,cb:()=>{frFind();return false;}},{label:'Change',close:false,cb:()=>{frChange(false);return false;}},{label:'Change All',primary:true,close:false,cb:()=>{frChange(true);return false;}},{label:'Done'}],root=>{$('#fr-f').focus();});
}
function frRe(){
  const f=$('#fr-f').value;if(!f)return null;
  const esc2=f.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  return new RegExp($('#fr-w').checked?'\\b'+esc2+'\\b':esc2,$('#fr-c').checked?'g':'gi');
}
function frFind(){
  const re=frRe();if(!re){$('#fr-s').textContent='Type the text to find.';return;}
  const tl=doc.layers.filter(l=>l.type==='text'&&l.props),start=Math.max(0,tl.findIndex(l=>l.id===doc.active)+1);
  for(let i=0;i<tl.length;i++){const l=tl[(start+i)%tl.length];re.lastIndex=0;if(re.test(l.props.text)){selectLayer(l.id);$('#fr-s').textContent='Found in "'+l.name+'".';return;}}
  $('#fr-s').textContent='Nothing found.';
}
function frChange(all){
  const re=frRe();if(!re){$('#fr-s').textContent='Type the text to find.';return;}
  const rep=$('#fr-r').value,tl=all?doc.layers.filter(l=>l.type==='text'&&l.props):[active()].filter(l=>l&&l.type==='text'&&l.props);
  let n=0;
  for(const l of tl){
    if(posLocked(l)&&pxLocked(l))continue;
    re.lastIndex=0;const t=l.props.text.replace(re,()=>{n++;return rep;});
    if(t!==l.props.text){l.props.text=t;renderText(l);touch(l);}
  }
  if(n){commit('Replace text');$('#fr-s').textContent='Changed '+n+' place'+(n===1?'':'s')+'.';}else $('#fr-s').textContent=all?'Nothing found.':'Select a text layer that contains the text.';
}
ACT.findReplace=openFindReplace;

/* ---------- Define Pattern ---------- */
function savePatterns(){try{localStorage.setItem('lk_pats',JSON.stringify(PATTERNS.filter(p=>/^user_/.test(p[0])).map(p=>({id:p[0],name:p[1],data:patCache[p[0]].toDataURL()}))));}catch(e){toast('Pattern added, but it could not be remembered on this device');}}
(function(){try{(JSON.parse(localStorage.getItem('lk_pats')||'[]')||[]).forEach(p=>{PATTERNS.push([p.id,p.name]);const im=new Image();im.onload=()=>{const c=mkCanvas(im.width,im.height);cctx(c).drawImage(im,0,0);patCache[p.id]=c;};im.src=p.data;});}catch(e){}})();
function openDefinePattern(){
  if(!needDoc())return;
  const flat=flatCanvas(1,null);let b=S.sel?S.sel.bbox:{x:0,y:0,w:doc.w,h:doc.h};
  if(b.w<2||b.h<2){toast('Choose a bigger area');return;}
  modalOpen('Pattern Name','<div class="row"><label>Name <input type="text" id="dp-n" value="Pattern '+(PATTERNS.filter(p=>/^user_/.test(p[0])).length+1)+'" style="width:200px"></label></div><div class="muted">The '+b.w+' x '+b.h+' px area will repeat as a tile. You can then pick it in Fill, Pattern Overlay and the Pattern Stamp.</div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const k=Math.min(1,512/Math.max(b.w,b.h)),t=mkCanvas(b.w*k,b.h*k);cctx(t).drawImage(flat,b.x,b.y,b.w,b.h,0,0,t.width,t.height);
      const id='user_'+Date.now().toString(36);patCache[id]=t;PATTERNS.push([id,$('#dp-n').value.trim()||'Pattern']);S.patId=id;savePatterns();toast('Pattern saved');
    }}],()=>{$('#dp-n').select();});
}
ACT.definePattern=openDefinePattern;

/* ---------- Purge ---------- */
function purge(what){
  if(!doc){toast('Nothing to purge');return;}
  let n=0;
  if(what==='undo'||what==='hist'||what==='all'){
    const one=e=>{const h=e===null?hist:e.hist,i=e===null?hi:e.hi;if(!h||h.length<2)return;const keep=h[i];n+=h.length-1;h.length=0;h.push(keep);if(e===null)hi=0;else e.hi=0;};
    if(what==='undo')one(null);else{one(null);docs.forEach(e=>{if(e.hist!==hist)one(e);});}
    updateUndo();if(S.tab==='history')renderHistory();
  }
  if(what==='clip'||what==='all'){if(S.clip){S.clip=null;n++;}}
  toast(n?'Purged':'Nothing to purge');
}

/* ---------- Colour settings ---------- */
function openColorSettings(){
  modalOpen('Color Settings','<div class="saform"><div class="row"><b>Working space</b></div><table class="kv"><tr><td>RGB</td><td>sRGB IEC61966-2.1</td></tr><tr><td>Gray</td><td>Dot Gain 20%</td></tr><tr><td>Bit depth</td><td>8 bits per channel</td></tr></table>'
    +'<p class="muted">The editor works in sRGB, the colour space browsers and phones show. Opening a file with another colour profile shows it as sRGB. CMYK and 16 bit editing are not available yet.</p></div>',[{label:'OK',primary:true}]);
}

/* ---------- Keyboard Shortcuts editor ---------- */
function cmdPath(it,path){return path.join(' > ');}
function shortcutRows(){
  const rows=[];
  const walk=(items,path)=>items.forEach(it=>{
    if(it.sep)return;const g=it.items&&Object.getOwnPropertyDescriptor(it,'items');
    if(it.items){if(!(g&&g.get))walk(it.items,path.concat([it.label]));}
    else if(it.fn)rows.push({it,path:path.concat([it.label]).join(' > ')});
  });
  MENUS.forEach(m=>walk(m.items,[m.label]));return rows;
}
function setItemKey(it,combo){
  Object.keys(SHORT).forEach(k=>{if(SHORT[k]===it)delete SHORT[k];});
  it.key=combo||'';
  if(combo){const old=SHORT[combo];if(old&&old!==it&&old.key===combo)old.key='';SHORT[combo]=it;}
}
function applyKeyOverrides(){
  const ov=PREFS.keys;if(!ov)return;
  const rows=shortcutRows();
  Object.keys(ov).forEach(p=>{const r=rows.find(x=>x.path===p);if(r)setItemKey(r.it,ov[p]);});
}
function openShortcuts(){
  const rows=shortcutRows();
  modalOpen('Keyboard Shortcuts for Menus','<div class="muted" style="margin-bottom:6px">Click a shortcut to change it, then press the new keys. Press Delete to remove it. Tool and panel keys (V, B, [ ] ...) are fixed.</div><input type="search" id="ks-q" placeholder="Filter commands" style="width:100%;margin-bottom:6px"><div id="ks-l" class="kslist"></div>',
    [{label:'Use Defaults',cb:()=>{PREFS.keys=null;savePrefs();toast('Shortcuts reset. Reload the app to restore every default.');}},{label:'Done',primary:true}],root=>{
      const list=$('#ks-l',root),q=$('#ks-q',root);let rec=null;
      const paint=()=>{
        const w=q.value.toLowerCase();
        list.innerHTML=rows.filter(r=>!w||r.path.toLowerCase().indexOf(w)>=0).map(r=>'<div class="ksrow"><span>'+esc(r.path)+'</span><button data-p="'+esc(r.path)+'">'+(r.it.key?esc(r.it.key.replace(/\+/g,' + ')):'(none)')+'</button></div>').join('');
      };
      const stop=()=>{if(rec){window.removeEventListener('keydown',rec,true);rec=null;}};
      const prevCancel=modalCancel;modalCancel=()=>{stop();};void prevCancel;
      list.addEventListener('click',e=>{
        const b=e.target.closest('button');if(!b)return;stop();b.textContent='press keys...';b.classList.add('rec');
        rec=ev=>{
          ev.preventDefault();ev.stopImmediatePropagation();
          if(['Control','Shift','Alt','Meta'].indexOf(ev.key)>=0)return;
          const it=rows.find(r=>r.path===b.dataset.p).it;let combo=comboOf(ev);
          if(ev.key==='Escape'){stop();paint();return;}
          if(ev.key==='Delete'||ev.key==='Backspace')combo='';
          setItemKey(it,combo);PREFS.keys=PREFS.keys||{};PREFS.keys[b.dataset.p]=combo;savePrefs();stop();paint();
        };
        window.addEventListener('keydown',rec,true);
      });
      q.addEventListener('input',paint);paint();
    },{wide:true});
}
ACT.shortcuts=openShortcuts;

/* ---------- Preferences ---------- */
function openPrefs(tab){
  tab=tab||'general';
  const tabs=[['general','General'],['interface','Interface'],['hist','History & Cache']];
  const body=t=>{
    if(t==='interface')return '<div class="h">Color Theme</div><div class="themes">'+Object.keys(THEMES).map(n=>'<button class="thm'+((PREFS.theme||'Darkest')===n?' on':'')+'" data-t="'+n+'" style="background:'+THEMES[n]['--panel']+';color:'+THEMES[n]['--fg']+'">'+n+'</button>').join('')+'</div>'
      +'<div class="h" style="margin-top:14px">Text size</div><div class="themes">'+[[12,'Small'],[13,'Medium'],[15,'Large']].map(s=>'<button class="thm'+((PREFS.ui||13)===s[0]?' on':'')+'" data-u="'+s[0]+'">'+s[1]+'</button>').join('')+'</div>';
    if(t==='hist')return eRng('pf-h','History states',20,200,S.histMax||50,1,'')+'<p class="muted">More states let you step further back, but use more memory. Large pictures on phones work best with 30 or fewer.</p>'
      +'<div class="h">Purge</div><div class="row"><button data-pg="undo">Histories</button> <button data-pg="clip">Clipboard</button> <button data-pg="all">All</button></div>';
    return '<p>LILKESSphoto Pro keeps your settings on this device.</p><div class="row"><button id="pf-keys">Keyboard Shortcuts...</button> <button id="pf-reset">Reset All Preferences</button></div><p class="muted">Rulers, grid and guides are in the View menu. Panels are in the Window menu.</p>';
  };
  modalOpen('Preferences','<div class="ptabs">'+tabs.map(t=>'<button class="ptab'+(t[0]===tab?' on':'')+'" data-tab="'+t[0]+'">'+t[1]+'</button>').join('')+'</div><div id="pf-b" class="pfbody">'+body(tab)+'</div>',[{label:'OK',primary:true}],root=>{
    const wire=()=>{
      const b=$('#pf-b',root);
      $$('.thm',b).forEach(x=>x.onclick=()=>{if(x.dataset.t)PREFS.theme=x.dataset.t;if(x.dataset.u)PREFS.ui=+x.dataset.u;savePrefs();applyPrefs();b.innerHTML=body('interface');wire();});
      $$('[data-pg]',b).forEach(x=>x.onclick=()=>purge(x.dataset.pg));
      const h=$('#pf-h',b);if(h){const out=$('#pf-h_v',b);h.oninput=()=>{out.textContent=h.value;PREFS.hist=+h.value;savePrefs();applyPrefs();};}
      const k=$('#pf-keys',b);if(k)k.onclick=()=>{closeModal();setTimeout(openShortcuts,30);};
      const r=$('#pf-reset',b);if(r)r.onclick=()=>{Object.keys(PREFS).forEach(x=>delete PREFS[x]);try{localStorage.removeItem('lk_prefs');}catch(e){}applyPrefs();toast('Preferences reset. Reload the app to restore default shortcuts.');};
    };
    $$('.ptab',root).forEach(t=>t.onclick=()=>{$$('.ptab',root).forEach(x=>x.classList.toggle('on',x===t));$('#pf-b',root).innerHTML=body(t.dataset.tab);wire();});
    wire();
  });
}
ACT.prefs=()=>openPrefs('general');

/* ---------- the Edit menu ---------- */
(function(){
  const M=MENUS.find(m=>m.label==='Edit');
  const dyn=(it,get)=>{Object.defineProperty(it,'label',{get,enumerable:true,configurable:true});return it;};
  const stepName=i=>{const h=hist[i];return h&&h.label&&h.label!=='Edit'?h.label:'';};
  const hasDoc=()=>!doc;
  M.items=[
    dyn(mi('Undo','Ctrl+Z','undo',{dis:()=>!doc||hi<=0}),()=>'Undo'+(doc&&hi>0&&stepName(hi)?' '+stepName(hi):'')),
    dyn(mi('Redo','Ctrl+Shift+Z','redo',{dis:()=>!doc||hi>=hist.length-1}),()=>'Redo'+(doc&&hi<hist.length-1&&stepName(hi+1)?' '+stepName(hi+1):'')),
    mi('Step Backward','Ctrl+Alt+Z','undo',{dis:()=>!doc||hi<=0}),
    mi('Toggle Last State','','toggleState',{dis:()=>!doc||hist.length<2}),SEP,
    mi('Fade...','Ctrl+Shift+F','fade',{dis:()=>!doc||hi<1}),SEP,
    mi('Cut','Ctrl+X','cut'),mi('Copy','Ctrl+C','copy'),mi('Copy Merged','Ctrl+Shift+C','copyMerged'),mi('Paste','Ctrl+V','paste'),
    sub('Paste Special',[mi('Paste in Place','Ctrl+Shift+V','pasteInPlace'),mi('Paste Into','Ctrl+Alt+Shift+V','pasteInto'),mi('Paste Outside','','pasteOutside')]),
    mi('Clear','Delete','clear'),SEP,
    al('Search...','Ctrl+F','search'),mi('Find and Replace Text...','','findReplace'),SEP,
    mi('Fill...','Shift+F5','fillDialog'),mi('Stroke...','','strokeDialog'),mi('Content-Aware Fill...','','contentAwareFill'),SEP,
    mi('Content-Aware Scale','Ctrl+Alt+Shift+C','contentScale'),
    mi('Free Transform','Ctrl+T','transform'),
    sub('Transform',[mi('Again','Ctrl+Shift+T','transformAgain'),SEP,mi('Scale...','','xScale'),mi('Rotate...','','xRotate'),mi('Skew...','','xSkew'),mi('Distort...','','xDistort'),mi('Perspective...','','xPerspective'),mi('Warp...','','xWarp'),SEP,
      mi('Rotate 180°','','xRot180'),mi('Rotate 90° Clockwise','','xRotCW'),mi('Rotate 90° Counter Clockwise','','xRotCCW'),SEP,mi('Flip Horizontal','','lflipH'),mi('Flip Vertical','','lflipV'),SEP,mi('Fit Inside Canvas','','fitLayer'),mi('Fill Canvas','','fillLayer')]),
    SEP,
    mi('Define Pattern...','','definePattern'),
    sub('Purge',[mi('Undo','',()=>purge('undo')),mi('Clipboard','',()=>purge('clip')),mi('Histories','',()=>purge('hist')),mi('All','',()=>purge('all'))]),SEP,
    al('Color Settings...','Ctrl+Shift+K',()=>openColorSettings()),al('Keyboard Shortcuts...','Ctrl+Alt+Shift+K','shortcuts'),
    sub('Preferences',[al('General...','Ctrl+K',()=>openPrefs('general')),al('Interface...','',()=>openPrefs('interface')),al('History & Cache...','',()=>openPrefs('hist'))])
  ];
  // Photoshop's last-filter key is Ctrl+Alt+F; Ctrl+F is Search
  const F=MENUS.find(m=>m.label==='Filter');if(F){const lf=F.items.find(i=>i.label==='Last filter'||i.label==='Last Filter');if(lf){lf.key='Ctrl+Alt+F';}}
  Object.keys(SHORT).forEach(k=>{if(/^(Ctrl\+F|Ctrl\+Shift\+F|Shift\+F5|Ctrl\+Alt\+Shift\+C|Ctrl\+Shift\+C|Ctrl\+Alt\+Shift\+V|Ctrl\+Shift\+T|Ctrl\+K|Ctrl\+Shift\+K|Ctrl\+Alt\+Shift\+K|Ctrl\+Alt\+Z|Ctrl\+Alt\+F)$/.test(k))delete SHORT[k];});
  const walk=its=>its.forEach(it=>{if(it.items){const g=Object.getOwnPropertyDescriptor(it,'items');if(!(g&&g.get))walk(it.items);}else if(it.key){const k=it.key.replace(/^Ctrl\+Shift\+Alt\+/,'Ctrl+Alt+Shift+');SHORT[k]=it;}});
  walk(M.items);if(F)walk(F.items);
  applyKeyOverrides();
})();
