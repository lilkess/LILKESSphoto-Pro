/* ===== Fonts: registry, categories, Google Fonts loader, picker, upload, local fonts ===== */
const FONT_CATS={
 'Sans-serif':['Inter','Poppins','Work Sans','Instrument Sans','Outfit','Montserrat','Roboto','Open Sans','Lato','Raleway','Nunito','Josefin Sans','Quicksand','Rubik','Barlow','Fira Sans','Source Sans 3','Ubuntu','Archivo','Urbanist','Sora','Lexend','Jost','Space Grotesk','Syne','DM Sans','Manrope','Plus Jakarta Sans','Mulish','Karla','Cabin','Hind','Noto Sans','PT Sans','Titillium Web','Exo 2','Kanit','Prompt','Heebo','Bricolage Grotesque','Red Hat Display','Figtree','Be Vietnam Pro','Albert Sans','Questrial','Varela Round','Comfortaa'],
 'Display':['Anton','Bebas Neue','Oswald','Fjalla One','League Gothic','Archivo Black','Black Ops One','Bangers','Righteous','Russo One','Teko','Staatliches','Abril Fatface','Alfa Slab One','Fredoka','Lilita One','Luckiest Guy','Titan One','Monoton','Orbitron','Audiowide','Bungee','Big Shoulders Display','Erica One','Boldonse','Smooch Sans','Jura','Tektur','Passion One','Bowlby One','Paytone One','Sigmar One','Rammetto One','Shrikhand','Chango','Fascinate','Racing Sans One','Press Start 2P','Rubik Mono One','Bungee Shade','Faster One','Creepster','Nosifer','Eater','Special Elite','Poiret One','Italiana','Gloock','Archivo Narrow','Pathway Extreme','Squada One','Secular One','Ultra','Wendy One','Gochi Hand'],
 'Serif':['Playfair Display','Merriweather','Cormorant Garamond','EB Garamond','DM Serif Display','Bitter','Cinzel','Spectral','Zilla Slab','Vollkorn','Prata','Bodoni Moda','Fraunces','Marcellus','Roboto Slab','Lora','Libre Baskerville','Young Serif','Instrument Serif','IBM Plex Serif','Crimson Pro','Crimson Text','Noto Serif','PT Serif','Libre Caslon Text','Cormorant','Old Standard TT','Rufina','Cardo','Gelasio','Arvo','Domine','Josefin Slab','Yeseva One','Rozha One','Playfair Display SC','Cinzel Decorative','Arsenal SC','Abhaya Libre','Alike','Lustria'],
 'Script':['Pacifico','Lobster','Lobster Two','Dancing Script','Great Vibes','Satisfy','Sacramento','Allura','Alex Brush','Parisienne','Tangerine','Yellowtail','Kaushan Script','Cookie','Playball','Pinyon Script','Courgette','Norican','Marck Script','Mr Dafoe','Rouge Script','Herr Von Muellerhoff','Monsieur La Doulaise','Italianno','Merienda','Leckerli One','Berkshire Swash','Niconne','Damion','Qwigley','Arizonia','Bad Script','Style Script','Petit Formal Script','Euphoria Script','Mea Culpa','Ballet'],
 'Handwriting':['Caveat','Amatic SC','Permanent Marker','Indie Flower','Shadows Into Light','Rock Salt','Nothing You Could Do','Patrick Hand','Gloria Hallelujah','Covered By Your Grace','Reenie Beanie','Kalam','Architects Daughter','Handlee','Just Another Hand','Walter Turncoat','Schoolbell','Coming Soon','Homemade Apple','Sue Ellen Francisco','Nanum Pen Script','Gaegu','Yomogi','Short Stack','Neucha','Swanky and Moo Moo','Fuzzy Bubbles'],
 'Fun':['Baloo 2','Chewy','Comic Neue','Bubblegum Sans','Fredericka the Great','Londrina Solid','Modak','Gluten','Sniglet','Mochiy Pop One','Rubik Bubbles','Rubik Glitch','Pixelify Sans','Silkscreen','Slackey','Spicy Rice','Henny Penny','Mystery Quest','Butcherman','Emilys Candy','Margarine','Kavoon','Oi','Rampart One','DotGothic16','Bungee Inline','Fontdiner Swanky','Lemon','Gorditas','Chelsea Market'],
 'Monospace':['JetBrains Mono','IBM Plex Mono','Red Hat Mono','Geist Mono','DM Mono','Roboto Mono','Space Mono','Source Code Pro','Fira Code','Inconsolata','Ubuntu Mono','Courier Prime','VT323','Anonymous Pro','Share Tech Mono','Major Mono Display'],
 'System':['Arial','Helvetica','Georgia','Times New Roman','Verdana','Tahoma','Trebuchet MS','Impact','Courier New','Palatino','Palatino Linotype','Century Gothic','Calibri','Cambria','Comic Sans MS','Bookman Old Style','Monotype Corsiva']
};
const FONT_EMBEDDED=new Set(['Inter','Poppins','Work Sans','Instrument Sans','Lora','IBM Plex Serif','Crimson Pro','Outfit','Bricolage Grotesque','Big Shoulders Display','National Park','JetBrains Mono','IBM Plex Mono','Red Hat Mono','Geist Mono','Smooch Sans','Jura','Tektur','Libre Baskerville','Gloock','Young Serif','Instrument Serif','Italiana','Arsenal SC','Erica One','Boldonse','Poiret One','Pixelify Sans','Silkscreen','Nothing You Could Do','DM Mono']);
const FONT_SYSTEM=new Set(FONT_CATS['System']);
const FONT_SINGLE=new Set(['Anton','Bebas Neue','Fjalla One','League Gothic','Archivo Black','Black Ops One','Bangers','Righteous','Russo One','Staatliches','Abril Fatface','Alfa Slab One','Lilita One','Luckiest Guy','Titan One','Monoton','Audiowide','Passion One','Bowlby One','Paytone One','Sigmar One','Rammetto One','Shrikhand','Chango','Fascinate','Racing Sans One','Press Start 2P','Rubik Mono One','Bungee Shade','Faster One','Creepster','Nosifer','Eater','Special Elite','Squada One','Secular One','Ultra','Wendy One','Gochi Hand','DM Serif Display','Prata','Marcellus','Yeseva One','Rozha One','Alike','Lustria','Old Standard TT','Rufina','Cardo','Pacifico','Lobster','Lobster Two','Great Vibes','Satisfy','Sacramento','Allura','Alex Brush','Parisienne','Tangerine','Yellowtail','Kaushan Script','Cookie','Playball','Pinyon Script','Courgette','Norican','Marck Script','Mr Dafoe','Rouge Script','Herr Von Muellerhoff','Monsieur La Doulaise','Italianno','Leckerli One','Berkshire Swash','Niconne','Damion','Qwigley','Arizonia','Bad Script','Style Script','Petit Formal Script','Euphoria Script','Mea Culpa','Ballet','Permanent Marker','Indie Flower','Shadows Into Light','Rock Salt','Patrick Hand','Gloria Hallelujah','Covered By Your Grace','Reenie Beanie','Architects Daughter','Handlee','Just Another Hand','Walter Turncoat','Schoolbell','Coming Soon','Homemade Apple','Sue Ellen Francisco','Nanum Pen Script','Gaegu','Yomogi','Short Stack','Neucha','Swanky and Moo Moo','Fuzzy Bubbles','Chewy','Bubblegum Sans','Fredericka the Great','Londrina Solid','Modak','Sniglet','Mochiy Pop One','Slackey','Spicy Rice','Henny Penny','Mystery Quest','Butcherman','Emilys Candy','Margarine','Kavoon','Oi','Rampart One','DotGothic16','Fontdiner Swanky','Lemon','Gorditas','Chelsea Market','VT323','Share Tech Mono','Major Mono Display','Anonymous Pro','Pathway Extreme','Cinzel Decorative','Playfair Display SC','Josefin Slab','Rubik Bubbles','Rubik Glitch','Bungee Inline','Bungee','Alfa Slab One','Questrial','Varela Round','Domine','Arvo','Gelasio','Merienda','Mea Culpa','Courier Prime','Source Code Pro','Fira Code','Inconsolata','Ubuntu Mono','Roboto Mono','Space Mono']);
const FONT_USER=[];      // uploaded fonts
const FONT_LOCAL=[];     // installed on this computer
const FONT_CAT_OF={};
(function(){
  const seen=new Set(FONTS);
  for(const c in FONT_CATS)for(const n of FONT_CATS[c]){if(!FONT_CAT_OF[n])FONT_CAT_OF[n]=c;if(!seen.has(n)){seen.add(n);FONTS.push(n);}}
})();
function fontCatOf(n){return FONT_CAT_OF[n]||(FONT_USER.includes(n)?'My fonts':FONT_LOCAL.includes(n)?'Installed':'Other');}
function fontFallback(f){
  const c=FONT_CAT_OF[f];
  if(c==='Serif')return 'Georgia,"Times New Roman",serif';
  if(c==='Monospace')return '"Courier New",monospace';
  if(c==='Script'||c==='Handwriting')return 'cursive,sans-serif';
  if(c==='System'){if(/Georgia|Times|Palatino|Cambria|Bookman/.test(f))return 'serif';if(/Courier/.test(f))return 'monospace';}
  return 'sans-serif';
}
function fontOptionsHtml(sel){
  const order=['My fonts','Installed','Sans-serif','Display','Serif','Script','Handwriting','Fun','Monospace','System'];
  const groups={};
  const add=(c,n)=>{(groups[c]=groups[c]||[]).push(n);};
  FONT_USER.forEach(n=>add('My fonts',n));FONT_LOCAL.forEach(n=>add('Installed',n));
  for(const c in FONT_CATS)FONT_CATS[c].forEach(n=>add(c,n));
  let known=new Set(FONTS);FONT_USER.forEach(n=>known.add(n));FONT_LOCAL.forEach(n=>known.add(n));
  let extra='';
  if(sel&&!known.has(sel))extra='<option selected>'+esc(sel)+'</option>';
  return extra+order.filter(c=>groups[c]).map(c=>'<optgroup label="'+c+'">'+groups[c].map(n=>'<option'+(n===sel?' selected':'')+'>'+esc(n)+'</option>').join('')+'</optgroup>').join('');
}
/* ---- Google Fonts (needs internet; embedded + system fonts work offline) ---- */
const gfLoaded=new Set();
function gfUrl(names){
  return 'https://fonts.googleapis.com/css2?'+names.map(n=>'family='+encodeURIComponent(n).replace(/%20/g,'+')+(FONT_SINGLE.has(n)?'':':wght@400;700')).join('&')+'&display=swap';
}
function gfLink(names,retry){
  const l=document.createElement('link');l.rel='stylesheet';l.href=gfUrl(names);
  l.onerror=()=>{l.remove();if(!retry&&names.length>1)names.forEach(n=>gfLink([n],true));else if(!FONT_SINGLE.has(names[0])&&retry===true){const k=document.createElement('link');k.rel='stylesheet';k.href='https://fonts.googleapis.com/css2?family='+encodeURIComponent(names[0]).replace(/%20/g,'+')+'&display=swap';document.head.appendChild(k);}};
  document.head.appendChild(l);
}
function loadGoogleFonts(){
  const names=[];
  for(const c in FONT_CATS)if(c!=='System')for(const n of FONT_CATS[c])if(!FONT_EMBEDDED.has(n)&&!gfLoaded.has(n)){gfLoaded.add(n);names.push(n);}
  for(let i=0;i<names.length;i+=10)gfLink(names.slice(i,i+10));
}
/* ---- re-render text when fonts finish loading ---- */
let fontRerT=0;
function rerenderAllText(){
  let n=0;
  for(const e of docs){const d=e.doc;if(!d)continue;for(const l of d.layers){if(l.type==='text'&&l.props){try{renderText(l);n++;}catch(_){}}}}
  if(n)redraw();
}
if(document.fonts&&document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',()=>{clearTimeout(fontRerT);fontRerT=setTimeout(rerenderAllText,200);});
/* ---- uploaded fonts (IndexedDB) ---- */
function fontDB(){return new Promise((res,rej)=>{try{const r=indexedDB.open('lk_fonts',1);r.onupgradeneeded=()=>r.result.createObjectStore('f',{keyPath:'name'});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);}catch(e){rej(e);}});}
async function fontDBPut(name,buf){const db=await fontDB();return new Promise((res,rej)=>{const t=db.transaction('f','readwrite');t.objectStore('f').put({name,buf});t.oncomplete=()=>res();t.onerror=()=>rej(t.error);});}
async function fontDBAll(){const db=await fontDB();return new Promise((res,rej)=>{const q=db.transaction('f').objectStore('f').getAll();q.onsuccess=()=>res(q.result||[]);q.onerror=()=>rej(q.error);});}
async function fontDBDel(name){const db=await fontDB();return new Promise((res)=>{const t=db.transaction('f','readwrite');t.objectStore('f').delete(name);t.oncomplete=()=>res();t.onerror=()=>res();});}
async function registerUserFont(name,buf,save){
  const ff=new FontFace(name,buf);await ff.load();document.fonts.add(ff);
  if(!FONT_USER.includes(name))FONT_USER.push(name);
  if(save)try{await fontDBPut(name,buf);}catch(_){}
  return name;
}
async function restoreUserFonts(){try{const all=await fontDBAll();for(const f of all){try{await registerUserFont(f.name,f.buf,false);}catch(_){}}if(all.length){refreshFontSelects();}}catch(_){}}
function uploadFonts(done){
  const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.accept='.ttf,.otf,.woff,.woff2';
  inp.onchange=async()=>{
    let ok=0;
    for(const f of inp.files){
      try{const buf=await f.arrayBuffer();const name=f.name.replace(/\.[^.]+$/,'').replace(/[-_]+/g,' ').replace(/\s+(Regular|Bold|Italic)$/i,'').trim();await registerUserFont(name,buf,true);ok++;}
      catch(e){toast('Could not load '+f.name);}
    }
    if(ok){toast(ok+' font'+(ok>1?'s':'')+' added (saved on this device)');refreshFontSelects();}
    if(done)done();
  };
  inp.click();
}
async function loadLocalFonts(){
  if(!window.queryLocalFonts){toast('Your browser cannot list installed fonts. Use Upload font instead.');return false;}
  try{
    const list=await window.queryLocalFonts();const fams=new Set();
    for(const f of list)fams.add(f.family);
    FONT_LOCAL.length=0;[...fams].sort().forEach(n=>{if(!FONT_CAT_OF[n])FONT_LOCAL.push(n);});
    toast(FONT_LOCAL.length+' installed fonts found');refreshFontSelects();return true;
  }catch(e){toast('Permission to read installed fonts was denied');return false;}
}
function refreshFontSelects(){
  document.querySelectorAll('#p-font,[data-ch="font"]').forEach(s=>{const v=s.value;s.innerHTML=fontOptionsHtml(v);s.value=v;});
}
/* ---- picker dialog ---- */
function openFontPicker(current,onPick){
  const cats=['All','My fonts','Installed','Sans-serif','Display','Serif','Script','Handwriting','Fun','Monospace','System'];
  let cat='All',q='';
  modalOpen('Fonts','<div class="fp-top"><input type="search" id="fp-q" placeholder="Search fonts" autocomplete="off"><button id="fp-up">Upload font…</button><button id="fp-loc">Installed fonts…</button></div>'+
    '<div class="fp-chips">'+cats.map(c=>'<button class="chip'+(c==='All'?' on':'')+'" data-c="'+c+'">'+c+'</button>').join('')+'</div><div class="fp-list" id="fp-list"></div>',
    [{label:'Close'}],root=>{
      const list=root.querySelector('#fp-list');
      const io=('IntersectionObserver' in window)?new IntersectionObserver(es=>{es.forEach(en=>{if(en.isIntersecting){const s=en.target.querySelector('.fp-s');if(s&&!s.dataset.on){s.dataset.on=1;const n=en.target.dataset.f;s.style.fontFamily='"'+n+'",'+fontFallback(n);try{document.fonts.load('18px "'+n+'"','Aa');}catch(_){}}io.unobserve(en.target);}});},{root:list,rootMargin:'120px'}):null;
      function all(){const a=[];FONT_USER.forEach(n=>a.push(n));FONT_LOCAL.forEach(n=>a.push(n));FONTS.forEach(n=>{if(!a.includes(n))a.push(n);});return a;}
      function draw(){
        const items=all().filter(n=>(cat==='All'||fontCatOf(n)===cat)&&(!q||n.toLowerCase().includes(q)));
        list.innerHTML=items.length?items.map(n=>'<div class="fp-it'+(n===current?' sel':'')+'" data-f="'+esc(n)+'"><span class="fp-n">'+esc(n)+'</span><span class="fp-s">The quick brown fox 123</span></div>').join(''):'<p style="opacity:.6;padding:12px">No fonts match.</p>';
        list.querySelectorAll('.fp-it').forEach(el=>{if(io)io.observe(el);else{const s=el.querySelector('.fp-s');s.style.fontFamily='"'+el.dataset.f+'"';}});
      }
      draw();
      root.querySelector('#fp-q').addEventListener('input',e=>{q=e.target.value.trim().toLowerCase();draw();});
      root.querySelector('.fp-chips').addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;cat=b.dataset.c;root.querySelectorAll('.fp-chips .chip').forEach(x=>x.classList.toggle('on',x===b));draw();});
      list.addEventListener('click',e=>{const it=e.target.closest('.fp-it');if(!it)return;const n=it.dataset.f;closeModal();onPick(n);});
      root.querySelector('#fp-up').onclick=()=>uploadFonts(draw);
      root.querySelector('#fp-loc').onclick=async()=>{if(await loadLocalFonts()){cat='Installed';root.querySelectorAll('.fp-chips .chip').forEach(x=>x.classList.toggle('on',x.dataset.c==='Installed'));draw();}};
      setTimeout(()=>root.querySelector('#fp-q').focus(),50);
    },{wide:true});
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-fontpick]');if(!b)return;
  const sel=b.parentElement.querySelector('select');if(!sel)return;
  openFontPicker(sel.value,n=>{
    if(![...sel.options].some(o=>o.value===n)){const o=document.createElement('option');o.textContent=n;sel.appendChild(o);}
    sel.value=n;sel.dispatchEvent(new Event('change',{bubbles:true}));
  });
});
setTimeout(()=>{loadGoogleFonts();restoreUserFonts();},600);
