/* ===== Camera Raw Filter: events, open, apply ===== */
function crClamp(v,a,b){return Math.max(a,Math.min(b,v));}
function crNear(a,b,px){return Math.hypot(a[0]-b[0],a[1]-b[1])<=px;}
function crScreen(nx,ny){const v=crView(),r=0;return [v.x+nx*CR.pw*v.z,v.y+ny*CR.ph*v.z];}
function crWire(){
  const root=$('#cr'),cv=$('#crc'),pn=$('#crpanel');
  /* toolbar */
  root.querySelectorAll('.crt').forEach(b=>b.addEventListener('click',()=>{crSetTool(b.dataset.tool);if(['hand','zoom','wb','samp','tai'].includes(b.dataset.tool)&&['mask','heal','red'].includes(CR.sec)){CR.sec='edit';crRenderPanel();}}));
  $('#cr-tai').onchange=e=>{CR.taiMode=e.target.value;};
  $('#cr-view').onclick=()=>crSetView((CR.vmode+1)%4);
  const bf=$('#cr-bef');bf.onpointerdown=()=>{CR.holdBefore=true;crDraw();};bf.onpointerup=bf.onpointerleave=()=>{if(CR.holdBefore){CR.holdBefore=false;crDraw();}};
  $('#cr-fit').onclick=()=>{CR.zoom=0;CR.cx=CR.pw/2;CR.cy=CR.ph/2;$('#cr-zoom').value='0';crDraw();};
  $('#cr-zoom').onchange=e=>{CR.zoom=+e.target.value;crDraw();};
  $('#cr-clipS').onclick=e=>{CR.clipS=!CR.clipS;e.target.classList.toggle('on',CR.clipS);crDraw();crHist();};
  $('#cr-clipH').onclick=e=>{CR.clipH=!CR.clipH;e.target.classList.toggle('on',CR.clipH);crDraw();crHist();};
  $('#cr-undo').onclick=()=>crUndo(-1);$('#cr-redo').onclick=()=>crUndo(1);
  /* bottom */
  $('#cr-prev').onchange=crQueue;
  $('#cr-nd').onchange=()=>{CR.nd=$('#cr-nd').checked;crPrepare();crRender();};
  $('#cr-reset').onclick=()=>{const sn=CR.st.snaps;CR.st=crNewState();CR.st.snaps=sn;CR.selMask=null;CR.maskDirty=true;crRenderPanel();crQueue();crPush();};
  $('#cr-auto').onclick=()=>{CR.st.p=raw_params(Object.assign({},CR.st.p,raw_autoSettings(CR.prevIn)));CR.st.wb='As Shot';crRenderPanel();crQueue();crPush();};
  $('#cr-cancel').onclick=crClose;$('#cr-ok').onclick=crApply;
  $('#crtabs').onclick=e=>{const b=e.target.closest('button[data-sec]');if(!b)return;CR.sec=b.dataset.sec;crRenderPanel();crDraw();};
  /* panel: sliders */
  pn.addEventListener('input',e=>{
    const el=e.target;if(!el.dataset.p)return;
    let v=+el.value;if(isNaN(v))return;const mn=+el.min,mx=+el.max;v=crClamp(v,mn,mx);
    crSet(el.dataset.p,v);
    pn.querySelectorAll('[data-p="'+el.dataset.p+'"]').forEach(o=>{if(o!==el)o.value=v;});
    const k=el.dataset.p;
    if(k==='p:temp'||k==='p:tint'){CR.st.wb='Custom';const w=$('#cr-wb');if(w)w.value='Custom';}
    if(k.startsWith('o:h')){const s=CR.sel&&CR.sel.kind==='spot'?CR.st.spots[CR.sel.i]:null;if(s){s.r=CR.opt.hsize/100;s.feather=CR.opt.hfeather;s.opacity=CR.opt.hop;}}
    if(k==='o:pamt'){return;}
    if(k.startsWith('m:'))CR.maskDirty=true;
    if(k.startsWith('o:')&&!k.startsWith('o:h')){crDraw();return;}
    if(k.startsWith('p:grade'))crDrawWheels();
    crQueue();
  });
  pn.addEventListener('change',e=>{const el=e.target;
    if(el.dataset&&el.dataset.p){crPush();return;}
    if(el.name==='crtr'){CR.st.p.bw=el.value==='b';crQueue();crPush();}
    else if(el.id==='cr-prof'){CR.st.profile=el.value;crQueue();crPush();}
    else if(el.id==='cr-wb'){const v=el.value;CR.st.wb=v;
      if(v==='Auto'){const m=crMeanRGB(CR.prevIn,0,0,0);let sr=0,sg=0,sb=0,n=0,d=CR.prevIn.data;for(let i=0;i<d.length;i+=16){sr+=d[i];sg+=d[i+1];sb+=d[i+2];n++;}const [t,ti]=crSolveWB([sr/n,sg/n,sb/n]);CR.st.p.temp=Math.round(t*0.8);CR.st.p.tint=Math.round(ti*0.8);}
      else if(v==='As Shot'){CR.st.p.temp=0;CR.st.p.tint=0;}else if(CR_WB[v]){CR.st.p.temp=CR_WB[v][0];CR.st.p.tint=CR_WB[v][1];}
      crSync();crQueue();crPush();}
    else if(el.id==='cr-cch'){CR.cch=el.value;crDrawCurve();}
    else if(el.id==='cr-ca'){CR.st.p.caFix=el.checked;crQueue();crPush();}
    else if(el.id==='cr-ov'){CR.overlay=el.checked;CR.maskDirty=true;crDraw();}
    else if(el.id==='cr-auto2')CR.opt.auto=el.checked;else if(el.id==='cr-erase')CR.opt.erase=el.checked;
  });
  pn.addEventListener('dblclick',e=>{
    const r=e.target.closest('[data-reset]');if(r){const k=r.dataset.reset,d=crDefault(k);if(d!==undefined){crSet(k,d);crSync();if(k.startsWith('m:'))CR.maskDirty=true;crQueue();crPush();}return;}
    if(e.target.id==='cr-curve')crCurveDbl(e);
    if(e.target.classList.contains('crwheel')){const g=CR.st.p.grade[e.target.dataset.z];g.h=0;g.s=0;crDrawWheels();crQueue();crPush();}
  });
  pn.addEventListener('toggle',e=>{if(e.target.dataset&&e.target.dataset.d)CR.open[e.target.dataset.d]=e.target.open;},true);
  pn.addEventListener('pointerdown',e=>{if(e.target.id==='cr-curve')crCurveDown(e);else if(e.target.classList.contains('crwheel')){e.target.setPointerCapture(e.pointerId);CR.wd=true;crWheelSet(e);}});
  pn.addEventListener('pointermove',e=>{if(e.target.id==='cr-curve')crCurveMove(e);else if(CR.wd&&e.target.classList.contains('crwheel'))crWheelSet(e);});
  pn.addEventListener('pointerup',e=>{if(e.target.id==='cr-curve')crCurveUp();else if(CR.wd){CR.wd=false;crPush();}});
  /* panel: buttons */
  pn.addEventListener('click',e=>{
    const t=e.target.closest('button,.crmk,.crpre');if(!t)return;
    if(t.id==='cr-wbpick'){crSetTool('wb');return;}
    if(t.id==='cr-creset'){CR.st.p[CR.cch||'curve']=null;crDrawCurve();crQueue();crPush();return;}
    if(t.dataset.hm){CR.hslMode=t.dataset.hm;crRenderPanel();return;}
    if(t.dataset.mt){crSetTool(t.dataset.mt);crRenderPanel();return;}
    if(t.dataset.mkdel!=null){CR.st.masks.splice(+t.dataset.mkdel,1);CR.selMask=null;CR.maskDirty=true;crRenderPanel();crQueue();crPush();return;}
    if(t.dataset.mkinv!=null){const m=CR.st.masks[+t.dataset.mkinv];m.invert=!m.invert;CR.maskDirty=true;crQueue();crPush();return;}
    if(t.dataset.mkov!=null){CR.selMask=+t.dataset.mkov;CR.overlay=true;CR.maskDirty=true;crRenderPanel();crDraw();return;}
    if(t.dataset.mk!=null){CR.selMask=+t.dataset.mk;CR.maskDirty=true;CR.ovC=null;crRenderPanel();crDraw();return;}
    if(t.dataset.hmode){CR.opt.hmode=t.dataset.hmode;crSetTool(t.dataset.hmode);const s=CR.sel&&CR.sel.kind==='spot'?CR.st.spots[CR.sel.i]:null;if(s){s.mode=t.dataset.hmode;crQueue();crPush();}crRenderPanel();return;}
    if(t.id==='cr-delspot'&&CR.sel){CR.st.spots.splice(CR.sel.i,1);CR.sel=null;crRenderPanel();crQueue();crPush();return;}
    if(t.id==='cr-clrspots'){CR.st.spots=[];CR.sel=null;crRenderPanel();crQueue();crPush();return;}
    if(t.id==='cr-clrred'){CR.st.reds=[];crRenderPanel();crQueue();crPush();return;}
    if(t.id==='cr-snapnew'){const c=JSON.parse(JSON.stringify(CR.st));c.snaps=[];CR.st.snaps.push({name:'Snapshot '+(CR.st.snaps.length+1),s:JSON.stringify(c)});crRenderPanel();crPush();return;}
    if(t.dataset.snapdel!=null){CR.st.snaps.splice(+t.dataset.snapdel,1);crRenderPanel();crPush();return;}
    if(t.dataset.snap!=null){const sn=CR.st.snaps,c=JSON.parse(sn[+t.dataset.snap].s);c.snaps=sn;CR.st=c;CR.selMask=null;CR.maskDirty=true;crRenderPanel();crQueue();crPush();return;}
    if(t.id==='cr-presave'){const n=prompt('Preset name','My preset');if(!n)return;const a=crUserPresets();a.push({name:n,p:JSON.parse(JSON.stringify(CR.st.p))});crSaveUserPresets(a);crRenderPanel();return;}
    if(t.dataset.predel!=null){const a=crUserPresets();a.splice(+t.dataset.predel.slice(2),1);crSaveUserPresets(a);crRenderPanel();return;}
    if(t.dataset.pre){crApplyPreset(t.dataset.pre);return;}
  });
  /* stage */
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  cv.addEventListener('wheel',e=>{e.preventDefault();crZoomAt(e,e.deltaY<0?1.2:1/1.2);},{passive:false});
  cv.addEventListener('pointerdown',crDown);cv.addEventListener('pointermove',crMove);cv.addEventListener('pointerup',crUp);cv.addEventListener('pointercancel',crUp);
  cv.addEventListener('pointerleave',()=>{CR.mouse=null;crDraw();});
  window.addEventListener('resize',()=>{if(CR)crDraw();});
  document.addEventListener('keydown',crKey,true);document.addEventListener('keyup',e=>{if(CR&&e.key==='\\'){CR.holdBefore=false;crDraw();}},true);
}
function crZoomAt(e,f){const v=crView(),r=$('#crc').getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,ix=(mx-v.x)/v.z,iy=(my-v.y)/v.z,nz=crClamp(v.z*f,0.05,8);
  CR.zoom=nz;CR.cx=ix-(mx-v.W/2)/nz;CR.cy=iy-(my-v.H/2)/nz;$('#cr-zoom').value='';crDraw();}
function crKey(e){
  if(!CR||$('#cr').hidden)return;
  const tg=e.target,typing=tg&&((tg.tagName==='INPUT'&&['text','number'].includes(tg.type))||tg.tagName==='TEXTAREA');
  const k=e.key,ctrl=e.ctrlKey||e.metaKey;
  if(ctrl&&(k==='z'||k==='Z')){e.preventDefault();e.stopPropagation();crUndo(e.shiftKey?1:-1);return;}
  if(ctrl&&(k==='y'||k==='Y')){e.preventDefault();e.stopPropagation();crUndo(1);return;}
  if(ctrl&&k==='0'){e.preventDefault();e.stopPropagation();$('#cr-fit').click();return;}
  if(ctrl&&k==='1'){e.preventDefault();e.stopPropagation();CR.zoom=1;crDraw();return;}
  if(typing)return;
  e.stopPropagation();
  if(k==='Escape'){crClose();return;}
  if(k==='Enter'&&tg.tagName!=='BUTTON'){crApply();return;}
  if(ctrl)return;
  const m={h:'hand',z:'zoom',i:'wb',s:'samp',t:'tai',b:'brush',g:'linear',r:'red',j:'heal'}[k.toLowerCase()];
  if(m){if(['brush','linear'].includes(m)){CR.sec='mask';crSetTool(m);crRenderPanel();}else if(m==='red'){CR.sec='red';crRenderPanel();}else if(m==='heal'){CR.sec='heal';crRenderPanel();}else crSetTool(m);e.preventDefault();return;}
  if(k==='q'||k==='Q'){crSetView((CR.vmode+1)%4);e.preventDefault();return;}
  if(k==='\\'){CR.holdBefore=true;crDraw();e.preventDefault();return;}
  if(k==='u'||k==='U'){$('#cr-clipS').click();return;}
  if(k==='o'||k==='O'){$('#cr-clipH').click();return;}
  if(k==='p'||k==='P'){$('#cr-prev').checked=!$('#cr-prev').checked;crQueue();return;}
}
/* ---- pointer on the picture ---- */
function crDown(e){
  const cv=$('#crc');cv.setPointerCapture(e.pointerId);
  const [ix,iy]=crToImg(e),nx=ix/CR.pw,ny=iy/CR.ph,t=CR.tool,v=crView();
  CR.drag={sx:e.clientX,sy:e.clientY,cx:CR.cx,cy:CR.cy,zoom:v.z};
  if(e.button===1||t==='hand'){CR.drag.kind='pan';cv.style.cursor='grabbing';return;}
  if(nx<0||ny<0||nx>1||ny>1){if(!['hand'].includes(t))return;}
  const scr=[e.clientX-cv.getBoundingClientRect().left,e.clientY-cv.getBoundingClientRect().top];
  if(t==='zoom'){crZoomAt(e,e.altKey?1/1.5:1.5);CR.drag=null;return;}
  if(t==='wb'){const rgb=crMeanRGB(CR.prevIn,Math.round(ix),Math.round(iy),2);crApplyWB(rgb);CR.drag=null;return;}
  if(t==='samp'){if(CR.samplers.length<9)CR.samplers.push([nx,ny]);crSamplerList();crDraw();CR.drag=null;return;}
  if(t==='tai'){CR.drag.kind='tai';const X=Math.round(ix),Y=Math.round(iy),j=(crClamp(Y,0,CR.ph-1)*CR.pw+crClamp(X,0,CR.pw-1))*4,d=CR.out.data;CR.taiPin=[nx,ny];
    const mode=CR.taiMode;
    if(mode==='c'){const lum=Math.round(0.2126*d[j]+0.7152*d[j+1]+0.0722*d[j+2]);let pts=(CR.st.p.curve||[[0,0],[255,255]]).map(q=>q.slice());let idx=pts.findIndex(q=>Math.abs(q[0]-lum)<10);
      if(idx<0){const L=raw_curveLUT(pts),yy=raw_lutAt(L,lum/255)*255;pts.push([lum,yy]);pts.sort((a,b)=>a[0]-b[0]);idx=pts.findIndex(q=>q[0]===lum);}
      CR.st.p.curve=pts;CR.drag.idx=idx;CR.drag.y0=pts[idx][1];}
    else{const pd=CR.prevIn.data,h=rgbHue(pd[j],pd[j+1],pd[j+2]);let best=0,bd=999;RAW_BAND_HUE.forEach((bh,i)=>{const dd=Math.min(Math.abs(h-bh),360-Math.abs(h-bh));if(dd<bd){bd=dd;best=i;}});
      CR.drag.key='hsl.'+RAW_BANDS[best]+'.'+mode;CR.drag.v0=raw_getParam(CR.st.p,CR.drag.key)||0;CR.sec='edit';CR.open.mixer=true;CR.hslMode=mode;crRenderPanel();}
    return;}
  if(t==='brush'){
    let m=crSel();if(!m||m.type!=='brush'){m=crNewMask('brush');m.name='Brush '+CR.st.seq++;CR.st.masks.push(m);CR.selMask=CR.st.masks.length-1;crRenderPanel();}
    const st={size:CR.opt.size/100,feather:CR.opt.feather,flow:CR.opt.flow,erase:!!(CR.opt.erase||e.altKey),auto:!!CR.opt.auto,pts:[[nx,ny]]};
    if(st.auto){st.col=crMeanRGB(CR.prevIn,Math.round(ix),Math.round(iy),3);st.tol=48;}
    m.strokes.push(st);CR.drag.kind='brush';CR.drag.st=st;CR.painting=true;CR.maskDirty=true;crQueue();return;}
  if(t==='linear'||t==='radial'){
    // grab handles of existing masks first
    for(let i=0;i<CR.st.masks.length;i++){const m=CR.st.masks[i];
      if(m.type==='linear'){if(crNear(scr,crScreen(m.x1,m.y1),12)){CR.selMask=i;CR.drag.kind='l1';return;}if(crNear(scr,crScreen(m.x2,m.y2),12)){CR.selMask=i;CR.drag.kind='l2';crRenderPanel();return;}}
      if(m.type==='radial'){if(crNear(scr,crScreen(m.cx,m.cy),12)){CR.selMask=i;CR.drag.kind='rc';crRenderPanel();return;}const ex=crScreen(m.cx+m.rx*CR.pw/CR.pw*1,m.cy);if(crNear(scr,[crScreen(m.cx,m.cy)[0]+m.rx*CR.pw*v.z,crScreen(m.cx,m.cy)[1]],12)){CR.selMask=i;CR.drag.kind='rr';crRenderPanel();return;}}}
    const m=crNewMask(t);m.name=(t==='linear'?'Linear ':'Radial ')+CR.st.seq++;
    if(t==='linear'){m.x1=nx;m.y1=ny;m.x2=nx;m.y2=ny;CR.drag.kind='l2';}else{m.cx=nx;m.cy=ny;m.rx=0.01;m.ry=0.01;CR.drag.kind='rn';CR.drag.o=[nx,ny];}
    CR.st.masks.push(m);CR.selMask=CR.st.masks.length-1;CR.maskDirty=true;crRenderPanel();return;}
  if(t==='heal'||t==='clone'||t==='red'){
    if(t==='red'){CR.st.reds.push({x:nx,y:ny,r:CR.redOpt.size/100,dark:CR.redOpt.dark});crRenderPanel();crQueue();crPush();CR.drag=null;return;}
    for(let i=0;i<CR.st.spots.length;i++){const s=CR.st.spots[i];
      if(CR.sel&&CR.sel.kind==='spot'&&CR.sel.i===i&&crNear(scr,crScreen(s.sx,s.sy),Math.max(10,s.r*CR.pw*v.z))){CR.drag.kind='src';CR.drag.i=i;return;}
      if(crNear(scr,crScreen(s.x,s.y),Math.max(10,s.r*CR.pw*v.z))){CR.sel={kind:'spot',i};CR.opt.hsize=s.r*100;CR.opt.hfeather=s.feather;CR.opt.hop=s.opacity;CR.drag.kind='spot';CR.drag.i=i;crRenderPanel();crDraw();return;}}
    const r=CR.opt.hsize/100,src=crAutoSource(CR.prevIn,nx,ny,r);
    CR.st.spots.push({x:nx,y:ny,sx:src[0],sy:src[1],r,feather:CR.opt.hfeather,opacity:CR.opt.hop,mode:t==='clone'?'clone':CR.opt.hmode});
    CR.sel={kind:'spot',i:CR.st.spots.length-1};crRenderPanel();crQueue();crPush();CR.drag=null;return;}
}
function rgbHue(r,g,b){const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;if(!d)return 0;let h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;return (h+360)%360;}
function crMove(e){
  const cv=$('#crc'),r=cv.getBoundingClientRect();CR.mouse=[e.clientX-r.left,e.clientY-r.top];
  crReadout(e);
  const d=CR.drag;if(!d){if(CR.tool==='brush')crDraw();return;}
  const [ix,iy]=crToImg(e),nx=ix/CR.pw,ny=iy/CR.ph,m=crSel();
  switch(d.kind){
    case 'pan':CR.zoom=d.zoom;CR.cx=d.cx-(e.clientX-d.sx)/d.zoom;CR.cy=d.cy-(e.clientY-d.sy)/d.zoom;crDraw();break;
    case 'brush':{const q=d.st.pts[d.st.pts.length-1];if(Math.hypot((nx-q[0])*CR.pw,(ny-q[1])*CR.ph)>Math.max(1.5,d.st.size*CR.pw*0.08)){d.st.pts.push([nx,ny]);CR.maskDirty=true;crQueue();}break;}
    case 'l1':m.x1=nx;m.y1=ny;CR.maskDirty=true;crQueue();break;
    case 'l2':m.x2=nx;m.y2=ny;CR.maskDirty=true;crQueue();break;
    case 'rc':m.cx=nx;m.cy=ny;CR.maskDirty=true;crQueue();break;
    case 'rr':m.rx=Math.max(0.005,Math.abs(nx-m.cx));CR.maskDirty=true;crQueue();break;
    case 'rn':{m.rx=Math.max(0.005,Math.abs(nx-d.o[0]));m.ry=Math.max(0.005,Math.abs(ny-d.o[1])*CR.ph/CR.pw);CR.maskDirty=true;crQueue();break;}
    case 'spot':{const s=CR.st.spots[d.i],dx=nx-s.x,dy=ny-s.y;s.x=nx;s.y=ny;s.sx+=dx;s.sy+=dy;crQueue();break;}
    case 'src':{const s=CR.st.spots[d.i];s.sx=nx;s.sy=ny;crQueue();break;}
    case 'tai':{const dy=(d.sy-e.clientY);
      if(CR.taiMode==='c'){const k='curve',pts=CR.st.p.curve;pts[d.idx][1]=crClamp(d.y0+dy*0.6,0,255);crQueue();}
      else{const val=crClamp(Math.round(d.v0+dy*0.5),-100,100);raw_setParam(CR.st.p,d.key,val);crSync();crQueue();}
      break;}
  }
}
function crUp(e){
  const d=CR.drag;CR.drag=null;
  if(!d)return;
  if(d.kind==='pan'){$('#crc').style.cursor=CR.tool==='hand'?'grab':'crosshair';return;}
  if(d.kind==='brush'){CR.painting=false;}
  if(d.kind==='tai'){CR.taiPin=null;const p=CR.st.p.curve;if(p&&p.length===2&&p[0][1]===0&&p[1][1]===255)CR.st.p.curve=null;}
  if(d.kind==='rn'||d.kind==='l2'||d.kind==='rr'||d.kind==='rc'||d.kind==='l1'||d.kind==='brush'){CR.maskDirty=true;crRenderPanel();}
  crPush();crQueue();
}
/* ---- opening, base picture, apply ---- */
function crPrepare(){
  const l=active();let c;
  if(CR.editLayer){const was=CR.editLayer.visible;CR.editLayer.visible=false;try{c=flatCanvas(1);}finally{CR.editLayer.visible=was;}}
  else c=CR.nd?flatCanvas(1):flatLayer(l);
  CR.baseC=c;
  const mx=window.innerWidth<700?900:1400,k=Math.min(1,mx/Math.max(c.width,c.height));
  CR.pw=Math.max(1,Math.round(c.width*k));CR.ph=Math.max(1,Math.round(c.height*k));CR.pscale=CR.pw/doc.w;
  const pc=mkCanvas(CR.pw,CR.ph),px=cctx(pc);px.imageSmoothingQuality='high';px.drawImage(c,0,0,CR.pw,CR.ph);
  CR.prevIn=px.getImageData(0,0,CR.pw,CR.ph);CR.befC=pc;CR.ovC=null;
  CR.cx=CR.pw/2;CR.cy=CR.ph/2;CR.zoom=0;
}
ACT.cameraRaw=function(){
  if(!doc){toast('Create or open a design first');return;}
  flush();const l=active();
  if(!l){toast('Select a layer first');return;}
  const editing=l.type==='adjust'&&l.adj&&l.adj.id==='camraw';
  if(l.type==='adjust'&&!editing){toast('Select a photo layer for Camera Raw');return;}
  crEnsureDom();
  CR={st:crNewState(),nd:editing,editLayer:editing?l:null,sec:'edit',tool:'hand',vmode:0,samplers:[],open:{basic:true},hslMode:'h',taiMode:'h',cch:'curve',selMask:null,sel:null,overlay:false,
      opt:{size:8,feather:50,flow:100,auto:false,erase:false,hmode:'heal',hsize:2.5,hfeather:50,hop:100,pamt:100},redOpt:{size:2,dark:50},hist:[],hi:-1};
  if(editing&&l.adj.p&&l.adj.p.state)CR.st=JSON.parse(JSON.stringify(l.adj.p.state));
  $('#cr-nd').checked=CR.nd;$('#cr-nd').disabled=editing;$('#cr-prev').checked=true;
  $('#cr').hidden=false;document.body.classList.add('cr-open');
  crPrepare();crSetView(0);crSetTool('hand');crRenderPanel();crRender();crPush();crSamplerList();crBtns();
  document.querySelectorAll('#cr-clipS,#cr-clipH').forEach(b=>b.classList.remove('on'));
};
function crClose(){const r=$('#cr');if(r)r.hidden=true;document.body.classList.remove('cr-open');CR=null;}
function crApply(){
  const st=JSON.parse(JSON.stringify(CR.st));st.snaps=[];
  if(CR.editLayer){const l=CR.editLayer;l.adj.p={state:st};crClose();commit('Camera Raw');refreshLayers();redraw();toast('Camera Raw updated');return;}
  if(CR.nd){crClose();const nl=addLayer({name:'Camera Raw',type:'adjust',above:true});nl.adj={t:'fx',id:'camraw',p:{state:st}};commit('Camera Raw adjustment layer');refreshLayers();setTab('props');renderProps();redraw();toast('Camera Raw layer added. Click Edit in Properties to change it again.');return;}
  const l=active(),textual=l.type==='text'||l.type==='shape';
  toast('Applying Camera Raw at full size...');
  crClose();
  setTimeout(()=>{
    try{
      const bc=flatLayer(l),id=cctx(bc).getImageData(0,0,doc.w,doc.h),out=crDevelop(id,st,1),oc=crToCanvas(out);
      const t=paintTarget('Camera Raw');if(!t)return;
      paintDoc(t,oc,{op:1,blend:'source-over',keepAlpha:!textual&&t===l});
      commit('Camera Raw Filter');refreshLayers();redraw();toast('Camera Raw Filter applied');
    }catch(err){console.error(err);toast('Camera Raw failed: '+err.message);}
  },40);
}
/* ---- menu, shortcut, properties button ---- */
{
  const F=MENUS.find(m=>m.label==='Filter');
  if(F)F.items.splice(2,0,mi('Camera Raw Filter...','Ctrl+Shift+A','cameraRaw'),SEP);
  document.addEventListener('keydown',e=>{if(CR)return;if((e.ctrlKey||e.metaKey)&&e.shiftKey&&!e.altKey&&(e.key==='A'||e.key==='a')){e.preventDefault();ACT.cameraRaw();}});
  const _rp3=renderProps;
  renderProps=function(){
    _rp3();
    const l=doc&&active();if(!l||l.type!=='adjust'||!l.adj||l.adj.id!=='camraw')return;
    const box=$('#p-adj');if(!box)return;
    const p=box.querySelector('p.muted');if(p)p.outerHTML='<div class="row"><button class="primary" id="cr-edit">Edit Camera Raw...</button></div>';
  };
  $('#tab-props').addEventListener('click',e=>{if(e.target.id==='cr-edit')ACT.cameraRaw();});
}
