/* ===== Templates: Party & Events ===== */
TEMPLATES.push(
{name:'Club night neon',cat:'Party & Events',tags:'club night dj party flyer neon friday',w:1240,h:1754,build(){
  tGrad('#07031a','#1a0638',180);
  tShape('ellipse',.2,.3,.9,.9,'#ff1f8f',{name:'Pink glow'}).opacity=.22;
  tShape('ellipse',.85,.62,.9,.9,'#00e5ff',{name:'Cyan glow'}).opacity=.18;
  tText('FRIDAY NIGHT',0.5,0.075,{font:'Outfit',size:72,color:'#00e5ff',shadow:20,shadowColor:'#00e5ff'});
  tText('AFTER',0.5,0.255,{font:'Big Shoulders Display',size:520,color:'#ffffff',shadow:40,shadowColor:'#ff1f8f'});
  tText('DARK',0.5,0.465,{font:'Big Shoulders Display',size:520,color:'#ff1f8f',shadow:40,shadowColor:'#ff1f8f'});
  tRule(.5,.62,.8,'#00e5ff',4);
  tText('RESIDENT DJs  •  LIVE VIBES  •  VIP TABLES',0.5,0.67,{font:'Outfit',size:50,color:'#ffffff'});
  tText('DJ KOFI   •   DJ AMARA   •   MC JAY',0.5,0.745,{font:'Outfit',size:62,color:'#ff1f8f'});
  tText('DOORS 9PM  •  FREE ENTRY BEFORE 10',0.5,0.84,{font:'Outfit',size:48,bold:false,color:'#ffffff'});
  tText('THE VELVET ROOM  •  12 Independence Ave\nBookings 000 000 0000',0.5,0.92,{font:'Outfit',size:40,bold:false,color:'#c4b5fd',lh:1.5});
}},
{name:'Live concert',cat:'Party & Events',tags:'concert live music show tour artist',w:1080,h:1350,build(){
  tGrad('#1c1c1c','#000000',180);
  tShape('ellipse',.5,.45,1.3,1.3,'#f97316',{name:'Stage light'}).opacity=.35;
  tShape('ellipse',.5,.45,.8,.8,'#fb923c',{name:'Stage light 2'}).opacity=.35;
  tText('LIVE IN',0.5,0.12,{font:'Outfit',size:80,color:'#ffffff'});
  tText('CONCERT',0.5,0.3,{font:'Erica One',size:210,bold:false,color:'#ffffff',stroke:'#f97316',sw:6});
  tText('THE GOLDEN TOUR',0.5,0.46,{font:'Big Shoulders Display',size:130,color:'#f97316'});
  tShape('rect',.5,.62,.88,.002,'#ffffff',{name:'Line'});
  tText('FEATURING',0.5,0.585,{font:'Outfit',size:36,bold:false,color:'#ffffffaa'});
  tText('NANA ADU  •  SARKODIE JR.  •  AMA B',0.5,0.67,{font:'Outfit',size:52,color:'#ffffff'});
  tShape('round',.5,.8,.62,.1,'#f97316',{name:'Button',p:{radius:50}});
  tText('GET TICKETS NOW',0.5,0.8,{font:'Outfit',size:54,color:'#000000'});
  tText('SAT 5 DEC  •  8PM  •  NATIONAL THEATRE\nTickets from GH₵ 150',0.5,0.92,{font:'Outfit',size:38,bold:false,color:'#ffffff',lh:1.45});
}},
{name:'Church revival night',cat:'Party & Events',tags:'church revival crusade worship faith god',w:1240,h:1754,build(){
  tGrad('#0b1b4d','#1b0f3a',180);
  tShape('ellipse',.5,.28,1.1,1.1,'#fbbf24',{name:'Light'}).opacity=.22;
  tShape('ellipse',.5,.28,.7,.7,'#fde68a',{name:'Light 2'}).opacity=.22;
  tShape('rect',.5,.17,.028,.17,'#fde68a',{name:'Cross'});tShape('rect',.5,.15,.11,.028,'#fde68a',{name:'Cross arm'});
  tText('REVIVAL',0.5,0.32,{font:'Gloock',size:270,bold:false,color:'#fde68a',shadow:30,shadowColor:'#00000088'});
  tText('NIGHT',0.5,0.43,{font:'Great Vibes',size:240,bold:false,color:'#ffffff'});
  tRule(.5,.52,.4,'#fbbf24',3);
  tText('"Come near to God and He will come near to you."\nJames 4:8',0.5,0.59,{font:'Instrument Serif',size:56,bold:false,italic:true,color:'#e0e7ff',lh:1.3});
  tText('GUEST MINISTER\nPASTOR DAVID MENSAH',0.5,0.72,{font:'Outfit',size:62,color:'#fde68a',lh:1.35});
  tText('FRIDAY - SUNDAY  •  6 PM NIGHTLY',0.5,0.83,{font:'Outfit',size:52,color:'#ffffff'});
  tText('Grace Chapel International\n24 Church Street  •  All are welcome',0.5,0.92,{font:'Outfit',size:42,bold:false,color:'#c7d2fe',lh:1.5});
}},
{name:'Graduation class',cat:'Party & Events',tags:'graduation class of 2026 congratulations school',w:1080,h:1350,build(){
  tGrad('#0f1f4d','#060d24',180);
  tFrame(.5,.5,.9,1.12,'#d4af37',4);
  tCustom('star5',.5,.13,.06,.06,'#d4af37',{name:'Star'});
  tText('CONGRATULATIONS',0.5,0.2,{font:'Outfit',size:58,color:'#d4af37'});
  tText('CLASS',0.5,0.34,{font:'Gloock',size:240,bold:false,color:'#ffffff'});
  tText('OF',0.38,0.49,{font:'Instrument Serif',size:100,bold:false,italic:true,color:'#d4af37'});
  tText('2026',0.58,0.5,{font:'Gloock',size:250,bold:false,color:'#d4af37'});
  tRule(.5,.62,.5,'#d4af37',3);
  tText('"The future belongs to those who believe in\nthe beauty of their dreams."',0.5,0.7,{font:'Instrument Serif',size:56,bold:false,italic:true,color:'#e5e7eb',lh:1.3});
  tText('GRADUATION CEREMONY\nFRIDAY 26 JUNE  •  10 AM  •  MAIN HALL',0.5,0.85,{font:'Outfit',size:42,color:'#d4af37',lh:1.5});
}},
{name:'Baby shower',cat:'Party & Events',tags:'baby shower mint peach newborn gender',w:1080,h:1350,build(){
  tGrad('#e9fbf1','#fff1e6',170);
  tDots(12,'#a7f3d0',2,[0,0,1,.4],.06,.18,.45);tDots(10,'#fed7aa',7,[0,.6,1,1],.06,.18,.45);
  tFrame(.5,.5,.86,1.08,'#34d399',3);
  tText('Please join us for a',0.5,0.15,{font:'Instrument Serif',size:60,bold:false,italic:true,color:'#047857'});
  tText('Baby',0.5,0.27,{font:'Great Vibes',size:280,bold:false,color:'#10b981'});
  tText('SHOWER',0.5,0.43,{font:'Italiana',size:170,bold:false,color:'#065f46'});
  tText('honoring Mama-to-be',0.5,0.53,{font:'Instrument Serif',size:60,bold:false,italic:true,color:'#047857'});
  tText('Sarah Owusu',0.5,0.62,{font:'Great Vibes',size:150,bold:false,color:'#ea580c'});
  tText('SATURDAY 11 APRIL  •  2 PM\nGarden Terrace, 8 Palm Street',0.5,0.78,{font:'Outfit',size:44,color:'#065f46',lh:1.5});
  tText('Games • Gifts • Refreshments\nRSVP 000 000 0000',0.5,0.9,{font:'Outfit',size:38,bold:false,color:'#047857',lh:1.5});
  tCustom('heart',.15,.12,.06,.06,'#fb7185',{name:'Heart'});tCustom('heart',.86,.88,.05,.05,'#fdba74',{name:'Heart'});
}},
{name:'Wedding invitation',cat:'Party & Events',tags:'wedding invitation save the date marriage ivory',w:1240,h:1754,build(){
  tSolid('#fcf8f0');
  tFrame(.5,.5,.88,1.2,'#b08d57',3);tFrame(.5,.5,.85,1.17,'#b08d57',1.5);
  tText('TOGETHER WITH THEIR FAMILIES',0.5,0.14,{font:'Italiana',size:50,bold:false,color:'#7a6240'});
  tText('Daniel',0.5,0.25,{font:'Great Vibes',size:270,bold:false,color:'#7a5a2c'});
  tText('&',0.5,0.34,{font:'Instrument Serif',size:130,bold:false,italic:true,color:'#b08d57'});
  tText('Abigail',0.5,0.44,{font:'Great Vibes',size:270,bold:false,color:'#7a5a2c'});
  tText('REQUEST THE HONOUR OF YOUR PRESENCE\nAT THEIR WEDDING',0.5,0.56,{font:'Italiana',size:46,bold:false,color:'#7a6240',lh:1.6});
  tRule(.5,.63,.3,'#b08d57',2);
  tText('SATURDAY  •  14 NOVEMBER 2026',0.5,0.69,{font:'Outfit',size:54,color:'#7a5a2c',bold:false});
  tText('AT FOUR O\'CLOCK IN THE AFTERNOON',0.5,0.74,{font:'Italiana',size:44,bold:false,color:'#7a6240'});
  tText('The Rosewood Estate\n12 Orchard Lane, Accra',0.5,0.82,{font:'Instrument Serif',size:66,bold:false,italic:true,color:'#7a5a2c',lh:1.3});
  tText('Reception to follow  •  RSVP by 1 October',0.5,0.9,{font:'Italiana',size:42,bold:false,color:'#7a6240'});
}},
{name:'New Year party',cat:'Party & Events',tags:'new year nye countdown 2027 party gold',w:1080,h:1350,build(){
  tGrad('#0a0a0f','#17120a',180);
  tConfetti(60,['#d4af37','#f5e6a8','#ffffff','#b8860b'],21,[0,0,1,1],{op:.8,min:.008,max:.02});
  tText('NEW YEAR\'S EVE',0.5,0.13,{font:'Outfit',size:80,color:'#f5e6a8'});
  tText('2027',0.5,0.34,{font:'Gloock',size:480,bold:false,color:'#d4af37',shadow:30,shadowColor:'#000000'});
  tText('COUNTDOWN PARTY',0.5,0.55,{font:'Big Shoulders Display',size:125,color:'#ffffff'});
  tRule(.5,.63,.5,'#d4af37',3);
  tText('Wednesday 31 December  •  9 PM till late\nLive band • Fireworks • Champagne at midnight',0.5,0.72,{font:'Outfit',size:42,bold:false,color:'#f5e6a8',lh:1.55});
  tShape('round',.5,.87,.5,.09,'#d4af37',{name:'Button',p:{radius:50}});
  tText('TICKETS GH₵ 200',0.5,0.87,{font:'Outfit',size:50,color:'#0a0a0f'});
}},
{name:'Halloween night',cat:'Party & Events',tags:'halloween spooky horror pumpkin october',w:1080,h:1350,build(){
  tGrad('#1a0b2e','#050208',180);
  tShape('ellipse',.5,.3,.7,.7,'#fb923c',{name:'Moon'});
  tShape('ellipse',.62,.26,.2,.2,'#ea580c',{name:'Crater'}).opacity=.5;
  tShape('ellipse',.4,.38,.12,.12,'#ea580c',{name:'Crater 2'}).opacity=.5;
  tCustom('cloud',.2,.5,.5,.2,'#1a0b2e',{name:'Cloud'});tCustom('cloud',.85,.45,.4,.15,'#1a0b2e',{name:'Cloud 2'});
  tShape('triangle',.15,.9,.12,.2,'#000000',{name:'Tree'});tShape('triangle',.88,.92,.1,.18,'#000000',{name:'Tree 2'});
  tText('HAUNTED',0.5,0.58,{font:'Erica One',size:165,bold:false,color:'#ffffff',stroke:'#7e22ce',sw:12,shadow:20,shadowColor:'#a855f7'});
  tText('NIGHT',0.5,0.69,{font:'Erica One',size:210,bold:false,color:'#fb923c',stroke:'#000000',sw:10});
  tText('COSTUME PARTY  •  PRIZES  •  SPOOKY DRINKS',0.5,0.8,{font:'Outfit',size:40,color:'#ffffff'});
  tText('FRIDAY 31 OCTOBER  •  8 PM\nDare to enter... 77 Dark Lane',0.5,0.9,{font:'Outfit',size:44,bold:false,color:'#fdba74',lh:1.45});
}},
{name:'Christmas celebration',cat:'Party & Events',tags:'christmas xmas holiday december festive',w:1080,h:1350,build(){
  tGrad('#7f1d1d','#450a0a',180);
  tDots(40,'#ffffff',31,[0,0,1,1],.008,.03,.8);
  tFrame(.5,.5,.88,1.1,'#fde68a',4);
  tCustom('star5',.5,.12,.1,.1,'#fde047',{name:'Star'});
  tText('Merry',0.5,0.27,{font:'Great Vibes',size:260,bold:false,color:'#fde68a',shadow:14,shadowColor:'#00000066'});
  tText('CHRISTMAS',0.5,0.42,{font:'Gloock',size:150,bold:false,color:'#ffffff'});
  tText('PARTY',0.5,0.54,{font:'Big Shoulders Display',size:200,color:'#fde047'});
  tShape('triangle',.12,.86,.12,.15,'#166534',{name:'Tree'});tShape('triangle',.12,.83,.09,.11,'#16a34a',{name:'Tree top'});
  tShape('triangle',.88,.86,.12,.15,'#166534',{name:'Tree'});tShape('triangle',.88,.83,.09,.11,'#16a34a',{name:'Tree top'});
  tText('SAT 20 DEC  •  6 PM\nCarols • Dinner • Gifts',0.5,0.7,{font:'Outfit',size:50,color:'#ffffff',lh:1.5});
  tText('Hosted by the Johnson family',0.5,0.9,{font:'Instrument Serif',size:56,bold:false,italic:true,color:'#fde68a'});
}},
{name:'Valentine\'s dinner',cat:'Party & Events',tags:'valentine love romantic dinner date heart',w:1080,h:1080,build(){
  tRadial('#be123c','#4c0519',.5,.5,.8);
  tCustom('heart',.5,.5,.9,.85,'#9f1239',{name:'Big heart'}).opacity=.6;
  tCustom('heart',.14,.18,.08,.08,'#fda4af',{name:'Heart'});tCustom('heart',.86,.82,.1,.1,'#fda4af',{name:'Heart'});tCustom('heart',.84,.16,.05,.05,'#fecdd3',{name:'Heart'});tCustom('heart',.16,.84,.05,.05,'#fecdd3',{name:'Heart'});
  tText('Valentine\'s',0.5,0.3,{font:'Great Vibes',size:160,bold:false,color:'#ffe4e6'});
  tText('DINNER',0.5,0.47,{font:'Italiana',size:170,bold:false,color:'#ffffff'});
  tText('FOR TWO',0.5,0.6,{font:'Outfit',size:64,color:'#fda4af'});
  tText('SATURDAY 14 FEBRUARY  •  7 PM\n3-course candlelit menu  •  Live piano',0.5,0.78,{font:'Outfit',size:40,bold:false,color:'#ffe4e6',lh:1.5});
}},
{name:'Eid Mubarak',cat:'Party & Events',tags:'eid ramadan islamic muslim mubarak crescent',w:1080,h:1350,build(){
  tGrad('#04342a','#021a15',180);
  tDots(30,'#fde68a',17,[0,0,1,.6],.006,.016,.9);
  tCustom('moon',.5,.25,.42,.42,'#f5c542',{name:'Crescent'});
  tStar(.68,.2,.07,'#f5c542');tStar(.24,.36,.04,'#f5c542');tStar(.8,.36,.04,'#fde68a');
  tText('Eid',0.5,0.5,{font:'Great Vibes',size:260,bold:false,color:'#f5c542'});
  tText('MUBARAK',0.5,0.64,{font:'Italiana',size:170,bold:false,color:'#ffffff'});
  tRule(.5,.72,.4,'#f5c542',3);
  tText('May this blessed day bring you\npeace, joy and prosperity',0.5,0.79,{font:'Instrument Serif',size:62,bold:false,italic:true,color:'#d1fae5',lh:1.3});
  tText('From our family to yours',0.5,0.91,{font:'Outfit',size:42,bold:false,color:'#f5c542'});
}}
);
