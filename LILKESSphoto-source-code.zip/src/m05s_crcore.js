/* ===== Camera Raw Filter: state, masks, healing, develop pipeline ===== */
const CR_PROFILES={
  'Adobe Color':null,
  'Adobe Vivid':{contrast:12,saturation:14,vibrance:6},
  'Adobe Portrait':{contrast:-8,saturation:-5,clarity:-6},
  'Adobe Landscape':{contrast:10,vibrance:14,saturation:6,dehaze:6},
  'Adobe Neutral':{contrast:-14,saturation:-6},
  'Adobe Flat':{contrast:-28,saturation:-14,highlights:-10,shadows:12},
  'Camera Matte':{contrast:-12,saturation:-8,blacks:22},
  'Camera Faithful':{contrast:4,saturation:-2}
};
const CR_WB={'As Shot':[0,0],'Auto':null,'Daylight':[8,4],'Cloudy':[16,5],'Shade':[26,9],'Tungsten':[-42,-6],'Fluorescent':[-20,26],'Flash':[6,3]};
const CR_LOCAL_KEYS=[['exposure','Exposure',-5,5,0.05],['contrast','Contrast',-100,100,1],['highlights','Highlights',-100,100,1],['shadows','Shadows',-100,100,1],['whites','Whites',-100,100,1],['blacks','Blacks',-100,100,1],
  ['temp','Temp',-100,100,1],['tint','Tint',-100,100,1],['saturation','Saturation',-100,100,1],['texture','Texture',-100,100,1],['clarity','Clarity',-100,100,1],['dehaze','Dehaze',-100,100,1],['sharpen','Sharpness',0,150,1],['nrLum','Noise',0,100,1]];
function crNewState(){return {p:raw_params(),para:{hi:0,li:0,da:0,sh:0},wb:'As Shot',profile:'Adobe Color',masks:[],spots:[],reds:[],snaps:[],seq:1};}
function crNewMask(type){
  const L={};CR_LOCAL_KEYS.forEach(k=>L[k[0]]=0);
  return {id:0,name:'',type,amount:100,invert:false,L,strokes:[],x1:.5,y1:.3,x2:.5,y2:.6,cx:.5,cy:.5,rx:.25,ry:.25,feather:50};
}
function crLocalActive(m){for(const k in m.L)if(m.L[k])return true;return false;}
/* effective global parameters: profile + parametric curve merged in */
function crEffective(st){
  const P=raw_clone(st.p),pr=CR_PROFILES[st.profile];
  if(pr)for(const k in pr)P[k]=Math.max(-100,Math.min(100,(P[k]||0)+pr[k]));
  const pa=st.para;
  if(pa&&(pa.hi||pa.li||pa.da||pa.sh)){
    const L=P.curve?raw_curveLUT(P.curve):null,pts=[];let prev=-1;
    const bell=(x,c)=>Math.exp(-Math.pow((x-c)/38,2));
    for(let x=0;x<=256;x+=16){const xx=Math.min(255,x);let y=(L?raw_lutAt(L,xx/255)*255:xx);
      y+=0.3*(pa.sh*bell(xx,32)+pa.da*bell(xx,96)+pa.li*bell(xx,160)+pa.hi*bell(xx,224));
      y=Math.max(0,Math.min(255,y));if(xx===0)y=Math.max(0,y*0);if(y<=prev)y=Math.min(255,prev+0.4);prev=y;pts.push([xx,y]);}
    pts[0][1]=Math.max(0,pts[0][1]*0);P.curve=pts;
  }
  return P;
}
/* ---- masks ---- */
function crMaskData(m,w,h,img){
  const out=new Float32Array(w*h);
  const sm=t=>t*t*(3-2*t);
  if(m.type==='linear'){
    const x1=m.x1*w,y1=m.y1*h,x2=m.x2*w,y2=m.y2*h,dx=x2-x1,dy=y2-y1,dd=dx*dx+dy*dy||1;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=((x-x1)*dx+(y-y1)*dy)/dd;out[y*w+x]=t<=0?1:t>=1?0:1-sm(t);}
  }else if(m.type==='radial'){
    const cx=m.cx*w,cy=m.cy*h,rx=Math.max(1,m.rx*w),ry=Math.max(1,m.ry*w),inner=1-Math.min(.98,m.feather/100);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const d=Math.hypot((x-cx)/rx,(y-cy)/ry);out[y*w+x]=d<=inner?1:d>=1?0:1-sm((d-inner)/(1-inner));}
  }else{
    const c=mkCanvas(w,h),x=cctx(c);
    for(const s of m.strokes){
      const sc=mkCanvas(w,h),sx=cctx(sc),r=Math.max(1,s.size*w/2),hard=1-Math.min(.99,s.feather/100),step=Math.max(1,r*0.3);
      const dab=(px,py)=>{const g=sx.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,'rgba(0,0,0,'+(s.flow/100)+')');g.addColorStop(Math.max(0.01,hard),'rgba(0,0,0,'+(s.flow/100)+')');g.addColorStop(1,'rgba(0,0,0,0)');sx.fillStyle=g;sx.fillRect(px-r,py-r,2*r,2*r);};
      let last=null;
      for(const q of s.pts){const px=q[0]*w,py=q[1]*h;if(!last){dab(px,py);last=[px,py];continue;}
        const d=Math.hypot(px-last[0],py-last[1]),n=Math.max(1,Math.ceil(d/step));for(let i=1;i<=n;i++)dab(last[0]+(px-last[0])*i/n,last[1]+(py-last[1])*i/n);last=[px,py];}
      if(s.auto&&img&&s.col){ // keep only pixels close in colour to where the stroke began
        const id=sx.getImageData(0,0,w,h),d=id.data,im=img.data,tol=s.tol||48;
        for(let i=0;i<w*h;i++){const a=d[i*4+3];if(!a)continue;const dr=im[i*4]-s.col[0],dg=im[i*4+1]-s.col[1],db=im[i*4+2]-s.col[2],dist=Math.sqrt(dr*dr+dg*dg+db*db);d[i*4+3]=a*Math.max(0,Math.min(1,1.6-dist/tol));}
        sx.putImageData(id,0,0);
      }
      x.globalCompositeOperation=s.erase?'destination-out':'source-over';x.drawImage(sc,0,0);
    }
    const d=x.getImageData(0,0,w,h).data;for(let i=0;i<w*h;i++)out[i]=d[i*4+3]/255;
  }
  if(m.invert)for(let i=0;i<out.length;i++)out[i]=1-out[i];
  const am=m.amount/100;if(am!==1)for(let i=0;i<out.length;i++)out[i]*=am;
  return out;
}
/* ---- spot healing and red eye ---- */
function crRingMean(d,w,h,cx,cy,r){let sr=0,sg=0,sb=0,n=0;for(let i=0;i<16;i++){const a=i/16*Math.PI*2,x=Math.round(cx+Math.cos(a)*r*1.25),y=Math.round(cy+Math.sin(a)*r*1.25);if(x<0||y<0||x>=w||y>=h)continue;const j=(y*w+x)*4;sr+=d[j];sg+=d[j+1];sb+=d[j+2];n++;}return n?[sr/n,sg/n,sb/n]:[128,128,128];}
function crAutoSource(img,x,y,r){
  const w=img.width,h=img.height,d=img.data,tgt=crRingMean(d,w,h,x*w,y*w*0+y*h,r*w);let best=null,bs=1e9;
  for(let k=0;k<14;k++){const a=k/14*Math.PI*2+0.4,dist=r*w*(2.6+(k%3)*0.7),sx=x*w+Math.cos(a)*dist,sy=y*h+Math.sin(a)*dist;
    if(sx<r*w||sy<r*w||sx>w-r*w||sy>h-r*w)continue;
    const m=crRingMean(d,w,h,sx,sy,r*w),sc=Math.abs(m[0]-tgt[0])+Math.abs(m[1]-tgt[1])+Math.abs(m[2]-tgt[2]);
    if(sc<bs){bs=sc;best=[sx/w,sy/h];}}
  return best||[Math.min(.98,x+r*3),y];
}
function crApplySpots(img,st){
  if(!st.spots.length&&!st.reds.length)return img;
  const w=img.width,h=img.height,d=new Uint8ClampedArray(img.data),src=img.data;
  for(const s of st.spots){
    const cx=s.x*w,cy=s.y*h,r=s.r*w,dx=(s.sx-s.x)*w,dy=(s.sy-s.y)*h;
    let off=[0,0,0];
    if(s.mode!=='clone'){const a=crRingMean(src,w,h,cx,cy,r),b=crRingMean(src,w,h,cx+dx,cy+dy,r);off=[a[0]-b[0],a[1]-b[1],a[2]-b[2]];}
    const R=r*1.15,inner=1-Math.min(.95,s.feather/100)*0.9;
    for(let y=Math.max(0,Math.floor(cy-R));y<=Math.min(h-1,Math.ceil(cy+R));y++)for(let x=Math.max(0,Math.floor(cx-R));x<=Math.min(w-1,Math.ceil(cx+R));x++){
      const dd=Math.hypot(x-cx,y-cy)/R;if(dd>=1)continue;
      const wgt=(dd<=inner?1:1-(dd-inner)/(1-inner))*(s.opacity/100);
      const sx=Math.round(x+dx),sy=Math.round(y+dy);if(sx<0||sy<0||sx>=w||sy>=h)continue;
      const j=(y*w+x)*4,k=(sy*w+sx)*4;
      for(let c=0;c<3;c++){const v=src[k+c]+off[c];d[j+c]=d[j+c]+(Math.max(0,Math.min(255,v))-d[j+c])*wgt;}
    }
  }
  for(const e of st.reds){
    const cx=e.x*w,cy=e.y*h,R=e.r*w;
    for(let y=Math.max(0,Math.floor(cy-R));y<=Math.min(h-1,Math.ceil(cy+R));y++)for(let x=Math.max(0,Math.floor(cx-R));x<=Math.min(w-1,Math.ceil(cx+R));x++){
      const dd=Math.hypot(x-cx,y-cy)/R;if(dd>=1)continue;const j=(y*w+x)*4,r=d[j],g=d[j+1],b=d[j+2],mx=Math.max(g,b);
      if(r>mx*1.35&&r>50){const f=Math.min(1,(r/(mx+1)-1.35)/0.8)*(1-dd*dd),t=(g+b)/2*(1-e.dark/100*0.5);d[j]=r+(t-r)*f;d[j+1]=g+(t*0.95-g)*f*0.6;d[j+2]=b+(t*0.95-b)*f*0.6;}
    }
  }
  return new ImageData(d,w,h);
}
/* ---- the develop pipeline: used by the dialog preview, the final apply and the adjustment layer ---- */
function crDevelop(base,st,scale){
  scale=scale||1;
  const work=crApplySpots(base,st);
  let A=raw_process(work,crEffective(st),{scale});
  const w=A.width,h=A.height;
  for(const m of st.masks){
    if(!crLocalActive(m))continue;
    const lp={};for(const k in m.L)if(m.L[k])lp[k]=m.L[k];
    const mk=crMaskData(m,w,h,work),B=raw_process(A,lp,{scale}),a=A.data,b=B.data;
    for(let i=0,j=0;i<mk.length;i++,j+=4){const f=mk[i];if(f<=0.002)continue;a[j]+=(b[j]-a[j])*f;a[j+1]+=(b[j+1]-a[j+1])*f;a[j+2]+=(b[j+2]-a[j+2])*f;}
  }
  return A;
}
/* ---- white balance from a sampled neutral ---- */
function crSolveWB(rgb){
  const px=(t,ti)=>{const im=new ImageData(new Uint8ClampedArray([rgb[0],rgb[1],rgb[2],255]),1,1);const o=raw_process(im,{temp:t,tint:ti},{scale:1}).data;return Math.pow(o[0]-o[1],2)+Math.pow(o[1]-o[2],2)+Math.pow(o[0]-o[2],2);};
  let t=0,ti=0,best=px(0,0);
  for(let pass=0;pass<4;pass++){const step=[40,12,4,1][pass];
    for(let it=0;it<3;it++){let moved=false;
      for(const [dt,dti] of [[step,0],[-step,0],[0,step],[0,-step],[step,step],[-step,-step],[step,-step],[-step,step]]){
        const nt=Math.max(-100,Math.min(100,t+dt)),nti=Math.max(-100,Math.min(100,ti+dti)),v=px(nt,nti);if(v<best-0.01){best=v;t=nt;ti=nti;moved=true;}}
      if(!moved)break;}}
  return [t,ti];
}
function crMeanRGB(img,x,y,r){const w=img.width,h=img.height,d=img.data;let sr=0,sg=0,sb=0,n=0;for(let yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy++)for(let xx=Math.max(0,x-r);xx<=Math.min(w-1,x+r);xx++){const j=(yy*w+xx)*4;sr+=d[j];sg+=d[j+1];sb+=d[j+2];n++;}return n?[sr/n,sg/n,sb/n]:[128,128,128];}
/* ---- the non-destructive Camera Raw adjustment layer ---- */
defFx('camraw','adjust','Camera Raw',[],(img,p,c)=>p&&p.state?crDevelop(img,p.state,(c&&c.scale)||1):img);
