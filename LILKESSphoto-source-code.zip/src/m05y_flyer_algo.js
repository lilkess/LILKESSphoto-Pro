/* ===== Flyer analysis: text boxes, flat/gradient regions, inpainting (pure image processing, no AI) ===== */
const FA_SIDE=900;
function fa_prep(canvas){
  const W=canvas.width,H=canvas.height,k=Math.min(1,FA_SIDE/Math.max(W,H)),w=Math.max(8,Math.round(W*k)),h=Math.max(8,Math.round(H*k));
  const c=mkCanvas(w,h),x=cctx(c);x.imageSmoothingQuality='high';x.drawImage(canvas,0,0,w,h);
  return {W,H,w,h,sc:W/w,data:x.getImageData(0,0,w,h).data};
}
function fa_blur(d,w,h){ // 3x3 box blur of RGBA -> Uint8ClampedArray (alpha ignored)
  const o=new Uint8ClampedArray(d.length),tmp=new Float32Array(w*h*3);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const xm=Math.max(0,x-1),xp=Math.min(w-1,x+1);for(let c=0;c<3;c++)tmp[(y*w+x)*3+c]=(d[(y*w+xm)*4+c]+d[(y*w+x)*4+c]+d[(y*w+xp)*4+c])/3;}
  for(let y=0;y<h;y++){const ym=Math.max(0,y-1),yp=Math.min(h-1,y+1);for(let x=0;x<w;x++)for(let c=0;c<3;c++)o[(y*w+x)*4+c]=(tmp[(ym*w+x)*3+c]+tmp[(y*w+x)*3+c]+tmp[(yp*w+x)*3+c])/3;o.fill(255,0,0);}
  for(let i=3;i<o.length;i+=4)o[i]=255;return o;
}
function fa_grad(s,w,h){ // largest per-channel difference between neighbours
  const G=new Float32Array(w*h);
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
    const i=(y*w+x)*4;let m=0;
    for(let c=0;c<3;c++){const dx=Math.abs(s[i+4+c]-s[i-4+c]),dy=Math.abs(s[i+w*4+c]-s[i-w*4+c]);if(dx>m)m=dx;if(dy>m)m=dy;}
    G[y*w+x]=m;
  }
  for(let x=0;x<w;x++){G[x]=G[w+x];G[(h-1)*w+x]=G[(h-2)*w+x];}for(let y=0;y<h;y++){G[y*w]=G[y*w+1];G[y*w+w-1]=G[y*w+w-2];}
  return G;
}
function fa_boxMax(m,w,h,rx,ry){ // dilate with a (2rx+1)x(2ry+1) box
  const t=new Uint8Array(w*h),o=new Uint8Array(w*h);
  for(let y=0;y<h;y++){let cnt=0;const row=y*w;for(let x=-rx;x<w;x++){const a=x+rx,b=x-rx-1;if(a<w&&m[row+a])cnt++;if(b>=0&&m[row+b])cnt--;if(x>=0)t[row+x]=cnt>0?1:0;}}
  for(let x=0;x<w;x++){let cnt=0;for(let y=-ry;y<h;y++){const a=y+ry,b=y-ry-1;if(a<h&&t[a*w+x])cnt++;if(b>=0&&t[b*w+x])cnt--;if(y>=0)o[y*w+x]=cnt>0?1:0;}}
  return o;
}
function fa_erode(m,w,h,rx,ry){const inv=new Uint8Array(w*h);for(let i=0;i<inv.length;i++)inv[i]=m[i]?0:1;const d=fa_boxMax(inv,w,h,rx,ry),o=new Uint8Array(w*h);for(let i=0;i<o.length;i++)o[i]=d[i]?0:1;return o;}
function fa_cc(m,w,h,c8){
  const lab=new Int32Array(w*h),comps=[],st=new Int32Array(w*h);let n=0;
  for(let s=0;s<w*h;s++){
    if(!m[s]||lab[s])continue;n++;let sp=0,area=0,x0=w,y0=h,x1=0,y1=0;st[sp++]=s;lab[s]=n;
    while(sp){const p=st[--sp],px=p%w,py=(p/w)|0;area++;if(px<x0)x0=px;if(px>x1)x1=px;if(py<y0)y0=py;if(py>y1)y1=py;
      for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;if(!c8&&dx&&dy)continue;const nx=px+dx,ny=py+dy;if(nx<0||ny<0||nx>=w||ny>=h)continue;const q=ny*w+nx;if(m[q]&&!lab[q]){lab[q]=n;st[sp++]=q;}}}
    comps.push({id:n,area,x0,y0,x1,y1});
  }
  return {lab,comps};
}
/* median colour of a ring around a box */
function fa_ring(d,w,h,b,pad){
  const R=[],G=[],B=[];
  const add=(x,y)=>{if(x<0||y<0||x>=w||y>=h)return;const i=(y*w+x)*4;R.push(d[i]);G.push(d[i+1]);B.push(d[i+2]);};
  for(let x=b.x-pad;x<=b.x+b.w+pad;x+=1){for(let k=1;k<=pad;k++){add(x,b.y-k);add(x,b.y+b.h-1+k);}}
  for(let y=b.y;y<b.y+b.h;y+=1){for(let k=1;k<=pad;k++){add(b.x-k,y);add(b.x+b.w-1+k,y);}}
  const med=a=>{if(!a.length)return 128;a.sort((p,q)=>p-q);return a[a.length>>1];};
  return [med(R),med(G),med(B)];
}
const fa_dist=(r,g,b,c)=>Math.max(Math.abs(r-c[0]),Math.abs(g-c[1]),Math.abs(b-c[2]));
/* analyse a box: background colour, ink colour, mask of ink pixels, line count */
function fa_inkStats(d,w,h,b){
  const pad=Math.max(2,Math.round(Math.min(b.w,b.h)*0.12)),bg=fa_ring(d,w,h,b,Math.min(4,pad));
  const far=[];let n=0;
  for(let y=Math.max(0,b.y);y<Math.min(h,b.y+b.h);y++)for(let x=Math.max(0,b.x);x<Math.min(w,b.x+b.w);x++){const i=(y*w+x)*4;n++;if(fa_dist(d[i],d[i+1],d[i+2],bg)>60)far.push(i);}
  if(far.length<12)return null;
  // ink colour: average of the farthest 40% (robust to anti-aliasing)
  far.sort((a,c)=>fa_dist(d[c],d[c+1],d[c+2],bg)-fa_dist(d[a],d[a+1],d[a+2],bg));
  const top=far.slice(0,Math.max(8,Math.round(far.length*0.4)));
  let r=0,g=0,bl=0;top.forEach(i=>{r+=d[i];g+=d[i+1];bl+=d[i+2];});r/=top.length;g/=top.length;bl/=top.length;
  let dev=0;top.forEach(i=>{dev+=Math.abs(d[i]-r)+Math.abs(d[i+1]-g)+Math.abs(d[i+2]-bl);});dev/=top.length*3;
  // line count from the row profile
  const prof=new Float32Array(b.h);
  for(let y=0;y<b.h;y++){let c=0;const yy=b.y+y;if(yy<0||yy>=h)continue;for(let x=Math.max(0,b.x);x<Math.min(w,b.x+b.w);x++){const i=(yy*w+x)*4;if(fa_dist(d[i],d[i+1],d[i+2],bg)>60)c++;}prof[y]=c;}
  let lines=0,inl=false,mx=Math.max(...prof);const thr=Math.max(1,mx*0.08);
  for(let y=0;y<b.h;y++){const on=prof[y]>thr;if(on&&!inl)lines++;inl=on;}
  return {bg,ink:[Math.round(r),Math.round(g),Math.round(bl)],dev,ratio:far.length/Math.max(1,n),lines:Math.max(1,lines)};
}

/* letters are small flat regions that contrast with what surrounds them; group them into lines */
function fa_findLines(A){
  const {w,h,data}=A,sm=fa_blur(data,w,h),G=fa_grad(sm,w,h);
  const S=new Uint8Array(w*h);for(let i=0;i<S.length;i++)S[i]=G[i]<10?1:0;
  const {lab,comps}=fa_cc(S,w,h,false),L=[];
  const minH=Math.max(8,h*0.011),maxH=h*0.2;
  for(const c of comps){
    const bw=c.x1-c.x0+1,bh=c.y1-c.y0+1;
    if(bh<minH||bh>maxH||bw<2||bw>w*0.5||c.area<14)continue;
    const fill=c.area/(bw*bh);if(fill<0.16||fill>0.96)continue;
    // colour of the region and of the ring around it
    let r=0,g=0,b=0,n=0;
    for(let y=c.y0;y<=c.y1;y++)for(let x=c.x0;x<=c.x1;x++)if(lab[y*w+x]===c.id){const i=(y*w+x)*4;r+=data[i];g+=data[i+1];b+=data[i+2];n++;}
    r/=n;g/=n;b/=n;
    const ring=fa_ring(data,w,h,{x:c.x0,y:c.y0,w:bw,h:bh},3);
    if(fa_dist(r,g,b,ring)<48)continue;
    L.push({x:c.x0,y:c.y0,w:bw,h:bh,c:[r,g,b],bg:ring});
  }
  L.sort((a,b)=>a.x-b.x);
  const par=L.map((_,i)=>i),find=i=>par[i]===i?i:(par[i]=find(par[i]));
  for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++){
    const a=L[i],b=L[j];if(b.x-(a.x+a.w)>Math.max(a.h,b.h)*1.3)continue;
    const ov=Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y);if(ov<0.55*Math.min(a.h,b.h))continue;
    const hr=Math.max(a.h,b.h)/Math.min(a.h,b.h);if(hr>1.7)continue;
    const tolA=0.22*Math.max(a.h,b.h);if(Math.abs(a.y-b.y)>tolA&&Math.abs((a.y+a.h)-(b.y+b.h))>tolA)continue;
    if(fa_dist(a.c[0],a.c[1],a.c[2],b.c)>55)continue;
    par[find(j)]=find(i);
  }
  const gr={};L.forEach((t,i)=>{(gr[find(i)]=gr[find(i)]||[]).push(t);});
  const out=[];
  for(const k in gr){
    const g=gr[k];let x0=1e9,y0=1e9,x1=0,y1=0;g.forEach(t=>{x0=Math.min(x0,t.x);y0=Math.min(y0,t.y);x1=Math.max(x1,t.x+t.w);y1=Math.max(y1,t.y+t.h);});
    const bw=x1-x0,bh=y1-y0;
    if(g.length<2)continue;
    if(g.length>=2&&bw<bh*1.6)continue;
    if(g.length>=2){const hs=g.map(t=>t.h),mh=hs.reduce((a,b)=>a+b,0)/hs.length,sd=Math.sqrt(hs.reduce((a,b)=>a+(b-mh)*(b-mh),0)/hs.length);if(sd>0.4*mh)continue;if(bh>h*0.14&&g.length<4)continue;}
    const box={x:x0,y:y0,w:bw,h:bh},st=fa_inkStats(data,w,h,box);if(!st||st.ratio<0.03||st.ratio>0.8||st.dev>34)continue;
    out.push(Object.assign({x:x0,y:y0,w:bw,h:bh,n:g.length},st));
  }
  return out;
}
/* ---------- text boxes ---------- */
function fa_findText(A){
  const {w,h,data}=A,s=fa_blur(data,w,h),G=fa_grad(s,w,h);
  const E=new Uint8Array(w*h);for(let i=0;i<E.length;i++)E[i]=G[i]>26?1:0;
  const rx=Math.max(3,Math.round(w*0.012)),D=fa_boxMax(E,w,h,rx,1),{lab,comps}=fa_cc(D,w,h,true);
  const out=[];
  for(const c of comps){
    const bw=c.x1-c.x0+1,bh=c.y1-c.y0+1;
    if(bh<Math.max(7,h*0.009)||bh>h*0.24||bw<bh*1.0||bw<14)continue;
    // box of the real edges inside the dilated blob (so it is tight)
    let x0=w,y0=h,x1=0,y1=0,ec=0;
    for(let y=c.y0;y<=c.y1;y++)for(let x=c.x0;x<=c.x1;x++){const p=y*w+x;if(E[p]&&lab[p]===c.id){ec++;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}}
    const tb={x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
    if(tb.h<6||tb.w<12||tb.w<tb.h*1.15)continue;
    const dens=ec/(tb.w*tb.h);if(dens<0.04||dens>0.75)continue;
    const st=fa_inkStats(data,w,h,tb);if(!st)continue;
    if(st.ratio<0.06||st.ratio>0.6||st.dev>30)continue;
    out.push(Object.assign({x:tb.x,y:tb.y,w:tb.w,h:tb.h},st));
  }
  // letter-based lines come first; drop edge-based boxes that overlap them
  const LL=fa_findLines(A),keep=LL.slice();
  const ovl=(a,b)=>{const ix=Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x),iy=Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y);return ix>0&&iy>0?ix*iy/Math.min(a.w*a.h,b.w*b.h):0;};
  out.forEach(t=>{if(!LL.some(l=>ovl(l,t)>0.4))keep.push(t);});
  out.length=0;keep.forEach(t=>out.push(t));
  // merge neighbouring lines into one paragraph
  out.sort((a,b)=>a.y-b.y);
  const par=out.map((_,i)=>i),find=i=>par[i]===i?i:(par[i]=find(par[i]));
  for(let i=0;i<out.length;i++)for(let j=i+1;j<out.length;j++){
    const a=out[i],b=out[j],gap=b.y-(a.y+a.h),hh=Math.min(a.lineH||a.h/a.lines,b.lineH||b.h/b.lines);
    if(gap>hh*0.9||gap<-hh*0.4)continue;
    const ah=a.h/a.lines,bh=b.h/b.lines;if(Math.abs(ah-bh)>0.45*Math.max(ah,bh))continue;
    const ov=Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x);if(ov<0.35*Math.min(a.w,b.w))continue;
    if(fa_dist(a.ink[0],a.ink[1],a.ink[2],b.ink)>70)continue;
    par[find(j)]=find(i);
  }
  const groups={};out.forEach((t,i)=>{(groups[find(i)]=groups[find(i)]||[]).push(t);});
  const res=[];
  for(const k in groups){
    const g=groups[k];let x0=1e9,y0=1e9,x1=0,y1=0,lines=0;g.forEach(t=>{x0=Math.min(x0,t.x);y0=Math.min(y0,t.y);x1=Math.max(x1,t.x+t.w);y1=Math.max(y1,t.y+t.h);lines+=t.lines;});
    const box={x:x0,y:y0,w:x1-x0,h:y1-y0};
    let align='center';
    if(g.length>1){const cs=g.map(t=>t.x+t.w/2),ls=g.map(t=>t.x),rs=g.map(t=>t.x+t.w),sp=a=>Math.max(...a)-Math.min(...a),tol=0.03*w;
      if(sp(cs)<=tol)align='center';else if(sp(ls)<=tol)align='left';else if(sp(rs)<=tol)align='right';else align='center';}
    const st=fa_inkStats(data,w,h,box)||g[0];
    res.push({x:box.x,y:box.y,w:box.w,h:box.h,lines,align,ink:st.ink,bg:st.bg,ratio:st.ratio});
  }
  res.sort((a,b)=>a.y-b.y||a.x-b.x);
  return res;
}
/* ---------- full-resolution text mask (pixels that belong to the lettering) ---------- */
function fa_textMask(img,box,pad){
  const W=img.width,H=img.height,d=img.data,m=new Uint8Array(W*H);
  const bx=Math.max(0,Math.floor(box.x-pad)),by=Math.max(0,Math.floor(box.y-pad)),bx1=Math.min(W,Math.ceil(box.x+box.w+pad)),by1=Math.min(H,Math.ceil(box.y+box.h+pad));
  const ring=fa_ring(d,W,H,{x:bx,y:by,w:bx1-bx,h:by1-by},Math.max(2,Math.round(pad*0.6)));
  const thr=Math.max(38,Math.round(((box.ink?Math.max(...box.ink.map((v,i)=>Math.abs(v-ring[i]))):90))*0.38));
  for(let y=by;y<by1;y++)for(let x=bx;x<bx1;x++){const i=(y*W+x)*4;if(fa_dist(d[i],d[i+1],d[i+2],ring)>thr)m[y*W+x]=1;}
  return m;
}
/* ---------- push-pull inpainting ---------- */
function fa_inpaint(img,mask){
  const W=img.width,H=img.height,d=img.data;
  const lv=[];let w=W,h=H,col=new Float32Array(w*h*3),wt=new Float32Array(w*h);
  for(let i=0;i<w*h;i++)if(!mask[i]){col[i*3]=d[i*4];col[i*3+1]=d[i*4+1];col[i*3+2]=d[i*4+2];wt[i]=1;}
  lv.push({w,h,col,wt});
  while(w>1||h>1){
    const nw=Math.ceil(w/2),nh=Math.ceil(h/2),nc=new Float32Array(nw*nh*3),nwt=new Float32Array(nw*nh),p=lv[lv.length-1];
    for(let y=0;y<nh;y++)for(let x=0;x<nw;x++){let sr=0,sg=0,sb=0,sw=0,cnt=0;
      for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){const xx=x*2+dx,yy=y*2+dy;if(xx>=w||yy>=h)continue;cnt++;const i=yy*w+xx,q=p.wt[i];if(q>0){sr+=p.col[i*3]*q;sg+=p.col[i*3+1]*q;sb+=p.col[i*3+2]*q;sw+=q;}}
      const o=y*nw+x;if(sw>0){nc[o*3]=sr/sw;nc[o*3+1]=sg/sw;nc[o*3+2]=sb/sw;nwt[o]=Math.min(1,sw/cnt);}}
    lv.push({w:nw,h:nh,col:nc,wt:nwt});w=nw;h=nh;
  }
  for(let l=lv.length-2;l>=0;l--){
    const c=lv[l],p=lv[l+1];
    for(let y=0;y<c.h;y++)for(let x=0;x<c.w;x++){
      const i=y*c.w+x,q=c.wt[i];if(q>=1)continue;
      const fx=(x+0.5)/2-0.5,fy=(y+0.5)/2-0.5,x0=Math.max(0,Math.min(p.w-1,Math.floor(fx))),y0=Math.max(0,Math.min(p.h-1,Math.floor(fy))),x1=Math.min(p.w-1,x0+1),y1=Math.min(p.h-1,y0+1),tx=Math.max(0,Math.min(1,fx-x0)),ty=Math.max(0,Math.min(1,fy-y0));
      for(let k=0;k<3;k++){const v=(p.col[(y0*p.w+x0)*3+k]*(1-tx)+p.col[(y0*p.w+x1)*3+k]*tx)*(1-ty)+(p.col[(y1*p.w+x0)*3+k]*(1-tx)+p.col[(y1*p.w+x1)*3+k]*tx)*ty;c.col[i*3+k]=c.col[i*3+k]*q+v*(1-q);}
      c.wt[i]=1;
    }
  }
  const out=new ImageData(new Uint8ClampedArray(d),W,H),base=lv[0];
  for(let i=0;i<W*H;i++)if(mask[i]){out.data[i*4]=base.col[i*3];out.data[i*4+1]=base.col[i*3+1];out.data[i*4+2]=base.col[i*3+2];out.data[i*4+3]=255;}
  return out;
}
/* ---------- flat and gradient regions ---------- */
function fa_modelFit(d,w,h,lab,id,bb,mode){
  // bin the region's pixels along a direction (linear) or a distance (radial) and measure the error
  const bw=bb.x1-bb.x0+1,bh=bb.y1-bb.y0+1,cx=(bb.x0+bb.x1)/2,cy=(bb.y0+bb.y1)/2;
  // per-channel plane fit to find the direction
  let n=0,sx=0,sy=0,sxx=0,syy=0,sxy=0;const sc=[0,0,0],sxc=[0,0,0],syc=[0,0,0];
  const stepSkip=Math.max(1,Math.floor(Math.sqrt(bw*bh/20000)));
  for(let y=bb.y0;y<=bb.y1;y+=stepSkip)for(let x=bb.x0;x<=bb.x1;x+=stepSkip){if(lab[y*w+x]!==id)continue;const i=(y*w+x)*4,u=x-cx,v=y-cy;n++;sx+=u;sy+=v;sxx+=u*u;syy+=v*v;sxy+=u*v;for(let c=0;c<3;c++){sc[c]+=d[i+c];sxc[c]+=u*d[i+c];syc[c]+=v*d[i+c];}}
  if(n<10)return null;
  const det=(sxx-sx*sx/n)*(syy-sy*sy/n)-Math.pow(sxy-sx*sy/n,2)||1e-9;
  let best=[0,0],bm=-1;
  for(let c=0;c<3;c++){const cxy=sxc[c]-sx*sc[c]/n,cyy=syc[c]-sy*sc[c]/n,a=((syy-sy*sy/n)*cxy-(sxy-sx*sy/n)*cyy)/det,b=((sxx-sx*sx/n)*cyy-(sxy-sx*sy/n)*cxy)/det,mag=Math.hypot(a*bw,b*bh);if(mag>bm){bm=mag;best=[a,b];}}
  let dx,dy;if(bm<3){dx=0;dy=1;}else{const l=Math.hypot(best[0],best[1]);dx=best[0]/l;dy=best[1]/l;}
  const L=Math.abs(bw*dx)+Math.abs(bh*dy)||1,NB=10;
  const mk=(tf)=>{const sum=new Float32Array(NB*3),cnt=new Float32Array(NB);
    for(let y=bb.y0;y<=bb.y1;y+=stepSkip)for(let x=bb.x0;x<=bb.x1;x+=stepSkip){if(lab[y*w+x]!==id)continue;const t=Math.max(0,Math.min(0.9999,tf(x,y))),b=(t*NB)|0,i=(y*w+x)*4;cnt[b]++;for(let c=0;c<3;c++)sum[b*3+c]+=d[i+c];}
    const bins=[];for(let b=0;b<NB;b++)if(cnt[b]>0)bins.push({t:(b+0.5)/NB,c:[sum[b*3]/cnt[b],sum[b*3+1]/cnt[b],sum[b*3+2]/cnt[b]]});
    if(bins.length<2)return {bins,rms:1e9};
    const at=t=>{if(t<=bins[0].t)return bins[0].c;for(let i=1;i<bins.length;i++)if(t<=bins[i].t){const a=bins[i-1],b=bins[i],f=(t-a.t)/(b.t-a.t);return a.c.map((v,k)=>v+(b.c[k]-v)*f);}return bins[bins.length-1].c;};
    let err=0,m=0;
    for(let y=bb.y0;y<=bb.y1;y+=stepSkip)for(let x=bb.x0;x<=bb.x1;x+=stepSkip){if(lab[y*w+x]!==id)continue;const t=Math.max(0,Math.min(1,tf(x,y))),c=at(t),i=(y*w+x)*4;err+=((d[i]-c[0])**2+(d[i+1]-c[1])**2+(d[i+2]-c[2])**2)/3;m++;}
    return {bins,rms:Math.sqrt(err/Math.max(1,m))};};
  const lin=mk((x,y)=>((x-cx)*dx+(y-cy)*dy)/L+0.5);
  // radial around the centroid
  let ccx=0,ccy=0,cn=0;for(let y=bb.y0;y<=bb.y1;y+=stepSkip)for(let x=bb.x0;x<=bb.x1;x+=stepSkip)if(lab[y*w+x]===id){ccx+=x;ccy+=y;cn++;}
  ccx/=cn;ccy/=cn;let R=1;for(let y=bb.y0;y<=bb.y1;y+=stepSkip)for(let x=bb.x0;x<=bb.x1;x+=stepSkip)if(lab[y*w+x]===id)R=Math.max(R,Math.hypot(x-ccx,y-ccy));
  const rad=mk((x,y)=>Math.hypot(x-ccx,y-ccy)/R);
  const useRad=rad.rms<lin.rms*0.75;
  const pick=useRad?rad:lin,bins=pick.bins;
  // simplify the stops
  let stops=bins.map(b=>({o:b.t,c:b.c}));
  stops.unshift({o:0,c:stops[0].c});stops.push({o:1,c:stops[stops.length-1].c});
  for(let i=stops.length-2;i>0;i--){const a=stops[i-1],b=stops[i],c=stops[i+1],f=(b.o-a.o)/(c.o-a.o),dev=Math.max(...b.c.map((v,k)=>Math.abs(v-(a.c[k]+(c.c[k]-a.c[k])*f))));if(dev<5)stops.splice(i,1);}
  const hex=c=>'#'+c.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')).join('');
  const solid=stops.every(s=>Math.max(...s.c.map((v,k)=>Math.abs(v-stops[0].c[k])))<4);
  const grad=solid?null:(useRad?{kind:'radial',angle:0,cx:(ccx-bb.x0)/bw,cy:(ccy-bb.y0)/bh,r:R/Math.max(bw,bh),stops:stops.map(s=>({o:s.o,c:hex(s.c),a:1}))}
    :{kind:'linear',angle:Math.round((Math.atan2(dx,-dy)*180/Math.PI+360)%360),cx:.5,cy:.5,r:.7,stops:stops.map(s=>({o:s.o,c:hex(s.c),a:1}))});
  return {rms:pick.rms,grad,color:hex(stops[Math.floor(stops.length/2)].c),solid};
}
function fa_findShapes(A,clean,textBoxes,opt){
  opt=opt||{};
  const {w,h}=A,d=clean,s=fa_blur(d,w,h),G=fa_grad(s,w,h),thr=opt.flat||7;
  let S=new Uint8Array(w*h);for(let i=0;i<S.length;i++)S[i]=G[i]<thr?1:0;
  S=fa_boxMax(fa_erode(S,w,h,1,1),w,h,1,1);
  const {lab,comps}=fa_cc(S,w,h,false),minA=Math.max(60,w*h*0.0015),res=[];
  let bgIdx=-1,bgArea=0;
  for(const c of comps){
    if(c.area<minA)continue;
    const bb={x0:c.x0,y0:c.y0,x1:c.x1,y1:c.y1},fit=fa_modelFit(s,w,h,lab,c.id,bb);
    if(!fit||fit.rms>(opt.rms||11))continue;
    if((textBoxes||[]).some(t=>{const ix=Math.min(c.x1,t.x+t.w)-Math.max(c.x0,t.x),iy=Math.min(c.y1,t.y+t.h)-Math.max(c.y0,t.y);return ix>0&&iy>0&&ix*iy>0.6*(c.x1-c.x0+1)*(c.y1-c.y0+1);}))continue;
    const bw=c.x1-c.x0+1,bh=c.y1-c.y0+1,touch=(c.x0<=1||c.y0<=1||c.x1>=w-2||c.y1>=h-2),ratio=c.area/(bw*bh);
    const it={id:c.id,area:c.area,box:{x:c.x0,y:c.y0,w:bw,h:bh},touch,ratio,fit};
    if(touch&&c.area>w*h*0.18&&c.area>bgArea){bgArea=c.area;bgIdx=res.length;}
    res.push(it);
  }
  res.forEach((it,i)=>{
    it.isBg=i===bgIdx;
    if(it.isBg){const full={x0:0,y0:0,x1:w-1,y1:h-1},f2=fa_modelFit(s,w,h,lab,it.id,full);if(f2&&f2.rms<=(opt.rms||11)+2){it.fit=f2;it.kind='rect';it.box={x:0,y:0,w:w,h:h};}else it.isBg=false;}
    if(!it.isBg){
      const r=it.ratio;
      if(r>=0.93)it.kind='rect';
      else if(r>=0.72&&r<=0.84&&Math.abs(it.box.w/it.box.h-1)<4)it.kind='ellipse';
      else if(r>=0.84){it.kind='round';it.radius=Math.min(it.box.w,it.box.h)/2*Math.min(1,Math.sqrt(Math.max(0,(it.box.w*it.box.h-it.area)/(4-Math.PI)))/(Math.min(it.box.w,it.box.h)/2));}
      else it.kind='cutout';
    }
  });
  const bgIt=res.find(i=>i.isBg),bgCol=bgIt&&bgIt.fit.grad?null:(bgIt?bgIt.fit.color:null);
  const hx=c=>[parseInt(c.slice(1,3),16),parseInt(c.slice(3,5),16),parseInt(c.slice(5,7),16)];
  const sameAsBg=it=>{if(it.isBg||!bgIt)return false;const bs=bgIt.fit.grad?bgIt.fit.grad.stops.map(s=>hx(s.c)):[hx(bgIt.fit.color)],c=hx(it.fit.color);return bs.some(b=>Math.max(Math.abs(b[0]-c[0]),Math.abs(b[1]-c[1]),Math.abs(b[2]-c[2]))<16)&&!it.fit.grad&&it.area<w*h*0.05;};
  const keepK=res.filter(i=>!sameAsBg(i)).filter(it=>it.isBg||it.kind!=='cutout'||(it.area>w*h*0.02&&it.fit.rms<5));
  return {lab,items:keepK,S};
}
