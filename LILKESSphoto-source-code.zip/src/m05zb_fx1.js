/* ===== More filters: Blur, Blur Gallery, Distort, Noise, Pixelate, Sharpen, Other ===== */
Object.assign(FX_GROUPS,{blurgal:'Blur Gallery',render:'Render',other:'Other',artistic:'Artistic',brush:'Brush Strokes',sketch:'Sketch',texture:'Texture'});
const fxRnd=seed=>{let s=(seed>>>0)||1;return()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);};
const fxLum=(d,i)=>0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];
const fxGB=(d,w,h,r)=>{r=Math.round(r);if(r>=1)boxBlur(d,w,h,r,3);return d;};
const fxSS=t=>{t=t<0?0:t>1?1:t;return t*t*(3-2*t);};
const fxOut=(img,fn)=>{const w=img.width,h=img.height,o=cp(img);fn(img.data,o,w,h);return mkImg(o,w,h);};
/* smooth value noise */
function fxHash(x,y,s){let h=Math.imul(x|0,374761393)^Math.imul(y|0,668265263)^Math.imul(s|0,2147483647);h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296;}
function fxNoise(x,y,s){const x0=Math.floor(x),y0=Math.floor(y),fx=fxSS(x-x0),fy=fxSS(y-y0);
  const a=fxHash(x0,y0,s),b=fxHash(x0+1,y0,s),c=fxHash(x0,y0+1,s),d=fxHash(x0+1,y0+1,s);return (a+(b-a)*fx)+((c+(d-c)*fx)-(a+(b-a)*fx))*fy;}
function fxFbm(x,y,s,oct){let v=0,a=0.5,f=1,t=0;for(let i=0;i<oct;i++){v+=a*fxNoise(x*f,y*f,s+i*17);t+=a;a*=0.5;f*=2;}return v/t;}
function fxMedian(img,r){ // Huang sliding-window histogram median, per channel
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length);r=Math.max(1,Math.round(r));
  const half=((2*r+1)*(2*r+1)+1)>>1;
  for(let c=0;c<3;c++){
    for(let y=0;y<h;y++){
      const hist=new Int32Array(256);
      for(let yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy++)for(let xx=0;xx<=Math.min(w-1,r);xx++)hist[s[(yy*w+xx)*4+c]]++;
      let cnt=0;for(let yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy++)cnt+=Math.min(w-1,r)+1;
      for(let x=0;x<w;x++){
        if(x>0){const ax=x+r,rx=x-r-1;
          if(ax<w){for(let yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy++){hist[s[(yy*w+ax)*4+c]]++;cnt++;}}
          if(rx>=0){for(let yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy++){hist[s[(yy*w+rx)*4+c]]--;cnt--;}}}
        const target=(cnt+1)>>1;let a=0,v=0;while(v<255&&a+hist[v]<target){a+=hist[v];v++;}
        o[(y*w+x)*4+c]=v;
      }
    }
  }
  for(let i=3;i<o.length;i+=4)o[i]=s[i];
  return mkImg(o,w,h);
}
function fxSobel(L,w,h){const m=new Float32Array(w*h);for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x,gx=-L[i-w-1]-2*L[i-1]-L[i+w-1]+L[i-w+1]+2*L[i+1]+L[i+w+1],gy=-L[i-w-1]-2*L[i-w]-L[i-w+1]+L[i+w-1]+2*L[i+w]+L[i+w+1];m[i]=Math.hypot(gx,gy);}return m;}
function fxTapBlur(img,taps,wf){ // average of taps (dx,dy), optional per-pixel weight array
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),n=taps.length;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    let r=0,g=0,b=0,a=0,ws=0;
    for(let t=0;t<n;t++){let sx=Math.round(x+taps[t][0]),sy=Math.round(y+taps[t][1]);sx=sx<0?0:sx>=w?w-1:sx;sy=sy<0?0:sy>=h?h-1:sy;const k=sy*w+sx,wt=wf?wf[k]:1,i=k*4;r+=s[i]*wt;g+=s[i+1]*wt;b+=s[i+2]*wt;a+=s[i+3];ws+=wt;}
    const i=(y*w+x)*4;o[i]=r/ws;o[i+1]=g/ws;o[i+2]=b/ws;o[i+3]=a/n;
  }
  return mkImg(o,w,h);
}
/* ---------- Blur ---------- */
defFx('lensblur','blur','Lens Blur',[P('r','Radius',1,60,12),P('n','Blades (3-8, 9 = round)',3,9,6),P('rot','Blade rotation',0,360,0),P('b','Highlight brightness',0,100,40),P('t','Highlight threshold',150,255,230)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,R=sc(p.r,c);if(R<1)return mkImg(cp(img),w,h);
  const N=Math.round(clamp(R*3,12,56)),taps=[],n=Math.round(p.n),rot=p.rot*Math.PI/180,seg=2*Math.PI/n;
  for(let i=0;i<N;i++){const rr=Math.sqrt((i+0.5)/N),a=i*2.399963;let rad=rr;if(n<9){const ang=(((a-rot)%seg)+seg)%seg-seg/2;rad=rr*Math.cos(Math.PI/n)/Math.cos(ang);}taps.push([Math.cos(a)*rad*R,Math.sin(a)*rad*R]);}
  const W8=new Float32Array(w*h),boost=p.b/100*8,thr=p.t;
  for(let i=0,k=0;i<s.length;i+=4,k++){const L=fxLum(s,i);W8[k]=1+(L>thr?boost*Math.pow((L-thr)/Math.max(1,255-thr),2):0);}
  return fxTapBlur(img,taps,W8);
});
function fxShapeIn(k,u,v){switch(k){case 0:return u*u+v*v<=1;case 1:return true;case 2:return Math.abs(u)+Math.abs(v)<=1;
  case 3:{const r=Math.hypot(u,v),a=Math.atan2(v,u)+Math.PI/2;return r<=0.45+0.55*Math.abs(Math.cos(2.5*a));}
  case 4:{const x=u*1.25,y=-v*1.25+0.15,q=x*x+y*y-1;return q*q*q-x*x*y*y*y<=0;}
  default:return v>=-1&&Math.abs(u)<=(v+1)/2;}}
defFx('shapeblur','blur','Shape Blur',[P('r','Radius',2,80,14),P('sh','Shape (0 round,1 square,2 diamond,3 star,4 heart,5 triangle)',0,5,0)],(img,p,c)=>{
  const R=sc(p.r,c),taps=[],k=Math.round(p.sh),step=Math.max(1,R/6);
  for(let y=-R;y<=R;y+=step)for(let x=-R;x<=R;x+=step)if(fxShapeIn(k,x/R,y/R))taps.push([x,y]);
  if(!taps.length)taps.push([0,0]);
  return fxTapBlur(img,taps);
});
defFx('smartblur','blur','Smart Blur',[P('r','Radius',1,60,6),P('t','Threshold',1,100,25)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const bl=new Uint8ClampedArray(s);fxGB(bl,w,h,sc(p.r,c)*0.85);
  for(let i=0;i<s.length;i+=4){const dm=Math.max(Math.abs(s[i]-bl[i]),Math.abs(s[i+1]-bl[i+1]),Math.abs(s[i+2]-bl[i+2])),k=1-fxSS(dm/p.t);for(let q=0;q<3;q++)o[i+q]=s[i+q]+(bl[i+q]-s[i+q])*k;}
}));
defFx('surfaceblur','blur','Surface Blur',[P('r','Radius',1,40,8),P('t','Threshold',2,100,24)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),R=sc(p.r,c),N=Math.round(clamp(R*2.5,10,40)),taps=[],t2=2*p.t*p.t;
  for(let i=0;i<N;i++){const rr=Math.sqrt((i+0.5)/N)*R,a=i*2.399963;taps.push([Math.cos(a)*rr,Math.sin(a)*rr]);}
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;let r=s[i],g=s[i+1],b=s[i+2],ws=1;
    for(let k=0;k<N;k++){let sx=Math.round(x+taps[k][0]),sy=Math.round(y+taps[k][1]);sx=sx<0?0:sx>=w?w-1:sx;sy=sy<0?0:sy>=h?h-1:sy;const j=(sy*w+sx)*4,dr=s[j]-s[i],dg=s[j+1]-s[i+1],db=s[j+2]-s[i+2],wt=Math.exp(-(dr*dr+dg*dg+db*db)/3/t2);r+=s[j]*wt;g+=s[j+1]*wt;b+=s[j+2]*wt;ws+=wt;}
    o[i]=r/ws;o[i+1]=g/ws;o[i+2]=b/ws;o[i+3]=s[i+3];}
  return mkImg(o,w,h);
});
/* ---------- Blur Gallery ---------- */
function fxLevels(img,amount,n){const w=img.width,h=img.height,out=[img.data];for(let i=1;i<=n;i++){const d=cp(img);fxGB(d,w,h,amount*i/n*0.85);out.push(d);}return out;}
function fxMix(levels,o,k,i){ // k in 0..levels-1 (float)
  const a=Math.min(levels.length-2,Math.floor(k)),f=k-a,A=levels[a],B=levels[a+1];for(let q=0;q<4;q++)o[i+q]=A[i+q]+(B[i+q]-A[i+q])*f;}
defFx('fieldblur','blurgal','Field Blur',[P('cx','Focus X %',0,100,50),P('cy','Focus Y %',0,100,50),P('f','Sharp area %',0,80,15),P('b','Blur amount',1,60,18)],(img,p,c)=>{
  const w=img.width,h=img.height,o=new Uint8ClampedArray(img.data.length),lv=fxLevels(img,sc(p.b,c),3),cx=w*p.cx/100,cy=h*p.cy/100,diag=Math.hypot(w,h),f0=diag*p.f/200;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=clamp((Math.hypot(x-cx,y-cy)-f0)/(diag*0.4),0,1);fxMix(lv,o,t*3,(y*w+x)*4);}
  return mkImg(o,w,h);
});
defFx('irisblur','blurgal','Iris Blur',[P('cx','Center X %',0,100,50),P('cy','Center Y %',0,100,50),P('rx','Width %',5,100,30),P('ry','Height %',5,100,30),P('fe','Feather %',5,100,50),P('b','Blur amount',1,60,20)],(img,p,c)=>{
  const w=img.width,h=img.height,o=new Uint8ClampedArray(img.data.length),lv=fxLevels(img,sc(p.b,c),3),cx=w*p.cx/100,cy=h*p.cy/100,rx=w*p.rx/200,ry=h*p.ry/200,inner=1-p.fe/100*0.9;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const e=Math.hypot((x-cx)/rx,(y-cy)/ry),t=fxSS((e-inner)/Math.max(0.05,1.8-inner));fxMix(lv,o,t*3,(y*w+x)*4);}
  return mkImg(o,w,h);
});
defFx('pathblur','blurgal','Path Blur',[P('a','Direction',-180,180,0),P('cv','Curve',-90,90,30),P('d','Distance',1,200,40)],(img,p,c)=>{
  const w=img.width,h=img.height,d=sc(p.d,c),A=motionBlurData(img.data,w,h,p.a-p.cv,d),B=motionBlurData(img.data,w,h,p.a+p.cv,d),o=new Uint8ClampedArray(A.length);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=x/w,i=(y*w+x)*4;for(let q=0;q<4;q++)o[i+q]=A[i+q]+(B[i+q]-A[i+q])*t;}
  return mkImg(o,w,h);
});
defFx('spinblur','blurgal','Spin Blur',[P('an','Angle',1,90,12),P('cx','Center X %',0,100,50),P('cy','Center Y %',0,100,50),P('r','Blur area %',5,100,45),P('fe','Feather %',0,100,50)],(img,p)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),cx=w*p.cx/100,cy=h*p.cy/100,R=Math.min(w,h)*p.r/100,fe=Math.max(0.05,p.fe/100),A=p.an*Math.PI/180,n=14;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,dist=Math.hypot(x-cx,y-cy),k=clamp((dist/R-(1-fe))/fe,0,1)<1?1-fxSS((dist/R-(1-fe))/fe):0;
    if(k<=0.01&&dist<R*0.0001){for(let q=0;q<4;q++)o[i+q]=s[i+q];continue;}
    let r=0,g=0,b=0,a=0;
    for(let t=0;t<n;t++){const an=A*((t/(n-1))-0.5)*(dist/Math.max(1,R))*2*Math.min(1,dist/Math.max(1,R)+0.2),cs=Math.cos(an),sn=Math.sin(an),vx=x-cx,vy=y-cy;let sx=Math.round(cx+vx*cs-vy*sn),sy=Math.round(cy+vx*sn+vy*cs);sx=sx<0?0:sx>=w?w-1:sx;sy=sy<0?0:sy>=h?h-1:sy;const j=(sy*w+sx)*4;r+=s[j];g+=s[j+1];b+=s[j+2];a+=s[j+3];}
    const m=dist>=R?0:1-fxSS(clamp((dist/R-(1-fe))/fe,0,1))*0;const wgt=1-fxSS(clamp((dist-R*(1-fe))/(R*fe+1e-6),0,1));
    // inside the area: sharp near the centre, spin blur grows outwards; outside the area: full blur
    const mix=dist<R*(1-fe)?clamp(dist/(R*(1-fe)+1e-6),0,1):1;
    o[i]=s[i]+(r/n-s[i])*mix;o[i+1]=s[i+1]+(g/n-s[i+1])*mix;o[i+2]=s[i+2]+(b/n-s[i+2])*mix;o[i+3]=s[i+3];
  }
  return mkImg(o,w,h);
});
/* ---------- Distort ---------- */
defFx('wave','distort','Wave',[P('ax','Horizontal amount',0,100,12),P('ay','Vertical amount',0,100,12),P('wl','Wavelength',5,400,60),P('ph','Phase',0,360,0)],(img,p,c)=>{
  const ax=sc(p.ax,c),ay=sc(p.ay,c),wl=Math.max(2,sc(p.wl,c)),ph=p.ph*Math.PI/180;
  return warp(img,(x,y,o)=>{o[0]=x+ax*Math.sin(y/wl*2*Math.PI+ph);o[1]=y+ay*Math.sin(x/wl*2*Math.PI+ph);});
});
defFx('zigzag','distort','ZigZag',[P('a','Amount',-100,100,40),P('rd','Ridges',1,40,8),P('st','Style (0 around, 1 out from centre, 2 pond ripples)',0,2,2)],(img,p)=>{
  const w=img.width,h=img.height,cx=w/2,cy=h/2,R=Math.min(w,h)/2,st=Math.round(p.st);
  return warp(img,(x,y,o)=>{const dx=x-cx,dy=y-cy,d=Math.hypot(dx,dy);if(d>R){o[0]=x;o[1]=y;return;}
    const ph=Math.sin(d/R*p.rd*Math.PI*2)*(p.a/100)*(1-d/R);
    if(st===0){const an=ph*1.2,cs=Math.cos(an),sn=Math.sin(an);o[0]=cx+dx*cs-dy*sn;o[1]=cy+dx*sn+dy*cs;}
    else if(st===1){const k=1+ph*0.35;o[0]=cx+dx*k;o[1]=cy+dy*k;}
    else{const k=d>0?ph*R*0.12/d:0;o[0]=x+dx*k;o[1]=y+dy*k;}});
});
defFx('shear','distort','Shear',[P('a','Bend',-100,100,40),P('ax','Axis (0 vertical, 1 horizontal)',0,1,0)],(img,p)=>{
  const w=img.width,h=img.height,hor=p.ax>=0.5;
  return warp(img,(x,y,o)=>{if(!hor){o[0]=x-Math.sin(y/h*Math.PI-Math.PI/2)*w*p.a/200;o[1]=y;}else{o[0]=x;o[1]=y-Math.sin(x/w*Math.PI-Math.PI/2)*h*p.a/200;}});
});
defFx('polar','distort','Polar Coordinates',[P('m','Mode (0 rectangular to polar, 1 polar to rectangular)',0,1,0)],(img,p)=>{
  const w=img.width,h=img.height,cx=w/2,cy=h/2,R=Math.min(w,h)/2,rect2polar=p.m<0.5;
  return warp(img,(x,y,o)=>{
    if(rect2polar){const dx=x-cx,dy=y-cy,a=Math.atan2(dx,-dy),r=Math.hypot(dx,dy);o[0]=((a/(2*Math.PI)+0.5))*w;o[1]=r/R*h;}
    else{const a=(x/w-0.5)*2*Math.PI,r=y/h*R;o[0]=cx+Math.sin(a)*r;o[1]=cy-Math.cos(a)*r;}});
});
defFx('oceanripple','distort','Ocean Ripple',[P('sz','Ripple size',1,30,8),P('m','Ripple magnitude',1,40,10)],(img,p,c)=>{
  const sz=Math.max(2,sc(p.sz,c)*4),m=sc(p.m,c);
  return warp(img,(x,y,o)=>{o[0]=x+(fxNoise(x/sz,y/sz,3)-0.5)*2*m;o[1]=y+(fxNoise(x/sz,y/sz,9)-0.5)*2*m;});
});
defFx('glass','distort','Glass',[P('d','Distortion',0,30,8),P('sm','Smoothness',1,15,5),P('s','Scale %',20,300,100)],(img,p,c)=>{
  const sm=Math.max(1,sc(p.sm,c))*4*p.s/100,m=sc(p.d,c)*2,e=0.5;
  return warp(img,(x,y,o)=>{const n0=fxNoise(x/sm,y/sm,5),gx=fxNoise((x+e)/sm,y/sm,5)-n0,gy=fxNoise(x/sm,(y+e)/sm,5)-n0;o[0]=x+gx*m*sm*1.2;o[1]=y+gy*m*sm*1.2;});
});
defFx('diffuseglow','distort','Diffuse Glow',[P('g','Graininess',0,20,6),P('gl','Glow amount',0,20,8),P('c','Clear amount',1,20,15)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const rnd=fxRnd(7),gl=new Uint8ClampedArray(s),amt=p.gl/20;
  for(let i=0;i<gl.length;i+=4){const L=fxLum(s,i)/255,n=(rnd()-0.5)*p.g*14,k=Math.max(0,(L-(1-p.c/40)))/(p.c/40+0.05);for(let q=0;q<3;q++)gl[i+q]=clamp(s[i+q]*k+n*k,0,255);}
  fxGB(gl,w,h,Math.max(2,sc(p.gl,c)*1.5));
  for(let i=0;i<s.length;i+=4)for(let q=0;q<3;q++)o[i+q]=255-(255-s[i+q])*(255-gl[i+q]*amt*2.2)/255;
}));
/* ---------- Noise ---------- */
defFx('despeckle','noise','Despeckle',[],(img)=>fxMedian(img,1),{immediate:true});
defFx('dust','noise','Dust & Scratches',[P('r','Radius',1,8,2),P('t','Threshold',0,128,12)],(img,p,c)=>{
  const m=fxMedian(img,Math.max(1,Math.round(sc(p.r,c)))),s=img.data,md=m.data,o=cp(img);
  for(let i=0;i<o.length;i+=4){const dm=Math.max(Math.abs(s[i]-md[i]),Math.abs(s[i+1]-md[i+1]),Math.abs(s[i+2]-md[i+2]));if(dm>=p.t){o[i]=md[i];o[i+1]=md[i+1];o[i+2]=md[i+2];}}
  return mkImg(o,img.width,img.height);
});
defFx('medianf','noise','Median',[P('r','Radius',1,10,2)],(img,p,c)=>fxMedian(img,Math.max(1,Math.round(sc(p.r,c)))));
/* ---------- Pixelate ---------- */
function fxCells(w,h,cell,seed){ // jittered grid of seed points; returns sampler
  const gw=Math.ceil(w/cell)+2,gh=Math.ceil(h/cell)+2,px=new Float32Array(gw*gh),py=new Float32Array(gw*gh),rnd=fxRnd(seed);
  for(let j=0;j<gh;j++)for(let i=0;i<gw;i++){px[j*gw+i]=(i-1+0.15+rnd()*0.7)*cell;py[j*gw+i]=(j-1+0.15+rnd()*0.7)*cell;}
  const id=new Int32Array(w*h),dist=new Float32Array(w*h);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const ci=Math.floor(x/cell)+1,cj=Math.floor(y/cell)+1;let best=1e9,bi=0;
    for(let dj=-1;dj<=1;dj++)for(let di=-1;di<=1;di++){const gi=Math.min(gw-1,Math.max(0,ci+di)),gj=Math.min(gh-1,Math.max(0,cj+dj)),k=gj*gw+gi,d=(px[k]-x)*(px[k]-x)+(py[k]-y)*(py[k]-y);if(d<best){best=d;bi=k;}}
    id[y*w+x]=bi;dist[y*w+x]=Math.sqrt(best);}
  return {id,dist,n:gw*gh,px,py,gw};
}
defFx('crystallize','pixelate','Crystallize',[P('s','Cell size',3,200,24)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,cell=Math.max(3,sc(p.s,c)),C=fxCells(w,h,cell,11),sum=new Float64Array(C.n*4),cnt=new Float64Array(C.n),o=new Uint8ClampedArray(s.length);
  for(let k=0,i=0;k<w*h;k++,i+=4){const id=C.id[k];sum[id*4]+=s[i];sum[id*4+1]+=s[i+1];sum[id*4+2]+=s[i+2];sum[id*4+3]+=s[i+3];cnt[id]++;}
  for(let k=0,i=0;k<w*h;k++,i+=4){const id=C.id[k],n=cnt[id];o[i]=sum[id*4]/n;o[i+1]=sum[id*4+1]/n;o[i+2]=sum[id*4+2]/n;o[i+3]=sum[id*4+3]/n;}
  return mkImg(o,w,h);
});
defFx('pointillize','pixelate','Pointillize',[P('s','Cell size',3,200,18)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,cell=Math.max(3,sc(p.s,c)),C=fxCells(w,h,cell,5),o=new Uint8ClampedArray(s.length),bg=hexRGB(S.bg||'#ffffff');
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=y*w+x,id=C.id[k],cx=Math.max(0,Math.min(w-1,Math.round(C.px[id]))),cy=Math.max(0,Math.min(h-1,Math.round(C.py[id]))),j=(cy*w+cx)*4,i=k*4,inside=C.dist[k]<cell*0.5?1:fxSS(1-(C.dist[k]-cell*0.5)/1.2);
    for(let q=0;q<3;q++)o[i+q]=bg[q]+(s[j+q]-bg[q])*inside;o[i+3]=255;}
  return mkImg(o,w,h);
});
function hexRGB(c){c=String(c);if(c[0]==='#'){if(c.length===4)c='#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return [parseInt(c.slice(1,3),16),parseInt(c.slice(3,5),16),parseInt(c.slice(5,7),16)];}return [255,255,255];}
defFx('colorhalftone','pixelate','Color Halftone',[P('r','Max radius',4,60,8),P('a1','Channel 1 angle',0,90,108%90),P('a2','Channel 2 angle',0,90,162%90),P('a3','Channel 3 angle',0,90,90%90||45)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),R=Math.max(3,sc(p.r,c)),sp=R*1.55,bl=cp(img);fxGB(bl,w,h,sp*0.5);
  const ang=[p.a1,p.a2,p.a3].map(a=>a*Math.PI/180);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
    for(let q=0;q<3;q++){const cs=Math.cos(ang[q]),sn=Math.sin(ang[q]),u=x*cs+y*sn,v=-x*sn+y*cs,cu=(Math.floor(u/sp)+0.5)*sp,cv=(Math.floor(v/sp)+0.5)*sp,sx=Math.max(0,Math.min(w-1,Math.round(cu*cs-cv*sn))),sy=Math.max(0,Math.min(h-1,Math.round(cu*sn+cv*cs))),val=bl[(sy*w+sx)*4+q]/255,rad=R*Math.sqrt(val)*1.05,d=Math.hypot(u-cu,v-cv);
      o[i+q]=255*clamp(rad-d+0.5,0,1);}
    o[i+3]=s[i+3];}
  return mkImg(o,w,h);
});
defFx('facet','pixelate','Facet',[],(img)=>{let m=fxMedian(img,2);m=fxMedian(m,2);const d=m.data;for(let i=0;i<d.length;i+=4)for(let q=0;q<3;q++)d[i+q]=Math.round(d[i+q]/12)*12;return m;},{immediate:true});
defFx('fragment','pixelate','Fragment',[P('d','Offset',1,40,4)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const d=Math.max(1,Math.round(sc(p.d,c))),at=(x,y,q)=>s[(Math.min(h-1,Math.max(0,y))*w+Math.min(w-1,Math.max(0,x)))*4+q];
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;for(let q=0;q<4;q++)o[i+q]=(at(x+d,y,q)+at(x-d,y,q)+at(x,y+d,q)+at(x,y-d,q))/4;}
}));
defFx('mezzotint','pixelate','Mezzotint',[P('t','Dot size',1,6,2),P('col','Colour (0 black & white, 1 colour)',0,1,0)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  const k=Math.max(1,Math.round(sc(p.t,c))),rnd=fxRnd(21);
  for(let y0=0;y0<h;y0+=k)for(let x0=0;x0<w;x0+=k){const n=[rnd(),rnd(),rnd()];
    for(let y=y0;y<Math.min(h,y0+k);y++)for(let x=x0;x<Math.min(w,x0+k);x++){const i=(y*w+x)*4;
      if(p.col>=0.5){for(let q=0;q<3;q++)o[i+q]=s[i+q]/255>n[q]?255:0;}else{const v=fxLum(s,i)/255>n[0]?255:0;o[i]=o[i+1]=o[i+2]=v;}}}
}));
/* ---------- Sharpen ---------- */
defFx('sharpmore','sharpen','Sharpen More',[],(img,p,c)=>unsharp(img,220,1.2,0,c),{immediate:true});
defFx('sharpedges','sharpen','Sharpen Edges',[P('a','Amount',10,400,150),P('t','Edge threshold',1,80,12)],(img,p,c)=>{
  const w=img.width,h=img.height,u=unsharp(img,p.a,1.5,0,c),s=img.data,o=cp(img),L=lumA(img),e=fxSobel(L,w,h);
  for(let k=0,i=0;k<w*h;k++,i+=4){const m=fxSS(e[k]/(p.t*8));for(let q=0;q<3;q++)o[i+q]=s[i+q]+(u.data[i+q]-s[i+q])*m;}
  return mkImg(o,w,h);
});
defFx('smartsharpen','sharpen','Smart Sharpen',[P('a','Amount %',1,500,120),P('r','Radius (px)',0.5,40,2,0.5),P('n','Reduce noise',0,100,20),P('rm','Remove (0 Gaussian, 1 motion)',0,1,0),P('an','Motion angle',-180,180,0)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{
  let bl;if(p.rm>=0.5)bl=motionBlurData(s,w,h,p.an,Math.max(1,sc(p.r,c)*2));else{bl=new Uint8ClampedArray(s);fxGB(bl,w,h,sc(p.r,c)*0.85);}
  const k=p.a/100,nr=p.n/100*20;
  for(let i=0;i<s.length;i+=4)for(let q=0;q<3;q++){const d=s[i+q]-bl[i+q],g=nr>0?fxSS(Math.abs(d)/nr):1;o[i+q]=s[i+q]+d*k*g;}
}));
/* ---------- Other ---------- */
defFx('highpass','other','High Pass',[P('r','Radius (px)',1,100,8)],(img,p,c)=>fxOut(img,(s,o,w,h)=>{const bl=new Uint8ClampedArray(s);fxGB(bl,w,h,sc(p.r,c)*0.85);for(let i=0;i<s.length;i+=4)for(let q=0;q<3;q++)o[i+q]=128+s[i+q]-bl[i+q];}));
function fxMinMax(img,r,max){
  const w=img.width,h=img.height,s=img.data,t=new Uint8ClampedArray(s.length),o=new Uint8ClampedArray(s.length);r=Math.max(1,Math.round(r));
  const cmp=max?(a,b)=>a>b:(a,b)=>a<b;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;for(let q=0;q<3;q++){let v=s[i+q];for(let k=-r;k<=r;k++){const xx=Math.min(w-1,Math.max(0,x+k)),u=s[(y*w+xx)*4+q];if(cmp(u,v))v=u;}t[i+q]=v;}t[i+3]=s[i+3];}
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;for(let q=0;q<3;q++){let v=t[i+q];for(let k=-r;k<=r;k++){const yy=Math.min(h-1,Math.max(0,y+k)),u=t[(yy*w+x)*4+q];if(cmp(u,v))v=u;}o[i+q]=v;}o[i+3]=s[i+3];}
  return mkImg(o,w,h);
}
defFx('maximum','other','Maximum',[P('r','Radius',1,20,2)],(img,p,c)=>fxMinMax(img,sc(p.r,c),true));
defFx('minimum','other','Minimum',[P('r','Radius',1,20,2)],(img,p,c)=>fxMinMax(img,sc(p.r,c),false));
defFx('offset','other','Offset',[P('x','Horizontal',-2000,2000,100),P('y','Vertical',-2000,2000,0),P('m','Edges (0 wrap around, 1 repeat, 2 transparent)',0,2,0)],(img,p,c)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),ox=Math.round(sc(p.x,c)*(p.x<0?-1:1)*(p.x<0?-1:1)),oy=Math.round(sc(p.y,c)),m=Math.round(p.m);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){let sx=x-ox,sy=y-oy;const i=(y*w+x)*4;
    if(m===0){sx=((sx%w)+w)%w;sy=((sy%h)+h)%h;}else if(m===1){sx=clamp(sx,0,w-1);sy=clamp(sy,0,h-1);}else if(sx<0||sy<0||sx>=w||sy>=h){continue;}
    const j=(sy*w+sx)*4;o[i]=s[j];o[i+1]=s[j+1];o[i+2]=s[j+2];o[i+3]=s[j+3];}
  return mkImg(o,w,h);
});
{const cust=[0,-1,0,-1,5,-1,0,-1,0];
defFx('custom','other','Custom',cust.map((v,i)=>P('k'+i,'Weight '+(i+1)+' ('+['top-left','top','top-right','left','centre','right','bottom-left','bottom','bottom-right'][i]+')',-10,10,v)).concat([P('sc','Scale',1,100,1),P('of','Offset',-255,255,0)]),(img,p)=>{
  const w=img.width,h=img.height,s=img.data,o=new Uint8ClampedArray(s.length),k=[0,1,2,3,4,5,6,7,8].map(i=>p['k'+i]);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;for(let q=0;q<3;q++){let a=0,n=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=Math.min(w-1,Math.max(0,x+dx)),yy=Math.min(h-1,Math.max(0,y+dy));a+=s[(yy*w+xx)*4+q]*k[n++];}o[i+q]=a/p.sc+p.of;}o[i+3]=s[i+3];}
  return mkImg(o,w,h);
});}
