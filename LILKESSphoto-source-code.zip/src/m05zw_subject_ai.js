/* ===== Select Subject engine: a real neural network (U2-Net small, Apache-2.0) =====
   - the network runs in a background worker (WebGL2 on the GPU, plain CPU if there is no usable GPU)
   - the result is a soft probability map, refined at high resolution with a colour guided filter so hair and fine edges follow the picture
   - modes: Subject, All subjects, People, Object (tap or rough region)
   Honest limits: it is a small general "salient object" model, not a dedicated person or hair matting network. */

/* ---------- worker ---------- */
function aiWorkerMain(){
  const M={};let GL=null,mode='cpu',why='',R=null;
  onmessage=function(e){
    const m=e.data;
    try{
      if(m.t==='load'){
        if(!R)R=ort_make();
        const G=R.parse(new Uint8Array(m.buf));
        if(m.out){const ix=G.nodes.findIndex(n=>n.o[0]===m.out);G.nodes=G.nodes.slice(0,ix+1);G.outputs=[m.out];}
        M[m.k]={G,cache:null};
        if(m.k==='sal'){
          try{if(typeof OffscreenCanvas==='undefined')throw new Error('no OffscreenCanvas');GL=ortgl_make();GL.init(new OffscreenCanvas(16,16));mode='gpu';}
          catch(err){GL=null;mode='cpu';why=String(err&&err.message||err);}
        }
        if(GL&&mode==='gpu'){try{M[m.k].cache=GL.prepare(G);}catch(err){mode='cpu';why=String(err&&err.message||err);}}
        postMessage({t:'loaded',k:m.k,mode,why});
      }else if(m.t==='run'){
        const X=M[m.k],s=m.s,x=m.data,prog=p=>postMessage({t:'prog',id:m.id,p});
        let out=null;
        if(mode==='gpu'){
          try{if(!X.cache)X.cache=GL.prepare(X.G);out=GL.run(X.G,X.cache,X.G.inputs[0],GL.upload(x,3,s,s),prog);}
          catch(err){mode='cpu';why=String(err&&err.message||err);out=null;}
        }
        if(!out)out=R.run(X.G,X.G.inputs[0],{d:[1,3,s,s],v:x},prog)[0];
        const v=out.v;postMessage({t:'done',id:m.id,v,d:out.d,mode,why},[v.buffer]);
      }
    }catch(err){postMessage({t:'err',id:m.id,msg:String(err&&err.message||err)});}
  };
}
const AI={w:null,mode:null,loading:null,seq:0,cb:{},cache:null,job:null};
function aiFail(err){for(const k of Object.keys(AI.cb)){const c=AI.cb[k];delete AI.cb[k];try{c.no(err);}catch(e){}}}
function aiSpawn(){
  if(AI.w&&AI.loading)return AI.loading;
  const src='"use strict";const ort_make='+ort_make.toString()+';const ortgl_make='+ortgl_make.toString()+';('+aiWorkerMain.toString()+')();';
  let w;
  try{w=new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));}
  catch(e){return Promise.reject(new Error('Background workers are not available in this browser'));}
  AI.w=w;
  w.onmessage=e=>{
    const m=e.data,key=m.t==='loaded'?'load'+m.k:m.id,c=AI.cb[key];if(!c)return;
    if(m.t==='prog'){if(c.prog)c.prog(m.p);}
    else if(m.t==='loaded'){delete AI.cb[key];AI.mode=m.mode;AI.why=m.why;c.ok(m);}
    else if(m.t==='done'){delete AI.cb[key];AI.mode=m.mode;c.ok(m);}
    else if(m.t==='err'){const kk=m.id===undefined?'loadsal':m.id;const cc=AI.cb[kk]||c;delete AI.cb[kk];cc.no(new Error(m.msg));}
  };
  w.onerror=ev=>{aiFail(new Error('The AI engine stopped: '+(ev.message||'unknown error')));AI.w=null;AI.loading=null;};
  /* the model comes either as base64 text (single-file builds) or as a real .onnx file next to the app (Android build) */
  const send=(k,b64,out,url)=>new Promise((ok,no)=>{
    AI.cb['load'+k]={ok,no};
    const post=buf=>w.postMessage({t:'load',k,out,buf},[buf]);
    if(b64){const bin=atob(b64),u8=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u8[i]=bin.charCodeAt(i);post(u8.buffer);return;}
    if(url){fetch(url).then(r=>{if(!r.ok)throw new Error('http '+r.status);return r.arrayBuffer();}).then(post).catch(e=>no(new Error('An AI model file could not be loaded: '+(e.message||e))));return;}
    no(new Error('An AI model file is missing from this build'));});
  AI.loading=send('sal',window.U2NETP_B64,undefined,window.U2NETP_URL).then(()=>send('per',window.PPHS_B64,'bilinear_interp_v2_13.tmp_0',window.PPHS_URL));
  AI.loading.catch(()=>{AI.w=null;AI.loading=null;});
  return AI.loading;
}
function aiCancel(){if(AI.w){try{AI.w.terminate();}catch(e){}}AI.w=null;AI.loading=null;aiFail(new Error('cancelled'));}
function aiRun(k,s,data,prog){
  return aiSpawn().then(()=>new Promise((ok,no)=>{const id=++AI.seq;AI.cb[id]={ok,no,prog};AI.w.postMessage({t:'run',k,id,s,data},[data.buffer]);}));
}
/* ---------- progress card ---------- */
let aiCard=null;
function aiShow(msg,cancellable){
  if(!aiCard){aiCard=document.createElement('div');aiCard.id='aiprog';aiCard.className='aiprog';
    aiCard.innerHTML='<div class="aipt"></div><div class="aibar"><i></i></div><button class="aix">Cancel</button>';document.body.appendChild(aiCard);
    aiCard.querySelector('.aix').onclick=()=>{AI.cancelled=true;aiCancel();};}
  AI.cancelled=false;aiCard.querySelector('.aipt').textContent=msg;aiCard.querySelector('i').style.width='4%';aiCard.querySelector('.aix').style.display=cancellable===false?'none':'';
}
function aiSet(frac,msg){if(!aiCard)return;if(msg)aiCard.querySelector('.aipt').textContent=msg;aiCard.querySelector('i').style.width=Math.round(Math.max(4,Math.min(100,frac*100)))+'%';}
function aiHide(){if(aiCard){aiCard.remove();aiCard=null;}}
const aiTick=()=>new Promise(r=>setTimeout(r,16));

/* ---------- network pass ---------- */
function aiPre(canvas,s,person){
  const c=mkCanvas(s,s),x=cctx(c);x.fillStyle='#fff';x.fillRect(0,0,s,s);x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(canvas,0,0,s,s);
  const px=x.getImageData(0,0,s,s).data,f=new Float32Array(3*s*s),n=s*s;
  if(person){for(let i=0;i<n;i++)for(let c2=0;c2<3;c2++)f[c2*n+i]=(px[i*4+c2]/255-0.5)/0.5;return {f,px};}
  let mx=1;
  for(let i=0;i<n;i++){const a=px[i*4],b=px[i*4+1],d=px[i*4+2];if(a>mx)mx=a;if(b>mx)mx=b;if(d>mx)mx=d;}
  const mean=[0.485,0.456,0.406],sd=[0.229,0.224,0.225];
  for(let i=0;i<n;i++)for(let c2=0;c2<3;c2++)f[c2*n+i]=(px[i*4+c2]/mx-mean[c2])/sd[c2];
  return {f,px};
}
/* both networks: the person network (fast, 192 px) and the salient-object network (320 px on a GPU).
   Result: one probability map "p" = the stronger of the two, plus the person map on its own. */
async function aiProb(canvas,label,wantMode){
  await aiSpawn();
  const gpu=AI.mode==='gpu',s=gpu?320:256;
  aiSet(0.12,label);
  const pp=aiPre(canvas,192,true),rp=await aiRun('per',192,pp.f,q=>aiSet(0.12+0.1*q,label));
  const n2=192*192,per=new Float32Array(n2),lv=rp.v;
  for(let i=0;i<n2;i++)per[i]=1/(1+Math.exp(lv[i]-lv[n2+i]));
  const perS=new Float32Array(s*s);aiUp(per,192,0,0,s,s,perS,s);
  let skipped=false,pc=0;for(let i=0;i<n2;i++)if(per[i]>0.5)pc++;
  /* without a GPU the big network takes about a minute: skip it when the person network already found a clear person */
  if(!gpu&&pc>n2*0.03&&wantMode!=='all'&&wantMode!=='point'&&wantMode!=='region')skipped=true;
  const pre=aiPre(canvas,s,false);
  let sal=null;
  if(!skipped){
    const r=await aiRun('sal',s,pre.f,q=>aiSet(0.22+0.68*q,label)),v=r.v,n=s*s;let mn=1e9,mx=-1e9;
    for(let i=0;i<n;i++){if(v[i]<mn)mn=v[i];if(v[i]>mx)mx=v[i];}
    sal=new Float32Array(n);const d=(mx-mn)||1;for(let i=0;i<n;i++)sal[i]=(v[i]-mn)/d;
  }
  const p=new Float32Array(s*s);
  for(let i=0;i<s*s;i++)p[i]=sal?Math.max(sal[i],perS[i]):perS[i];
  return {p,s,sal,perS,px:pre.px,mode:AI.mode,personOnly:skipped};
}
/* ---------- small image helpers ---------- */
function aiUp(p,s,x0,y0,w,h,out,W,blend){ // bilinear: s*s map -> region (x0,y0,w,h) of out (W wide)
  for(let y=0;y<h;y++){let fy=(y+0.5)*s/h-0.5;if(fy<0)fy=0;const ya=Math.min(s-1,Math.floor(fy)),yb=Math.min(s-1,ya+1),wy=fy-ya;
    for(let x=0;x<w;x++){let fx=(x+0.5)*s/w-0.5;if(fx<0)fx=0;const xa=Math.min(s-1,Math.floor(fx)),xb=Math.min(s-1,xa+1),wx=fx-xa;
      const v=(p[ya*s+xa]*(1-wx)+p[ya*s+xb]*wx)*(1-wy)+(p[yb*s+xa]*(1-wx)+p[yb*s+xb]*wx)*wy,o=(y0+y)*W+x0+x;
      out[o]=blend==null?v:out[o]*(1-blend)+v*blend;}}
}
function aiGrid(p,s){
  const B=new Uint8Array(s*s);for(let i=0;i<s*s;i++)B[i]=p[i]>0.5?1:0;
  const D=cut__dilate(B,s,s,Math.max(2,Math.round(s*0.02))),C=cut__components(D,s,s,true),G=[];
  for(let k=0;k<=C.n;k++)G.push({id:k,area:0,x0:s,y0:s,x1:-1,y1:-1,sx:0,sy:0,touch:0});
  for(let i=0;i<s*s;i++){if(!B[i])continue;const g=G[C.id[i]],x=i%s,y=(i/s)|0;g.area++;g.sx+=x;g.sy+=y;if(x<g.x0)g.x0=x;if(x>g.x1)g.x1=x;if(y<g.y0)g.y0=y;if(y>g.y1)g.y1=y;if(x===0||y===0||x===s-1||y===s-1)g.touch++;}
  const groups=G.filter(g=>g.id&&g.area>0);groups.forEach(g=>{g.cx=g.sx/g.area;g.cy=g.sy/g.area;});
  return {B,C,groups,s};
}
function aiSkin(px,s,gr,grid){
  let sk=0,tot=0;const ylim=gr.y0+(gr.y1-gr.y0)*0.6;
  for(let y=gr.y0;y<=ylim;y++)for(let x=gr.x0;x<=gr.x1;x++){const i=y*s+x;if(!grid.B[i]||grid.C.id[i]!==gr.id)continue;tot++;
    const r=px[i*4],g=px[i*4+1],b=px[i*4+2],Y=0.299*r+0.587*g+0.114*b,cb=128-0.168736*r-0.331264*g+0.5*b,cr=128+0.5*r-0.418688*g-0.081312*b;
    if(Y>28&&cr>132&&cr<178&&cb>74&&cb<128)sk++;}
  return {sk,tot};
}
async function aiFaces(canvas){
  try{if(typeof FaceDetector==='undefined')return null;const fd=new FaceDetector({fastMode:true,maxDetectedFaces:12}),r=await fd.detect(canvas);return r.map(f=>f.boundingBox);}catch(e){return null;}
}
async function aiPick(grid,mode,pass,canvas){
  const s=grid.s,gs=grid.groups.filter(g=>g.area>=s*s*0.004);
  if(!gs.length)return {err:'no subject'};
  const sc=g=>{const dx=(g.cx-s/2)/s,dy=(g.cy-s/2)/s;return g.area*(1-0.35*Math.min(1,Math.hypot(dx,dy)*1.4));};
  gs.sort((a,b)=>sc(b)-sc(a));
  const main=gs[0];let pick;
  if(mode==='all')pick=gs.slice();
  else if(mode==='people'){
    pick=gs.filter(g=>{let c=0;for(let y=g.y0;y<=g.y1;y++)for(let x=g.x0;x<=g.x1;x++){const i=y*s+x;if(grid.B[i]&&grid.C.id[i]===g.id&&pass.perS[i]>0.5)c++;}return c>=g.area*0.25&&c>=s*s*0.003;});
    if(!pick.length)return {err:'no people'};
  }else{
    pick=gs.filter((g,i)=>i===0||g.area>=main.area*0.3||(g.cx>=main.x0&&g.cx<=main.x1&&g.cy>=main.y0&&g.cy<=main.y1&&g.area>=s*s*0.003));
  }
  const ids=new Set(pick.map(g=>g.id)),chosen=new Uint8Array(s*s);
  for(let i=0;i<s*s;i++)if(grid.B[i]&&ids.has(grid.C.id[i]))chosen[i]=1;
  let x0=s,y0=s,x1=-1,y1=-1;pick.forEach(g=>{x0=Math.min(x0,g.x0);y0=Math.min(y0,g.y0);x1=Math.max(x1,g.x1);y1=Math.max(y1,g.y1);});
  return {chosen,box:{x0,y0,x1,y1},n:pick.length};
}
/* fill small holes inside a grid mask (not touching the border) */
function aiFillHoles(m,s,maxFrac){
  const inv=new Uint8Array(s*s);for(let i=0;i<s*s;i++)inv[i]=m[i]?0:1;
  const C=cut__components(inv,s,s,false);
  for(let k=1;k<=C.n;k++){if(C.touch[k]||C.area[k]>s*s*maxFrac)continue;for(let i=0;i<s*s;i++)if(C.id[i]===k)m[i]=1;}
  return m;
}
/* ---------- colour guided filter (He et al.) ---------- */
function aiGuided(I,P,w,h,r,eps){
  const n=w*h,bx=a=>cut__box(a,w,h,r),mul=(a,b)=>{const o=new Float32Array(n);for(let i=0;i<n;i++)o[i]=a[i]*b[i];return o;};
  const [R,Gc,B]=I,mR=bx(R),mG=bx(Gc),mB=bx(B),mP=bx(P),mRP=bx(mul(R,P)),mGP=bx(mul(Gc,P)),mBP=bx(mul(B,P));
  const vRR=bx(mul(R,R)),vRG=bx(mul(R,Gc)),vRB=bx(mul(R,B)),vGG=bx(mul(Gc,Gc)),vGB=bx(mul(Gc,B)),vBB=bx(mul(B,B));
  const aR=new Float32Array(n),aG=new Float32Array(n),aB=new Float32Array(n),b0=new Float32Array(n);
  for(let i=0;i<n;i++){
    const rr=vRR[i]-mR[i]*mR[i]+eps,rg=vRG[i]-mR[i]*mG[i],rb=vRB[i]-mR[i]*mB[i],gg=vGG[i]-mG[i]*mG[i]+eps,gb=vGB[i]-mG[i]*mB[i],bb=vBB[i]-mB[i]*mB[i]+eps;
    const cR=mRP[i]-mR[i]*mP[i],cG=mGP[i]-mG[i]*mP[i],cB=mBP[i]-mB[i]*mP[i];
    const c00=gg*bb-gb*gb,c01=rb*gb-rg*bb,c02=rg*gb-rb*gg,c11=rr*bb-rb*rb,c12=rb*rg-rr*gb,c22=rr*gg-rg*rg;
    const det=rr*c00+rg*c01+rb*c02,id=1/(Math.abs(det)<1e-12?1e-12:det);
    const x=(c00*cR+c01*cG+c02*cB)*id,y=(c01*cR+c11*cG+c12*cB)*id,z=(c02*cR+c12*cG+c22*cB)*id;
    aR[i]=x;aG[i]=y;aB[i]=z;b0[i]=mP[i]-x*mR[i]-y*mG[i]-z*mB[i];
  }
  const mAR=bx(aR),mAG=bx(aG),mAB=bx(aB),mB0=bx(b0),q=new Float32Array(n);
  for(let i=0;i<n;i++){const v=mAR[i]*R[i]+mAG[i]*Gc[i]+mAB[i]*B[i]+mB0[i];q[i]=v<0?0:v>1?1:v;}
  return q;
}
/* prior (soft mask at working size) -> final alpha 0..1 using the picture's own edges.
   hair 0..100 widens the uncertain band and lowers the guide strictness so thin strands can be recovered. */
function aiEdge(P,planes,w,h,radiusK,hair){
  const n=w*h,md=Math.max(w,h),hr=(hair||0)/100;
  const r=Math.max(2,Math.round(md*0.006*(radiusK||1)*(1+hr*1.2))),eps=0.0012*(1-0.75*hr);
  const Bn=new Uint8Array(n);for(let i=0;i<n;i++)Bn[i]=P[i]>0.5?1:0;
  const bw=Math.max(3,Math.round(md*(0.012+0.016*hr)*(radiusK||1)));
  const fg=cut__erode(Bn,w,h,bw),bgm=cut__dilate(Bn,w,h,bw);
  const q=aiGuided(planes,P,w,h,r,eps),a=new Float32Array(n);
  const lo=0.08+0.1*hr,hi=0.92-0.1*hr;
  for(let i=0;i<n;i++){
    if(fg[i])a[i]=1;else if(!bgm[i])a[i]=0;
    else{let v=(q[i]-lo)/(hi-lo);v=v<0?0:v>1?1:v;a[i]=v*v*(3-2*v);}
  }
  return a;
}
function aiPlanes(canvas,w,h){
  const c=mkCanvas(w,h),x=cctx(c);x.fillStyle='#fff';x.fillRect(0,0,w,h);x.imageSmoothingQuality='high';x.drawImage(canvas,0,0,w,h);
  const d=x.getImageData(0,0,w,h).data,n=w*h,R=new Float32Array(n),G=new Float32Array(n),B=new Float32Array(n);
  for(let i=0;i<n;i++){R[i]=d[i*4]/255;G[i]=d[i*4+1]/255;B[i]=d[i*4+2]/255;}
  return [R,G,B];
}
function aiAlphaCanvas(a,w,h,W,H){
  const u=new Uint8ClampedArray(w*h);for(let i=0;i<w*h;i++)u[i]=Math.round(a[i]*255);
  const c=cut_alphaToCanvas(u,w,h);return (w===W&&h===H)?c:cut__resize(c,W,H);
}
/* ---------- the subject pipeline ---------- */
/* o: {mode:'subject'|'all'|'people'|'point'|'region', pt:{x,y} (canvas px), region:{rect|poly} (canvas px), key} */
async function aiSubject(canvas,o){
  const W=canvas.width,H=canvas.height,k=Math.min(1,1280/Math.max(W,H)),ww=Math.max(8,Math.round(W*k)),hh=Math.max(8,Math.round(H*k));
  let pass=AI.cache&&AI.cache.key===o.key&&o.key?AI.cache.pass:null;
  if(!pass){aiSet(0.08,'Finding the subject...');pass=await aiProb(canvas,'Finding the subject...',o.mode);if(o.key)AI.cache={key:o.key,pass};}
  aiSet(0.9,'Choosing the subject...');await aiTick();
  const grid=aiGrid(pass.p,pass.s),s=pass.s;
  let pick=null,passes=[],region={x:0,y:0,w:ww,h:hh},limit=null;
  const toWR=v=>({x:v.x*ww/W,y:v.y*hh/H});
  const cropPass=async(rx,ry,rw,rh,label)=>{
    rx=Math.max(0,Math.floor(rx));ry=Math.max(0,Math.floor(ry));rw=Math.min(W-rx,Math.ceil(rw));rh=Math.min(H-ry,Math.ceil(rh));
    const cc=mkCanvas(rw,rh);cctx(cc).drawImage(canvas,rx,ry,rw,rh,0,0,rw,rh);
    const pp=await aiProb(cc,label,o.mode);pp.rect={x:rx,y:ry,w:rw,h:rh};return pp;};
  if(o.mode==='point'||o.mode==='region'){
    let rx,ry,rw,rh,rg=null;
    if(o.mode==='point'){const side=Math.max(64,Math.min(W,H)*0.5);rx=o.pt.x-side/2;ry=o.pt.y-side/2;rw=side;rh=side;}
    else{
      const b=o.region.rect?{x0:o.region.rect.x,y0:o.region.rect.y,x1:o.region.rect.x+o.region.rect.w,y1:o.region.rect.y+o.region.rect.h}:
        o.region.poly.reduce((a,q)=>({x0:Math.min(a.x0,q.x),y0:Math.min(a.y0,q.y),x1:Math.max(a.x1,q.x),y1:Math.max(a.y1,q.y)}),{x0:1e9,y0:1e9,x1:-1e9,y1:-1e9});
      const mx=(b.x1-b.x0)*0.12+4,my=(b.y1-b.y0)*0.12+4;rx=b.x0-mx;ry=b.y0-my;rw=b.x1-b.x0+2*mx;rh=b.y1-b.y0+2*my;
      rg=b;
    }
    aiSet(0.3,'Looking closely...');
    const pp=await cropPass(rx,ry,rw,rh,'Looking closely...');const g2=aiGrid(pp.p,pp.s),R=pp.rect;
    let gs=g2.groups.filter(g=>g.area>=pp.s*pp.s*0.004);
    if(!gs.length)return {err:'no subject'};
    let sel=[];
    if(o.mode==='point'){
      const gx=Math.round((o.pt.x-R.x)/R.w*pp.s),gy=Math.round((o.pt.y-R.y)/R.h*pp.s);let best=null,bd=1e9;
      for(const g of gs){let d=0;if(gx<g.x0)d+=g.x0-gx;else if(gx>g.x1)d+=gx-g.x1;if(gy<g.y0)d+=g.y0-gy;else if(gy>g.y1)d+=gy-g.y1;
        const idx=Math.min(pp.s-1,Math.max(0,gy))*pp.s+Math.min(pp.s-1,Math.max(0,gx));if(g2.B[idx]&&g2.C.id[idx]===g.id)d=-1;if(d<bd){bd=d;best=g;}}
      if(!best||bd>pp.s*0.08)return {err:'nothing here'};sel=[best];
    }else{
      const inside=(x,y)=>{if(o.region.rect){const r=o.region.rect;return x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;}return aiPip(o.region.poly,x,y);};
      const ov=gs.map(g=>{let c=0;for(let y=g.y0;y<=g.y1;y+=1)for(let x=g.x0;x<=g.x1;x+=1){const i=y*pp.s+x;if(g2.B[i]&&g2.C.id[i]===g.id&&inside(R.x+(x+0.5)/pp.s*R.w,R.y+(y+0.5)/pp.s*R.h))c++;}return {g,c};}).sort((a,b)=>b.c-a.c);
      if(!ov[0]||ov[0].c<pp.s*pp.s*0.002)return {err:'nothing in the region'};
      sel=ov.filter(v=>v.c>=ov[0].c*0.3).map(v=>v.g);
    }
    const ids=new Set(sel.map(g=>g.id)),chosen=new Uint8Array(pp.s*pp.s);for(let i=0;i<chosen.length;i++)if(g2.B[i]&&ids.has(g2.C.id[i]))chosen[i]=1;
    const sr=toWR(R),er=toWR({x:R.x+R.w,y:R.y+R.h});
    region={x:Math.round(sr.x),y:Math.round(sr.y),w:Math.max(2,Math.round(er.x-sr.x)),h:Math.max(2,Math.round(er.y-sr.y))};
    passes=[{p:pp.p,s:pp.s,reg:region,w:1}];pick={chosen,s:pp.s,reg:region};
    if(o.mode==='region'&&o.region.poly){limit={poly:o.region.poly.map(toWR)};}else if(o.mode==='region'){const r=o.region.rect,a=toWR(r),b=toWR({x:r.x+r.w,y:r.y+r.h});limit={rect:{x:a.x,y:a.y,w:b.x-a.x,h:b.y-a.y}};}
  }else{
    const pk=await aiPick(grid,o.mode,pass,canvas);
    if(pk.err)return pk;
    pick={chosen:pk.chosen,s,reg:{x:0,y:0,w:ww,h:hh},n:pk.n};
    passes=[{p:pass.p,s,reg:pick.reg,w:1}];
    const bx=pk.box,mg=s*0.08,cx0=Math.max(0,bx.x0-mg),cy0=Math.max(0,bx.y0-mg),cx1=Math.min(s,bx.x1+mg),cy1=Math.min(s,bx.y1+mg);
    if((cx1-cx0)*(cy1-cy0)<s*s*0.72){
      const pp=await cropPass(cx0/s*W,cy0/s*H,(cx1-cx0)/s*W,(cy1-cy0)/s*H,'Looking closely...');
      const sr=toWR(pp.rect),er=toWR({x:pp.rect.x+pp.rect.w,y:pp.rect.y+pp.rect.h});
      passes.push({p:pp.p,s:pp.s,reg:{x:Math.round(sr.x),y:Math.round(sr.y),w:Math.max(2,Math.round(er.x-sr.x)),h:Math.max(2,Math.round(er.y-sr.y))},w:0.65});
    }
  }
  /* compose the working-size probability */
  aiSet(0.93,'Refining edges...');await aiTick();
  const n=ww*hh,P=new Float32Array(n);
  passes.forEach((ps,i)=>{aiUp(ps.p,ps.s,ps.reg.x,ps.reg.y,ps.reg.w,ps.reg.h,P,ww,i===0?null:ps.w);});
  /* allowed area: the chosen groups grown a little, so other objects stay out */
  const cm=new Uint8Array(n),ch=pick.chosen,ps=pick.s,rg=pick.reg;
  aiFillHoles(ch,ps,0.012);
  for(let y=0;y<rg.h;y++){const gy=Math.min(ps-1,Math.floor((y+0.5)*ps/rg.h));for(let x=0;x<rg.w;x++){const gx=Math.min(ps-1,Math.floor((x+0.5)*ps/rg.w));if(ch[gy*ps+gx])cm[(rg.y+y)*ww+rg.x+x]=1;}}
  const bwid=Math.max(4,Math.round(Math.max(ww,hh)*0.03)),allow=cut__dilate(cm,ww,hh,bwid);
  let lim=null;
  if(limit){lim=new Uint8Array(n);const c=mkCanvas(ww,hh),x=cctx(c);x.fillStyle='#fff';x.beginPath();if(limit.rect){const r=limit.rect;x.rect(r.x,r.y,r.w,r.h);}else limit.poly.forEach((q,i)=>i?x.lineTo(q.x,q.y):x.moveTo(q.x,q.y));x.fill();
    const d=x.getImageData(0,0,ww,hh).data;for(let i=0;i<n;i++)lim[i]=d[i*4+3]>127?1:0;lim=cut__dilate(lim,ww,hh,Math.max(2,Math.round(bwid*0.4)));}
  const cmIn=cut__erode(cm,ww,hh,Math.ceil(Math.max(ww,hh)/ps*1.6));
  for(let i=0;i<n;i++){if(!allow[i]||(lim&&!lim[i]))P[i]=0;else if(cmIn[i]&&P[i]<0.6)P[i]=0.6;}   // solid inside the chosen groups (fills small holes)
  const planes=aiPlanes(canvas,ww,hh);
  aiSet(0.95,'Refining edges...');await aiTick();
  const a=aiEdge(P,planes,ww,hh,1,0);
  let cover=0;for(let i=0;i<n;i++)cover+=a[i];cover/=n;
  if(cover<0.003)return {err:'no subject'};
  if(cover>0.985&&o.mode!=='region'&&o.mode!=='point')return {err:'whole picture'};
  return {alpha:aiAlphaCanvas(a,ww,hh,W,H),ww,hh,W,H,P,planes,a,count:pick.n||1,mode:o.mode,engine:pass.mode};
}
function aiPip(poly,x,y){let c=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a.y>y)!==(b.y>y)&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)c=!c;}return c;}
const aiKey=l=>l.id+':'+l.ver+':'+l.canvas.width+'x'+l.canvas.height;
const aiMsg=e=>{const m=String(e&&e.message||e);
  if(/cancel/i.test(m))return null;
  if(/whole picture/.test(m))return 'The subject fills the whole picture, so there is no background to separate. Use the Lasso, Pen or Quick Selection tool instead.';
  return null;};
/* run a job with the progress card, honest failure messages */
async function aiJob(title,fn){
  if(AI.job){toast('Still working on the last request. Cancel it first or wait.');return null;}
  AI.job=true;aiShow(title,true);
  try{await aiTick();return await fn();}
  catch(err){
    if(AI.cancelled||/cancel/i.test(String(err&&err.message))){toast('Cancelled. Nothing was changed.');return null;}
    console.error(err);toast('The AI engine could not run here ('+String(err&&err.message||err)+'), so the basic colour-based detector was used instead.');return {unavailable:true};}
  finally{AI.job=null;aiHide();}
}
const aiErrText=(e,mode)=>e==='whole picture'?'The subject fills the whole picture, so there is no background to separate. Use the Lasso, Pen or Quick Selection tool instead.'
  :e==='no people'?'No people found. Try Subject, or the Object Selection tool.'
  :e==='nothing here'?'Nothing clear to select at that point. Try dragging a rough box around the object.'
  :e==='nothing in the region'?'Nothing clear inside that area. Try a slightly larger box.'
  :'Could not find a clear subject in this picture. Nothing was changed. Try the Object Selection, Quick Selection or Pen tool.';
/* ---------- commands ---------- */
S.subj=null;
function aiApplySelection(l,r,mode){
  S.subj={lid:l.id,ver:l.ver,r,mode:r.mode};
  setSelection(layerToDocCanvas(l,r.alpha),mode||'new');
  S.subj.docSmall=aiSmallSel();
}
function aiSmallSel(){if(!S.sel)return null;const c=mkCanvas(48,48);cctx(c).drawImage(S.sel.c,0,0,48,48);return cctx(c).getImageData(0,0,48,48).data;}
async function aiSelectSubject(mode){
  const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return;}
  if(l.locked){toast('This layer is locked');return;}
  ensureRaster(l);
  const label=mode==='all'?'Selecting all subjects...':mode==='people'?'Looking for people...':'Finding the subject...';
  const r=await aiJob(label,()=>aiSubject(l.canvas,{mode,key:aiKey(l)}));
  if(!r)return;
  if(r.unavailable){_ssClassic();return;}
  if(r.err){toast(aiErrText(r.err,mode));return;}
  aiApplySelection(l,r,'new');
  toast((r.mode==='people'?'People':r.mode==='all'?(r.count>1?r.count+' subjects':'Subject'):'Subject')+' selected'+(r.engine==='cpu'?' (CPU mode: no usable GPU found)':'')+'. Click Add Layer Mask to hide the background, or Select and Mask to refine.');
  subjBarShow();
}
const _ssClassic=ACT.selSubject;
ACT.selSubject=D(()=>aiSelectSubject('subject'));
ACT.selAllSubjects=D(()=>aiSelectSubject('all'));
ACT.selPeople=D(()=>aiSelectSubject('people'));
/* object: tap a point, or a rough region (rect / lasso polygon in canvas coordinates of the document) */
async function aiSelectObject(region,pt,mode){
  const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return false;}
  ensureRaster(l);
  const inv=docToLocalM(l),T=p=>({x:inv[0]*p.x+inv[2]*p.y+inv[4],y:inv[1]*p.x+inv[3]*p.y+inv[5]});
  let o;
  if(pt)o={mode:'point',pt:T(pt)};
  else if(region.rect){const a=T({x:region.rect.x,y:region.rect.y}),b=T({x:region.rect.x+region.rect.w,y:region.rect.y+region.rect.h});o={mode:'region',region:{rect:{x:Math.min(a.x,b.x),y:Math.min(a.y,b.y),w:Math.abs(b.x-a.x),h:Math.abs(b.y-a.y)}}};}
  else o={mode:'region',region:{poly:region.poly.map(T)}};
  o.key=aiKey(l);
  const r=await aiJob('Selecting the object...',()=>aiSubject(l.canvas,o));
  if(!r)return false;
  if(r.unavailable){if(region&&selectFromRegion.classic)selectFromRegion.classic(region);return false;}
  if(r.err){toast(aiErrText(r.err,o.mode));return false;}
  aiApplySelection(l,r,mode||S.selMode);
  toast('Object selected');return true;
}
{const _sfr=selectFromRegion;
 selectFromRegion=function(region){
  aiSelectObject(region,null,S.selMode).then(ok=>{if(ok===false&&!AI.cancelled){/* the AI said nothing useful: fall back to the colour-based method so the tool still works */
    if(S._aiFallbackOnce)return;}});
 };
 selectFromRegion.classic=_sfr;
}
ACT.selObjectClassic=D(()=>toast('Use the Object Selection tool and drag around an object'));
/* tap with the Object Selection tool picks the thing under the tap */
{const T=TOOLS.objsel;if(T&&!T._ai){const up0=T.up;T.up=function(d){
  const w=Math.abs(d.p1.x-d.p0.x),h=Math.abs(d.p1.y-d.p0.y);
  if(w<8&&h<8){const sm=S.selMode;S.selMode=d.mode;aiSelectObject(null,d.p0,d.mode).then(()=>{S.selMode=sm;});return;}
  return up0.call(this,d);};T._ai=1;
  T.opts=()=>selModeBtns()+'<label class="opt">Mode '+sel('o-objm',[['rect','Rectangle'],['lasso','Lasso']],S.objMode)+'</label><span class="opt muted">Tap an object, or drag a rough box around it. Use Add and Subtract to fix it.</span><button data-act="selSubject">Select subject</button>';}}
/* ---------- subject bar ---------- */
function subjInverted(){
  if(!S.subj||!S.subj.docSmall||!S.sel)return false;const cur=aiSmallSel();if(!cur)return false;
  let a=0,b=0,both=0;for(let i=3;i<cur.length;i+=4){const x=S.subj.docSmall[i]>127,y=cur[i]>127;if(x)a++;if(x&&y)both++;if(y)b++;}
  return a>20&&both<a*0.3&&b>0;
}
subjBarShow=function(){
  subjBarHide();const b=document.createElement('div');b.id='subjbar';b.className='subjbar';
  b.innerHTML='<b>Subject selected</b><button data-s="mask" class="primary">Add Layer Mask</button><button data-s="sam">Select and Mask...</button>'
    +'<button data-s="add" title="Tap or drag around a part that was missed">+ Add</button><button data-s="sub" title="Tap or drag around something that should not be selected">- Subtract</button>'
    +'<button data-s="inv">Invert</button><button data-s="all">All subjects</button><button data-s="ppl">People</button><button data-s="cut">Cut out to new layer</button><button data-s="x" title="Close" aria-label="Close">×</button>';
  document.body.appendChild(b);subjBar=b;
  b.onclick=e=>{const t=e.target.closest('button');if(!t)return;const s=t.dataset.s;
    if(s==='mask'){ACT.maskReveal();refreshLayers();subjBarHide();}
    else if(s==='sam'){ACT.selMask();}
    else if(s==='add'){S.selMode='add';setTool('objsel');toast('Add: tap the missed part, or drag a box around it');}
    else if(s==='sub'){S.selMode='sub';setTool('objsel');toast('Subtract: tap the part to remove, or drag a box around it');}
    else if(s==='inv'){ACT.selInv();toast(subjInverted()?'The background is selected now. Click Invert again to go back to the subject.':'Subject selected again');}
    else if(s==='all')ACT.selAllSubjects();
    else if(s==='ppl')ACT.selPeople();
    else if(s==='cut'){try{ACT.layerViaCut&&ACT.layerViaCut();}catch(err){}subjBarHide();}
    else subjBarHide();};
};
/* Add Layer Mask: tell the user when the background (not the subject) is selected */
{const _mr=ACT.maskReveal;
 ACT.maskReveal=D(()=>{
  const inv=subjInverted();_mr();
  if(inv&&active()&&active().mask)toast('Mask added, but the background was selected, so the SUBJECT is hidden. Undo, click Invert, and add the mask again.');
 });}
/* ---------- Remove Background uses the same engine ---------- */
{const _bd=brDetect;
 brDetect=async function(canvas,kind){
  const mode=kind==='person'?'people':'subject';
  let r=null;
  try{
    aiShow('Finding the subject...',true);
    r=await aiSubject(canvas,{mode,key:null});
    if(r&&r.err==='no people'){r=await aiSubject(canvas,{mode:'subject',key:null});if(r&&!r.err)r.fallback=true;}
  }catch(err){
    aiHide();
    if(AI.cancelled||/cancel/i.test(String(err&&err.message)))throw new Error('cancelled');
    console.error(err);toast('The AI engine is not available here, so the basic detector was used.');
    return _bd(canvas,kind);
  }
  aiHide();
  if(!r||r.err){throw new Error(r&&r.err?r.err:'no subject');}
  const W=canvas.width,H=canvas.height,d=cctx(r.alpha).getImageData(0,0,W,H).data,al=new Uint8ClampedArray(W*H);
  for(let i=0;i<W*H;i++)al[i]=d[i*4+3];
  return {alpha:al,how:mode==='people'?'person':'object',n:r.count,fallback:!!r.fallback};
 };}
/* progress card styles */
{const st=document.createElement('style');st.textContent='.aiprog{position:fixed;left:50%;top:76px;transform:translateX(-50%);z-index:90;background:var(--panel,#2a2a2a);color:var(--text,#eee);border:1px solid var(--line,#444);border-radius:10px;padding:10px 14px;min-width:240px;box-shadow:0 6px 24px #0008;display:flex;flex-direction:column;gap:8px;align-items:stretch;font-size:13px}.aibar{height:6px;background:#0005;border-radius:3px;overflow:hidden}.aibar i{display:block;height:100%;background:#4aa3ff;width:4%;transition:width .2s}.aix{align-self:flex-end}';document.head.appendChild(st);}
{const g=MENUS.find(m=>m.label==='Select');if(g){const it=g.items.find(i=>i.label==='Subject');if(it&&!g.items.some(i=>i.label==='All subjects')){const ix=g.items.indexOf(it);g.items.splice(ix+1,0,mi('All subjects','','selAllSubjects'),mi('People','','selPeople'),mi('Select and Mask...','','selMask'));}}}
if(typeof ACT.selMask==='undefined')ACT.selMask=()=>toast('Select and Mask is not ready yet');
