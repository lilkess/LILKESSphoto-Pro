/* ===== Photoshop-style Color Picker, Gradient Editor, Gradient tool ===== */

/* ---------- colour maths ---------- */
const cpClamp=(v,a,b)=>v<a?a:v>b?b:v;
function cpHsv2rgb(h,s,v){
  h=((h%360)+360)%360;s/=100;v/=100;const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r,g,b;
  if(h<60){r=c;g=x;b=0;}else if(h<120){r=x;g=c;b=0;}else if(h<180){r=0;g=c;b=x;}else if(h<240){r=0;g=x;b=c;}else if(h<300){r=x;g=0;b=c;}else{r=c;g=0;b=x;}
  return [(r+m)*255,(g+m)*255,(b+m)*255];
}
function cpRgb2hsv(r,g,b){
  r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;
  if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h*=60;if(h<0)h+=360;}
  return [h,mx?d/mx*100:0,mx*100];
}
function cpRgb2lab(r,g,b){
  const f=v=>{v/=255;return v>0.04045?Math.pow((v+0.055)/1.055,2.4):v/12.92;};
  const R=f(r),G=f(g),B=f(b);
  let X=(R*0.4124+G*0.3576+B*0.1805)/0.95047,Y=(R*0.2126+G*0.7152+B*0.0722),Z=(R*0.0193+G*0.1192+B*0.9505)/1.08883;
  const t=v=>v>0.008856?Math.cbrt(v):7.787*v+16/116;X=t(X);Y=t(Y);Z=t(Z);
  return [116*Y-16,500*(X-Y),200*(Y-Z)];
}
function cpLab2rgb(L,a,b){
  const fy=(L+16)/116,fx=fy+a/500,fz=fy-b/200,it=t=>t*t*t>0.008856?t*t*t:(t-16/116)/7.787;
  const X=it(fx)*0.95047,Y=it(fy),Z=it(fz)*1.08883;
  let R=X*3.2406+Y*-1.5372+Z*-0.4986,G=X*-0.9689+Y*1.8758+Z*0.0415,B=X*0.0557+Y*-0.2040+Z*1.0570;
  const g=v=>{v=v<=0.0031308?12.92*v:1.055*Math.pow(v,1/2.4)-0.055;return cpClamp(v,0,1)*255;};
  return [g(R),g(G),g(B)];
}
const cpRgb2cmyk=(r,g,b)=>{r/=255;g/=255;b/=255;const k=1-Math.max(r,g,b);if(k>=1)return [0,0,0,100];return [(1-r-k)/(1-k)*100,(1-g-k)/(1-k)*100,(1-b-k)/(1-k)*100,k*100];};
const cpCmyk2rgb=(c,m,y,k)=>{k/=100;return [255*(1-c/100)*(1-k),255*(1-m/100)*(1-k),255*(1-y/100)*(1-k)];};

/* ---------- the Color Picker dialog ---------- */
let cpOpen=false;
function openColorPicker(startHex,title,cb){
  if(cpOpen)return;cpOpen=true;
  const orig=hexRgb(/^#[0-9a-f]{6}$/i.test(startHex)?startHex:'#000000');
  let h,s,v,mode='h',web=false;
  const st={r:orig[0],g:orig[1],b:orig[2]};
  [h,s,v]=cpRgb2hsv(st.r,st.g,st.b);
  const ov=document.createElement('div');ov.id='cpick';ov.setAttribute('role','dialog');ov.setAttribute('aria-label',title||'Color Picker');
  const fld=(id,lab,max,unit)=>'<label class="cpf"><span>'+lab+'</span><input type="number" id="cpf-'+id+'" min="0" max="'+max+'" step="1"><i>'+(unit||'')+'</i></label>';
  const rad=m=>'<input type="radio" name="cpm" value="'+m+'" '+(m==='h'?'checked':'')+' aria-label="Edit by '+m+'">';
  ov.innerHTML='<div class="cpbox"><header><b>'+esc(title||'Color Picker')+'</b><button id="cp-x" aria-label="Close">&#10005;</button></header>'
   +'<div class="cpbody"><div class="cparea"><div class="cpsq"><canvas id="cp-sq" width="256" height="256"></canvas><i id="cp-dot"></i></div><div class="cpsl"><canvas id="cp-sl" width="22" height="256"></canvas><i id="cp-ar"></i></div></div>'
   +'<div class="cpside"><div class="cpsw"><div class="cpsw-l">new</div><div id="cp-new"></div><div id="cp-cur" title="Click to go back to the first colour"></div><div class="cpsw-l">current</div></div>'
   +'<div class="cpbtns"><button class="primary" id="cp-ok">OK</button><button id="cp-cancel">Cancel</button><button id="cp-add">Add to Swatches</button><button id="cp-pal">Color Swatches</button>'+(window.EyeDropper?'<button id="cp-eye">Eyedropper</button>':'')+'</div></div>'
   +'<div class="cpflds"><div class="cpcol">'
   +'<div class="cpr">'+rad('h')+fld('h','H',360,'°')+'</div><div class="cpr">'+rad('s')+fld('s','S',100,'%')+'</div><div class="cpr">'+rad('b')+fld('b','B',100,'%')+'</div>'
   +'<div class="cpr">'+rad('r')+fld('r','R',255)+'</div><div class="cpr">'+rad('g')+fld('g','G',255)+'</div><div class="cpr">'+rad('bl')+fld('bl','B',255)+'</div>'
   +'<div class="cpr hexr"><span class="cph">#</span><input type="text" id="cpf-hex" maxlength="6" spellcheck="false" aria-label="Hex colour"></div>'
   +'<label class="cpr web"><input type="checkbox" id="cp-web"> Only Web Colors</label></div>'
   +'<div class="cpcol">'+'<div class="cpr">'+fld('L','L',100)+'</div><div class="cpr">'+fld('la','a',128)+'</div><div class="cpr">'+fld('lb','b',128)+'</div>'
   +'<div class="cpr">'+fld('C','C',100,'%')+'</div><div class="cpr">'+fld('M','M',100,'%')+'</div><div class="cpr">'+fld('Y','Y',100,'%')+'</div><div class="cpr">'+fld('K','K',100,'%')+'</div></div></div></div>'
   +'<div id="cp-sws" hidden></div></div>';
  document.body.appendChild(ov);
  const $c=q=>ov.querySelector(q),sq=$c('#cp-sq'),sl=$c('#cp-sl'),sqx=sq.getContext('2d'),slx=sl.getContext('2d');
  $c('#cp-cur').style.background=rgbHex(orig[0],orig[1],orig[2]);
  const chans={h:()=>h,s:()=>s,b:()=>v,r:()=>st.r,g:()=>st.g,bl:()=>st.b};
  const maxOf={h:360,s:100,b:100,r:255,g:255,bl:255};
  const axes={h:['s','b'],s:['h','b'],b:['h','s'],r:['bl','g'],g:['bl','r'],bl:['r','g']};
  const roundRgb=()=>{st.r=Math.round(st.r);st.g=Math.round(st.g);st.b=Math.round(st.b);};
  function fromHsv(){const c=cpHsv2rgb(h,s,v);st.r=c[0];st.g=c[1];st.b=c[2];if(web)snapWeb();}
  function snapWeb(){st.r=Math.round(st.r/51)*51;st.g=Math.round(st.g/51)*51;st.b=Math.round(st.b/51)*51;const c=cpRgb2hsv(st.r,st.g,st.b);if(c[1]>0)h=c[0];s=c[1];v=c[2];}
  function fromRgb(){roundRgb();if(web)snapWeb();const c=cpRgb2hsv(st.r,st.g,st.b);if(c[1]>0&&c[2]>0)h=c[0];if(c[2]>0)s=c[1];v=c[2];if(c[1]===0)s=0;}
  function pixelAt(ch,val,ax,ay,vx,vy){ // colour for slider channel ch=val with the two axes
    const o={h,s,b:v,r:st.r,g:st.g,bl:st.b};o[ch]=val;o[ax]=vx;o[ay]=vy;
    if('hsb'.includes(ch)&&ch.length===1)return cpHsv2rgb(o.h,o.s,o.b);
    return [o.r,o.g,o.bl];
  }
  let sqKey='';
  function drawSquare(){
    const key=mode+'|'+Math.round(chans[mode]()*2);if(key===sqKey)return;sqKey=key;
    const [ax,ay]=axes[mode],img=sqx.createImageData(256,256),d=new Uint32Array(img.data.buffer),cv=chans[mode]();
    const hsbMode=mode==='h'||mode==='s'||mode==='b';
    for(let y=0;y<256;y++){const vy=(1-y/255)*maxOf[ay];
      for(let x=0;x<256;x++){const vx=x/255*maxOf[ax];let c;
        if(hsbMode){const o={h,s,b:v};o[mode]=cv;o[ax]=vx;o[ay]=vy;c=cpHsv2rgb(o.h,o.s,o.b);}
        else{const o={r:st.r,g:st.g,bl:st.b};o[mode]=cv;o[ax]=vx;o[ay]=vy;c=[o.r,o.g,o.bl];}
        d[y*256+x]=0xff000000|(c[2]|0)<<16|(c[1]|0)<<8|(c[0]|0);}}
    sqx.putImageData(img,0,0);
  }
  function drawSlider(){
    const img=slx.createImageData(22,256),d=new Uint32Array(img.data.buffer),[ax,ay]=axes[mode],hsbMode=mode==='h'||mode==='s'||mode==='b';
    for(let y=0;y<256;y++){const val=(1-y/255)*maxOf[mode];let c;
      if(hsbMode){const o={h,s,b:v};o[mode]=val;c=cpHsv2rgb(o.h,o.s,o.b);}else{const o={r:st.r,g:st.g,bl:st.b};o[mode]=val;c=[o.r,o.g,o.bl];}
      const px=0xff000000|(c[2]|0)<<16|(c[1]|0)<<8|(c[0]|0);for(let x=0;x<22;x++)d[y*22+x]=px;}
    slx.putImageData(img,0,0);
  }
  function setVal(id,val){const e=$c('#cpf-'+id);if(e&&document.activeElement!==e)e.value=val;}
  function sync(skipSquare){
    if(!skipSquare)drawSquare();drawSlider();
    const [ax,ay]=axes[mode];
    $c('#cp-dot').style.left=(chans[ax]()/maxOf[ax]*100)+'%';$c('#cp-dot').style.top=((1-chans[ay]()/maxOf[ay])*100)+'%';
    $c('#cp-ar').style.top=((1-chans[mode]()/maxOf[mode])*100)+'%';
    const hex=rgbHex(st.r,st.g,st.b);$c('#cp-new').style.background=hex;
    setVal('h',Math.round(h));setVal('s',Math.round(s));setVal('b',Math.round(v));setVal('r',Math.round(st.r));setVal('g',Math.round(st.g));setVal('bl',Math.round(st.b));
    const hx=$c('#cpf-hex');if(document.activeElement!==hx)hx.value=hex.slice(1);
    const lab=cpRgb2lab(st.r,st.g,st.b),cm=cpRgb2cmyk(st.r,st.g,st.b);
    setVal('L',Math.round(lab[0]));setVal('la',Math.round(lab[1]));setVal('lb',Math.round(lab[2]));setVal('C',Math.round(cm[0]));setVal('M',Math.round(cm[1]));setVal('Y',Math.round(cm[2]));setVal('K',Math.round(cm[3]));
  }
  sqKey='';sync();
  // dragging on the square
  const dragOn=(el,fn)=>{
    el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);const mv=ev=>{const r=el.getBoundingClientRect();fn(cpClamp((ev.clientX-r.left)/r.width,0,1),cpClamp((ev.clientY-r.top)/r.height,0,1));};mv(e);
      const up=()=>{el.removeEventListener('pointermove',mv);el.removeEventListener('pointerup',up);el.removeEventListener('pointercancel',up);};el.addEventListener('pointermove',mv);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);});
  };
  const hsbMode=()=>mode==='h'||mode==='s'||mode==='b';
  function setCh(ch,val){
    if(ch==='h')h=val;else if(ch==='s')s=val;else if(ch==='b')v=val;else{if(ch==='r')st.r=val;else if(ch==='g')st.g=val;else st.b=val;}
  }
  dragOn(sq.parentNode,(fx,fy)=>{
    const [ax,ay]=axes[mode];setCh(ax,fx*maxOf[ax]);setCh(ay,(1-fy)*maxOf[ay]);
    if(hsbMode())fromHsv();else fromRgb();sync(true);
  });
  dragOn(sl.parentNode,(fx,fy)=>{
    setCh(mode,(1-fy)*maxOf[mode]);if(hsbMode())fromHsv();else fromRgb();sqKey='';sync();
  });
  ov.querySelectorAll('input[name=cpm]').forEach(r=>r.addEventListener('change',()=>{mode=r.value;sqKey='';sync();}));
  // typed values
  ov.addEventListener('input',e=>{
    const t=e.target;if(!t.id||t.id.slice(0,4)!=='cpf-')return;const id=t.id.slice(4),n=+t.value;
    if(id==='hex'){if(/^[0-9a-f]{6}$/i.test(t.value)){const c=hexRgb(t.value);st.r=c[0];st.g=c[1];st.b=c[2];fromRgb();sqKey='';sync();}return;}
    if(t.value===''||isNaN(n))return;
    if(id==='h'){h=cpClamp(n,0,360);fromHsv();}else if(id==='s'){s=cpClamp(n,0,100);fromHsv();}else if(id==='b'){v=cpClamp(n,0,100);fromHsv();}
    else if(id==='r'){st.r=cpClamp(n,0,255);fromRgb();}else if(id==='g'){st.g=cpClamp(n,0,255);fromRgb();}else if(id==='bl'){st.b=cpClamp(n,0,255);fromRgb();}
    else if(id==='L'||id==='la'||id==='lb'){const lab=cpRgb2lab(st.r,st.g,st.b);if(id==='L')lab[0]=cpClamp(n,0,100);else if(id==='la')lab[1]=cpClamp(n,-128,127);else lab[2]=cpClamp(n,-128,127);const c=cpLab2rgb(lab[0],lab[1],lab[2]);st.r=c[0];st.g=c[1];st.b=c[2];fromRgb();}
    else{const cm=cpRgb2cmyk(st.r,st.g,st.b);cm['CMYK'.indexOf(id)]=cpClamp(n,0,100);const c=cpCmyk2rgb(cm[0],cm[1],cm[2],cm[3]);st.r=c[0];st.g=c[1];st.b=c[2];fromRgb();}
    sqKey='';sync();
  });
  $c('#cp-web').addEventListener('change',e=>{web=e.target.checked;if(web){fromRgb();}sqKey='';sync();});
  $c('#cp-cur').addEventListener('click',()=>{st.r=orig[0];st.g=orig[1];st.b=orig[2];fromRgb();sqKey='';sync();});
  const close=()=>{ov.remove();cpOpen=false;document.removeEventListener('keydown',kd,true);};
  const kd=e=>{if(e.key==='Escape'){e.stopPropagation();close();}else if(e.key==='Enter'&&e.target.tagName!=='BUTTON'){e.stopPropagation();e.preventDefault();ok();}};
  document.addEventListener('keydown',kd,true);
  function ok(){const hex=rgbHex(st.r,st.g,st.b);close();cb(hex);}
  $c('#cp-ok').onclick=ok;$c('#cp-cancel').onclick=close;$c('#cp-x').onclick=close;
  $c('#cp-add').onclick=()=>{const hex=rgbHex(st.r,st.g,st.b);if(!SWATCHES.includes(hex)){SWATCHES.push(hex);buildSwatches();}toast('Added to Swatches');};
  const pal=$c('#cp-sws');
  $c('#cp-pal').onclick=()=>{pal.hidden=!pal.hidden;if(!pal.hidden)pal.innerHTML=SWATCHES.map(c=>'<button class="sw" data-c="'+c+'" style="background:'+c+'" title="'+c+'"></button>').join('');};
  pal.addEventListener('click',e=>{const b=e.target.closest('.sw');if(!b)return;const c=hexRgb(b.dataset.c);st.r=c[0];st.g=c[1];st.b=c[2];fromRgb();sqKey='';sync();});
  const eb=$c('#cp-eye');if(eb)eb.onclick=async()=>{try{const r=await new EyeDropper().open();const c=hexRgb(r.sRGBHex);st.r=c[0];st.g=c[1];st.b=c[2];fromRgb();sqKey='';sync();}catch(err){}};
  ov.addEventListener('pointerdown',e=>{if(e.target===ov)close();});
  setTimeout(()=>{const o=$c('#cp-ok');o&&o.focus();},30);
}
function buildSwatches(){
  const g=$('#tab-swatches .swgrid');if(g)g.innerHTML=SWATCHES.map(c=>'<button class="sw" data-c="'+c+'" style="background:'+c+'" title="'+c+'" aria-label="Colour '+c+'"></button>').join('');
}
// every colour box in the app opens this picker instead of the browser one
document.addEventListener('click',e=>{
  const t=e.target;if(!t||t.tagName!=='INPUT'||t.type!=='color'||t.hidden||t.dataset.native)return;
  e.preventDefault();e.stopPropagation();
  const nm=t.getAttribute('title')||t.getAttribute('aria-label')||'Color Picker';
  openColorPicker(t.value,nm.indexOf('olour')>=0||nm.indexOf('olor')>=0?nm.replace('colour','color'):'Color Picker',hex=>{t.value=hex;t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));});
},true);
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target&&e.target.tagName==='INPUT'&&e.target.type==='color'){e.preventDefault();e.target.click();}},true);

/* ---------- gradient model ---------- */
/* g = {name,type:'solid'|'noise',smooth:0..100,cs:[{p,c,ref?,m?}],os:[{p,a,m?}],rough,seed,trans} ; p is 0..1, a is 0..1, m is the midpoint 0..1 */
const gcol=(s)=>s.ref==='fg'?S.fg:s.ref==='bg'?S.bg:s.c;
function GM(name,cols,alphas){
  const n=cols.length;
  return {name,type:'solid',smooth:100,rough:50,seed:1,
    cs:cols.map((c,i)=>{const o={p:n>1?i/(n-1):0,c:c,m:0.5};if(c==='fg'||c==='bg'){o.ref=c;o.c=c==='fg'?'#000000':'#ffffff';}return o;}),
    os:(alphas||[1,1]).map((a,i,arr)=>({p:arr.length>1?i/(arr.length-1):0,a:a,m:0.5}))};
}
const gradClone=g=>JSON.parse(JSON.stringify(g));
const GRAD_GROUPS=[
 {n:'Basics',items:[GM('Foreground to Background',['fg','bg']),GM('Foreground to Transparent',['fg','fg'],[1,0]),GM('Black, White',['#000000','#ffffff']),GM('Black to Transparent',['#000000','#000000'],[1,0]),GM('White to Transparent',['#ffffff','#ffffff'],[1,0]),GM('Red, Green',['#ff0000','#00ff00']),GM('Violet, Orange',['#8a2be2','#ff8c00']),GM('Blue, Red, Yellow',['#0000ff','#ff0000','#ffff00']),GM('Blue, Yellow, Blue',['#0000ff','#ffff00','#0000ff']),GM('Orange, Yellow, Orange',['#ff7a00','#ffe600','#ff7a00']),GM('Violet, Green, Orange',['#8a2be2','#27c93f','#ff8c00']),GM('Yellow, Violet, Orange, Blue',['#ffe600','#8a2be2','#ff8c00','#0050ff']),GM('Copper',['#4a2511','#b87333','#f3c9a0','#b87333','#4a2511']),GM('Chrome',['#ffffff','#7a7a7a','#ffffff','#4d4d4d','#d9d9d9']),GM('Spectrum',['#ff0000','#ffff00','#00ff00','#00ffff','#0000ff','#ff00ff','#ff0000']),GM('Transparent Rainbow',['#ff0000','#ffff00','#00ff00','#00ffff','#0000ff','#ff00ff'],[0,1,1,1,1,0]),GM('Transparent Stripes',['#000000','#000000','#000000','#000000','#000000'],[0,1,0,1,0])]},
 {n:'Blues',items:[GM('Blue 01',['#e6f4ff','#4aa3f0','#0a3d91']),GM('Blue 02',['#a1c4fd','#c2e9fb']),GM('Blue 03',['#00c6ff','#0072ff','#001a4d']),GM('Blue 04',['#0f2027','#203a43','#2c5364']),GM('Blue 05',['#3a7bd5','#00d2ff']),GM('Blue 06',['#1c92d2','#f2fcfe']),GM('Blue 07',['#02030f','#1b2a5e','#4e6cc4']),GM('Blue 08',['#4facfe','#00f2fe']),GM('Blue 09',['#0b486b','#f56217'])]},
 {n:'Purples',items:[GM('Purple 01',['#f3e7ff','#b57bff','#4b1d91']),GM('Purple 02',['#8e2de2','#4a00e0']),GM('Purple 03',['#1a0033','#8e2de2','#f7b5ff']),GM('Purple 04',['#614385','#516395']),GM('Purple 05',['#c471f5','#fa71cd']),GM('Purple 06',['#5f2c82','#49a09d']),GM('Purple 07',['#3813c2','#ff6fd8'])]},
 {n:'Pinks',items:[GM('Pink 01',['#ffe4ee','#ff8fb3','#c2185b']),GM('Pink 02',['#ff9a9e','#fad0c4']),GM('Pink 03',['#ee9ca7','#ffdde1']),GM('Pink 04',['#f953c6','#b91d73']),GM('Pink 05',['#ff758c','#ff7eb3']),GM('Pink 06',['#fbc2eb','#a6c1ee']),GM('Pink 07',['#ff6a88','#ff99ac','#fcb69f'])]},
 {n:'Reds & Oranges',items:[GM('Red 01',['#ffd6d6','#e53935','#7f0000']),GM('Red 02',['#eb3349','#f45c43']),GM('Red 03',['#cb2d3e','#ef473a']),GM('Orange 01',['#ffe0b2','#fb8c00','#e65100']),GM('Orange 02',['#ff512f','#f09819']),GM('Orange 03',['#f12711','#f5af19']),GM('Fire',['#200000','#d40000','#ff9a00','#fff08a']),GM('Sunset',['#ff512f','#f09819','#fff6a3']),GM('Sunrise',['#ffb347','#ffcc33','#87ceeb']),GM('Peach',['#ffecd2','#fcb69f'])]},
 {n:'Yellows',items:[GM('Yellow 01',['#fffbe0','#ffe34d','#b38600']),GM('Yellow 02',['#f7971e','#ffd200']),GM('Yellow 03',['#fdfc47','#24fe41']),GM('Yellow 04',['#fff176','#ffb74d']),GM('Gold',['#bf953f','#fcf6ba','#b38728','#fbf5b7','#aa771c']),GM('Gold 2',['#7a5a14','#f5d76e','#fff4b0','#c9992b','#6b4a0c'])]},
 {n:'Greens',items:[GM('Green 01',['#e8f5e9','#43a047','#1b5e20']),GM('Green 02',['#134e5e','#71b280']),GM('Green 03',['#00b09b','#96c93d']),GM('Green 04',['#11998e','#38ef7d']),GM('Green 05',['#56ab2f','#a8e063']),GM('Forest',['#0b3d0b','#2e7d32','#9ccc65']),GM('Mint',['#d4fc79','#96e6a1'])]},
 {n:'Neutrals',items:[GM('Neutral 01',['#ffffff','#9e9e9e','#212121']),GM('Neutral 02',['#232526','#414345']),GM('Neutral 03',['#bdc3c7','#2c3e50']),GM('Neutral 04',['#757f9a','#d7dde8']),GM('Steel',['#cfd9df','#e2ebf0']),GM('Silver',['#fdfbfb','#a3a3a3','#ebedee','#8a8a8a']),GM('Charcoal',['#0f0f0f','#4a4a4a','#0f0f0f'])]},
 {n:'Pastels',items:[GM('Pastel 01',['#ffd6e0','#ffefd6','#d6f5ff']),GM('Pastel 02',['#e0c3fc','#8ec5fc']),GM('Pastel 03',['#fdcbf1','#e6dee9']),GM('Pastel 04',['#a8edea','#fed6e3']),GM('Pastel 05',['#ffecd2','#fcb69f','#ff9a9e']),GM('Pastel Rainbow',['#ffb3ba','#ffdfba','#ffffba','#baffc9','#bae1ff','#e0bbff'])]},
 {n:'Metals',items:[GM('Brass',['#5a3d0a','#e3b341','#fff2b8','#c58f1c','#5a3d0a']),GM('Bronze',['#3d2208','#cd7f32','#f1c27d','#8a5a1f']),GM('Rose Gold',['#b76e79','#f8d7da','#b76e79','#e8b4b8']),GM('Titanium',['#42464b','#c5c9ce','#6d7278','#e5e8ec']),GM('Steel Blue',['#1f2933','#8aa1b5','#e6eef5','#5c7388']),GM('Gunmetal',['#1c1f22','#5b6269','#2c3136'])]},
 {n:'Special',items:[GM('Night Sky',['#02030f','#1b2a5e','#6b4e9b']),GM('Candy',['#ff6fd8','#3813c2']),GM('Ocean',['#00c6ff','#0072ff','#001a4d']),GM('Rainbow',['#ff0000','#ffd000','#2bd000','#00c8ff','#6a00ff','#ff00c8']),GM('Aurora',['#00c9a7','#4d8af0','#9b59b6','#00c9a7']),GM('Neon',['#08f7fe','#fe53bb','#f5d300']),GM('Vaporwave',['#ff71ce','#b967ff','#01cdfe','#05ffa1']),GM('Lava',['#1a0000','#8b0000','#ff4500','#ffd700']),GM('Glass',['#ffffff','#ffffff','#ffffff'],[0.05,0.5,0.05]),GM('Shine',['#ffffff','#ffffff','#ffffff'],[0,0.9,0])]}
];
// user presets saved on this device
let userGrads=[];
try{userGrads=JSON.parse(localStorage.getItem('lk_grads')||'[]');}catch(err){userGrads=[];}
const saveUserGrads=()=>{try{localStorage.setItem('lk_grads',JSON.stringify(userGrads));}catch(err){}};
const FG_BG=()=>gradClone(GRAD_GROUPS[0].items[0]);
S.grad=Object.assign({kind:'linear',mode:'fgbg'},S.grad,{g:null,rev:false,dither:true,trans:true,op:100,blend:'source-over'});

function gEval(arr,t,key,isCol){
  const a=arr;if(!a.length)return isCol?[0,0,0]:1;
  const val=s=>isCol?hexRgb(gcol(s)):s.a;
  if(t<=a[0].p)return val(a[0]);if(t>=a[a.length-1].p)return val(a[a.length-1]);
  let i=0;while(i<a.length-2&&a[i+1].p<=t)i++;
  const x=a[i],y=a[i+1],span=y.p-x.p;let u=span>0?(t-x.p)/span:0;
  const m=cpClamp(x.m==null?0.5:x.m,0.02,0.98);if(Math.abs(m-0.5)>0.001)u=Math.pow(u,Math.log(0.5)/Math.log(m));
  const A=val(x),B=val(y);
  return isCol?[A[0]+(B[0]-A[0])*u,A[1]+(B[1]-A[1])*u,A[2]+(B[2]-A[2])*u]:A+(B-A)*u;
}
const gSorted=(arr)=>[...arr].sort((a,b)=>a.p-b.p);
function noiseStops(g){
  let sd=(g.seed||1)*9301+49297;const rnd=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
  const n=Math.round(3+(g.rough==null?50:g.rough)/100*30),out=[];
  for(let i=0;i<=n;i++){const c=rgbHex(rnd()*255,rnd()*255,rnd()*255);out.push({p:i/n,c,a:g.trans?0.35+rnd()*0.65:1});}
  return out;
}
/* turn the editable model into plain stops with 8-digit hex colours (what the renderer wants) */
function gFlatten(g){
  const hex2=n=>Math.round(cpClamp(n,0,255)).toString(16).padStart(2,'0');
  if(g.type==='noise'){return noiseStops(g).map(s=>({p:s.p,c:s.c+hex2(s.a*255)}));}
  const cs=gSorted(g.cs),os=gSorted(g.os),sm=(g.smooth==null?100:g.smooth)/100;
  const simple=cs.every(s=>(s.m==null||Math.abs(s.m-0.5)<0.001))&&os.every(s=>(s.m==null||Math.abs(s.m-0.5)<0.001))&&sm>=0.995;
  const pts=[];
  if(simple){new Set([...cs.map(s=>s.p),...os.map(s=>s.p)]).forEach(p=>pts.push(p));pts.sort((a,b)=>a-b);}
  else{const N=sm<0.995?Math.max(2,Math.round(sm*30)):0;
    if(N){for(let i=0;i<=N*8;i++)pts.push(i/(N*8));}else for(let i=0;i<=64;i++)pts.push(i/64);}
  return pts.map(p=>{
    let q=p;const sm2=sm;if(!simple&&sm2<0.995){const N=Math.max(2,Math.round(sm2*30));q=Math.min(1,Math.floor(p*N+1e-9)/(N-1));if(!isFinite(q))q=p;}
    const c=gEval(cs,q,'c',true),a=gEval(os,q,'a',false);return {p,c:rgbHex(c[0],c[1],c[2])+hex2(a*255)};
  });
}
function gCss(g,rev,withAlpha){
  const st=gFlatten(g).map(s=>{const c=hexRgb(s.c.slice(0,7)),a=parseInt(s.c.slice(7,9)||'ff',16)/255;return 'rgba('+c[0]+','+c[1]+','+c[2]+','+(withAlpha===false?1:+a.toFixed(3))+') '+(Math.round((rev?1-s.p:s.p)*1000)/10)+'%';});
  if(rev)st.reverse();
  return 'linear-gradient(90deg,'+st.join(',')+')';
}
// layer style gradient <-> model
function fxToGrad(fg){
  if(fg.model)return gradClone(fg.model);
  const g={name:'Custom',type:'solid',smooth:100,rough:50,seed:1,cs:[],os:[]};
  (fg.stops||[]).forEach(s=>{const hex=(s.c||'#000000').replace('#','');g.cs.push({p:s.p,c:'#'+hex.slice(0,6),m:0.5});g.os.push({p:s.p,a:hex.length>=8?parseInt(hex.slice(6,8),16)/255:1,m:0.5});});
  if(g.cs.length<2){g.cs=[{p:0,c:'#ffffff',m:0.5},{p:1,c:'#000000',m:0.5}];g.os=[{p:0,a:1,m:0.5},{p:1,a:1,m:0.5}];}
  return g;
}
const gradToFx=g=>({stops:gFlatten(g)});
function gradCss(stops,rev){
  const st=[...stops].sort((a,b)=>a.p-b.p).map(s=>{const hx=s.c.replace('#','');const c=hexRgb(hx.slice(0,6)),a=hx.length>=8?parseInt(hx.slice(6,8),16)/255:1;return {p:s.p,css:'rgba('+c[0]+','+c[1]+','+c[2]+','+(+a.toFixed(3))+')'};});
  const out=(rev?st.map(s=>({p:1-s.p,css:s.css})).reverse():st).map(s=>s.css+' '+Math.round(s.p*1000)/10+'%');
  return 'linear-gradient(90deg,'+out.join(',')+')';
}

/* ---------- the Gradient Editor dialog ---------- */
let geOpen=false;
function openGradEditor(start,cb){
  if(geOpen)return;geOpen=true;
  let g=gradClone(start||FG_BG());if(!g.cs||!g.os)g=FG_BG();
  let sel={k:'c',i:0},open={};GRAD_GROUPS.forEach((gr,i)=>open[i]=i===0);
  const ov=document.createElement('div');ov.id='ged';ov.setAttribute('role','dialog');ov.setAttribute('aria-label','Gradient Editor');
  ov.innerHTML='<div class="gebox"><header><b>Gradient Editor</b><button id="ge-x" aria-label="Close">&#10005;</button></header>'
   +'<div class="gebody"><div class="gepre"><div class="geh">Presets</div><div id="ge-pre"></div></div>'
   +'<div class="gemain"><div class="gerow"><label>Name <input type="text" id="ge-name"></label><button id="ge-new">New</button><button id="ge-del" title="Delete the selected custom preset">Delete preset</button></div>'
   +'<div class="gerow"><label>Gradient Type <select id="ge-type"><option value="solid">Solid</option><option value="noise">Noise</option></select></label><label id="ge-smwrap">Smoothness <input type="number" id="ge-smooth" min="0" max="100" style="width:58px"> %</label></div>'
   +'<div class="gebarbox"><div class="gestrip top" id="ge-top"></div><div class="gebar" id="ge-bar"><div class="checker"></div><div class="fill" id="ge-fill"></div></div><div class="gestrip bot" id="ge-bot"></div></div>'
   +'<div class="gestops" id="ge-stops"></div><div id="ge-noise" hidden></div></div></div>'
   +'<footer><button id="ge-cancel">Cancel</button><button class="primary" id="ge-ok">OK</button></footer></div>';
  document.body.appendChild(ov);
  const q=s=>ov.querySelector(s);
  let activeUser=-1;
  function drawPresets(){
    const box=q('#ge-pre');let h='';
    GRAD_GROUPS.forEach((gr,i)=>{h+='<div class="gegrp"><button class="gegh" data-gr="'+i+'"><i>'+(open[i]?'&#9662;':'&#9656;')+'</i> '+gr.n+'</button>'+(open[i]?'<div class="gegrid">'+gr.items.map((it,j)=>'<button class="gesw" data-gi="'+i+'" data-gj="'+j+'" title="'+it.name+'"><span class="checker"></span><span class="gsp" style="background:'+gCss(it)+'"></span></button>').join('')+'</div>':'')+'</div>';});
    h+='<div class="gegrp"><button class="gegh" data-gr="u"><i>'+(open.u!==false?'&#9662;':'&#9656;')+'</i> Custom ('+userGrads.length+')</button>'+(open.u!==false?'<div class="gegrid">'+(userGrads.length?userGrads.map((it,j)=>'<button class="gesw'+(j===activeUser?' on':'')+'" data-ui="'+j+'" title="'+esc(it.name)+'"><span class="checker"></span><span class="gsp" style="background:'+gCss(it)+'"></span></button>').join(''):'<span class="muted" style="padding:4px 6px">Press New to save your gradient here.</span>')+'</div>':'')+'</div>';
    box.innerHTML=h;
  }
  const bar=q('#ge-bar'),top=q('#ge-top'),bot=q('#ge-bot');
  function drawBar(){
    q('#ge-fill').style.background=gCss(g);
    const isN=g.type==='noise';
    top.style.display=bot.style.display=isN?'none':'';
    top.innerHTML=g.os.map((s,i)=>'<div class="gst op'+(sel.k==='o'&&sel.i===i?' on':'')+'" data-k="o" data-i="'+i+'" style="left:'+s.p*100+'%"><b style="background:rgb('+Math.round(255-s.a*255)+','+Math.round(255-s.a*255)+','+Math.round(255-s.a*255)+')"></b></div>').join('')
      +g.os.slice(0,-1).map((s,i)=>{const nx=g.os[i+1],m=s.m==null?0.5:s.m;return '<div class="gmid" data-k="om" data-i="'+i+'" style="left:'+(s.p+(nx.p-s.p)*m)*100+'%'+'"></div>';}).join('');
    bot.innerHTML=g.cs.map((s,i)=>'<div class="gst cl'+(sel.k==='c'&&sel.i===i?' on':'')+'" data-k="c" data-i="'+i+'" style="left:'+s.p*100+'%"><b style="background:'+gcol(s)+'"></b></div>').join('')
      +g.cs.slice(0,-1).map((s,i)=>{const nx=g.cs[i+1],m=s.m==null?0.5:s.m;return '<div class="gmid" data-k="cm" data-i="'+i+'" style="left:'+(s.p+(nx.p-s.p)*m)*100+'%'+'"></div>';}).join('');
  }
  function drawStops(){
    const box=q('#ge-stops'),isN=g.type==='noise';
    q('#ge-smwrap').style.display=isN?'none':'';q('#ge-smooth').value=Math.round(g.smooth==null?100:g.smooth);q('#ge-type').value=g.type;q('#ge-name').value=g.name||'';
    const nz=q('#ge-noise');nz.hidden=!isN;box.hidden=isN;
    if(isN){nz.innerHTML='<div class="gerow"><label>Roughness <input type="number" id="ge-rough" min="0" max="100" value="'+Math.round(g.rough==null?50:g.rough)+'" style="width:58px"> %</label><label><input type="checkbox" id="ge-trans"'+(g.trans?' checked':'')+'> Add Transparency</label><button id="ge-rand">Randomize</button></div><p class="muted">Noise makes a random gradient. Press Randomize until you like it.</p>';return;}
    const arr=sel.k==='o'?g.os:g.cs;let s=sel.k==='o'||sel.k==='c'?arr[sel.i]:null;
    let h='';
    const isMid=sel.k==='om'||sel.k==='cm';
    if(isMid){const a=sel.k==='om'?g.os:g.cs,x=a[sel.i];h='<div class="geset"><div class="geh">Midpoint</div><label>Location <input type="number" id="ge-mid" min="5" max="95" value="'+Math.round((x.m==null?0.5:x.m)*100)+'" style="width:58px"> %</label></div>';box.innerHTML=h;return;}
    if(!s){sel={k:'c',i:0};s=g.cs[0];}
    if(sel.k==='o'){h='<div class="geset"><div class="geh">Opacity Stop</div><label>Opacity <input type="number" id="ge-op" min="0" max="100" value="'+Math.round(s.a*100)+'" style="width:58px"> %</label><label>Location <input type="number" id="ge-loc" min="0" max="100" value="'+Math.round(s.p*100)+'" style="width:58px"> %</label><button id="ge-delstop"'+(g.os.length<=2?' disabled':'')+'>Delete</button></div>';}
    else{h='<div class="geset"><div class="geh">Color Stop</div><label>Color <span id="ge-colbtn" class="gecol" tabindex="0" role="button" aria-label="Stop colour" style="background:'+gcol(s)+'"></span></label>'
      +'<span class="seg"><button data-gref="fg" class="'+(s.ref==='fg'?'on':'')+'">Foreground</button><button data-gref="bg" class="'+(s.ref==='bg'?'on':'')+'">Background</button><button data-gref="user" class="'+(!s.ref?'on':'')+'">User</button></span>'
      +'<label>Location <input type="number" id="ge-loc" min="0" max="100" value="'+Math.round(s.p*100)+'" style="width:58px"> %</label><button id="ge-delstop"'+(g.cs.length<=2?' disabled':'')+'>Delete</button></div>';}
    box.innerHTML=h;
  }
  const full=()=>{drawPresets();drawBar();drawStops();};
  full();
  const refresh=()=>{drawBar();drawStops();};
  const fixOrder=()=>{};
  // preset clicks
  ov.addEventListener('click',e=>{
    const gh=e.target.closest('.gegh');if(gh){const k=gh.dataset.gr;open[k]=k==='u'?!(open.u!==false):!open[k];drawPresets();return;}
    const sw=e.target.closest('.gesw');
    if(sw){let it;if(sw.dataset.ui!==undefined){activeUser=+sw.dataset.ui;it=userGrads[activeUser];}else{activeUser=-1;it=GRAD_GROUPS[+sw.dataset.gi].items[+sw.dataset.gj];}
      g=gradClone(it);sel={k:'c',i:0};full();return;}
    const gr=e.target.closest('[data-gref]');
    if(gr){const s=g.cs[sel.i],k=gr.dataset.gref;if(k==='user')delete s.ref;else{s.ref=k;}refresh();return;}
  });
  q('#ge-new').onclick=()=>{const c=gradClone(g);c.name=(q('#ge-name').value||'Custom Gradient');userGrads.push(c);saveUserGrads();open.u=true;activeUser=userGrads.length-1;drawPresets();toast('Saved to your presets');};
  q('#ge-del').onclick=()=>{if(activeUser>=0){userGrads.splice(activeUser,1);activeUser=-1;saveUserGrads();drawPresets();}else toast('Select one of your own presets first');};
  // fields
  ov.addEventListener('input',e=>{
    const t=e.target,id=t.id;if(!id)return;const n=+t.value;
    if(id==='ge-name'){g.name=t.value;return;}
    if(id==='ge-type'){g.type=t.value;if(g.type==='noise'&&!g.seed)g.seed=1;refresh();return;}
    if(id==='ge-smooth'){g.smooth=cpClamp(n,0,100);drawBar();return;}
    if(id==='ge-rough'){g.rough=cpClamp(n,0,100);drawBar();return;}
    if(id==='ge-trans'){g.trans=t.checked;drawBar();return;}
    if(t.value===''||isNaN(n))return;
    if(id==='ge-op'){g.os[sel.i].a=cpClamp(n,0,100)/100;drawBar();return;}
    if(id==='ge-loc'){const arr=sel.k==='o'?g.os:g.cs,s=arr[sel.i];s.p=cpClamp(n,0,100)/100;const cur=s;arr.sort((a,b)=>a.p-b.p);sel.i=arr.indexOf(cur);drawBar();return;}
    if(id==='ge-mid'){const a=sel.k==='om'?g.os:g.cs;a[sel.i].m=cpClamp(n,5,95)/100;drawBar();return;}
  });
  ov.addEventListener('change',e=>{if(e.target.id==='ge-type'||e.target.id==='ge-loc')refresh();});
  ov.addEventListener('click',e=>{
    if(e.target.id==='ge-rand'){g.seed=Math.floor(Math.random()*100000)+1;drawBar();return;}
    if(e.target.id==='ge-delstop'){const arr=sel.k==='o'?g.os:g.cs;if(arr.length>2){arr.splice(sel.i,1);sel={k:sel.k,i:Math.max(0,sel.i-1)};refresh();}return;}
    const cb2=e.target.closest('#ge-colbtn');
    if(cb2){const s=g.cs[sel.i];openColorPicker(gcol(s),'Select stop color',hex=>{s.c=hex;delete s.ref;refresh();});}
  });
  ov.addEventListener('keydown',e=>{if(e.target.id==='ge-colbtn'&&(e.key==='Enter'||e.key===' ')){e.preventDefault();e.target.click();}});
  // dragging stops
  function posOf(ev){const r=bar.getBoundingClientRect();return cpClamp((ev.clientX-r.left)/r.width,0,1);}
  function addStop(kind,p){
    if(kind==='o'){const a=gEval(gSorted(g.os),p,'a',false);const s={p,a,m:0.5};g.os.push(s);g.os.sort((a,b)=>a.p-b.p);sel={k:'o',i:g.os.indexOf(s)};}
    else{const c=gEval(gSorted(g.cs),p,'c',true);const s={p,c:rgbHex(c[0],c[1],c[2]),m:0.5};g.cs.push(s);g.cs.sort((a,b)=>a.p-b.p);sel={k:'c',i:g.cs.indexOf(s)};}
    return sel;
  }
  function startDrag(ev,strip,kind){
    const el=ev.target.closest('.gst,.gmid');
    ev.preventDefault();
    if(!el){ // empty strip: add a new stop
      if(g.type==='noise')return;addStop(kind,posOf(ev));refresh();
      const arr=kind==='o'?g.os:g.cs,me=arr[sel.i];
      return begin(kind,arr,me,false);
    }
    const k=el.dataset.k,i=+el.dataset.i;
    if(k==='om'||k==='cm'){sel={k,i};refresh();const a=k==='om'?g.os:g.cs,x=a[i],nx=a[i+1];
      const mv=e2=>{const p=posOf(e2);x.m=cpClamp((p-x.p)/Math.max(1e-6,nx.p-x.p),0.05,0.95);drawBar();const m=q('#ge-mid');if(m)m.value=Math.round(x.m*100);};
      const up=()=>{document.removeEventListener('pointermove',mv);document.removeEventListener('pointerup',up);};document.addEventListener('pointermove',mv);document.addEventListener('pointerup',up);return;}
    sel={k,i};refresh();const arr=k==='o'?g.os:g.cs;begin(k,arr,arr[i],true);
    function dummy(){}
  }
  function begin(kind,arr,me,allowDelete){
    let removed=false;const y0=null;
    const mv=e2=>{
      const r=bar.getBoundingClientRect(),away=kind==='o'?r.top-e2.clientY:e2.clientY-r.bottom;
      if(allowDelete&&arr.length>2&&(away>50||(kind==='o'?e2.clientY>r.bottom+10:e2.clientY<r.top-10)&&false)){if(!removed){removed=true;me.__rm=true;}}else removed=false;
      me.p=posOf(e2);
      arr.sort((a,b)=>a.p-b.p);sel={k:kind,i:arr.indexOf(me)};
      drawBar();const l=q('#ge-loc');if(l)l.value=Math.round(me.p*100);
    };
    const up=()=>{document.removeEventListener('pointermove',mv);document.removeEventListener('pointerup',up);
      if(removed&&arr.length>2){arr.splice(arr.indexOf(me),1);sel={k:kind,i:0};}
      refresh();};
    document.addEventListener('pointermove',mv);document.addEventListener('pointerup',up);
  }
  top.addEventListener('pointerdown',e=>startDrag(e,top,'o'));
  bot.addEventListener('pointerdown',e=>startDrag(e,bot,'c'));
  bot.addEventListener('dblclick',e=>{const el=e.target.closest('.gst');if(!el)return;const s=g.cs[+el.dataset.i];openColorPicker(gcol(s),'Select stop color',hex=>{s.c=hex;delete s.ref;refresh();});});
  const close=()=>{ov.remove();geOpen=false;document.removeEventListener('keydown',kd,true);};
  const kd=e=>{
    if(cpOpen)return;
    if(e.key==='Escape'){e.stopPropagation();close();}
    else if((e.key==='Delete'||e.key==='Backspace')&&!/INPUT|SELECT/.test(e.target.tagName)){const arr=sel.k==='o'?g.os:g.cs;if((sel.k==='o'||sel.k==='c')&&arr.length>2){arr.splice(sel.i,1);sel={k:sel.k,i:0};refresh();}e.preventDefault();}
    else if(e.key==='Enter'&&!/BUTTON|INPUT|SELECT/.test(e.target.tagName)){e.preventDefault();ok();}
  };
  document.addEventListener('keydown',kd,true);
  function ok(){const out=gradClone(g);close();cb(out);}
  q('#ge-ok').onclick=ok;q('#ge-cancel').onclick=close;q('#ge-x').onclick=close;
  ov.addEventListener('pointerdown',e=>{if(e.target===ov)close();});
}

/* ---------- Gradient tool: options bar, rendering ---------- */
const GKINDS=[['linear','Linear','<path d="M4 20L20 4" /><path d="M7 20l13-13M4 17L17 4" opacity=".4"/>'],['radial','Radial','<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4" opacity=".5"/>'],['angle','Angle','<path d="M12 12L20 12M12 12L18 6M12 12L12 4" /><circle cx="12" cy="12" r="8" opacity=".4"/>'],['reflected','Reflected','<path d="M4 12h16M4 8h16M4 16h16" opacity=".5"/><path d="M12 4v16"/>'],['diamond','Diamond','<path d="M12 3l9 9-9 9-9-9z"/><path d="M12 8l4 4-4 4-4-4z" opacity=".5"/>']];
function gradOptsHtml(){
  const g=S.grad.g||FG_BG();
  return '<span class="opt gtoolbar"><button class="gprev" id="g-prev" title="Click to edit the gradient"><span class="checker"></span><span class="gsp" style="background:'+gCss(g,S.grad.rev)+'"></span></button><button id="g-pick" title="Pick a preset gradient" aria-label="Gradient presets">&#9662;</button></span>'
   +'<span class="opt seg" role="group" aria-label="Gradient type">'+GKINDS.map(k=>'<button data-gk="'+k[0]+'" title="'+k[1]+' gradient" class="gk'+(S.grad.kind===k[0]?' on':'')+'"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8">'+k[2]+'</svg></button>').join('')+'</span>'
   +'<label class="opt">Mode <select id="g-blend">'+BLEND_OPTS.map(o=>'<option value="'+o[0]+'"'+(o[0]===S.grad.blend?' selected':'')+'>'+o[1]+'</option>').join('')+'</select></label>'
   +'<label class="opt">Opacity <input type="range" id="g-op" min="1" max="100" value="'+S.grad.op+'"><output>'+S.grad.op+'</output></label>'
   +'<label class="opt"><input type="checkbox" id="g-rev"'+(S.grad.rev?' checked':'')+'> Reverse</label><label class="opt"><input type="checkbox" id="g-dith"'+(S.grad.dither?' checked':'')+'> Dither</label><label class="opt"><input type="checkbox" id="g-trans"'+(S.grad.trans?' checked':'')+'> Transparency</label>'
   +'<span class="opt muted">Drag on the picture.</span>';
}
function gradPopover(anchor){
  const old=document.getElementById('gpop');if(old){old.remove();return;}
  const p=document.createElement('div');p.id='gpop';
  p.innerHTML=GRAD_GROUPS.map((gr,i)=>'<div class="geh">'+gr.n+'</div><div class="gegrid">'+gr.items.map((it,j)=>'<button class="gesw" data-gi="'+i+'" data-gj="'+j+'" title="'+it.name+'"><span class="checker"></span><span class="gsp" style="background:'+gCss(it)+'"></span></button>').join('')+'</div>').join('')
    +(userGrads.length?'<div class="geh">Custom</div><div class="gegrid">'+userGrads.map((it,j)=>'<button class="gesw" data-ui="'+j+'" title="'+esc(it.name)+'"><span class="checker"></span><span class="gsp" style="background:'+gCss(it)+'"></span></button>').join('')+'</div>':'');
  document.body.appendChild(p);
  const r=anchor.getBoundingClientRect();p.style.left=Math.max(4,Math.min(r.left,innerWidth-p.offsetWidth-4))+'px';p.style.top=(r.bottom+4)+'px';
  p.addEventListener('click',e=>{const sw=e.target.closest('.gesw');if(!sw)return;
    S.grad.g=gradClone(sw.dataset.ui!==undefined?userGrads[+sw.dataset.ui]:GRAD_GROUPS[+sw.dataset.gi].items[+sw.dataset.gj]);p.remove();renderOpts();if(PANELS.gradients&&S.tab==='gradients')PANELS.gradients.render();});
  setTimeout(()=>{const off=e=>{if(!p.contains(e.target)){p.remove();document.removeEventListener('pointerdown',off,true);}};document.addEventListener('pointerdown',off,true);},0);
}
document.addEventListener('click',e=>{
  const t=e.target;if(!t.closest)return;
  if(t.closest('#g-prev')){openGradEditor(S.grad.g||FG_BG(),g=>{S.grad.g=g;renderOpts();});return;}
  const pk=t.closest('#g-pick');if(pk){gradPopover(pk);return;}
  const gk=t.closest('.gk[data-gk]');if(gk){S.grad.kind=gk.dataset.gk;$$('.gk').forEach(b=>b.classList.toggle('on',b===gk));return;}
});
document.addEventListener('input',e=>{
  const t=e.target;if(!t.id)return;
  if(t.id==='g-blend')S.grad.blend=t.value;
  else if(t.id==='g-op'){S.grad.op=+t.value;t.nextElementSibling.textContent=t.value;}
  else if(t.id==='g-rev'){S.grad.rev=t.checked;renderOpts();}
  else if(t.id==='g-dith')S.grad.dither=t.checked;
  else if(t.id==='g-trans')S.grad.trans=t.checked;
});
gradientLayer=function(p0,p1){
  const g=S.grad.g||FG_BG(),lut=fxr_gradLUT(gFlatten(g));
  const l=addLayer({name:'Gradient',above:true});l.opacity=S.grad.op/100;l.blend=S.grad.blend||'source-over';
  const cv=l.canvas,w=cv.width,h=cv.height,ctx=cctx(cv),img=ctx.createImageData(w,h),d=img.data;
  const dx=p1.x-p0.x,dy=p1.y-p0.y,L=Math.max(1,Math.hypot(dx,dy)),L2=L*L,ux=dx/L,uy=dy/L,kind=S.grad.kind,rev=S.grad.rev,TP=Math.PI*2,a0=Math.atan2(-dy,dx),dith=S.grad.dither,tr=S.grad.trans;
  for(let y=0;y<h;y++){const ry=y+.5-p0.y;
    for(let x=0;x<w;x++){
      const rx=x+.5-p0.x;let t;
      switch(kind){
        case 'radial':t=Math.sqrt(rx*rx+ry*ry)/L;break;
        case 'angle':t=(Math.atan2(-ry,rx)-a0)/TP;t-=Math.floor(t);break;
        case 'reflected':t=Math.abs(rx*dx+ry*dy)/L2;break;
        case 'diamond':{const u=rx*ux+ry*uy,v=-rx*uy+ry*ux;t=(Math.abs(u)+Math.abs(v))/L;break;}
        default:t=(rx*dx+ry*dy)/L2;
      }
      if(rev)t=1-t;t=t<0?0:t>1?1:t;
      const k=((t*511+.5)|0)*4,i=(y*w+x)*4,n=dith?(Math.random()-.5)*2:0;
      d[i]=lut[k]+n;d[i+1]=lut[k+1]+n;d[i+2]=lut[k+2]+n;d[i+3]=tr?lut[k+3]:255;
    }}
  ctx.putImageData(img,0,0);touch(l);restrictCanvasToSel(l);
};

/* ---------- Gradients panel ---------- */
PNL('gradients','Gradients','A',pnl('gradients',()=>{
  const cur=S.grad.g?S.grad.g.name:'Foreground to Background';
  return '<div class="gtop"><button class="gprev wide" id="gp-edit" title="Edit this gradient"><span class="checker"></span><span class="gsp" style="background:'+gCss(S.grad.g||FG_BG(),S.grad.rev)+'"></span></button><button data-gpact="edit">Edit</button></div><div class="muted" style="padding:0 2px 6px">'+esc(cur)+'</div>'
   +GRAD_GROUPS.map((gr,i)=>'<div class="geh">'+gr.n+'</div><div class="gegrid">'+gr.items.map((it,j)=>'<button class="gesw'+((S.grad.g?S.grad.g.name:'Foreground to Background')===it.name?' on':'')+'" data-gi="'+i+'" data-gj="'+j+'" title="'+it.name+'"><span class="checker"></span><span class="gsp" style="background:'+gCss(it)+'"></span></button>').join('')+'</div>').join('')
   +(userGrads.length?'<div class="geh">Custom</div><div class="gegrid">'+userGrads.map((it,j)=>'<button class="gesw" data-ui="'+j+'" title="'+esc(it.name)+'"><span class="checker"></span><span class="gsp" style="background:'+gCss(it)+'"></span></button>').join('')+'</div>':'')
   +'<p class="muted">Pick a gradient, then use the Gradient tool (G) and drag on the picture. Press Edit to change colours and opacity.</p>';
}));
document.addEventListener('click',e=>{
  const t=e.target.closest('#tab-gradients');if(!t)return;
  if(e.target.closest('#gp-edit,[data-gpact=edit]')){openGradEditor(S.grad.g||FG_BG(),g=>{S.grad.g=g;PANELS.gradients.render();});return;}
  const sw=e.target.closest('.gesw');if(!sw)return;
  S.grad.g=gradClone(sw.dataset.ui!==undefined?userGrads[+sw.dataset.ui]:GRAD_GROUPS[+sw.dataset.gi].items[+sw.dataset.gj]);PANELS.gradients.render();
  if(S.tool!=='gradient')pickTool('fill',0);
});
// double-click the Gradient tool's preview in the toolbox area is handled by the options bar; Foreground/Background swatches follow the colour boxes
