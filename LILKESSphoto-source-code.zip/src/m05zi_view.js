/* ===== canvas scroll bars, full screen button, workspaces ===== */
{
  const mk=(id,cls)=>{const b=document.createElement('div');b.id=id;b.className='sbar '+cls;b.innerHTML='<i></i>';b.addEventListener('pointerdown',e=>e.stopPropagation());b.addEventListener('wheel',e=>e.stopPropagation());vp.appendChild(b);return b;};
  const sbH=mk('sbH','h'),sbV=mk('sbV','v'),corner=document.createElement('div');corner.className='sbcorner';vp.appendChild(corner);
  const range=(vpLen,docLen)=>{const z=S.zoom,len=docLen*z,min=vpLen*0.12-len,max=vpLen*0.88;return {min,max,content:(max-min)+vpLen};};
  function updateSB(){
    const on=PREFS.scrollbars!==false&&doc&&!S.rot;
    sbH.style.display=sbV.style.display=corner.style.display=on?'':'none';if(!on)return;
    const r=vp.getBoundingClientRect(),th=sbH.clientWidth||r.width-14,tv=sbV.clientHeight||r.height-14;
    const rx=range(r.width,doc.w),ry=range(r.height,doc.h);
    const set=(bar,track,rg,off,vpLen,horiz)=>{const thumb=bar.firstChild,len=Math.max(28,track*vpLen/rg.content),pos=(track-len)*clamp((rg.max-off)/(rg.max-rg.min),0,1);
      if(horiz){thumb.style.width=len+'px';thumb.style.left=pos+'px';}else{thumb.style.height=len+'px';thumb.style.top=pos+'px';}bar._m={track,len,rg,vpLen};};
    set(sbH,th,rx,S.px,r.width,true);set(sbV,tv,ry,S.py,r.height,false);
  }
  const _av=applyView;applyView=function(){_av();updateSB();};
  new ResizeObserver(updateSB).observe(vp);
  const drag=(bar,horiz)=>{
    bar.addEventListener('pointerdown',e=>{if(!doc||!bar._m)return;e.preventDefault();const m=bar._m,th=bar.firstChild,rect=th.getBoundingClientRect();
      const p0=horiz?e.clientX:e.clientY;
      if(e.target!==th){ // click in the track: page up/down
        const t0=horiz?rect.left:rect.top,dir=p0<t0?1:-1,r=vp.getBoundingClientRect();(horiz?S.px+=dir*r.width*0.8:S.py+=dir*r.height*0.8);S.autoFit=false;S.px=clamp(S.px,bar===sbH?m.rg.min:S.px-1e9,bar===sbH?m.rg.max:S.px+1e9);applyView();return;}
      const start=horiz?S.px:S.py;bar.setPointerCapture(e.pointerId);
      const mv=ev=>{const d=(horiz?ev.clientX:ev.clientY)-p0,k=m.rg.content/m.track;let v=start-d*k;v=clamp(v,m.rg.min,m.rg.max);if(horiz)S.px=v;else S.py=v;S.autoFit=false;applyView();};
      const up=()=>{bar.removeEventListener('pointermove',mv);bar.removeEventListener('pointerup',up);};
      bar.addEventListener('pointermove',mv);bar.addEventListener('pointerup',up);});
  };
  drag(sbH,true);drag(sbV,false);
  updateSB();
  ACT.scrollbars=()=>{PREFS.scrollbars=PREFS.scrollbars===false;savePrefs();updateSB();toast(PREFS.scrollbars===false?'Scroll bars hidden':'Scroll bars shown');};
  const V=MENUS.find(m=>m.label==='View');if(V)V.items.splice(V.items.length-1,0,al('Scroll bars','','scrollbars',{check:()=>PREFS.scrollbars!==false}));
}
/* full screen button */
{
  const undo=document.getElementById('undo'),b=document.createElement('button');b.className='ibtn';b.id='fsbtn';b.dataset.act='fullscreen';b.title='Full screen (F11)';b.setAttribute('aria-label','Full screen');b.innerHTML='&#9974;';
  undo.parentNode.insertBefore(b,undo);
  document.addEventListener('fullscreenchange',()=>{const on=!!document.fullscreenElement;b.classList.toggle('on',on);b.title=on?'Exit full screen (Esc)':'Full screen (F11)';setTimeout(()=>{if(doc&&S.autoFit)fitView();else drawRulers();},150);});
  document.addEventListener('keydown',e=>{if(e.key==='F11'&&!e.ctrlKey&&!e.altKey){e.preventDefault();ACT.fullscreen();}});
}
/* ===== workspaces ===== */
const WORKSPACES={
  'Essentials':{A:['color','swatches','adjust','filters','info'],B:['layers','channels','paths','history','props'],tool:'move',tabA:'color',tabB:'layers',note:''},
  '3D':{A:['color','swatches','adjust','info'],B:['layers','props','paths','history'],tool:'move',tabA:'adjust',tabB:'props',note:'3D workspace: Filter > 3D makes a 2.5D extrusion. Real 3D models are not supported.'},
  'Graphics and Web':{A:['color','swatches','gradients','styles','libraries'],B:['layers','props','character','paragraph','paths'],tool:'shape',tabA:'swatches',tabB:'props',note:''},
  'Painting':{A:['color','swatches','brushes','brushset','brushpre'],B:['layers','history','props','channels'],tool:'brush',tabA:'brushes',tabB:'layers',note:''},
  'Photography':{A:['histogram','adjust','filters','navigator','info'],B:['layers','history','props','channels'],tool:'move',tabA:'histogram',tabB:'layers',note:''}
};
let curWs=PREFS.workspace||'Essentials';
function userWs(){return PREFS.userWs||(PREFS.userWs={});}
function applyWorkspace(name,quiet){
  const w=WORKSPACES[name]||userWs()[name];if(!w)return;
  if(typeof makeSections==='function')makeSections();
  const all=new Set([...w.A,...w.B]);
  PANEL_ORDER.forEach(id=>{const p=PANELS[id];if(!p)return;const want=w.A.includes(id)?'A':w.B.includes(id)?'B':p.dock;if(p.dock!==want){p.dock=want;}const sec=$('#tab-'+id),body=$('#dock'+(want)+' .dbody');if(sec&&body&&sec.parentNode!==body)body.appendChild(sec);});
  DOCK_A.length=0;DOCK_A.push(...w.A.filter(id=>PANELS[id]));DOCK_B.length=0;DOCK_B.push(...w.B.filter(id=>PANELS[id]));
  S.tabA=DOCK_A.includes(w.tabA)?w.tabA:DOCK_A[0];S.tabB=DOCK_B.includes(w.tabB)?w.tabB:DOCK_B[0];
  buildDockTabs();setTab(S.tabB,false,true);setTab(S.tabA,false,true);
  if(w.tool&&doc&&!quiet){try{setTool(w.tool);}catch(e){}}
  curWs=name;PREFS.workspace=name;savePrefs();updateWsBtn();
  if(!quiet)toast(name+' workspace'+(w.note?'. '+w.note:''));
  setTimeout(()=>{if(doc&&S.autoFit)fitView();else if(doc)drawRulers();},60);
}
function saveWorkspaceAs(){
  askText('New workspace','Name','My workspace',n=>{n=(n||'').trim();if(!n)return;if(WORKSPACES[n]){toast('That name is used by a built-in workspace');return;}
    userWs()[n]={A:DOCK_A.slice(),B:DOCK_B.slice(),tool:null,tabA:S.tabA,tabB:S.tabB,note:''};curWs=n;PREFS.workspace=n;savePrefs();updateWsBtn();toast('Workspace "'+n+'" saved');});
}
function deleteWorkspace(n){if(userWs()[n]){delete userWs()[n];savePrefs();if(curWs===n){applyWorkspace('Essentials');}else updateWsBtn();}}
function wsMenuItems(){
  const it=Object.keys(WORKSPACES).map(n=>({label:(curWs===n?'✓ ':'    ')+n,fn:()=>applyWorkspace(n)}));
  const u=Object.keys(userWs());if(u.length){it.push({sep:true});u.forEach(n=>it.push({label:(curWs===n?'✓ ':'    ')+n,fn:()=>applyWorkspace(n)}));}
  it.push({sep:true},{label:'    New Workspace...',fn:saveWorkspaceAs});
  u.forEach(n=>it.push({label:'    Delete "'+n+'"',fn:()=>deleteWorkspace(n)}));
  it.push({label:'    Reset '+curWs,fn:()=>applyWorkspace(WORKSPACES[curWs]?curWs:'Essentials')});
  return it;
}
{
  const undo=document.getElementById('undo'),b=document.createElement('button');b.className='wsbtn';b.id='wsbtn';b.title='Switch workspace';b.setAttribute('aria-label','Workspace');
  undo.parentNode.insertBefore(b,document.getElementById('fsbtn'));
  b.addEventListener('click',e=>{const r=b.getBoundingClientRect();showCtx(Math.max(8,r.right-200),r.bottom+4,wsMenuItems());});
  window.updateWsBtn=()=>{b.innerHTML='<span>'+esc(curWs)+'</span> &#9662;';};updateWsBtn();
  ACT.workspace=n=>applyWorkspace(n);
  const W=MENUS.find(m=>m.label==='Window');
  if(W){const subItems=()=>Object.keys(WORKSPACES).map(n=>al(n,'',()=>applyWorkspace(n),{check:()=>curWs===n}));
    const s=sub('Workspace',subItems().concat([SEP,al('New Workspace...','',()=>saveWorkspaceAs()),al('Reset current workspace','',()=>applyWorkspace(WORKSPACES[curWs]?curWs:'Essentials'))]),{dis:()=>false});
    const i=W.items.findIndex(x=>x.label&&x.label.startsWith('Reset workspace'));if(i>=0)W.items.splice(i,1,s);else W.items.unshift(s);}
  ACT.resetWorkspace=()=>applyWorkspace('Essentials');
  if(curWs!=='Essentials'&&(WORKSPACES[curWs]||userWs()[curWs]))setTimeout(()=>applyWorkspace(curWs,true),50);
}
