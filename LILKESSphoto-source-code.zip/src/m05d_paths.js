/* ===== tool registry, paths and the Pen tools ===== */
const TOOLS={};
const BRUSHY={brush:'brush',pencil:'brush',colrep:'brush',mixer:'brush',pstamp:'brush',histbrush:'brush',arthist:'brush',eraser:'eraser',bgerase:'eraser',retouch:'retouch',remove:'aux',spot:'aux',heal:'aux',quicksel:'aux'};
S.aux={size:40};
const brushLike=t=>!!BRUSHY[t];
function brushObj(t){const k=BRUSHY[t];return k==='eraser'?S.eraser:k==='retouch'?S.retouch:k==='aux'?S.aux:S.brush;}
const brushSizeOf=t=>brushObj(t).size;
function toolSwitch(a,b){
  if(a===b)return;
  const T=TOOLS[a];if(T&&T.leave)T.leave();
  S.pen.sub=null;S.pen.sel=null;
}
const pdist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);

/* a small text prompt that also works inside Electron (which has no window.prompt) */
function askText(title,label,def,cb,multi){
  const field=multi?'<textarea id="at" rows="4" style="width:100%">'+esc(def||'')+'</textarea>':'<input type="text" id="at" style="width:100%" value="'+esc(def||'')+'">';
  modalOpen(title,'<div class="row" style="display:block"><label>'+esc(label)+'</label><div style="margin-top:6px">'+field+'</div></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{cb($('#at').value);}}],()=>{$('#at').focus();$('#at').select();});
}

/* ===== path data: doc.paths=[{name,path}], doc.ap = active path index ===== */
S.pen={mode:'path',sub:null,sel:null,hv:null,fill:'#f2b134'};
const paths=()=>doc.paths||(doc.paths=[]);
function curPath(create){
  const P=paths();
  if(doc.ap>=0&&P[doc.ap])return P[doc.ap];
  if(!create)return null;
  P.push({name:'Work Path',path:{subs:[]}});doc.ap=P.length-1;return P[doc.ap];
}
function penCur(ph){const s=S.pen.sub;return s&&ph&&ph.path.subs.includes(s)&&!s.closed?s:null;}

/* shapes made from paths keep their outline normalised to 0..1 of their box */
const NORM_CACHE={};
function shapeNorm(p){
  if(p.np)return p.np;
  const id=p.cid||(p.kind==='custom'?'heart':null);
  if(id){if(!NORM_CACHE[id])NORM_CACHE[id]=vec_transform(vec_shape(id),[0.01,0,0,0.01,0,0]);return NORM_CACHE[id];}
  return null;
}
const shapeEditable=l=>!!(l&&l.type==='shape'&&l.props&&(l.props.kind==='path'||l.props.kind==='custom'));
function shapeDims(p){return {pad:Math.ceil(p.sw/2)+3,w:Math.max(2,Math.round(p.w)),h:Math.max(2,Math.round(p.h))};}
function layerToDocM(l){
  const hw=l.canvas.width/2,hh=l.canvas.height/2,c=Math.cos(l.r),s=Math.sin(l.r),k=l.s;
  return [k*c,k*s,-k*s,k*c,l.x-hw*k*c+hh*k*s,l.y-hw*k*s-hh*k*c];
}
function shapeToDocPath(l){
  const p=l.props,d=shapeDims(p),np=shapeNorm(p);
  return vec_transform(vec_transform(np,[d.w,0,0,d.h,d.pad,d.pad]),layerToDocM(l));
}
function docPathToShape(l,path){
  const p=l.props,d=shapeDims(p),loc=vec_transform(path,docToLocalM(l));
  p.np=vec_transform(loc,[1/d.w,0,0,1/d.h,-d.pad/d.w,-d.pad/d.h]);
  renderShape(l);
}
function editTarget(){
  const l=active();
  if(shapeEditable(l)&&!S.pen.usePath)return {kind:'layer',l,get:()=>shapeToDocPath(l),set:p=>docPathToShape(l,p)};
  const ph=curPath(false);
  if(ph)return {kind:'path',get:()=>ph.path,set:p=>{ph.path=p;}};
  return null;
}

/* shape layer from a doc-space path */
function pathToShapeLayer(path,o){
  o=o||{};
  const b=vec_bounds(path),w=Math.max(2,b.x1-b.x0),h=Math.max(2,b.y1-b.y0),cx=(b.x0+b.x1)/2,cy=(b.y0+b.y1)/2;
  const np=vec_transform(path,[1/w,0,0,1/h,-b.x0/w,-b.y0/h]);
  const l=addLayer({name:o.name||'Shape',type:'shape',w:10,h:10,x:cx,y:cy,above:true,
    props:{kind:'path',np,fill:o.fill||S.shape.fill,stroke:o.stroke||S.shape.stroke,sw:o.sw||0,radius:0,w,h,flip:false,nofill:false,sides:6,cid:null}});
  renderShape(l);return l;
}

/* ===== drawing the paths on the overlay ===== */
function drawPathOver(o,z,path,opt){
  opt=opt||{};
  o.save();o.lineJoin='round';
  o.beginPath();vec_trace(o,path);
  o.strokeStyle='rgba(0,0,0,.55)';o.lineWidth=3.2/z;o.stroke();
  o.strokeStyle=opt.color||'#19c2d8';o.lineWidth=1.4/z;o.stroke();
  if(opt.anchors!==false){
    const hs=7/z,sel=opt.sel;
    path.subs.forEach((s,si)=>s.pts.forEach((q,j)=>{
      const isSel=sel&&sel.sub===si&&sel.pt===j;
      const showH=opt.handles==='all'||(opt.handles==='sel'&&isSel)||(opt.handles==='last'&&si===path.subs.length-1&&j===s.pts.length-1&&!s.closed);
      if(showH&&vec_hasH(q)){
        o.strokeStyle='#19c2d8';o.lineWidth=1/z;o.beginPath();
        o.moveTo(q.ix,q.iy);o.lineTo(q.x,q.y);o.lineTo(q.ox,q.oy);o.stroke();o.fillStyle='#fff';
        [[q.ix,q.iy],[q.ox,q.oy]].forEach(h=>{if(h[0]!==q.x||h[1]!==q.y){o.beginPath();o.arc(h[0],h[1],3.6/z,0,7);o.fill();o.stroke();}});
      }
      o.fillStyle=isSel?'#19c2d8':'#fff';o.strokeStyle='#0a5560';o.lineWidth=1.2/z;
      o.fillRect(q.x-hs/2,q.y-hs/2,hs,hs);o.strokeRect(q.x-hs/2,q.y-hs/2,hs,hs);
    }));
  }
  o.restore();
}
const PEN_TOOLS=['pen','freeform','curv','addpt','delpt','cvpt','psel','dsel'];
function drawToolOver(o,z){
  if(!doc)return;
  const T=TOOLS[S.tool];
  if(PEN_TOOLS.includes(S.tool)){
    const tg=editTarget();
    if(tg&&(tg.kind==='layer'||S.tool!=='psel'||true)){
      const path=tg.get();
      drawPathOver(o,z,path,{sel:S.pen.sel,handles:S.tool==='dsel'||S.tool==='cvpt'||S.tool==='addpt'||S.tool==='delpt'?'all':'last'});
      /* rubber band from the last point to the cursor */
      const ph=curPath(false),cs=(S.tool==='pen'||S.tool==='curv')&&penCur(ph);
      if(cs&&S.pen.hv&&cs.pts.length){
        const a=cs.pts[cs.pts.length-1],h=S.pen.hv;o.save();o.strokeStyle='#19c2d8';o.lineWidth=1.2/z;o.setLineDash([5/z,4/z]);o.beginPath();o.moveTo(a.x,a.y);
        if(S.tool==='pen'&&(a.ox!==a.x||a.oy!==a.y))o.bezierCurveTo(a.ox,a.oy,h.x,h.y,h.x,h.y);else o.lineTo(h.x,h.y);o.stroke();o.restore();
      }
    }
    if(drag&&drag.tool==='freeform'&&drag.pts){o.save();o.strokeStyle='#19c2d8';o.lineWidth=1.5/z;o.beginPath();drag.pts.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));o.stroke();o.restore();}
  }
  if(S.qm)drawQuickMask(o);
  if(T&&T.over)T.over(o,z);
  drawDocMarks(o,z);
}

/* ===== the Pen tool ===== */
function penFinish(shapeOk){
  const ph=curPath(false),s=penCur(ph);
  S.pen.sub=null;
  if(S.pen.mode==='shape'&&shapeOk!==false&&ph&&s&&s.pts.length>=2){
    const i=ph.path.subs.indexOf(s);ph.path.subs.splice(i,1);
    pathToShapeLayer({subs:[s]},{name:'Shape',fill:S.pen.fill});pend=false;commit('Pen shape');renderProps();
  }else if(s&&s.pts.length<2){const i=ph.path.subs.indexOf(s);ph.path.subs.splice(i,1);}
  redraw();
}
function penOpts(extra){
  return '<label class="opt">Mode '+sel('o-pmode',[['path','Path'],['shape','Shape']],S.pen.mode)+'</label>'+(S.pen.mode==='shape'?'<label class="opt">Fill <input type="color" id="o-pfill" value="'+S.pen.fill+'"></label>':'')
    +'<button data-act="pathSel" title="Turn the path into a selection">Make selection</button><button data-act="pathCut" title="Keep only what is inside the path">Cut out</button><button data-act="pathShape">To shape</button>'+(extra||'')
    +'<span class="opt muted">Click for corners, drag for curves. Click the first point to close. Enter ends the path.</span>';
}
$('#opts').addEventListener('input',e=>{
  const t=e.target;
  if(t.id==='o-pmode'){S.pen.mode=t.value;renderOpts();}
  else if(t.id==='o-pfill')S.pen.fill=t.value;
  else if(t.id==='o-asize')S.aux.size=+t.value;
});
const penKey=(combo)=>{
  if(combo==='Enter'||combo==='Escape'){if(penCur(curPath(false))){penFinish();return true;}return false;}
  if(combo==='Backspace'||combo==='Delete'){
    const ph=curPath(false),s=penCur(ph);
    if(s){s.pts.pop();if(!s.pts.length){ph.path.subs.splice(ph.path.subs.indexOf(s),1);S.pen.sub=null;}pend=true;redraw();return true;}
    if(PEN_TOOLS.includes(S.tool)&&S.pen.sel&&S.tool==='dsel'){return deleteSelPoint();}
  }
  return false;
};
TOOLS.pen={
  opts:()=>penOpts(),
  down(p,e){
    const ph=curPath(true),tol=10/S.zoom,cur=penCur(ph);
    if(cur&&cur.pts.length>2&&pdist(p,cur.pts[0])<tol){cur.closed=true;S.pen.sub=null;pend=true;
      if(S.pen.mode==='shape'){const i=ph.path.subs.indexOf(cur);ph.path.subs.splice(i,1);pathToShapeLayer({subs:[cur]},{name:'Shape',fill:S.pen.fill});pend=false;commit('Pen shape');renderProps();}
      redraw();return;}
    if(!cur)for(const s of ph.path.subs){if(!s.closed&&s.pts.length&&pdist(p,s.pts[s.pts.length-1])<tol){S.pen.sub=s;redraw();return;}}
    let sub=cur;
    if(!sub){sub={closed:false,pts:[]};ph.path.subs.push(sub);S.pen.sub=sub;}
    const q=vec_pt(p.x,p.y);sub.pts.push(q);
    drag={k:'x',tool:'pen',q,p0:p,moved:false};pend=true;redraw();
  },
  move(p){const d=drag,q=d.q;if(!d.moved&&pdist(p,d.p0)*S.zoom<4)return;d.moved=true;q.ox=p.x;q.oy=p.y;q.ix=2*q.x-p.x;q.iy=2*q.y-p.y;redraw();},
  up(){redraw();},
  hover(p){S.pen.hv=p;},
  dbl(){penFinish();},
  key:penKey,
  leave(){penFinish(false);}
};

/* Freeform pen: draw freehand, the line is smoothed into a path */
TOOLS.freeform={
  opts:()=>penOpts().replace(/<span class="opt muted">.*<\/span>$/,'<span class="opt muted">Draw freehand. Finish near the start to close the shape.</span>'),
  down(p){drag={k:'x',tool:'freeform',pts:[p]};},
  move(p){drag.pts.push(p);redraw();},
  up(d,p){
    const pts=d.pts;if(pts.length<3){redraw();return;}
    const ph=curPath(true),closed=pdist(pts[0],pts[pts.length-1])<18/S.zoom;
    const sub=vec_fromPolyline(pts,closed,Math.max(1.2,2.2/S.zoom));
    if(sub.pts.length<2){redraw();return;}
    if(S.pen.mode==='shape'){pathToShapeLayer({subs:[sub]},{name:'Shape',fill:S.pen.fill});commit('Freeform shape');renderProps();return;}
    ph.path.subs.push(sub);commit('Freeform pen');redraw();
  },
  key:penKey
};

/* Curvature pen: click to place points, the curve smooths itself. Double-click a point to switch it between smooth and corner */
function curvSmooth(sub){
  vec_autoSmooth(sub,0.55);
  sub.pts.forEach(q=>{if(q.corner){q.ix=q.x;q.iy=q.y;q.ox=q.x;q.oy=q.y;}});
}
TOOLS.curv={
  opts:()=>penOpts().replace(/<span class="opt muted">.*<\/span>$/,'<span class="opt muted">Click to add points. Drag a point to move it. Double-click a point for a corner.</span>'),
  down(p){
    const ph=curPath(true),tol=10/S.zoom,cur=penCur(ph);
    for(const s of ph.path.subs){
      const j=s.pts.findIndex(q=>pdist(p,q)<tol);
      if(j>=0){
        if(cur&&s===cur&&j===0&&s.pts.length>2){s.closed=true;S.pen.sub=null;curvSmooth(s);pend=true;redraw();return;}
        if(!cur&&!s.closed&&j===s.pts.length-1){S.pen.sub=s;redraw();return;}
        drag={k:'x',tool:'curv',s,j,p0:p,last:p,moved:false};return;
      }
    }
    let sub=cur;if(!sub){sub={closed:false,pts:[]};ph.path.subs.push(sub);S.pen.sub=sub;}
    sub.pts.push(vec_pt(p.x,p.y));curvSmooth(sub);pend=true;redraw();
  },
  move(p){const d=drag;if(!d.moved&&pdist(p,d.p0)*S.zoom<4)return;d.moved=true;vec_moveAnchor(d.s,d.j,p.x-d.last.x,p.y-d.last.y);d.last=p;curvSmooth(d.s);redraw();},
  up(d){if(d.moved){pend=true;}redraw();},
  hover(p){S.pen.hv=p;},
  dbl(p){
    const ph=curPath(false);if(!ph)return;
    for(const s of ph.path.subs){const j=s.pts.findIndex(q=>pdist(p,q)<12/S.zoom);if(j>=0){s.pts[j].corner=!s.pts[j].corner;curvSmooth(s);pend=true;redraw();return;}}
    penFinish();
  },
  key:penKey,leave(){penFinish(false);}
};

/* Add / Delete / Convert anchor points */
const tolsOf=()=>[10/S.zoom,8/S.zoom,7/S.zoom];
TOOLS.addpt={
  opts:()=>'<span class="opt muted">Click on a path line to add a point.</span>',
  down(p){
    const T=editTarget();if(!T){toast('Draw a path first');return;}
    const path=T.get(),[a,h,s]=tolsOf(),hit=vec_hitTest(path,p.x,p.y,a,h,s);
    if(hit&&hit.type==='segment'){vec_insertPointAt(path.subs[hit.sub],hit.pt,hit.t);T.set(path);S.pen.sel={sub:hit.sub,pt:hit.pt+1};commit('Add anchor point');redraw();}
  }
};
function deleteSelPoint(){
  const T=editTarget(),sl=S.pen.sel;if(!T||!sl)return false;
  const path=T.get(),s=path.subs[sl.sub];if(!s)return false;
  const tooFew=vec_deletePoint(s,sl.pt);
  if(tooFew||!s.pts.length)path.subs.splice(sl.sub,1);
  T.set(path);S.pen.sel=null;commit('Delete anchor point');redraw();return true;
}
TOOLS.delpt={
  opts:()=>'<span class="opt muted">Click a point to delete it.</span>',
  down(p){
    const T=editTarget();if(!T){toast('Draw a path first');return;}
    const path=T.get(),[a,h,s]=tolsOf(),hit=vec_hitTest(path,p.x,p.y,a,h,s);
    if(hit&&hit.type==='anchor'){S.pen.sel={sub:hit.sub,pt:hit.pt};deleteSelPoint();}
  }
};
TOOLS.cvpt={
  opts:()=>'<span class="opt muted">Click a point to switch smooth and corner. Drag from a point to pull out curve handles.</span>',
  down(p,e){
    const T=editTarget();if(!T){toast('Draw a path first');return;}
    const path=T.get(),[a,h,s]=tolsOf(),hit=vec_hitTest(path,p.x,p.y,a,h,s);
    if(!hit)return;
    if(hit.type==='anchor')drag={k:'x',tool:'cvpt',T,path,sub:path.subs[hit.sub],j:hit.pt,p0:p,moved:false};
    else if(hit.type==='in'||hit.type==='out')drag={k:'x',tool:'cvpt',T,path,sub:path.subs[hit.sub],j:hit.pt,which:hit.type,p0:p,moved:true,brk:true};
  },
  move(p){
    const d=drag;if(!d.moved&&pdist(p,d.p0)*S.zoom<4)return;d.moved=true;
    if(d.which)vec_moveHandle(d.sub,d.j,d.which,p.x,p.y,true);
    else{const q=d.sub.pts[d.j];q.ox=p.x;q.oy=p.y;q.ix=2*q.x-p.x;q.iy=2*q.y-p.y;}
    d.T.set(d.path);redraw();
  },
  up(d){
    if(!d.moved)vec_convertPoint(d.sub,d.j);
    d.T.set(d.path);commit('Convert point');redraw();
  }
};

/* Direct Selection: move points, handles and segments (also edits custom shape layers) */
TOOLS.dsel={
  opts:()=>'<span class="opt muted">Drag a point, a handle or a line. Hold Alt on a handle to break it. Delete removes the selected point.</span><button data-act="pathSel">Make selection</button>',
  down(p){
    const T=editTarget();if(!T){toast('Draw a path with the Pen tool, or select a shape layer first');return;}
    const path=T.get(),[a,h,s]=tolsOf(),hit=vec_hitTest(path,p.x,p.y,a,h,s);
    if(!hit||hit.type==='fill'){S.pen.sel=null;redraw();return;}
    S.pen.sel={sub:hit.sub,pt:hit.pt};
    drag={k:'x',tool:'dsel',T,path,h:hit,sub:path.subs[hit.sub],last:p,moved:false};redraw();
  },
  move(p,e){
    const d=drag,dx=p.x-d.last.x,dy=p.y-d.last.y,n=d.sub.pts.length;d.moved=true;
    if(d.h.type==='anchor')vec_moveAnchor(d.sub,d.h.pt,dx,dy);
    else if(d.h.type==='in'||d.h.type==='out')vec_moveHandle(d.sub,d.h.pt,d.h.type,p.x,p.y,!!(e&&e.altKey));
    else if(d.h.type==='segment'){vec_moveAnchor(d.sub,d.h.pt,dx,dy);vec_moveAnchor(d.sub,(d.h.pt+1)%n,dx,dy);}
    d.last=p;d.T.set(d.path);redraw();
  },
  up(d){if(d.moved){commit(d.T.kind==='layer'?'Edit shape points':'Edit path');renderProps();}redraw();},
  key:(c)=>{if(c==='Delete'||c==='Backspace')return deleteSelPoint();return false;}
};
/* Path Selection: move a whole sub-path */
TOOLS.psel={
  opts:()=>'<span class="opt muted">Drag a path to move it.</span><button data-act="pathSel">Make selection</button>',
  down(p){
    const ph=curPath(false);if(!ph){toast('Draw a path with the Pen tool first');return;}
    const [a,h,s]=tolsOf();let si=-1;
    const hit=vec_hitTest(ph.path,p.x,p.y,a,h,s);
    if(hit&&hit.sub!=null)si=hit.sub;
    else si=ph.path.subs.findIndex(sb=>vec_pointInPath({subs:[sb]},p.x,p.y,'evenodd'));
    if(si<0){S.pen.sel=null;redraw();return;}
    S.pen.sel={sub:si,pt:-1};drag={k:'x',tool:'psel',ph,si,last:p,moved:false};redraw();
  },
  move(p){const d=drag,s=d.ph.path.subs[d.si];d.moved=true;const dx=p.x-d.last.x,dy=p.y-d.last.y;s.pts.forEach((q,j)=>vec_moveAnchor(s,j,dx,dy));d.last=p;redraw();},
  up(d){if(d.moved)commit('Move path');redraw();}
};

/* ===== path commands ===== */
const needPath=()=>{const ph=curPath(false);if(!ph||!ph.path.subs.some(s=>s.pts.length>1)){toast('Draw a path with the Pen tool first');return null;}return ph;};
function pathAsSelection(mode){
  const ph=needPath();if(!ph)return false;
  selFromPathFn(c=>{c.beginPath();vec_trace(c,ph.path);c.fill('evenodd');},mode||'new');return true;
}
ACT.pathSel=D(()=>{if(pathAsSelection(S.selMode))toast('Selection made from the path');});
ACT.pathFill=D(()=>{
  const ph=needPath();if(!ph)return;
  let l=active();if(!l||l.locked||l.smart||l.type==='adjust'||l.type==='text'||l.type==='shape')l=addLayer({name:'Path fill',above:true});
  withLocal(l,ctx=>{ctx.fillStyle=S.fg;ctx.beginPath();vec_trace(ctx,ph.path);ctx.fill('evenodd');});commit('Fill path');
});
ACT.pathStroke=D(()=>{
  const ph=needPath();if(!ph)return;
  let l=active();if(!l||l.locked||l.smart||l.type==='adjust'||l.type==='text'||l.type==='shape')l=addLayer({name:'Path stroke',above:true});
  withLocal(l,ctx=>{ctx.strokeStyle=S.fg;ctx.lineWidth=Math.max(1,S.brush.size/4);ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();vec_trace(ctx,ph.path);ctx.stroke();});commit('Stroke path');
});
ACT.pathMask=D(()=>{
  const ph=needPath();if(!ph)return;
  const l=active();if(!l||l.locked){toast('Select a layer first');return;}
  const n=mkCanvas(l.canvas.width,l.canvas.height),x=cctx(n);
  x.setTransform.apply(x,docToLocalM(l));x.fillStyle='#fff';x.beginPath();vec_trace(x,ph.path);x.fill('evenodd');
  if(l.mask){const y=cctx(n);y.setTransform(1,0,0,1,0,0);y.globalCompositeOperation='destination-in';y.drawImage(l.mask,0,0);}
  l.mask=n;l.editMask=false;l.mver++;touch(l);commit('Vector mask');refreshLayers();toast('Layer mask made from the path');
});
ACT.pathCut=D(()=>{
  const l=active();if(!l||!isPixelLayer(l)){toast('Select the photo layer first');return;}
  if(!needPath())return;
  ensureRaster(l);ACT.pathMask();toast('Background removed. The path became a layer mask, so you can still change it.');
});
ACT.pathCutInside=D(()=>{
  const l=active();if(!l||!isPixelLayer(l)){toast('Select the photo layer first');return;}
  const ph=needPath();if(!ph)return;
  ensureRaster(l);
  const n=mkCanvas(l.canvas.width,l.canvas.height),x=cctx(n);
  x.fillStyle='#fff';x.fillRect(0,0,n.width,n.height);
  x.setTransform.apply(x,docToLocalM(l));x.globalCompositeOperation='destination-out';x.beginPath();vec_trace(x,ph.path);x.fill('evenodd');
  l.mask=n;l.editMask=false;l.mver++;touch(l);commit('Remove inside path');refreshLayers();
});
ACT.pathShape=D(()=>{
  const ph=needPath();if(!ph)return;
  const l=pathToShapeLayer(ph.path,{name:ph.name==='Work Path'?'Shape':ph.name,fill:S.pen.fill});commit('Shape from path');renderProps();setTool('dsel');
  toast('Shape created. Use the Direct Selection tool to reshape it.');
});
ACT.pathNew=D(()=>{const P=paths();P.push({name:'Path '+(P.length+1),path:{subs:[]}});doc.ap=P.length-1;S.pen.sub=null;commit('New path');renderPathsPanel();redraw();});
ACT.pathDup=D(()=>{const ph=curPath(false);if(!ph)return;paths().push({name:ph.name+' copy',path:clone(ph.path)});doc.ap=paths().length-1;commit('Duplicate path');renderPathsPanel();redraw();});
ACT.pathDel=D(()=>{const P=paths();if(!P[doc.ap])return;P.splice(doc.ap,1);doc.ap=P.length?Math.min(doc.ap,P.length-1):-1;S.pen.sub=null;commit('Delete path');renderPathsPanel();redraw();});
ACT.selToPath=D(()=>{
  if(!S.sel){toast('Make a selection first');return;}
  const p=vec_traceAlpha(S.sel.c,{tol:1});
  if(!p.subs.length){toast('Could not make a path from that selection');return;}
  paths().push({name:'Work Path',path:p});doc.ap=paths().length-1;commit('Make work path');renderPathsPanel();toast('Selection turned into a path');redraw();
});
function renderPathsPanel(){
  const box=$('#tab-paths');if(!box)return;
  if(!doc){box.innerHTML='<p class="muted">No document open.</p>';return;}
  const P=paths();
  box.innerHTML='<div class="plist">'+(P.length?P.map((q,i)=>'<button class="prow'+(i===doc.ap?' on':'')+'" data-i="'+i+'"><span class="pth">'+pathThumb(q.path)+'</span><span>'+esc(q.name)+'</span></button>').join(''):'<p class="muted" style="padding:10px">No paths yet. Pick the Pen tool and click on the picture to start one.</p>')+'</div>'
    +'<div class="pbtns"><button data-act="pathFill">Fill</button><button data-act="pathStroke">Stroke</button><button data-act="pathSel">Selection</button><button data-act="pathMask">Mask</button><button data-act="pathShape">Shape</button><button data-act="selToPath">From selection</button><button data-act="pathNew">New</button><button data-act="pathDup">Duplicate</button><button data-act="pathDel">Delete</button></div>'
    +'<div class="pbtns"><button class="primary" data-act="pathCut">Remove background using this path</button></div>';
}
function pathThumb(path){
  if(!path.subs.length)return '';
  const b=vec_bounds(path),w=Math.max(1,b.x1-b.x0),h=Math.max(1,b.y1-b.y0),k=Math.min(26/w,26/h);
  const c=mkCanvas(30,30),x=cctx(c);x.translate(2+(26-w*k)/2,2+(26-h*k)/2);x.scale(k,k);x.translate(-b.x0,-b.y0);
  x.beginPath();vec_trace(x,path);x.lineWidth=1.5/k;x.strokeStyle='#bbb';x.stroke();
  return '<img width="30" height="30" src="'+c.toDataURL()+'" alt="">';
}
document.addEventListener('click',e=>{
  const r=e.target.closest('#tab-paths .prow');if(!r||!doc)return;
  doc.ap=+r.dataset.i;S.pen.sub=null;renderPathsPanel();redraw();
});
document.addEventListener('dblclick',e=>{
  const r=e.target.closest('#tab-paths .prow');if(!r||!doc)return;
  const q=paths()[+r.dataset.i];if(!q)return;
  askText('Rename path','Path name',q.name,v=>{q.name=v.trim()||q.name;commit('Rename path');renderPathsPanel();});
});

/* ===== text to shape (whole text, or one shape per letter) ===== */
function cleanTextRender(l,K){
  const p=clone(l.props);p.size*=K;p.sw=0;p.shadow=0;
  const tl={props:p,canvas:mkCanvas(4,4),ver:0,mask:null};renderText(tl);return tl;
}
function textDocM(l,K,tl){
  const fake={x:l.x,y:l.y,s:l.s,r:l.r,canvas:{width:tl.canvas.width/K,height:tl.canvas.height/K}};
  const A=layerToDocM(fake);
  /* trace coordinates are in 1/K scaled pixels */
  return [A[0]/K,A[1]/K,A[2]/K,A[3]/K,A[4],A[5]];
}
function textShapeCommon(l,per){
  const K=2,tl=cleanTextRender(l,K),M=textDocM(l,K,tl),col=l.props.color,idx=doc.layers.indexOf(l);
  const made=[];doc.active=l.id;
  const mk=(path,name)=>{
    const sl=pathToShapeLayer(vec_transform(path,M),{name,fill:col,stroke:l.props.stroke,sw:0});
    sl.fx=clone(l.fx);sl.opacity=l.opacity;sl.blend=l.blend;sl.fillOp=l.fillOp;
    made.push(sl);
  };
  if(!per){
    const pth=vec_traceAlpha(tl.canvas,{tol:1.4});
    if(!pth.subs.length){toast('Nothing to convert');return;}
    mk(pth,l.name.slice(0,24));
  }else{
    const gs=vec_traceAlphaGroups(tl.canvas,{tol:1.4});
    if(!gs.length){toast('Nothing to convert');return;}
    const p=tl.props,lh=p.size*p.lh,pad=Math.ceil(p.size*0.12+4);
    gs.forEach(g=>{g.line=Math.max(0,Math.floor((g.bbox.y+g.bbox.h/2-pad)/lh));});
    gs.sort((a,b)=>a.line-b.line||a.bbox.x-b.bbox.x);
    const chars=Array.from((p.caps?p.text.toUpperCase():p.text).replace(/\s/g,''));
    gs.forEach((g,i)=>mk(g.path,gs.length===chars.length?'Letter '+chars[i]:'Letter '+(i+1)));
  }
  const at=doc.layers.indexOf(l);doc.layers.splice(at,1);
  /* keep the new layers where the text was */
  made.forEach(m=>{const i=doc.layers.indexOf(m);doc.layers.splice(i,1);});
  doc.layers.splice(Math.min(idx,doc.layers.length),0,...made);
  doc.active=made[made.length-1].id;
  commit(per?'Text to letter shapes':'Convert text to shape');refreshLayers();renderProps();
  toast(per?made.length+' letter shapes made. Move, recolour or reshape each one with the Direct Selection tool.':'Text converted to a shape. Use the Direct Selection tool to edit its points.');
}
ACT.textToShape=D(()=>{const l=active();if(!l||l.type!=='text'){toast('Select a text layer first');return;}textShapeCommon(l,false);});
ACT.textToLetters=D(()=>{const l=active();if(!l||l.type!=='text'){toast('Select a text layer first');return;}textShapeCommon(l,true);});
ACT.textToPath=D(()=>{
  const l=active();if(!l||l.type!=='text'){toast('Select a text layer first');return;}
  const K=2,tl=cleanTextRender(l,K),M=textDocM(l,K,tl),pth=vec_transform(vec_traceAlpha(tl.canvas,{tol:1.4}),M);
  paths().push({name:'Work Path',path:pth});doc.ap=paths().length-1;commit('Create work path');renderPathsPanel();redraw();toast('Work path made from the text');
});
