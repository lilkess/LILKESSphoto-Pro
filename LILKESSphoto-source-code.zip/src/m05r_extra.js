/* ===== Focus Area, Match Color, Variations, Calculations, Indexed Color, CMYK preview ===== */
function rgb2lab(r,g,b){
  const f=v=>{v/=255;return v>0.04045?Math.pow((v+0.055)/1.055,2.4):v/12.92;};
  const R=f(r),G=f(g),B=f(b);
  let x=(R*0.4124+G*0.3576+B*0.1805)/0.95047,y=R*0.2126+G*0.7152+B*0.0722,z=(R*0.0193+G*0.1192+B*0.9505)/1.08883;
  const t=v=>v>0.008856?Math.cbrt(v):7.787*v+16/116;x=t(x);y=t(y);z=t(z);
  return [116*y-16,500*(x-y),200*(y-z)];
}
function lab2rgb(L,a,b){
  const y=(L+16)/116,x=a/500+y,z=y-b/200,i=v=>{const v3=v*v*v;return v3>0.008856?v3:(v-16/116)/7.787;};
  const X=i(x)*0.95047,Y=i(y),Z=i(z)*1.08883;
  let R=X*3.2406+Y*-1.5372+Z*-0.4986,G=X*-0.9689+Y*1.8758+Z*0.0415,B=X*0.0557+Y*-0.2040+Z*1.0570;
  const g=v=>{v=v<=0.0031308?12.92*v:1.055*Math.pow(Math.max(v,0),1/2.4)-0.055;return Math.max(0,Math.min(255,v*255));};
  return [g(R),g(G),g(B)];
}
/* ---------- Indexed Color (median cut palette) ---------- */
function medianCut(d,n){
  const px=[];const step=Math.max(1,Math.floor(d.length/4/60000));
  for(let i=0;i<d.length;i+=4*step){if(d[i+3]>8)px.push([d[i],d[i+1],d[i+2]]);}
  if(!px.length)return [[0,0,0]];
  let boxes=[px];
  while(boxes.length<n){
    let bi=-1,bs=-1,ch=0;
    boxes.forEach((b,i)=>{if(b.length<2)return;for(let c=0;c<3;c++){let mn=255,mx=0;for(const p of b){if(p[c]<mn)mn=p[c];if(p[c]>mx)mx=p[c];}const sc=(mx-mn)*Math.sqrt(b.length);if(sc>bs){bs=sc;bi=i;ch=c;}}});
    if(bi<0)break;
    const b=boxes[bi];b.sort((p,q)=>p[ch]-q[ch]);const m=b.length>>1;boxes.splice(bi,1,b.slice(0,m),b.slice(m));
  }
  return boxes.map(b=>{let r=0,g=0,bl=0;for(const p of b){r+=p[0];g+=p[1];bl+=p[2];}const k=b.length||1;return [r/k,g/k,bl/k];});
}
defFx('indexed','adjust','Indexed Color',[P('n','Colors',2,256,32),P('dt','Dither (1 = on)',0,1,1)],(img,p)=>{
  const d=cp(img),w=img.width,h=img.height,pal=medianCut(d,Math.round(p.n)),cache=new Map();
  const near=(r,g,b)=>{const k=((r>>2)<<12)|((g>>2)<<6)|(b>>2);let v=cache.get(k);if(v!==undefined)return v;let bd=1e9,bi=0;for(let i=0;i<pal.length;i++){const q=pal[i],dr=r-q[0],dg=g-q[1],db=b-q[2],dd=dr*dr*.3+dg*dg*.59+db*db*.11;if(dd<bd){bd=dd;bi=i;}}cache.set(k,bi);return bi;};
  if(p.dt>=0.5){
    const e=new Float32Array(w*h*3);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,k=(y*w+x)*3;if(d[i+3]<8)continue;
      const r=Math.max(0,Math.min(255,d[i]+e[k])),g=Math.max(0,Math.min(255,d[i+1]+e[k+1])),b=Math.max(0,Math.min(255,d[i+2]+e[k+2]));
      const q=pal[near(r|0,g|0,b|0)];d[i]=q[0];d[i+1]=q[1];d[i+2]=q[2];
      const er=r-q[0],eg=g-q[1],eb=b-q[2];
      const sp=(dx,dy,f)=>{const xx=x+dx,yy=y+dy;if(xx<0||xx>=w||yy>=h)return;const kk=(yy*w+xx)*3;e[kk]+=er*f;e[kk+1]+=eg*f;e[kk+2]+=eb*f;};
      sp(1,0,7/16);sp(-1,1,3/16);sp(0,1,5/16);sp(1,1,1/16);
    }
  }else for(let i=0;i<d.length;i+=4){if(d[i+3]<8)continue;const q=pal[near(d[i],d[i+1],d[i+2])];d[i]=q[0];d[i+1]=q[1];d[i+2]=q[2];}
  return mkImg(d,w,h);
});
/* ---------- CMYK preview (soft proof; the file stays RGB) ---------- */
defFx('cmykprev','adjust','CMYK Preview (soft proof)',[P('a','Strength',0,100,100)],(img,p)=>{
  const d=cp(img),k=p.a/100;
  for(let i=0;i<d.length;i+=4){
    let r=d[i],g=d[i+1],b=d[i+2];
    // naive RGB->CMYK with 300% total ink limit and back, then compress the gamut like a press would
    const K=1-Math.max(r,g,b)/255;let c=1-r/255-K,m=1-g/255-K,y=1-b/255-K;
    const den=1-K||1;c/=den;m/=den;y/=den;
    const ink=(c+m+y)*(1-K)+K;const lim=3.0/Math.max(ink,3.0);
    const l=0.299*r+0.587*g+0.114*b,mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx?(mx-mn)/mx:0;
    const kc=1-0.28*sat*sat-0.06*sat;
    let nr=l+(r-l)*kc,ng=l+(g-l)*kc,nb=l+(b-l)*kc;
    nr=nr*0.94+12;ng=ng*0.94+12;nb=nb*0.94+12;
    // cyan and green are the colors presses reproduce worst
    const cy=Math.max(0,(g+b)/2-r)/255;nr+=cy*18;ng-=cy*14;nb-=cy*8;
    d[i]=r+(nr*lim-r)*k;d[i+1]=g+(ng*lim-g)*k;d[i+2]=b+(nb*lim-b)*k;
  }
  return mkImg(d,img.width,img.height);
});
{
  const old=modeLayer;
  modeLayer=()=>doc&&doc.layers.find(l=>l.type==='adjust'&&l.modeTag);
  void old;
}
const modeKind=()=>{const l=modeLayer();return !l?'rgb':l.adj&&l.adj.id==='indexed'?'indexed':l.adj&&l.adj.id==='cmykprev'?'cmyk':'gray';};
function setModeAdj(id,name,note){
  if(!needDoc())return;
  const cur=modeLayer();if(cur){doc.layers.splice(doc.layers.indexOf(cur),1);}
  ACT.adjLayer(id);const l=active();if(l){l.name=name;l.modeTag=true;l.locked=false;
    doc.layers.push(doc.layers.splice(doc.layers.indexOf(l),1)[0]);doc.active=l.id;commit('Mode: '+name);refreshLayers();redraw();toast(note);}
}
ACT.modeIndexed=()=>setModeAdj('indexed','Indexed Color (mode)','Indexed Color: a layer on top reduces the picture to a small palette. Change Colors in Properties. Switch to RGB Color to remove it.');
ACT.modeCMYK=()=>setModeAdj('cmykprev','CMYK preview (mode)','CMYK Color is a preview only: it shows how colors may look in print. The file itself stays RGB.');
{
  const _g=ACT.modeGray;
  ACT.modeGray=()=>{const cur=modeLayer();if(cur&&cur.adj&&cur.adj.id!=='desat'){doc.layers.splice(doc.layers.indexOf(cur),1);}_g();};
}
/* ---------- Focus Area ---------- */
function sharpnessMap(W,H,data,noise){
  const L=new Float32Array(W*H);
  for(let i=0;i<W*H;i++)L[i]=0.299*data[i*4]+0.587*data[i*4+1]+0.114*data[i*4+2];
  // smooth lightly to ignore noise, then a Laplacian magnitude
  const S1=new Uint8ClampedArray(W*H);for(let i=0;i<W*H;i++)S1[i]=L[i];
  if(noise>0)boxBlur(S1,W,H,Math.min(3,Math.ceil(noise)),1);
  const M=new Float32Array(W*H);
  for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){const i=y*W+x;M[i]=Math.abs(4*S1[i]-S1[i-1]-S1[i+1]-S1[i-W]-S1[i+W])+Math.abs(2*S1[i]-S1[i-W-1]-S1[i+W+1])*0.5;}
  return M;
}
ACT.focusArea=()=>{
  if(!needDoc())return;
  const W=doc.w,H=doc.h,data=flatData();let map=null,lastN=-1,sm=null;
  selDialog('Focus Area','<div class="saform"><div class="muted" style="margin-bottom:6px">Selects the parts of the picture that are sharp.</div>'
    +eRng('fa-r','In-Focus Range',1,100,35,1,'')+eRng('fa-n','Image Noise Level',0,5,1,1,'')+eRng('fa-s','Soften edge',0,40,8,1,' px')
    +'<label class="row"><input type="checkbox" id="fa-i"> Invert (select the blurred parts)</label></div>',
    (oa,root)=>{
      const nz=eNum('fa-n'),rng=eNum('fa-r'),soft=eNum('fa-s'),inv=$('#fa-i',root).checked;
      if(!map||lastN!==nz){map=sharpnessMap(W,H,data,nz);lastN=nz;
        // spread the sharpness over the neighbourhood so whole objects, not just edges, are selected
        const b=new Uint8ClampedArray(W*H);let mx=0;for(let i=0;i<b.length;i++)if(map[i]>mx)mx=map[i];
        const k=mx>0?255/Math.min(mx,120):1;for(let i=0;i<b.length;i++)b[i]=Math.min(255,map[i]*k);
        boxBlur(b,W,H,Math.max(4,Math.round(Math.min(W,H)/60)),2);sm=b;}
      const th=(101-rng)*0.9+2,out=new Uint8Array(W*H);
      for(let i=0;i<out.length;i++){let v=clamp((sm[i]-th)/Math.max(2,th*.3)+0.5,0,1);if(inv)v=1-v;out[i]=Math.round(v*255);}
      if(soft>0){const t=new Uint8ClampedArray(out);boxBlur(t,W,H,Math.round(soft/2),1);for(let i=0;i<out.length;i++)out[i]=t[i];}
      if(oa)for(let i=0;i<out.length;i++)out[i]=Math.min(out[i],oa[i]);
      return out;
    });
};
/* ---------- Match Color ---------- */
function labStats(data,step){
  let n=0;const s=[0,0,0],q=[0,0,0];
  for(let i=0;i<data.length;i+=4*step){if(data[i+3]<20)continue;const c=rgb2lab(data[i],data[i+1],data[i+2]);n++;for(let k=0;k<3;k++){s[k]+=c[k];q[k]+=c[k]*c[k];}}
  n=n||1;const mu=s.map(v=>v/n);return {mu,sd:q.map((v,k)=>Math.sqrt(Math.max(1e-6,v/n-mu[k]*mu[k])))};
}
function docCanvasOf(entry){const keep=doc;try{doc=entry.doc;return flatCanvas(1,null);}finally{doc=keep;}}
ACT.matchColor=()=>{
  if(!needDoc())return;const tl=active();if(!tl||tl.type==='adjust'){toast('Select a photo layer first');return;}
  const others=docs.map((e,i)=>({e,i})).filter(o=>o.e.doc!==doc);
  const layers=doc.layers.filter(l=>l!==tl&&l.type!=='adjust');
  if(!others.length&&!layers.length){toast('Open another picture, or add another layer to match to');return;}
  const opts=others.map(o=>'<option value="d'+o.i+'">Picture: '+esc(o.e.doc.name||'untitled')+'</option>').join('')+layers.map(l=>'<option value="l'+l.id+'">Layer: '+esc(l.name)+'</option>').join('');
  let tc=flatLayer(tl),tdata=cctx(tc).getImageData(0,0,doc.w,doc.h).data,tst=labStats(tdata,Math.max(1,Math.round(doc.w*doc.h/80000)));
  const stCache={};
  const srcStats=v=>{if(stCache[v])return stCache[v];let c;
    if(v[0]==='d')c=docCanvasOf(docs[+v.slice(1)]);else c=flatLayer(doc.layers.find(l=>l.id===+v.slice(1)));
    const dd=cctx(c).getImageData(0,0,c.width,c.height).data;return stCache[v]=labStats(dd,Math.max(1,Math.round(c.width*c.height/80000)));};
  function compute(){
    const st=srcStats($('#mc-s').value),lum=eNum('mc-l')/100,ci=eNum('mc-c')/100,fade=eNum('mc-f')/100,neu=$('#mc-n').checked;
    const out=mkCanvas(doc.w,doc.h),ox=cctx(out),id=ox.createImageData(doc.w,doc.h),d=id.data;
    for(let i=0;i<tdata.length;i+=4){
      d[i+3]=tdata[i+3];if(!tdata[i+3])continue;
      const c=rgb2lab(tdata[i],tdata[i+1],tdata[i+2]);
      const L=(c[0]-tst.mu[0])*(st.sd[0]/tst.sd[0])+st.mu[0],
            a=(c[1]-tst.mu[1])*(st.sd[1]/tst.sd[1])+(neu?0:st.mu[1]),
            b=(c[2]-tst.mu[2])*(st.sd[2]/tst.sd[2])+(neu?0:st.mu[2]);
      const L2=c[0]+(L-c[0])*lum,a2=c[1]+(a-c[1])*ci,b2=c[2]+(b-c[2])*ci;
      const r=lab2rgb(L2,a2,b2);
      d[i]=tdata[i]+(r[0]-tdata[i])*(1-fade);d[i+1]=tdata[i+1]+(r[1]-tdata[i+1])*(1-fade);d[i+2]=tdata[i+2]+(r[2]-tdata[i+2])*(1-fade);
    }
    ox.putImageData(id,0,0);return out;
  }
  let prevSnap=null;
  modalOpen('Match Color','<div class="saform"><div class="muted" style="margin-bottom:6px">Gives the selected layer the colors and brightness of another picture or layer.</div>'
    +'<label class="fld erow">Source<select id="mc-s">'+opts+'</select></label>'
    +eRng('mc-l','Luminance',1,200,100,1,'')+eRng('mc-c','Color Intensity',1,200,100,1,'')+eRng('mc-f','Fade',0,100,0,1,'')
    +'<label class="row"><input type="checkbox" id="mc-n"> Neutralize</label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const l=paintTarget('Match color');if(!l)return false;
      paintDoc(l,compute(),{op:1,blend:'source-over',keepAlpha:true});commit('Match Color');
    }}],root=>{eBind(root,()=>{});},{side:true});
};
/* ---------- Variations ---------- */
ACT.variations=()=>{
  if(!needDoc())return;const tl=active();if(!tl||tl.type==='adjust'){toast('Select a photo layer first');return;}
  const full=flatLayer(tl);
  const sk=Math.min(1,130/Math.max(doc.w,doc.h)),small=mkCanvas(Math.max(1,Math.round(doc.w*sk)),Math.max(1,Math.round(doc.h*sk)));
  cctx(small).drawImage(full,0,0,small.width,small.height);
  const sdata=cctx(small).getImageData(0,0,small.width,small.height);
  const st={r:0,g:0,b:0,l:0,s:0,range:'mid'};
  const DIR={Green:[-.5,1,-.5],Yellow:[.5,.5,-1],Red:[1,-.5,-.5],Magenta:[.5,-1,.5],Blue:[-.5,-.5,1],Cyan:[-1,.5,.5]};
  function apply(imgd,s,amt,range){
    const d=new Uint8ClampedArray(imgd.data);
    for(let i=0;i<d.length;i+=4){
      if(!d[i+3])continue;
      const l=(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])/255;
      const w=range==='shadows'?(1-l)*(1-l):range==='high'?l*l:4*l*(1-l)*0.9+0.1;
      let r=d[i]+(s.r)*w,g=d[i+1]+(s.g)*w,b=d[i+2]+(s.b)*w;
      const ll=s.l;r+=ll*w*1.2;g+=ll*w*1.2;b+=ll*w*1.2;
      if(s.s){const lu=0.299*r+0.587*g+0.114*b,k=1+s.s/100;r=lu+(r-lu)*k;g=lu+(g-lu)*k;b=lu+(b-lu)*k;}
      d[i]=r;d[i+1]=g;d[i+2]=b;
    }
    return new ImageData(d,imgd.width,imgd.height);
  }
  const tile=(label,fn,key)=>'<button class="vtile" data-v="'+key+'"><canvas width="'+small.width+'" height="'+small.height+'"></canvas><span>'+label+'</span></button>';
  const names=['Green','Yellow','Red','Magenta','Blue','Cyan'];
  const step=()=>eNum('va-a')*0.6;
  const body='<div class="saform"><div class="muted">Click a picture to push the colors that way. Click as many times as you like.</div>'
    +'<div class="col" style="margin:6px 0"><label class="row"><input type="radio" name="va-r" value="shadows"> Shadows</label><label class="row"><input type="radio" name="va-r" value="mid" checked> Midtones</label><label class="row"><input type="radio" name="va-r" value="high"> Highlights</label></div>'
    +eRng('va-a','Fine ... Coarse',1,100,30,1,'')
    +'<div class="vgrid">'+names.map(n=>tile('More '+n,null,'c:'+n)).join('')+tile('Lighter',null,'l:1')+tile('Current pick',null,'cur')+tile('Darker',null,'l:-1')+tile('Less saturation',null,'s:-1')+tile('More saturation',null,'s:1')+'</div></div>';
  modalOpen('Variations',body,[{label:'Reset',close:false,cb:()=>{Object.assign(st,{r:0,g:0,b:0,l:0,s:0});paint();return false;}},{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
    const l=paintTarget('Variations');if(!l)return false;
    const out=mkCanvas(doc.w,doc.h),ox=cctx(out),idt=cctx(full).getImageData(0,0,doc.w,doc.h);
    ox.putImageData(apply(idt,st,1,st.range),0,0);paintDoc(l,out,{op:1,blend:'source-over',keepAlpha:true});commit('Variations');
  }}],root=>{
    const tiles=[...root.querySelectorAll('.vtile')];
    function trial(key){
      const t=Object.assign({},st),a=step()*1.5;
      if(key[0]==='c'){const v=DIR[key.slice(2)];t.r+=v[0]*a;t.g+=v[1]*a;t.b+=v[2]*a;}
      else if(key[0]==='l')t.l+=(+key.slice(2))*a;
      else if(key[0]==='s')t.s+=(+key.slice(2))*a*2;
      return t;
    }
    function paint(){
      st.range=(root.querySelector('input[name=va-r]:checked')||{}).value||'mid';
      tiles.forEach(b=>{const key=b.dataset.v,t=key==='cur'?st:trial(key);b.querySelector('canvas').getContext('2d').putImageData(apply(sdata,t,1,st.range),0,0);});
    }
    window.__vaPaint=paint;
    root.addEventListener('click',e=>{const b=e.target.closest('.vtile');if(!b||b.dataset.v==='cur')return;Object.assign(st,trial(b.dataset.v));paint();});
    root.addEventListener('input',()=>paint());root.addEventListener('change',()=>paint());
    paint();
  },{wide:true});
  function paint(){if(window.__vaPaint)window.__vaPaint();}
};
/* ---------- Calculations ---------- */
ACT.calculations=()=>{
  if(!needDoc())return;
  const layers=doc.layers.filter(l=>l.type!=='adjust');
  const lOpts='<option value="m">Merged</option>'+layers.map(l=>'<option value="'+l.id+'">'+esc(l.name)+'</option>').join('');
  const cOpts=[['gray','Gray'],['r','Red'],['g','Green'],['b','Blue'],['a','Transparency'],['sat','Saturation']].map(c=>'<option value="'+c[0]+'">'+c[1]+'</option>').join('');
  const mOpts=[['multiply','Multiply'],['screen','Screen'],['overlay','Overlay'],['softlight','Soft Light'],['hardlight','Hard Light'],['add','Add'],['sub','Subtract'],['diff','Difference'],['darken','Darken'],['lighten','Lighter'],['normal','Normal']].map(c=>'<option value="'+c[0]+'">'+c[1]+'</option>').join('');
  const W=doc.w,H=doc.h,cache={};
  const src=(lid)=>{if(cache[lid])return cache[lid];const c=lid==='m'?flatCanvas(1,null):flatLayer(doc.layers.find(l=>l.id===+lid));return cache[lid]=cctx(c).getImageData(0,0,W,H).data;};
  const chan=(d,ch)=>{const o=new Float32Array(W*H);for(let i=0;i<o.length;i++){const r=d[i*4],g=d[i*4+1],b=d[i*4+2],a=d[i*4+3];
    o[i]=ch==='r'?r:ch==='g'?g:ch==='b'?b:ch==='a'?a:ch==='sat'?(Math.max(r,g,b)?(Math.max(r,g,b)-Math.min(r,g,b))/Math.max(r,g,b)*255:0):0.299*r+0.587*g+0.114*b;}return o;};
  const bl=(m,a,b)=>{a/=255;b/=255;let v;
    switch(m){case 'multiply':v=a*b;break;case 'screen':v=1-(1-a)*(1-b);break;case 'overlay':v=a<.5?2*a*b:1-2*(1-a)*(1-b);break;
      case 'softlight':v=b<.5?a-(1-2*b)*a*(1-a):a+(2*b-1)*(Math.sqrt(a)-a);break;case 'hardlight':v=b<.5?2*a*b:1-2*(1-a)*(1-b);break;
      case 'add':v=a+b;break;case 'sub':v=a-b;break;case 'diff':v=Math.abs(a-b);break;case 'darken':v=Math.min(a,b);break;case 'lighten':v=Math.max(a,b);break;default:v=b;}
    return clamp(v,0,1)*255;};
  const row=(n,t)=>'<div class="h" style="margin-top:6px">'+t+'</div><div class="row"><select id="ca-l'+n+'">'+lOpts+'</select><select id="ca-c'+n+'">'+cOpts+'</select><label class="row"><input type="checkbox" id="ca-i'+n+'"> Invert</label></div>';
  const calc=()=>{
    const a=chan(src($('#ca-l1').value),$('#ca-c1').value),b=chan(src($('#ca-l2').value),$('#ca-c2').value),m=$('#ca-m').value,op=eNum('ca-o')/100,i1=$('#ca-i1').checked,i2=$('#ca-i2').checked;
    const out=new Uint8Array(W*H);
    for(let i=0;i<out.length;i++){const x=i1?255-a[i]:a[i],y=i2?255-b[i]:b[i];const r=bl(m,x,y);out[i]=Math.round(x+(r-x)*op);}
    return out;
  };
  const grayCanvas=(a)=>{const c=mkCanvas(W,H),x=cctx(c),id=x.createImageData(W,H),d=id.data;for(let i=0;i<a.length;i++){d[i*4]=d[i*4+1]=d[i*4+2]=a[i];d[i*4+3]=255;}x.putImageData(id,0,0);return c;};
  const orig=S.sel;let done=false;
  modalOpen('Calculations','<div class="saform">'+row(1,'Source 1')+row(2,'Source 2')
    +'<div class="h" style="margin-top:6px">Blending</div><div class="row"><select id="ca-m">'+mOpts+'</select></div>'+eRng('ca-o','Opacity',0,100,100,1,'%')
    +'<div class="h" style="margin-top:6px">Result</div><div class="row"><select id="ca-r"><option value="sel">Selection</option><option value="chan">New Channel</option><option value="layer">New gray layer</option></select></div></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const a=calc(),r=$('#ca-r').value;done=true;modalCancel=null;
      if(r==='sel'){if(orig)S.lastSel=orig;previewSel(a);commit('Calculations');}
      else if(r==='chan'){S.sel=orig;const L=exa('alpha'),c=alphaToCanvas(a),t=mkCanvas(64,Math.max(1,Math.round(64*H/W))),tx=cctx(t);tx.fillStyle='#000';tx.fillRect(0,0,t.width,t.height);tx.drawImage(c,0,0,t.width,t.height);
        L.push({name:'Calculation '+(L.length+1),url:c.toDataURL(),thumb:t.toDataURL()});commit('Calculations');if(PANELS.channels&&PANELS.channels.render)PANELS.channels.render();toast('Saved as a new channel. Use Select > Load Selection to use it.');redraw();}
      else{S.sel=orig;const l=addLayer({name:'Calculation',above:true});cctx(l.canvas).drawImage(grayCanvas(a),0,0);l.ver++;commit('Calculations');refreshLayers();redraw();}
    }}],root=>{
      modalCancel=()=>{if(!done){S.sel=orig;redraw();}};
      const upd=()=>{if($('#ca-r').value==='sel')previewSel(calc());else{S.sel=orig;redraw();}};
      eBind(root,upd);
    },{side:true});
};
/* ---------- menus ---------- */
(function(){
  const chk=(it,fn)=>{it.check=fn;return it;};
  const S_=MENUS.find(m=>m.label==='Select');
  const at=S_.items.findIndex(i=>i.label==='Subject');
  S_.items.splice(at>=0?at:3,0,mi('Focus Area...','','focusArea'));
  const M=MENUS.find(m=>m.label==='Image');
  M.items[0]=sub('Mode',[chk(mi('RGB Color','','modeRGB'),()=>doc&&modeKind()==='rgb'),chk(mi('Grayscale','','modeGray'),()=>!!doc&&modeKind()==='gray'),chk(mi('Indexed Color...','','modeIndexed'),()=>!!doc&&modeKind()==='indexed'),chk(mi('CMYK Color (preview)','','modeCMYK'),()=>!!doc&&modeKind()==='cmyk'),SEP,chk(mi('8 Bits/Channel','',()=>{}),()=>true)]);
  const adj=M.items[1];
  if(adj&&adj.items){const g=Object.getOwnPropertyDescriptor(adj,'items');if(!(g&&g.get)){const k=adj.items.findIndex(i=>i&&i.sep);adj.items.splice(Math.max(0,adj.items.length-1),0,mi('Match Color...','','matchColor'),mi('Variations...','','variations'));}}
  const ai=M.items.findIndex(i=>i&&i.label==='Apply Image...');
  M.items.splice(ai+1,0,mi('Calculations...','','calculations'));
})();
