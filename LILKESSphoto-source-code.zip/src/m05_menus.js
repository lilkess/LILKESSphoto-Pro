
/* ===== modal dialogs ===== */
function modalOpen(title,body,buttons,onMount,opts){
  $('#mtitle').textContent=title;$('#mbody').innerHTML=body;
  const f=$('#mfoot');f.innerHTML='';
  (buttons||[]).forEach(b=>{
    const el=document.createElement('button');el.textContent=b.label;if(b.primary)el.className='primary';if(b.primary)el.dataset.primary='1';
    el.addEventListener('click',()=>{const r=b.cb?b.cb():undefined;if(r!==false&&b.close!==false)closeModal();});f.appendChild(el);
  });
  f.hidden=!(buttons&&buttons.length);
  $('#modal .sheet').classList.toggle('wide',!!(opts&&opts.wide&&!opts.side));$('#modal').classList.toggle('side',!!(opts&&opts.side));
  $('#modal').hidden=false;
  if(onMount)onMount($('#mbody'));
}
function closeModal(){const m=$('#modal');if(m.hidden)return;m.hidden=true;$('#mbody').oninput=null;$('#mbody').onchange=null;$('#mbody').innerHTML='';$('#mfoot').innerHTML='';if(modalCancel){const c=modalCancel;modalCancel=null;c();}}
let modalCancel=null;
$('#modal').addEventListener('pointerdown',e=>{if(e.target.id==='modal')closeModal();});
function askNumber(title,label,def,min,max,cb){
  modalOpen(title,'<div class="row"><label>'+esc(label)+' <input type="number" id="an" value="'+def+'" min="'+min+'" max="'+max+'" style="width:96px"></label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{const v=clamp(+$('#an').value||def,min,max);cb(v);}}],()=>{$('#an').focus();$('#an').select();});
}
function askSaveBeforeClose(i){
  const e=docs[i];if(!e)return;
  modalOpen('Close design','<p>Save changes to <b>'+esc(e.doc.name)+'</b> on this device before closing?</p>',[
    {label:'Cancel'},
    {label:"Don't save",cb:()=>{closeDoc(i,true);}},
    {label:'Save',primary:true,cb:async()=>{if(i!==cur)switchDoc(i);await doSaveProject();closeDoc(docs.findIndex(x=>x.doc===e.doc),true);}}
  ]);
}
function askCloseAll(){
  modalOpen('Close all','<p>Some designs have unsaved changes. Close them all anyway?</p>',[{label:'Cancel'},{label:'Close all',primary:true,cb:()=>{while(docs.length)closeDoc(docs.length-1,true);}}]);
}

/* ===== new design dialog ===== */
const PRESET_GROUPS=[
  ['Social',[['Instagram post',1080,1080],['Instagram portrait',1080,1350],['Story / Status / Reel',1080,1920],['Facebook cover',1640,624],['YouTube thumbnail',1280,720],['X (Twitter) header',1500,500],['LinkedIn banner',1584,396]]],
  ['Print',[['A4 flyer',2480,3508,300],['A5 flyer',1748,2480,300],['A3 poster',3508,4961,300],['Poster 18 x 24 in',2700,3600,150],['US Letter',2550,3300,300],['Business card',1050,600,300],['Passport photo 35 x 45 mm',413,531,300]]],
  ['Photo',[['4 x 6 in landscape',1800,1200,300],['4 x 6 in portrait',1200,1800,300],['5 x 7 in',2100,1500,300],['8 x 10 in',3000,2400,300],['Square 3000',3000,3000,300]]],
  ['Web',[['Full HD 1920 x 1080',1920,1080],['4K 3840 x 2160',3840,2160],['Blog header 1600 x 900',1600,900],['Banner 1200 x 628',1200,628],['Icon 512 x 512',512,512]]],
  ['Mobile',[['Phone 1080 x 2400',1080,2400],['iPhone 1170 x 2532',1170,2532],['App icon 1024',1024,1024],['Phone wallpaper 1440 x 3040',1440,3040]]]
];
const UNITS={px:1,in:1,cm:2.54,mm:25.4};
function openNewDoc(){
  let group=0,w=1080,h=1080,ppi=72,unit='px';
  const body='<div class="newdoc"><div class="nd-left"><div class="nd-tabs" id="nd-tabs">'+PRESET_GROUPS.map((g,i)=>'<button data-g="'+i+'" class="'+(i===0?'on':'')+'">'+g[0]+'</button>').join('')+'</div><div class="nd-tiles" id="nd-tiles"></div></div>'
   +'<div class="nd-right"><div class="h">Preset details</div>'
   +'<label class="fld">Name<input type="text" id="nd-name" value="Untitled-'+(docSeq+1)+'"></label>'
   +'<div class="fld2"><label>Width<input type="number" id="nd-w" min="1" step="any"></label><label>Height<input type="number" id="nd-h" min="1" step="any"></label><label>Unit<select id="nd-u"><option value="px">Pixels</option><option value="in">Inches</option><option value="cm">Centimetres</option><option value="mm">Millimetres</option></select></label></div>'
   +'<div class="row"><span class="muted">Orientation</span><span class="seg"><button id="nd-port" aria-label="Portrait">Portrait</button><button id="nd-land" aria-label="Landscape">Landscape</button></span></div>'
   +'<div class="fld2"><label>Resolution<input type="number" id="nd-ppi" min="1" max="1200" value="72"></label><label>Pixels per inch<input type="text" value="ppi" disabled></label><span></span></div>'
   +'<label class="fld">Background<select id="nd-bg"><option value="#ffffff">White</option><option value="#000000">Black</option><option value="bgcolor">Background colour</option><option value="transparent">Transparent</option><option value="custom">Custom colour</option></select></label>'
   +'<input type="color" id="nd-bgc" value="#f2b134" hidden>'
   +'<p class="muted" id="nd-info"></p><p class="err" id="nd-err" role="alert"></p></div></div>';
  modalOpen('New design',body,[{label:'Cancel'},{label:'Create',primary:true,cb:()=>create()}],root=>{
    const tiles=$('#nd-tiles',root),info=$('#nd-info',root),err=$('#nd-err',root);
    const toUnit=px=>unit==='px'?px:px/ppi*UNITS[unit]/(unit==='in'?1:1)*(unit==='in'?1:1)/(unit==='in'?1:UNITS[unit]/UNITS[unit]);
    function fromPx(px){return unit==='px'?px:(px/ppi)*UNITS[unit];}
    function toPx(v){return unit==='px'?v:v/UNITS[unit]*ppi;}
    void toUnit;
    const fmt=v=>String(Math.round(v*100)/100);
    function show(){
      $('#nd-w',root).value=fmt(fromPx(w));$('#nd-h',root).value=fmt(fromPx(h));
      info.textContent=Math.round(w)+' x '+Math.round(h)+' px  ('+(w*h/1e6).toFixed(1)+' megapixels)';err.textContent='';
      $('#nd-port',root).classList.toggle('on',h>=w);$('#nd-land',root).classList.toggle('on',w>h);
    }
    function drawTiles(){
      tiles.innerHTML=PRESET_GROUPS[group][1].map((p,i)=>'<button class="nd-tile" data-i="'+i+'"><b>'+p[0]+'</b><small>'+p[1]+' x '+p[2]+' px'+(p[3]?' @ '+p[3]+' ppi':'')+'</small></button>').join('');
    }
    $('#nd-tabs',root).addEventListener('click',e=>{const b=e.target.closest('[data-g]');if(!b)return;group=+b.dataset.g;$$('#nd-tabs button',root).forEach(x=>x.classList.toggle('on',x===b));drawTiles();});
    tiles.addEventListener('click',e=>{
      const b=e.target.closest('[data-i]');if(!b)return;const p=PRESET_GROUPS[group][1][+b.dataset.i];
      w=p[1];h=p[2];ppi=p[3]||72;$('#nd-ppi',root).value=ppi;unit='px';$('#nd-u',root).value='px';$('#nd-name',root).value=p[0];
      $$('.nd-tile',root).forEach(x=>x.classList.toggle('on',x===b));show();
    });
    root.addEventListener('input',e=>{
      const id=e.target.id;
      if(id==='nd-w'){w=Math.max(1,toPx(+e.target.value||1));info.textContent=Math.round(w)+' x '+Math.round(h)+' px';}
      else if(id==='nd-h'){h=Math.max(1,toPx(+e.target.value||1));info.textContent=Math.round(w)+' x '+Math.round(h)+' px';}
      else if(id==='nd-ppi'){const old=ppi;ppi=clamp(+e.target.value||72,1,1200);if(unit!=='px'){w=w/old*ppi;h=h/old*ppi;}show();}
      else if(id==='nd-u'){unit=e.target.value;show();}
      else if(id==='nd-bg'){$('#nd-bgc',root).hidden=e.target.value!=='custom';}
    });
    $('#nd-port',root).addEventListener('click',()=>{if(w>h){const t=w;w=h;h=t;show();}});
    $('#nd-land',root).addEventListener('click',()=>{if(h>w){const t=w;w=h;h=t;show();}});
    window.__ndCreate=()=>{
      const W=Math.round(w),H=Math.round(h);
      {const pr=docSizeProblem(W,H,2);if(pr){err.textContent=pr;return false;}}
      let bg=$('#nd-bg',root).value;if(bg==='custom')bg=$('#nd-bgc',root).value;if(bg==='bgcolor')bg=S.bg;
      newBlank($('#nd-name',root).value.trim()||'Untitled',W,H,ppi,bg);setTool('move');return true;
    };
    drawTiles();show();
  },{wide:true});
  function create(){return window.__ndCreate?window.__ndCreate():false;}
}
function newBlank(name,w,h,ppi,bg){
  startDoc(name,w,h,ppi);
  if(bg!=='transparent')addLayer({name:'Background',fill:bg,select:false});
  else addLayer({name:'Layer 1'});
  finishDoc();
}

/* ===== image size, canvas size ===== */
function openImageSize(){
  let w=doc.w,h=doc.h;const ar=doc.w/doc.h;
  modalOpen('Image size','<p class="muted" style="margin-top:0">Current size: '+doc.w+' x '+doc.h+' px</p><div class="fld2"><label>Width (px)<input type="number" id="is-w" min="1" max="12000" value="'+w+'"></label><label>Height (px)<input type="number" id="is-h" min="1" max="12000" value="'+h+'"></label><span></span></div><label class="row"><input type="checkbox" id="is-lock" checked> Keep proportions</label><label class="row">Resample <select id="is-mode"><option value="smooth">Bicubic smoother (best for enlarging)</option><option value="detail">Preserve details (enlarge + sharpen)</option><option value="bilinear">Bilinear</option><option value="nearest">Nearest neighbor (hard edges)</option></select></label><p class="err" id="is-err" role="alert"></p>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const W=Math.round(+$('#is-w').value),H=Math.round(+$('#is-h').value);
      if(!(W>=1&&H>=1&&W<=12000&&H<=12000&&W*H<=90e6)){$('#is-err').textContent='Choose a size up to 12000 pixels per side and 90 megapixels.';return false;}
      if(W===doc.w&&H===doc.h)return true;
      S.resampleMode=$('#is-mode').value;resizeImage(W,H);commit('Image size');S.autoFit=true;fitView();return true;}}],root=>{
      root.addEventListener('input',e=>{
        if(!$('#is-lock').checked)return;
        if(e.target.id==='is-w')$('#is-h').value=Math.max(1,Math.round(+e.target.value/ar));
        if(e.target.id==='is-h')$('#is-w').value=Math.max(1,Math.round(+e.target.value*ar));
      });
    });
}
function openCanvasSize(){
  let anchor=4;
  modalOpen('Canvas size','<p class="muted" style="margin-top:0">Current size: '+doc.w+' x '+doc.h+' px. New area is transparent.</p><div class="fld2"><label>Width (px)<input type="number" id="cs-w" min="1" value="'+doc.w+'"></label><label>Height (px)<input type="number" id="cs-h" min="1" value="'+doc.h+'"></label><span></span></div><div class="h">Anchor</div><div class="anchor" id="cs-a">'+[0,1,2,3,4,5,6,7,8].map(i=>'<button data-i="'+i+'" class="'+(i===4?'on':'')+'" aria-label="Anchor '+i+'"></button>').join('')+'</div><p class="err" id="cs-err" role="alert"></p>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const W=Math.round(+$('#cs-w').value),H=Math.round(+$('#cs-h').value);
      {const pr=docSizeProblem(W,H,doc.layers.length+1);if(pr){$('#cs-err').textContent=pr;return false;}}
      resizeCanvas(W,H,anchor);commit('Canvas size');S.autoFit=true;fitView();return true;}}],root=>{
      $('#cs-a',root).addEventListener('click',e=>{const b=e.target.closest('[data-i]');if(!b)return;anchor=+b.dataset.i;$$('#cs-a button',root).forEach(x=>x.classList.toggle('on',x===b));});
    });
}

/* ===== export ===== */
function openExport(){
  modalOpen('Export as','<div class="row"><label>Format <select id="xf"><option value="png">PNG (sharp, keeps transparency)</option><option value="jpeg">JPG (smaller file)</option><option value="webp">WebP</option></select></label>'
    +'<label>Size <select id="xs"><option value="0.25">25%</option><option value="0.5">50%</option><option value="1" selected>100% (original)</option><option value="2">200% (2x)</option><option value="3">300% (3x)</option><option value="4">400% (4x)</option></select></label>'
    +'<label>Print resolution <select id="xd"><option value="">Default</option><option value="72">72 ppi</option><option value="150">150 ppi</option><option value="300">300 ppi (print)</option></select></label>'
    +'<label>Quality <input type="range" id="xq" min="40" max="100" value="92" style="width:110px"></label></div>'
    +'<p class="muted" id="xinfo" style="margin:4px 0"></p>'
    +'<img id="xprev" alt="Export preview">',[{label:'Close'},{label:'Save file',primary:true,close:false,cb:()=>{xdl();return false;}}],root=>{
    let c=null,blobType='image/png',ext='png';
    const make=()=>{
      const fmt=$('#xf').value,q=$('#xq').value/100,sc2=+$('#xs').value,w=Math.round(doc.w*sc2),h=Math.round(doc.h*sc2);
      if(w>16000||h>16000||w*h>150e6){$('#xinfo').textContent='Too large. Choose a smaller size.';c=null;return;}
      c=mkCanvas(w,h);const x=cctx(c);
      if(fmt==='jpeg'){x.fillStyle='#fff';x.fillRect(0,0,w,h);}
      if(sc2>1){c=flatCanvas(sc2,fmt==='jpeg'?'#ffffff':null);}else compose(x,sc2);blobType='image/'+fmt;ext=fmt==='jpeg'?'jpg':fmt;
      const pv=mkCanvas(Math.min(w,900),Math.min(h,900)*h/Math.max(h,1));
      const k=Math.min(1,900/Math.max(w,h));const pc=mkCanvas(w*k,h*k);cctx(pc).drawImage(c,0,0,pc.width,pc.height);void pv;
      $('#xprev').src=pc.toDataURL(blobType==='image/png'?'image/png':blobType,q);
      $('#xinfo').textContent=w+' x '+h+' px';
    };
    window.xdl=()=>{
      if(!c){toast('Choose a smaller size first');return;}
      c.toBlob(async b0=>{if(!b0){toast('Could not create the file');return;}const b=await setDpiBlob(b0,+$('#xd').value||0);saveBlob(b,(doc.name||'design').replace(/[^\w\- ]+/g,'_')+'.'+ext);},blobType,$('#xq').value/100);
    };
    let xt=0;root.oninput=()=>{clearTimeout(xt);xt=setTimeout(make,200);};make();
  },{wide:true});
}

/* ===== help and about ===== */
function openHelp(){
  const k=[['V','Move'],['M','Marquee select'],['L','Lasso'],['W','Magic wand'],['C','Crop'],['I','Eyedropper'],['J','Skin smoothing brush'],['S','Clone stamp'],['B','Brush'],['E','Eraser'],['G','Gradient / bucket'],['T','Type'],['U','Shapes'],['H or Space','Hand (pan)'],['Z','Zoom'],['X','Swap colours'],['D','Default colours'],['[ and ]','Smaller / bigger brush'],['Ctrl + Z','Undo'],['Ctrl + Shift + Z','Redo'],['Ctrl + J','Layer via copy / duplicate'],['Ctrl + E','Merge down'],['Ctrl + T','Free transform'],['Ctrl + A / D','Select all / Deselect'],['Ctrl + Shift + I','Inverse selection'],['Ctrl + L / M / U','Levels / Curves / Hue-Saturation'],['Ctrl + 0 / 1','Fit on screen / 100%'],['Tab','Hide or show panels'],['Arrow keys','Nudge layer (Shift = 10 px)'],['Enter / Esc','Apply crop / Cancel']];
  modalOpen('Keyboard shortcuts','<div class="keys">'+k.map(r=>'<span><kbd>'+r[0]+'</kbd></span><span>'+r[1]+'</span>').join('')+'</div><p class="muted" style="margin-top:14px">Phone: pinch to zoom, drag with two fingers to pan, long-press a tool for its options. In a web browser a few shortcuts belong to the browser; the menus always work.</p>',[{label:'Close',primary:true}]);
}
function openAbout(){
  modalOpen('About LILKESSphoto Pro','<p><b>LILKESSphoto Pro 1.0</b><br><span class="muted">Free photo editing and graphic design. No account, no subscription.</span></p>'
   +'<div class="h">Included</div><p>Layers with blend modes, masks and styles. Selections (marquee, lasso, magic wand). Brush, eraser, clone stamp, skin smoothing, dodge and burn. Text, shapes, gradients. Levels, curves, hue and saturation, filters. Open and save PSD with layers, editable text and layer styles. Save as PDF, TIFF, GIF, BMP, PNG, JPG and WebP.</p>'
   +'<div class="h">Not included yet</div><p class="muted">Real CMYK files and 16-bit colour (CMYK Color is a preview only), real RAW file decoding (Camera Raw Filter works on normal 8-bit pictures, with no lens profiles or calibration), liquify, puppet warp, custom brush tips and actions. Adjustment layers and smart objects are not stored inside PSD files. Content-aware fill and scale are basic versions. Import Flyer as Template finds text, flat colours and gradients automatically, but you type the words (or use the online reader) and photos stay as pictures.</p>'
   +'<p class="muted">This is an independent app. It is not made by or connected to Adobe.</p>',[{label:'Close',primary:true}]);
}

/* ===== menus ===== */
const ADJ_KINDS=[
  ['bc','Brightness / Contrast'],['levels','Levels'],['exposure','Exposure'],['vibrance','Vibrance'],['huesat','Hue / Saturation'],['colbal','Color Balance'],
  ['bw','Black & White'],['temp','Photo Filter (warmth)'],['shadhi','Shadows / Highlights'],['poster','Posterize'],['thresh','Threshold'],['invert','Invert'],['desat','Desaturate']
];
const SEP={sep:true};
const mi=(label,key,act,o)=>Object.assign({label,key,fn:typeof act==='function'?act:()=>ACT[act](),dis:()=>!doc},o||{});
const al=(label,key,act,o)=>mi(label,key,act,Object.assign({dis:()=>false},o||{}));
const sub=(label,items,o)=>Object.assign({label,items,dis:()=>false},o||{});
const fxi=(id,key)=>mi(FX[id].name+(FX[id].immediate?'':'...'),key,()=>openFx(id));
function fxGroup(g){return Object.keys(FX).filter(k=>FX[k].group===g).map(k=>fxi(k));}
const MENUS=[
  {label:'File',items:[
    al('New...','Ctrl+N','new'),al('Open...','Ctrl+O','open'),al('Open from this device...','',()=>openRecentDialog()),mi('Place image...','','place'),SEP,
    mi('Close','Ctrl+W','closeDoc'),mi('Close all','Ctrl+Alt+W','closeAll'),SEP,
    mi('Save to this device','Ctrl+S','saveProject'),mi('Save as PSD...','Ctrl+Shift+S','savePSD'),mi('Export as...','Ctrl+Alt+E','exportAs'),mi('Export artboards as PNG','','boardExportAll'),SEP,
    al('Welcome screen','','welcome')]},
  {label:'Edit',items:[
    mi('Undo','Ctrl+Z','undo'),mi('Redo','Ctrl+Shift+Z','redo'),SEP,
    mi('Cut','Ctrl+X','cut'),mi('Copy','Ctrl+C','copy'),mi('Paste','Ctrl+V','paste'),mi('Paste in place','Ctrl+Shift+V','pasteInPlace'),SEP,
    mi('Clear','Delete','clear'),mi('Fill with foreground colour','Alt+Backspace','fillFg'),mi('Fill with background colour','Ctrl+Backspace','fillBg'),SEP,
    mi('Free transform','Ctrl+T','transform'),
    sub('Transform layer',[mi('Rotate 90°','','rot90'),mi('Flip horizontal','','lflipH'),mi('Flip vertical','','lflipV'),mi('Fit inside canvas','','fitLayer'),mi('Fill canvas','','fillLayer')],{dis:()=>!doc})]},
  {label:'Image',items:[
    sub('Adjustments',[fxi('bc'),fxi('levels','Ctrl+L'),fxi('curves','Ctrl+M'),fxi('exposure'),fxi('vibrance'),fxi('huesat','Ctrl+U'),fxi('colbal','Ctrl+B'),fxi('bw','Ctrl+Alt+Shift+B'),fxi('temp'),fxi('shadhi'),SEP,fxi('invert','Ctrl+I'),fxi('desat','Ctrl+Shift+U'),fxi('poster'),fxi('thresh')],{dis:()=>!doc}),
    fxi('autotone','Ctrl+Shift+L'),fxi('autocon','Ctrl+Alt+Shift+L'),fxi('autocol','Ctrl+Shift+B'),SEP,
    mi('Image size...','Ctrl+Alt+I','imageSize'),mi('Canvas size...','Ctrl+Alt+C','canvasSize'),
    sub('Image rotation',[mi('180°','','rot180'),mi('90° clockwise','','rotCW'),mi('90° counter-clockwise','','rotCCW'),SEP,mi('Flip canvas horizontal','','flipCH'),mi('Flip canvas vertical','','flipCV')],{dis:()=>!doc}),
    mi('Crop','','cropSel'),mi('Trim transparent pixels','','trim')]},
  {label:'Layer',items:[
    sub('New',[mi('Layer','Ctrl+Shift+N','lnew'),mi('Colour fill layer','','lnewFill'),mi('Layer via copy','Ctrl+J','viaCopy'),mi('Layer via cut','Ctrl+Shift+J','viaCut')],{dis:()=>!doc}),
    mi('Duplicate layer','','ldup'),mi('Delete layer','','ldel'),SEP,
    sub('Layer style',[mi('Blending options...','',()=>ACT.lsOpen('blend')),mi('Bevel & Emboss...','',()=>ACT.lsOpen('bevel')),mi('Stroke...','',()=>ACT.lsOpen('stroke')),mi('Inner shadow...','',()=>ACT.lsOpen('ishadow')),mi('Inner glow...','',()=>ACT.lsOpen('iglow')),mi('Satin...','',()=>ACT.lsOpen('satin')),mi('Color overlay...','',()=>ACT.lsOpen('overlay')),mi('Gradient overlay...','',()=>ACT.lsOpen('grad')),mi('Pattern overlay...','',()=>ACT.lsOpen('pat')),mi('Outer glow...','',()=>ACT.lsOpen('glow')),mi('Drop shadow...','',()=>ACT.lsOpen('shadow')),SEP,mi('Copy layer style','','lcopyfx'),mi('Paste layer style','','lpastefx'),mi('Clear layer style','','lclearfx')],{dis:()=>!doc}),
    mi('Create clipping mask','Ctrl+Alt+G','clipToggle'),mi('Place image into shape...','','clipPlace'),
    sub('New adjustment layer',ADJ_KINDS.map(k=>mi(k[1]+'...','',()=>ACT.adjLayer(k[0]))),{dis:()=>!doc}),
    sub('Smart object',[mi('Convert to smart object','','toSmart'),mi('Edit contents','','smartEdit'),mi('Rasterize smart object','','rasterizeLayer')],{dis:()=>!doc}),
    mi('Remove background','','removeBg'),mi('Remove object (fill the background)...','','removeObject'),mi('Apply mask (delete hidden pixels)','','removeBgApply'),SEP,
    sub('Layer mask',[mi('Reveal all','','maskReveal'),mi('Hide all','','maskHide'),mi('Reveal selection','','maskSel'),SEP,mi('Delete mask','','maskDel'),mi('Apply mask','','maskApply'),mi('Invert mask','','maskInvert')],{dis:()=>!doc}),
    mi('Rasterize layer','','rasterizeLayer'),SEP,
    sub('Arrange',[mi('Bring to front','Ctrl+Shift+]','lfront'),mi('Bring forward','Ctrl+]','lfwd'),mi('Send backward','Ctrl+[','lbwd'),mi('Send to back','Ctrl+Shift+[','lback')],{dis:()=>!doc}),
    sub('Align to canvas',[mi('Left','','alignL'),mi('Centre horizontally','','alignHC'),mi('Right','','alignR'),mi('Top','','alignT'),mi('Centre vertically','','alignVC'),mi('Bottom','','alignB')],{dis:()=>!doc}),
    sub('Flip and rotate',[mi('Flip horizontal','','lflipH'),mi('Flip vertical','','lflipV'),mi('Rotate 90°','','rot90')],{dis:()=>!doc}),
    mi('Lock or unlock','','lockToggle'),mi('Show or hide','','visToggle'),SEP,
    mi('Merge down','Ctrl+E','lmerge'),mi('Merge visible','Ctrl+Shift+E','mergeVisible'),mi('Flatten image','','flatten')]},
  {label:'Type',items:[
    mi('Add text','',()=>setTool('text')),SEP,mi('Bold','','boldToggle'),mi('Italic','','italicToggle'),mi('All caps','','capsToggle'),SEP,
    mi('Align left','','txtL'),mi('Align centre','','txtC'),mi('Align right','','txtR'),SEP,mi('Rasterize type layer','','rasterize')]},
  {label:'Select',items:[
    mi('All','Ctrl+A','selAll'),mi('Deselect','Ctrl+D','selNone'),mi('Reselect','Ctrl+Shift+D','reselect'),mi('Inverse','Ctrl+Shift+I','selInv'),SEP,
    mi('Layer pixels','','selLayer'),mi('Subject','','selSubject'),SEP,
    sub('Modify',[mi('Feather...','Shift+F6','selFeather'),mi('Grow...','','selGrow'),mi('Shrink...','','selShrink'),mi('Smooth...','','selSmooth')],{dis:()=>!doc})]},
  {label:'Filter',items:[
    mi('Last filter','Ctrl+F','lastFilter'),SEP,
    sub('Blur',fxGroup('blur'),{dis:()=>!doc}),sub('Sharpen',fxGroup('sharpen'),{dis:()=>!doc}),sub('Noise',fxGroup('noise'),{dis:()=>!doc}),
    sub('Stylize',fxGroup('stylize'),{dis:()=>!doc}),sub('Pixelate',fxGroup('pixelate'),{dis:()=>!doc}),sub('Distort',fxGroup('distort'),{dis:()=>!doc}),sub('Retouch',fxGroup('retouch'),{dis:()=>!doc})]},
  {label:'View',items:[
    mi('Zoom in','Ctrl++','zin'),mi('Zoom out','Ctrl+-','zout'),mi('Fit on screen','Ctrl+0','zfit'),mi('100%','Ctrl+1','z100'),SEP,
    al('Rulers','Ctrl+R','rulers',{check:()=>S.rulers}),mi('Grid',"Ctrl+'",'grid',{check:()=>S.grid}),mi('Guides','Ctrl+;','guidesToggle',{check:()=>S.showGuides}),mi('Snap','Ctrl+Shift+;','snap',{check:()=>S.snap}),mi('Clear guides','','clearGuides'),SEP,
    al('Full screen','','fullscreen')]},
  {label:'Window',items:[
    al('Color','',()=>setTab('color')),al('Swatches','',()=>setTab('swatches')),al('Adjustments','',()=>setTab('adjust')),al('Looks','',()=>setTab('filters')),SEP,
    al('Layers','F7',()=>setTab('layers')),al('History','',()=>setTab('history')),al('Properties','',()=>setTab('props')),SEP,
    al('Hide or show panels','Tab',()=>togglePanels())]},
  {label:'Help',items:[al('Welcome screen','','welcome'),al('Keyboard shortcuts','','help'),al('About LILKESSphoto Pro','','about')]}
];
function togglePanels(){document.body.classList.toggle('hide-ui');setTimeout(()=>{if(doc&&S.autoFit)fitView();else drawRulers();},30);}
$('#menus').innerHTML=MENUS.map((m,i)=>'<button class="mn" data-m="'+i+'">'+m.label+'</button>').join('');
let openMenuIdx=-1;
function closeMenus(){
  $$('.menu').forEach(m=>m.remove());$$('.mn.open').forEach(b=>b.classList.remove('open'));openMenuIdx=-1;
}
function buildItems(items,wrap){
  items.forEach(it=>{
    if(it.sep){const s=document.createElement('div');s.className='msep';wrap.appendChild(s);return;}
    const dis=it.dis?it.dis():false,b=document.createElement('button');b.className='mitem';b.disabled=!!dis;
    const chk=it.check?(it.check()?'✓':''):'';
    b.innerHTML='<span class="mck">'+chk+'</span><span class="ml">'+esc(it.label)+'</span>'+(it.items?'<span class="marr">&#9656;</span>':(it.key?'<span class="mk">'+esc(it.key.replace(/\+/g,' + ').replace('Ctrl','Ctrl'))+'</span>':''));
    if(it.items){
      const holder=document.createElement('div');holder.className='msubwrap';holder.appendChild(b);
      const sm=document.createElement('div');sm.className='menu msub';sm.hidden=true;buildItems(it.items,sm);holder.appendChild(sm);
      const show=()=>{
        $$('.msub',wrap).forEach(x=>{if(x!==sm)x.hidden=true;});
        sm.hidden=false;sm.style.left='';sm.style.right='';
        if(!isMobile()){const r=sm.getBoundingClientRect();if(r.right>innerWidth-4){sm.style.left='auto';sm.style.right='100%';}if(r.bottom>innerHeight-4)sm.style.top=(-(r.bottom-innerHeight)-8)+'px';}
      };
      b.addEventListener('click',e=>{e.stopPropagation();if(sm.hidden)show();else sm.hidden=true;});
      holder.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse'&&!dis)show();});
      wrap.appendChild(holder);
    }else{
      b.addEventListener('click',e=>{e.stopPropagation();closeMenus();it.fn();});
      wrap.appendChild(b);
    }
  });
}
function openMenuAt(i,btn){
  closeMenus();openMenuIdx=i;btn.classList.add('open');
  const dd=document.createElement('div');dd.className='menu mdrop';buildItems(MENUS[i].items,dd);document.body.appendChild(dd);
  const r=btn.getBoundingClientRect();
  dd.style.top=r.bottom+'px';dd.style.left=Math.max(4,Math.min(r.left,innerWidth-dd.offsetWidth-4))+'px';
}
$('#menus').addEventListener('click',e=>{
  const b=e.target.closest('.mn');if(!b)return;const i=+b.dataset.m;
  if(openMenuIdx===i)closeMenus();else openMenuAt(i,b);
});
$('#menus').addEventListener('pointerover',e=>{
  const b=e.target.closest('.mn');if(!b||openMenuIdx<0||e.pointerType!=='mouse')return;
  const i=+b.dataset.m;if(i!==openMenuIdx)openMenuAt(i,b);
});
document.addEventListener('pointerdown',e=>{if(!e.target.closest('.menu')&&!e.target.closest('.mn')&&!e.target.closest('[data-more]'))closeMenus();});

/* ===== global click handler for data-act buttons ===== */
const NOFLUSH=['adjReset','adjApply','autoFix','quickSkin','closeModal','zin','zout','zfit','z100','help','about','welcome','new','open','fxOk','fxCancel','fxReset','setSrc'];
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b)return;
  const a=b.dataset.act,f=ACT[a];if(!f)return;
  if(doc&&!NOFLUSH.includes(a)&&!(document.body.classList.contains('fx-open')))flush();
  f();
});

/* ===== keyboard ===== */
const CODE_NAMES={BracketLeft:'[',BracketRight:']',Equal:'+',Minus:'-',Quote:"'",Semicolon:';',Backspace:'Backspace',Delete:'Delete',Tab:'Tab',Enter:'Enter',Escape:'Escape',Space:' '};
function comboOf(e){
  let n=CODE_NAMES[e.code];
  if(!n){if(/^Key[A-Z]$/.test(e.code))n=e.code.slice(3);else if(/^Digit\d$/.test(e.code))n=e.code.slice(5);else if(/^F\d+$/.test(e.code))n=e.code;else if(e.code.startsWith('Arrow'))n=e.code;else n=e.key;}
  return ((e.ctrlKey||e.metaKey)?'Ctrl+':'')+(e.altKey?'Alt+':'')+(e.shiftKey?'Shift+':'')+n;
}
const SHORT={};
(function(){
  const walk=items=>items.forEach(it=>{if(it.items)walk(it.items);else if(it.key){const k=it.key.replace(/^Ctrl\+Shift\+Alt\+/,'Ctrl+Alt+Shift+');SHORT[k]=it;}});
  MENUS.forEach(m=>walk(m.items));
  /* Photoshop-style aliases */
  SHORT['Ctrl+=']=SHORT['Ctrl++'];SHORT['Ctrl+Shift++']=SHORT['Ctrl++'];
})();
document.addEventListener('keydown',e=>{
  const tg=e.target,typing=tg.tagName==='TEXTAREA'||tg.tagName==='SELECT'||(tg.tagName==='INPUT'&&/text|number|search/.test(tg.type));
  if(!$('#modal').hidden){
    if(e.key==='Escape')closeModal();
    else if(e.key==='Enter'&&tg.tagName!=='TEXTAREA'&&tg.tagName!=='BUTTON'&&tg.tagName!=='SELECT'){const p=$('#mfoot [data-primary]');if(p){e.preventDefault();p.click();}}
    return;
  }
  if(document.body.classList.contains('fx-open')){
    if(e.key==='Escape')fxCancel();else if(e.key==='Enter'&&!typing){e.preventDefault();fxOk();}
    return;
  }
  if(!$('#welcome').hidden){if(e.key==='Escape'&&docs.length)hideWelcome();}
  if(typing)return;
  const combo=comboOf(e);
  if(SHORT[combo]){const it=SHORT[combo];if(it.dis&&it.dis())return;e.preventDefault();it.fn();return;}
  if(!doc)return;
  const mod=e.ctrlKey||e.metaKey;
  if(mod)return;
  if(combo===' '){spaceDown=true;vp.style.cursor='grab';e.preventDefault();return;}
  {const T=TOOLS[S.tool];if(T&&T.key&&T.key(combo,e)){e.preventDefault();return;}}
  if(combo==='Escape'){if(drag&&drag.k==='lasso'){drag=null;redraw();return;}S.crop=null;redraw();return;}
  if(combo==='Enter'){if(S.tool==='crop'){ACT.cropApply();return;}if(drag&&drag.k==='lasso'&&drag.poly){finishLasso(drag);return;}}
  if(combo==='Delete'||combo==='Backspace'){e.preventDefault();ACT.clear();return;}
  if(combo==='Alt+Backspace'){e.preventDefault();ACT.fillFg();return;}
  if(combo==='Tab'){e.preventDefault();togglePanels();return;}
  if(combo==='Shift+F6'){e.preventDefault();ACT.selFeather();return;}
  if(combo.startsWith('Arrow')||combo.startsWith('Shift+Arrow')){
    const l=active();if(l&&S.tool==='move'&&!posLocked(l)){
      const st=e.shiftKey?10:1,k=e.code;
      if(k==='ArrowLeft')l.x-=st;else if(k==='ArrowRight')l.x+=st;else if(k==='ArrowUp')l.y-=st;else l.y+=st;
      e.preventDefault();pend=true;redraw();clearTimeout(nudgeT);nudgeT=setTimeout(()=>{if(pend){pend=false;commit('Nudge');renderProps();}},350);
    }
    return;
  }
  const k=e.key;
  if(k==='['||k===']'){
    const o=brushLike(S.tool)?brushObj(S.tool):null;
    if(o){o.size=clamp(Math.round(o.size*(k===']'?1.15:0.87)+(k===']'?1:-1)),1,2500);renderOpts();redraw();}return;
  }
  if(k==='x'||k==='X'){const t=S.fg;S.fg=S.bg;S.bg=t;setSwatches();return;}
  if(k==='d'||k==='D'){S.fg='#000000';S.bg='#ffffff';setSwatches();return;}
  if(k.length===1)selectToolByKey(k.toUpperCase());
});
let nudgeT=0;
document.addEventListener('keyup',e=>{if(e.key===' '){spaceDown=false;vp.style.cursor=CURSORS[S.tool]||'default';}});
window.addEventListener('beforeunload',e=>{if(docs.some(d=>d.doc.modified)){e.preventDefault();e.returnValue='';}});

/* ===== welcome screen ===== */
const WSIZES=[['Instagram post',1080,1080],['Story',1080,1920],['A4 flyer',2480,3508,300],['Poster',2700,3600,150],['YouTube thumbnail',1280,720],['Passport photo',413,531,300]];
function hideWelcome(){$('#welcome').hidden=true;}
function showWelcome(){$('#welcome').hidden=false;$('#w-close').hidden=!docs.length;renderRecent();renderWelcomeTemplates();}
async function renderRecent(){
  const box=$('#w-recent'),list=await listProjects();
  if(list===null){box.innerHTML='<p class="muted">Saved designs are not available in this browser mode.</p>';return;}
  if(!list.length){box.innerHTML='<p class="muted">Designs you save to this device appear here.</p>';return;}
  box.innerHTML='<div class="rgrid">'+list.map(p=>'<div class="rcard" data-id="'+p.id+'" tabindex="0" role="button" aria-label="Open '+esc(p.name)+'"><img alt="" src="'+p.thumb+'"><b>'+esc(p.name)+'</b><small>'+p.w+' x '+p.h+' px</small><button class="rdel" data-del="'+p.id+'" aria-label="Delete '+esc(p.name)+'">&#10005;</button></div>').join('')+'</div>';
}
$('#w-recent').addEventListener('click',async e=>{
  const d=e.target.closest('[data-del]');
  if(d){e.stopPropagation();await deleteProject(d.dataset.del);renderRecent();return;}
  const c=e.target.closest('.rcard');if(c)loadProject(c.dataset.id);
});
$('#w-recent').addEventListener('keydown',e=>{if(e.key==='Enter'){const c=e.target.closest('.rcard');if(c)loadProject(c.dataset.id);}});
async function openRecentDialog(){
  const list=await listProjects();
  modalOpen('Open from this device',list&&list.length?'<div class="rgrid" id="rd">'+list.map(p=>'<div class="rcard" data-id="'+p.id+'" tabindex="0" role="button"><img alt="" src="'+p.thumb+'"><b>'+esc(p.name)+'</b><small>'+p.w+' x '+p.h+' px</small></div>').join('')+'</div>':'<p class="muted">No saved designs yet. Use File, Save to this device.</p>',[{label:'Close'}],root=>{
    root.addEventListener('click',e=>{const c=e.target.closest('.rcard');if(c){closeModal();loadProject(c.dataset.id);}});
  },{wide:true});
}
$('#w-sizes').innerHTML=WSIZES.map((s,i)=>'<button class="wsz" data-i="'+i+'"><span class="wshape" style="aspect-ratio:'+s[1]+'/'+s[2]+'"></span><b>'+s[0]+'</b><small>'+s[1]+' x '+s[2]+'</small></button>').join('');
$('#w-sizes').addEventListener('click',e=>{const b=e.target.closest('[data-i]');if(!b)return;const s=WSIZES[+b.dataset.i];newBlank(s[0],s[1],s[2],s[3]||72,'#ffffff');setTool('move');});
let tplDone=false;
function renderWelcomeTemplatesOld(){
  const grid=$('#w-tpl');
  const paint=()=>{
    grid.innerHTML='';
    TEMPLATES.forEach(t=>{
      const b=document.createElement('button');b.className='tcard';b.appendChild(makeThumb(t));
      b.insertAdjacentHTML('beforeend','<b>'+t.name+'</b><small>'+t.w+' x '+t.h+' px</small>');
      b.addEventListener('click',()=>loadTemplate(t));grid.appendChild(b);
    });
  };
  paint();
  if(!tplDone&&document.fonts&&document.fonts.ready){tplDone=true;Promise.all(FONTS.slice(0,10).map(f=>document.fonts.load('700 40px "'+f+'"','Aa'))).then(()=>{if(!$('#welcome').hidden)paint();}).catch(()=>{});}
}

/* ===== templates ===== */
function tText(text,x,y,o){
  o=o||{};const name=o.name;delete o.name;
  const l=addLayer({name:name||text.split('\n')[0].slice(0,20),type:'text',w:10,h:10,x:x*doc.w,y:y*doc.h,
    props:Object.assign({text,font:'Outfit',size:80,bold:true,italic:false,caps:false,color:'#ffffff',align:'center',lh:1.1,stroke:'#000000',sw:0,shadow:0,shadowColor:'#000000'},o)});
  renderText(l);
  const q=l.props;if(q.align==='left'||q.align==='right'){const pad=Math.ceil(q.size*0.12+q.sw+q.shadow*1.6+4);l.x+=(q.align==='left'?1:-1)*(l.canvas.width/2-pad);} // x is the left/right edge for aligned text
  return l;
}
function tShape(kind,x,y,w,h,fill,o){
  o=o||{};
  const l=addLayer({name:o.name||KIND_NAMES[kind],type:'shape',w:10,h:10,x:x*doc.w,y:y*doc.h,
    props:Object.assign({kind,fill,stroke:'#000000',sw:0,radius:0,w:w*doc.w,h:h*doc.w,flip:false,nofill:!fill},o.p||{})});
  renderShape(l);return l;
}
function tGrad(c1,c2,deg){
  const l=addLayer({name:'Background',locked:true}),ctx=cctx(l.canvas),a=deg*Math.PI/180,R=Math.hypot(doc.w,doc.h)/2,cx=doc.w/2,cy=doc.h/2,dx=Math.sin(a),dy=-Math.cos(a);
  const g=ctx.createLinearGradient(cx-dx*R,cy-dy*R,cx+dx*R,cy+dy*R);g.addColorStop(0,c1);g.addColorStop(1,c2);
  ctx.fillStyle=g;ctx.fillRect(0,0,doc.w,doc.h);return l;
}
const TEMPLATES=[
  {name:'Weekend sale',cat:'Business',tags:'sale discount shop offer',w:1080,h:1350,build(){
    tGrad('#0f4231','#06150f',160);
    tShape('ellipse',0.5,0.42,0.86,0.86,'#f2b134',{name:'Sun disc'});
    tText('WEEKEND',0.5,0.29,{font:'Big Shoulders Display',size:190,color:'#0f4231',bold:false});
    tText('SALE',0.5,0.45,{font:'Big Shoulders Display',size:340,color:'#0f4231',bold:false});
    tText('UP TO 50% OFF',0.5,0.605,{font:'Big Shoulders Display',size:84,color:'#0f4231'});
    tShape('rect',0.5,0.775,0.92,0.13,'#ffffff',{name:'Ribbon'});
    tText('FRIDAY TO SUNDAY  |  9AM TO 8PM',0.5,0.775,{size:44,color:'#0f4231'});
    tText('Your shop name  |  Your address  |  000 000 0000',0.5,0.92,{size:34,color:'#f2b134',bold:false});
  }},
  {name:'Night of gold flyer',cat:'Party & Events',tags:'party night dj club event',w:1240,h:1754,build(){
    tGrad('#050505','#3a0e0e',180);
    tShape('ellipse',0.5,0.3,0.92,0.92,null,{name:'Gold ring',p:{stroke:'#f2b134',sw:8,nofill:true}});
    tText('NIGHT',0.5,0.27,{font:'Big Shoulders Display',size:430,color:'#f2b134',bold:false});
    tText('of Gold',0.5,0.395,{font:'Pacifico',size:210,color:'#ffffff',bold:false,shadow:24});
    tText('LIVE DJ  |  FOOD  |  DRINKS',0.5,0.6,{size:56,color:'#f2b134'});
    tShape('line',0.5,0.665,0.5,0,null,{name:'Divider',p:{stroke:'#f2b134',sw:5,h:2,nofill:true}});
    tText('SATURDAY 24 OCTOBER\n8PM TILL LATE',0.5,0.745,{size:78,color:'#ffffff',lh:1.25});
    tText('Venue name, street, city\nFree entry before 9pm',0.5,0.9,{size:42,color:'#f2b134',bold:false,lh:1.4});
  }},
  {name:'Quote card',cat:'Social',tags:'quote instagram post',w:1080,h:1080,build(){
    tGrad('#f6b93b','#e58e26',150);
    tText('“',0.16,0.2,{font:'Playfair Display',size:520,color:'#1c1503',bold:true,align:'center'});
    tText('Make the thing\nyou wish existed.',0.5,0.52,{font:'Playfair Display',size:112,color:'#1c1503',italic:true,lh:1.2});
    tText('YOUR NAME',0.5,0.84,{size:38,color:'#1c1503'});
  }},
  {name:'Grand opening story',cat:'Business',tags:'opening launch shop story',w:1080,h:1920,build(){
    tGrad('#0b5360','#07242b',170);
    tShape('star',0.5,0.2,0.5,0.5,'#f2b134',{name:'Star'});
    tText('GRAND',0.5,0.4,{font:'Big Shoulders Display',size:300,color:'#ffffff',bold:false});
    tText('OPENING',0.5,0.5,{font:'Big Shoulders Display',size:300,color:'#f2b134',bold:false});
    tText('Saturday 31 October  |  10am',0.5,0.62,{size:60,color:'#ffffff'});
    tShape('round',0.5,0.76,0.74,0.12,'#f2b134',{name:'Button',p:{radius:120}});
    tText('Come celebrate with us',0.5,0.76,{size:50,color:'#1c1503'});
    tText('Your shop name, your address',0.5,0.92,{size:36,color:'#ffffff',bold:false});
  }}
];
function makeThumb(t){
  const keep=doc;
  doc={w:t.w,h:t.h,layers:[],active:null,nextId:1,guides:[]};
  try{const k=260/Math.max(t.w,t.h),c=mkCanvas(t.w*k,t.h*k);t.build();compose(cctx(c),k);return c;}
  finally{doc=keep;}
}
function loadTemplate(t){
  startDoc(t.name,t.w,t.h,72);t.build();finishDoc();
  const txt=doc.layers.filter(l=>l.type==='text');if(txt.length)doc.active=txt[0].id;
  refreshAll();redraw();setTool('move');
  if(doc.layers.some(l=>l.ph))toast('Photo frames: click a frame, then press Add or replace photo in Properties. All text is editable.');
}
