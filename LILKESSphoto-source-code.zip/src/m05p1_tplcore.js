/* ===== Template helpers + welcome-screen template browser ===== */
function trnd(seed){let s=seed>>>0;return()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);}
function tSolid(c){return tGrad(c,c,0);}
function tRadial(c1,c2,cx,cy,r){
  const l=addLayer({name:'Background',locked:true}),ctx=cctx(l.canvas),R=r*Math.max(doc.w,doc.h);
  const g=ctx.createRadialGradient(cx*doc.w,cy*doc.h,0,cx*doc.w,cy*doc.h,R);g.addColorStop(0,c1);g.addColorStop(1,c2);
  ctx.fillStyle=g;ctx.fillRect(0,0,doc.w,doc.h);return l;
}
function tCustom(id,x,y,w,h,fill,o){o=o||{};o.p=Object.assign({cid:id},o.p||{});return tShape('custom',x,y,w,h,fill,o);}
function tOp(l,v,r){if(v!=null)l.opacity=v;if(r!=null)l.r=r*Math.PI/180;return l;}
function tConfetti(n,cols,seed,box,o){
  o=o||{};const r=trnd(seed),kinds=o.kinds||['ellipse','rect','star','triangle'];
  for(let i=0;i<n;i++){
    const k=kinds[(r()*kinds.length)|0],sz=(o.min||0.012)+r()*(o.max||0.028);
    const l=tShape(k,box[0]+r()*(box[2]-box[0]),box[1]+r()*(box[3]-box[1]),sz,k==='rect'?sz*.45:sz,cols[(r()*cols.length)|0],{name:'Confetti'});
    l.r=r()*6.28;if(o.op)l.opacity=o.op;
  }
}
function tDots(n,col,seed,box,min,max,op){
  const r=trnd(seed);
  for(let i=0;i<n;i++){const sz=min+r()*(max-min);const l=tShape('ellipse',box[0]+r()*(box[2]-box[0]),box[1]+r()*(box[3]-box[1]),sz,sz,col,{name:'Dot'});l.opacity=op==null?.5:op;}
}
function tBalloon(x,y,s,col,string){
  if(string!==false){const l=tShape('line',x+s*.04,y+s*1.5*doc.w/doc.h,s*.12,s*1.2,null,{name:'String',p:{stroke:'#ffffff',sw:3,nofill:true}});l.opacity=.8;}
  tShape('triangle',x,y+s*.62*doc.w/doc.h,s*.12,s*.1,col,{name:'Knot'});
  tShape('ellipse',x,y,s,s*1.15,col,{name:'Balloon'});
  const h=tShape('ellipse',x-s*.2,y-s*.28*doc.w/doc.h,s*.17,s*.26,'#ffffff',{name:'Shine'});h.opacity=.35;h.r=.5;
}
function tFrame(x,y,w,h,col,sw,o){return tShape('rect',x,y,w,h,null,{name:(o&&o.name)||'Frame',p:{stroke:col,sw:sw||6,nofill:true}});}
function tRule(x,y,w,col,sw){return tShape('rect',x,y,w,(sw||4)/doc.w,col,{name:'Rule'});}
function tStar(x,y,s,col){return tCustom('star5',x,y,s,s,col,{name:'Star'});}
function tCake(x,y,s){
  const W=doc.w;const u=s;
  tShape('ellipse',x,y+u*.46,u*1.25,u*.12,'#00000033',{name:'Shadow'});
  tShape('rect',x,y+u*.34,u*1.1,u*.2,'#f9a8d4',{name:'Cake base'});
  tShape('rect',x,y+u*.14,u*.8,u*.2,'#fde68a',{name:'Cake mid'});
  tShape('rect',x,y-u*.04,u*.5,u*.18,'#fb7185',{name:'Cake top'});
  tShape('round',x,y-u*.14*1,u*.52,u*.04,'#ffffff',{name:'Icing',p:{radius:20}});
  [-.16,0,.16].forEach((dx,i)=>{tShape('rect',x+u*dx,y-u*.3,u*.035,u*.14,['#60a5fa','#34d399','#fbbf24'][i],{name:'Candle'});tShape('ellipse',x+u*dx,y-u*.4,u*.04,u*.06,'#fb923c',{name:'Flame'});});
}
/* ---- category list + welcome browser ---- */
const TPL_CATS=['All','Birthday','Party & Events','Church','Movie & Sports','Beauty & Salon','Business','Social','Portrait'];
function tplFonts(t){const f=new Set();const k=doc;doc={w:t.w,h:t.h,layers:[],active:null,nextId:1,guides:[]};try{t.build();doc.layers.forEach(l=>{if(l.type==='text')f.add(l.props.font+'|'+(l.props.bold?700:400));});}finally{doc=k;}return [...f];}
let tplCat='All',tplQ='',tplIO=null,tplQueue=[],tplBusy=false;
function tplThumb(t){if(!t._th)t._th=makeThumb(t);return t._th;}
function tplPump(){
  if(tplBusy)return;tplBusy=true;
  const step=()=>{
    const job=tplQueue.shift();if(!job){tplBusy=false;return;}
    try{const c=tplThumb(job.t);if(!job.el.firstChild){const cc=mkCanvas(c.width,c.height);cctx(cc).drawImage(c,0,0);job.el.appendChild(cc);}}catch(e){console.error(e);}
    setTimeout(step,12);
  };
  setTimeout(step,0);
}
function renderWelcomeTemplates(){
  const grid=$('#w-tpl'),cats=$('#w-tcats'),qi=$('#w-tq');
  if(!grid)return;
  if(!cats.dataset.init){
    cats.dataset.init=1;
    cats.innerHTML=TPL_CATS.map(c=>'<button class="chip'+(c==='All'?' on':'')+'" data-c="'+c+'">'+c+'</button>').join('');
    cats.addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;tplCat=b.dataset.c;cats.querySelectorAll('.chip').forEach(x=>x.classList.toggle('on',x===b));tplPaint();});
    qi.addEventListener('input',()=>{tplQ=qi.value.trim().toLowerCase();tplPaint();});
    if(document.fonts&&document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',()=>{
      clearTimeout(tplFT);tplFT=setTimeout(()=>{if($('#welcome').hidden)return;TEMPLATES.forEach(t=>{t._th=null;});tplPaint();},400);});
  }
  tplPaint();
  if(!tplPre){tplPre=true;setTimeout(()=>{
    const want=new Set();TEMPLATES.forEach(t=>{try{tplFonts(t).forEach(f=>want.add(f));}catch(_){}});
    want.forEach(f=>{const [n,w]=f.split('|');try{document.fonts.load(w+' 40px "'+n+'"','Aa');}catch(_){}});
  },50);}
}
let tplFT=0,tplPre=false;
function tplPaint(){
  const grid=$('#w-tpl');
  const list=TEMPLATES.filter(t=>(tplCat==='All'||t.cat===tplCat)&&(!tplQ||(t.name+' '+(t.cat||'')+' '+(t.tags||'')).toLowerCase().includes(tplQ)));
  tplQueue=[];
  if(tplIO)tplIO.disconnect();
  tplIO=('IntersectionObserver' in window)?new IntersectionObserver(es=>{es.forEach(en=>{if(en.isIntersecting){tplIO.unobserve(en.target);tplQueue.push({t:en.target._t,el:en.target.querySelector('.tph')});tplPump();}});},{rootMargin:'200px'}):null;
  grid.innerHTML='';
  if(!list.length){grid.innerHTML='<p class="muted">No templates match your search.</p>';return;}
  list.forEach(t=>{
    const b=document.createElement('button');b.className='tcard';b._t=t;
    b.innerHTML='<div class="tph"></div><b>'+esc(t.name)+'</b><small>'+(t.cat?esc(t.cat)+' · ':'')+t.w+' x '+t.h+' px</small>';
    b.addEventListener('click',()=>loadTemplate(t));grid.appendChild(b);
    if(tplIO)tplIO.observe(b);else{tplQueue.push({t,el:b.querySelector('.tph')});}
  });
  if(!tplIO)tplPump();
}
/* ---- photo frames in templates ---- */
function tPhoto(x,y,w,h,o){
  o=o||{};
  const l=tShape(o.kind||'rect',x,y,w,h,o.fill||'#b9c0cc',{name:o.name||'Photo frame',p:Object.assign({radius:o.radius||0,stroke:o.stroke||'#ffffff',sw:o.sw||0},o.p||{})});
  l.ph=true;if(o.r)l.r=o.r*Math.PI/180;return l;
}
ACT.phAdd=()=>{const l=active();if(!l||!l.ph){toast('Select a photo frame first');return;}pickFile('clip');};

function tIcon(kind,x,y,s,bg,fg){
  tShape('ellipse',x,y,s,s,bg,{name:'Icon'});
  if(kind==='cal'){tShape('round',x,y+s*.03,s*.5,s*.42,fg,{name:'Icon cal',p:{radius:5}});tShape('rect',x,y-s*.02,s*.5,s*.07,bg,{name:'Icon cal line'});}
  else if(kind==='clock'){tShape('ellipse',x,y,s*.5,s*.5,null,{name:'Icon clock',p:{stroke:fg,sw:Math.max(3,s*doc.w*.04),nofill:true}});tShape('rect',x,y-s*.07,s*.04,s*.17,fg,{name:'Icon hand'});}
  else if(kind==='pin'){tCustom('drop',x,y-s*.01,s*.4,s*.46,fg,{name:'Icon pin'}).r=Math.PI;tShape('ellipse',x,y-s*.07,s*.13,s*.13,bg,{name:'Icon pin dot'});}
  else if(kind==='phone'){tShape('round',x,y,s*.28,s*.5,fg,{name:'Icon phone',p:{radius:8}});tShape('ellipse',x,y+s*.17,s*.07,s*.07,bg,{name:'Icon phone btn'});}
  else if(kind==='check'){tCustom('check',x,y,s*.5,s*.5,fg,{name:'Icon check'});}
}
