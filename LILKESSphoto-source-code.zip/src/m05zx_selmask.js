/* ===== Select and Mask workspace =====
   Works on a working copy of the selection (or the layer's mask) at up to 1280 px, and writes the result back as
   a selection, a layer mask or a new masked layer. Every control changes the alpha that is written out. The photo is never touched. */
const SM={on:false,lid:0,doc:null,ww:0,hh:0,W:0,H:0,planes:null,P:null,base0:null,E0:null,Eh:null,A:null,M:null,Z:null,
  p:{view:'overlay',radius:1,hair:0,smooth:0,feather:0,contrast:0,shift:0,out:'mask'},brush:'',size:40,stack:[],alpha:null,pvAlpha:null,pvDoc:null,layerDoc:null,prevTool:'move',hasP:false,t:0};
const smF=n=>new Float32Array(n);
function smBox(a,w,h,r,it){let o=a;for(let i=0;i<(it||1);i++)o=cut__box(o,w,h,r);return o;}
const smClamp=v=>v<0?0:v>1?1:v;
/* stage 1: edge-aware alpha (needs the network probability when the selection came from Select Subject) */
function smEdge(radius,hair){
  const n=SM.ww*SM.hh;
  if(!SM.hasP&&radius===1&&hair===0)return Float32Array.from(SM.base0);
  return aiEdge(SM.P,SM.planes,SM.ww,SM.hh,radius,hair);
}
/* stage 2 + 3: refine zones, add/subtract strokes, then Smooth / Shift / Contrast / Feather */
function smCompose(){
  const {ww,hh}=SM,n=ww*hh,p=SM.p,sc=Math.max(ww,hh)/1000;
  let a=Float32Array.from(SM.E0);
  if(SM.Zany){
    if(!SM.Eh)SM.Eh=aiEdge(SM.P,SM.planes,ww,hh,Math.max(1.4,p.radius*1.5),100);
    for(let i=0;i<n;i++){const z=SM.Z[i];if(z>0)a[i]=a[i]*(1-z)+SM.Eh[i]*z;}
  }
  for(let i=0;i<n;i++){const ad=SM.A[i],sb=SM.M[i];if(ad>a[i])a[i]=ad;if(sb>0)a[i]*=(1-sb);}
  if(p.smooth>0){const r=Math.max(1,Math.round(p.smooth/100*10*sc)),b=smBox(a,ww,hh,r,2);for(let i=0;i<n;i++)a[i]=smClamp((b[i]-0.5)*(6+p.smooth/8)+0.5);}
  if(p.shift!==0){const r=Math.max(1,Math.round(Math.abs(p.shift)*sc*0.5)),t=smBox(a,ww,hh,r,2);
    if(p.shift>0)for(let i=0;i<n;i++)a[i]=Math.max(a[i],smClamp((t[i]-0.1)/0.5));else for(let i=0;i<n;i++)a[i]=Math.min(a[i],smClamp((t[i]-0.62)/0.3));}
  if(p.contrast!==0){const k=p.contrast>0?1+p.contrast/18:1/(1+(-p.contrast)/40);for(let i=0;i<n;i++)a[i]=smClamp((a[i]-0.5)*k+0.5);}
  if(p.feather>0){a=fthGauss(a,ww,hh,fthRadiusToSigma(p.feather*ww/SM.W));}   /* feather is in full-size image pixels */
  SM.alpha=a;
}
function smPreviewBuild(){
  const l=doc.layers.find(x=>x.id===SM.lid);if(!l)return;
  const c=aiAlphaCanvas(SM.alpha,SM.ww,SM.hh,SM.ww,SM.hh);
  SM.pvDoc=layerToDocCanvas(l,c);
  if(!SM.layerDoc||SM.layerDoc.ver!==l.ver){const ld=layerToDocCanvas(l,l.canvas);ld.ver=l.ver;SM.layerDoc=ld;}
  redraw();
}
let smTimer=0;
function smUpdate(full,instant){
  clearTimeout(smTimer);
  const go=()=>{
    if(!SM.on)return;
    if(full){SM.E0=smEdge(SM.p.radius,SM.p.hair);SM.Eh=null;}
    smCompose();smPreviewBuild();smSyncSel();
  };
  if(instant)go();else smTimer=setTimeout(go,full?250:90);
}
/* keep the real selection (marching ants) in step with the preview */
function smSyncSel(){
  const l=doc.layers.find(x=>x.id===SM.lid);if(!l||!SM.pvDoc)return;
  S.sel=null;setSelection(SM.pvDoc,'new');
}
/* ---- overlays drawn behind the marching ants ---- */
{const _do=drawOver;
 drawOver=function(){
  _do();
  if(!SM.on||!SM.pvDoc||!doc)return;
  if(doc!==SM.doc||!doc.layers.some(x=>x.id===SM.lid)){smClose(false);return;}
  const o=octx,v=SM.p.view,w=doc.w,h=doc.h,pv=SM.pvDoc,ld=SM.layerDoc;
  if(v==='reveal'||v==='ants'||!ld)return;
  o.save();o.globalCompositeOperation='destination-over';
  const masked=()=>{const t=mkCanvas(w,h),x=cctx(t);x.drawImage(ld,0,0);x.globalCompositeOperation='destination-in';x.drawImage(pv,0,0);return t;};
  if(v==='overlay'){const t=mkCanvas(w,h),x=cctx(t);x.fillStyle='rgba(255,40,60,.55)';x.fillRect(0,0,w,h);x.globalCompositeOperation='destination-out';x.drawImage(pv,0,0);o.drawImage(t,0,0);}
  else if(v==='bw'){const t=mkCanvas(w,h),x=cctx(t);x.fillStyle='#000';x.fillRect(0,0,w,h);const u=mkCanvas(w,h),y=cctx(u);y.fillStyle='#fff';y.fillRect(0,0,w,h);y.globalCompositeOperation='destination-in';y.drawImage(pv,0,0);x.drawImage(u,0,0);o.drawImage(t,0,0);}
  else if(v==='black'||v==='white'){o.drawImage(masked(),0,0);o.globalCompositeOperation='destination-over';o.fillStyle=v==='black'?'#000':'#fff';o.fillRect(0,0,w,h);}
  else if(v==='onion'){o.drawImage(masked(),0,0);o.globalAlpha=0.35;o.drawImage(ld,0,0);o.globalAlpha=1;o.globalCompositeOperation='destination-over';
    const t=mkCanvas(16,16),x=cctx(t);x.fillStyle='#fff';x.fillRect(0,0,16,16);x.fillStyle='#cfcfcf';x.fillRect(0,0,8,8);x.fillRect(8,8,8,8);o.fillStyle=o.createPattern(t,'repeat');o.fillRect(0,0,w,h);}
  o.restore();
 };}
/* ---- brush tool inside the workspace ---- */
TOOLS.sambrush={
  opts:()=>SIZE_OPT()+'<span class="opt muted">'+(SM.brush==='add'?'Paint over parts that should be kept.':SM.brush==='sub'?'Paint over parts that should be hidden.':'Paint along hair and soft edges to rebuild them from the picture.')+'</span>',
  down(p){const l=doc.layers.find(x=>x.id===SM.lid);if(!l||!SM.on)return;drag={k:'x',tool:'sambrush',l,pts:[toLocal(l,p)],dpts:[p]};},
  move(p){const d=drag;if(!d||d.tool!=='sambrush')return;d.pts.push(toLocal(d.l,p));d.dpts.push(p);redraw();},
  over(o,z){overStroke(o,z,SM.brush==='sub'?'rgba(255,60,60,.45)':SM.brush==='add'?'rgba(70,220,120,.45)':'rgba(80,160,255,.45)');},
  up(d){smStroke(d);}
};
BRUSHY.sambrush='aux';CURSORS.sambrush='crosshair';
function smStroke(d){
  const l=d.l,k=SM.ww/SM.W,rad=Math.max(1.5,S.aux.size/2/l.s*k),{ww,hh}=SM,c=mkCanvas(ww,hh),x=cctx(c);
  x.strokeStyle='#fff';x.fillStyle='#fff';x.lineWidth=rad*2;x.lineCap=x.lineJoin='round';x.beginPath();
  d.pts.forEach((q,i)=>i?x.lineTo(q.x*k,q.y*k):x.moveTo(q.x*k,q.y*k));if(d.pts.length===1)x.lineTo(d.pts[0].x*k+0.01,d.pts[0].y*k);x.stroke();
  const id=x.getImageData(0,0,ww,hh).data,s=smF(ww*hh);for(let i=0;i<s.length;i++)s[i]=id[i*4+3]/255;
  const sb=smBox(s,ww,hh,1,1);
  smPush();
  const n=ww*hh;
  if(SM.brush==='add'){for(let i=0;i<n;i++){if(sb[i]>SM.A[i])SM.A[i]=sb[i];SM.M[i]*=(1-sb[i]);}}
  else if(SM.brush==='sub'){for(let i=0;i<n;i++){if(sb[i]>SM.M[i])SM.M[i]=sb[i];SM.A[i]*=(1-sb[i]);}}
  else{SM.Zany=true;for(let i=0;i<n;i++)if(sb[i]>SM.Z[i])SM.Z[i]=sb[i];}
  smUpdate(false,true);smPanelSync();
}
function smPush(){SM.stack.push({A:Float32Array.from(SM.A),M:Float32Array.from(SM.M),Z:Float32Array.from(SM.Z),Zany:SM.Zany});if(SM.stack.length>12)SM.stack.shift();}
/* ---- open / close ---- */
ACT.selMask=D(()=>{
  const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return;}
  if(SM.on){toast('Select and Mask is already open');return;}
  let src=null,fromMask=false;
  if(S.sel)src=selAlphaCanvasLocal(l);else if(l.mask){src=cloneCanvas(l.mask);fromMask=true;}
  if(!src){toast('Make a selection first: Select Subject, Quick Selection, Lasso or Pen. Then open Select and Mask.');return;}
  ensureRaster(l);
  const W=l.canvas.width,H=l.canvas.height,k=Math.min(1,1280/Math.max(W,H)),ww=Math.max(8,Math.round(W*k)),hh=Math.max(8,Math.round(H*k)),n=ww*hh;
  const sm=cut__resize(src,ww,hh),d=cctx(sm).getImageData(0,0,ww,hh).data,b0=smF(n);for(let i=0;i<n;i++)b0[i]=d[i*4+3]/255;
  Object.assign(SM,{on:true,lid:l.id,doc,ww,hh,W,H,base0:b0,A:smF(n),M:smF(n),Z:smF(n),Zany:false,stack:[],Eh:null,prevTool:S.tool,brush:'',layerDoc:null,
    p:{view:'overlay',radius:1,hair:0,smooth:0,feather:0,contrast:0,shift:0,out:fromMask?'mask':(S.sel&&!l.mask?'mask':'mask')},origMask:l.mask?cloneCanvas(l.mask):null,origSel:S.sel,fromMask});
  SM.planes=aiPlanes(l.canvas,ww,hh);
  /* the network probability is only valid while the picture and the selection still come from Select Subject */
  const sj=S.subj;SM.hasP=!!(sj&&sj.r&&sj.lid===l.id&&sj.ver===l.ver&&sj.r.ww===ww&&sj.r.hh===hh&&!fromMask);
  SM.P=SM.hasP?sj.r.P:Float32Array.from(b0);
  SM.E0=SM.hasP?sj.r.a:Float32Array.from(b0);
  smPanelOpen();smCompose();smPreviewBuild();smSyncSel();
  toast('Select and Mask: change the view, the sliders or paint with the brushes. OK writes the result.');
});
function smClose(apply){
  if(!SM.on)return;
  const l=doc&&doc.layers.find(x=>x.id===SM.lid);
  if(apply&&l){
    aiShow('Applying...',false);
    const alpha=aiAlphaCanvas(SM.alpha,SM.ww,SM.hh,SM.W,SM.H),out=SM.p.out;
    SM.on=false;
    if(out==='selection'){S.sel=null;setSelection(layerToDocCanvas(l,alpha),'new');toast('Selection updated');}
    else{
      let tgt=l;
      if(out==='newmask'){S.selSave=S.sel;dupLayer(l,0);tgt=active();tgt.name=l.name+' (cut out)';}
      const w=tgt.canvas.width,h=tgt.canvas.height,n=mkCanvas(w,h),x=cctx(n);x.drawImage(alpha,0,0,w,h);
      tgt.mask=n;tgt.mOff=false;tgt.mView=false;tgt.editMask=true;tgt.mver++;touch(tgt);
      if(S.sel){/* keep the refined edge as the selection too */}
      commit('Select and Mask');refreshLayers();renderProps();toast(out==='newmask'?'New layer with a layer mask created':'Layer mask written. The original picture is untouched.');
    }
    aiHide();
  }else if(l){
    SM.on=false;
    if(SM.origSel!==undefined)S.sel=SM.origSel;
    toast('Select and Mask cancelled');
  }
  SM.on=false;SM.pvDoc=null;SM.layerDoc=null;SM.planes=null;SM.P=null;SM.E0=null;SM.Eh=null;SM.A=SM.M=SM.Z=null;SM.base0=null;SM.alpha=null;
  smPanelClose();redraw();
  if(S.tool==='sambrush')setTool(SM.prevTool&&SM.prevTool!=='sambrush'?SM.prevTool:'move');
}
/* ---- panel ---- */
function smPanelOpen(){
  smPanelClose();
  const d=document.createElement('div');d.id='sampanel';d.className='sampanel';
  const sl=(k,lab,min,max,note)=>'<label class="sl"><span>'+lab+'</span><input type="range" data-sm="'+k+'" min="'+min+'" max="'+max+'" step="'+(k==='radius'?0.1:1)+'" value="'+SM.p[k]+'"><b data-smv="'+k+'">'+SM.p[k]+'</b></label>';
  d.innerHTML='<div class="smh"><b>Select and Mask</b><button data-sma="x" title="Cancel" aria-label="Cancel">×</button></div>'
   +'<label class="opt">View <select data-sm="view"><option value="overlay">Overlay (red = hidden)</option><option value="ants">Marching ants</option><option value="onion">Onion skin</option><option value="black">On black</option><option value="white">On white</option><option value="bw">Black and white</option><option value="layers">On layers</option><option value="reveal">Original image</option></select></label>'
   +'<div class="smb"><button data-sma="add">Add (keep)</button><button data-sma="sub">Subtract (hide)</button><button data-sma="refine">Refine edge brush</button></div>'
   +'<label class="sl"><span>Brush size</span><input type="range" data-sma-size min="4" max="200" value="'+S.aux.size+'"></label>'
   +'<div class="muted smn">Edge detection</div>'+sl('radius','Radius',0.3,3)+sl('hair','Hair detail',0,100)
   +'<div class="muted smn">Global refinements</div>'+sl('smooth','Smooth',0,100)+sl('feather','Feather (px)',0,Math.max(60,Math.round(Math.max(SM.W,SM.H)/8)))+sl('contrast','Contrast',-100,100)+sl('shift','Shift edge',-100,100)
   +'<label class="opt">Output <select data-sm="out"><option value="mask">Layer mask</option><option value="selection">Selection</option><option value="newmask">New layer with layer mask</option></select></label>'
   +'<div class="smb"><button data-sma="zin">+</button><button data-sma="zout">−</button><button data-sma="zfit">Fit</button><button data-sma="hand">Hand</button><button data-sma="undo">Undo stroke</button></div>'
   +'<div class="smb"><button data-sma="reset">Reset</button><button data-sma="x">Cancel</button><button class="primary" data-sma="ok">OK</button></div>'
   +'<p class="muted smn">Edge detection uses the picture itself to find hair and soft edges. Radius widens the area it looks at. The sliders change the selection or mask only.</p>';
  document.body.appendChild(d);
  d.querySelector('[data-sm="view"]').value=SM.p.view;d.querySelector('[data-sm="out"]').value=SM.p.out;
  d.addEventListener('input',e=>{const t=e.target;
    if(t.dataset.sm&&t.type==='range'){SM.p[t.dataset.sm]=+t.value;const b=d.querySelector('[data-smv="'+t.dataset.sm+'"]');if(b)b.textContent=t.value;smUpdate(t.dataset.sm==='radius'||t.dataset.sm==='hair');}
    else if(t.hasAttribute('data-sma-size')){S.aux.size=+t.value;redraw();}});
  d.addEventListener('change',e=>{const t=e.target;if(t.tagName==='SELECT'&&t.dataset.sm){SM.p[t.dataset.sm]=t.value;if(t.dataset.sm==='view')redraw();}});
  d.addEventListener('click',e=>{const t=e.target.closest('[data-sma]');if(!t)return;const a=t.dataset.sma;
    if(a==='x')smClose(false);else if(a==='ok')smClose(true);
    else if(a==='add'||a==='sub'||a==='refine'){SM.brush=a;setTool('sambrush');smPanelSync();}
    else if(a==='hand')setTool('hand');
    else if(a==='zin')ACT.zin();else if(a==='zout')ACT.zout();else if(a==='zfit')ACT.zfit();
    else if(a==='undo'){const s=SM.stack.pop();if(s){SM.A=s.A;SM.M=s.M;SM.Z=s.Z;SM.Zany=s.Zany;smUpdate(false,true);}else toast('Nothing to undo');}
    else if(a==='reset'){Object.assign(SM.p,{radius:1,hair:0,smooth:0,feather:0,contrast:0,shift:0});SM.A=smF(SM.ww*SM.hh);SM.M=smF(SM.ww*SM.hh);SM.Z=smF(SM.ww*SM.hh);SM.Zany=false;SM.stack=[];
      d.querySelectorAll('input[data-sm]').forEach(i=>{i.value=SM.p[i.dataset.sm];const b=d.querySelector('[data-smv="'+i.dataset.sm+'"]');if(b)b.textContent=i.value;});smUpdate(true,true);toast('Refinement reset');}
  });
}
function smPanelSync(){const d=document.getElementById('sampanel');if(!d)return;d.querySelectorAll('[data-sma="add"],[data-sma="sub"],[data-sma="refine"]').forEach(b=>b.classList.toggle('on',b.dataset.sma===SM.brush&&S.tool==='sambrush'));}
function smPanelClose(){const d=document.getElementById('sampanel');if(d)d.remove();}
document.addEventListener('keydown',e=>{if(SM.on&&e.key==='Escape'){e.preventDefault();smClose(false);}},true);
{const st=document.createElement('style');st.textContent='.sampanel{position:fixed;right:12px;top:70px;z-index:80;width:272px;max-height:calc(100vh - 90px);overflow:auto;background:var(--panel,#2a2a2a);color:var(--text,#eee);border:1px solid var(--line,#444);border-radius:10px;padding:10px 12px;box-shadow:0 8px 28px #000a;display:flex;flex-direction:column;gap:7px;font-size:13px}.smh{display:flex;justify-content:space-between;align-items:center}.smb{display:flex;flex-wrap:wrap;gap:5px}.smb button{flex:1 1 auto}.smb button.on{background:var(--accent,#3b82f6);color:#fff}.sampanel .sl{display:grid;grid-template-columns:84px 1fr 34px;align-items:center;gap:6px}.sampanel .sl b{font-weight:400;text-align:right}.smn{font-size:12px;margin:2px 0}@media(max-width:700px){.sampanel{left:8px;right:8px;top:auto;bottom:8px;width:auto;max-height:46vh}}';document.head.appendChild(st);}
