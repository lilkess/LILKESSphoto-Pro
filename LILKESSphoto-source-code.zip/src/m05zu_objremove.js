/* ===== Remove Object: paint or pick a person / object and the background behind it is rebuilt (patch-based fill, runs on this device) ===== */
S.orm={grow:6,busy:false};
let OR=null;
function orLayer(){const l=active();if(!l||!isPixelLayer(l)){toast('Select a photo layer first');return null;}if(l.locked){toast('This layer is locked');return null;}ensureRaster(l);return l;}
function orInit(l){
  if(OR&&OR.lid===l.id&&OR.W===l.canvas.width&&OR.H===l.canvas.height)return OR;
  const hc=mkCanvas(l.canvas.width,l.canvas.height);OR={lid:l.id,W:hc.width,H:hc.height,hc,tint:null,stack:[]};return OR;
}
function orTint(l){
  if(!OR)return;const W=OR.W,H=OR.H,d=cctx(OR.hc).getImageData(0,0,W,H).data,t=mkCanvas(W,H),tx=cctx(t),id=tx.createImageData(W,H),o=id.data;let any=false;
  for(let i=0;i<W*H;i++){if(d[i*4+3]>127){o[i*4]=255;o[i*4+1]=40;o[i*4+2]=60;o[i*4+3]=140;any=true;}}
  tx.putImageData(id,0,0);OR.any=any;OR.tint=any?layerToDocCanvas(l,t):null;OR.tintL=[l.x,l.y,l.r,l.s];redraw();
}
function orPush(){const x=cctx(OR.hc);OR.stack.push(x.getImageData(0,0,OR.W,OR.H));if(OR.stack.length>8)OR.stack.shift();}
function orAddAlpha(l,alpha){ // alpha: Uint8ClampedArray W*H
  orPush();const x=cctx(OR.hc),id=x.getImageData(0,0,OR.W,OR.H),d=id.data;
  for(let i=0;i<alpha.length;i++)if(alpha[i]>127){d[i*4]=255;d[i*4+1]=255;d[i*4+2]=255;d[i*4+3]=255;}
  x.putImageData(id,0,0);orTint(l);
}
/* ---- the fill ---- */
function orPushPull(img,known,w,h){ // onion-peel average so the first guess is smooth
  const kn=Uint8Array.from(known);let left=1;
  for(let guard=0;guard<4000&&left;guard++){left=0;const add=[];
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(kn[i])continue;let r=0,g=0,b=0,n=0;
      for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;const j=Y*w+X;if(kn[j]){r+=img[j*3];g+=img[j*3+1];b+=img[j*3+2];n++;}}
      if(n){add.push(i,r/n,g/n,b/n);}else left++;}
    for(let k=0;k<add.length;k+=4){const i=add[k];img[i*3]=add[k+1];img[i*3+1]=add[k+2];img[i*3+2]=add[k+3];kn[i]=1;}}
}
function orPatchMatch(img,hole,w,h,pr,iters,nnf,rand,sharp){
  const P=pr,valid=new Uint8Array(w*h),list=[];
  for(let y=P;y<h-P;y++)for(let x=P;x<w-P;x++){let ok=1;for(let dy=-P;dy<=P&&ok;dy++)for(let dx=-P;dx<=P;dx++)if(hole[(y+dy)*w+x+dx]){ok=0;break;}if(ok){valid[y*w+x]=1;list.push(y*w+x);}}
  if(!list.length)return null;
  const hp=[];for(let y=P;y<h-P;y++)for(let x=P;x<w-P;x++)if(hole[y*w+x])hp.push(y*w+x);
  // hole pixels too near the edge: clamp their centre inward
  const dist=(c,q,best)=>{let s=0;const cx=c%w,cy=(c/w)|0,qx=q%w,qy=(q/w)|0;
    for(let dy=-P;dy<=P;dy++){const a=((cy+dy)*w+cx-P)*3,b=((qy+dy)*w+qx-P)*3;for(let k=0;k<(2*P+1)*3;k++){const d=img[a+k]-img[b+k];s+=d*d;}if(s>=best)return s;}return s;};
  if(!nnf.has){for(const c of hp)nnf.v[c]=list[(rand()*list.length)|0];nnf.has=true;}
  else for(const c of hp){const q=nnf.v[c];if(!q||!valid[q])nnf.v[c]=list[(rand()*list.length)|0];}
  const cost=new Float64Array(w*h);for(const c of hp)cost[c]=dist(c,nnf.v[c],1e30);
  for(let it=0;it<iters;it++){
    const fwd=it%2===0;
    for(let k=0;k<hp.length;k++){const c=hp[fwd?k:hp.length-1-k],cx=c%w,cy=(c/w)|0;let best=cost[c],bq=nnf.v[c];
      const tryq=q=>{if(q<0||q>=w*h||!valid[q])return;const d=dist(c,q,best);if(d<best){best=d;bq=q;}};
      const nb=fwd?[-1,-w]:[1,w];
      for(const off of nb){const n=c+off;if(hole[n]&&nnf.v[n]){const q=nnf.v[n]-off,qx=q%w;if(Math.abs(qx-(nnf.v[n]%w))<=1)tryq(q);}}
      let rad=Math.max(w,h)>>1;const bx=bq%w,by=(bq/w)|0;
      while(rad>=1){for(let t=0;t<2;t++){const qx=bx+Math.round((rand()*2-1)*rad),qy=by+Math.round((rand()*2-1)*rad);if(qx>=P&&qx<w-P&&qy>=P&&qy<h-P)tryq(qy*w+qx);}rad>>=1;}
      cost[c]=best;nnf.v[c]=bq;}
    // vote: every hole pixel becomes the average of what the overlapping patches say it should be
    if(sharp&&it===iters-1){for(const c of hp){const q=nnf.v[c];img[c*3]=img[q*3];img[c*3+1]=img[q*3+1];img[c*3+2]=img[q*3+2];}break;} // last pass: copy the matched pixel, keeps texture crisp
    const acc=new Float32Array(w*h*3),cnt=new Float32Array(w*h);
    for(const c of hp){const q=nnf.v[c],cx=c%w,cy=(c/w)|0,qx=q%w,qy=(q/w)|0;
      for(let dy=-P;dy<=P;dy++)for(let dx=-P;dx<=P;dx++){const t=(cy+dy)*w+cx+dx;if(!hole[t])continue;const s=(qy+dy)*w+qx+dx;acc[t*3]+=img[s*3];acc[t*3+1]+=img[s*3+1];acc[t*3+2]+=img[s*3+2];cnt[t]++;}}
    for(let t=0;t<w*h;t++)if(hole[t]&&cnt[t]){img[t*3]=acc[t*3]/cnt[t];img[t*3+1]=acc[t*3+1]/cnt[t];img[t*3+2]=acc[t*3+2]/cnt[t];}
  }
  return true;
}
function orInpaint(cv,holeA,grow){
  const W=cv.width,H=cv.height;let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(holeA[y*W+x]){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
  if(x1<0)return false;
  const bw=x1-x0+1,bh=y1-y0+1,mg=Math.round(Math.max(40,Math.max(bw,bh)*0.7)+grow);
  const cx0=Math.max(0,x0-mg),cy0=Math.max(0,y0-mg),cx1=Math.min(W,x1+1+mg),cy1=Math.min(H,y1+1+mg),cw=cx1-cx0,ch=cy1-cy0;
  const s=Math.min(1,600/Math.max(cw,ch)),w=Math.max(16,Math.round(cw*s)),h=Math.max(16,Math.round(ch*s));
  const crop=mkCanvas(cw,ch);cctx(crop).drawImage(cv,cx0,cy0,cw,ch,0,0,cw,ch);
  const wk=mkCanvas(w,h),wx=cctx(wk);wx.imageSmoothingQuality='high';wx.drawImage(crop,0,0,w,h);const wd=wx.getImageData(0,0,w,h).data;
  // hole at working size
  const hc=mkCanvas(cw,ch),hx=cctx(hc),hid=hx.createImageData(cw,ch);
  for(let y=0;y<ch;y++)for(let x=0;x<cw;x++)if(holeA[(y+cy0)*W+x+cx0]){const k=(y*cw+x)*4;hid.data[k+3]=255;}hx.putImageData(hid,0,0);
  const hs=mkCanvas(w,h),hsx=cctx(hs);hsx.imageSmoothingQuality='high';hsx.drawImage(hc,0,0,w,h);const hd=hsx.getImageData(0,0,w,h).data;
  let hole=new Uint8Array(w*h);for(let i=0;i<w*h;i++)hole[i]=hd[i*4+3]>40?1:0;
  hole=cut__dilate(hole,w,h,Math.max(1,Math.round(grow*s)));
  let nh=0;for(let i=0;i<w*h;i++)nh+=hole[i];if(nh>0.9*w*h)return false;
  // pyramid
  const lv=[{w,h,img:new Float32Array(w*h*3),hole}];for(let i=0;i<w*h;i++){lv[0].img[i*3]=wd[i*4];lv[0].img[i*3+1]=wd[i*4+1];lv[0].img[i*3+2]=wd[i*4+2];}
  while(lv.length<5&&Math.min(lv[lv.length-1].w,lv[lv.length-1].h)>=48){const p=lv[lv.length-1],nw=p.w>>1,nh2=p.h>>1,im=new Float32Array(nw*nh2*3),ho=new Uint8Array(nw*nh2);
    for(let y=0;y<nh2;y++)for(let x=0;x<nw;x++){let r=0,g=0,b=0,n=0,hh=0;for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){const j=(y*2+dy)*p.w+x*2+dx;if(p.hole[j])hh=1;else{r+=p.img[j*3];g+=p.img[j*3+1];b+=p.img[j*3+2];n++;}}
      ho[y*nw+x]=hh;if(n){im[(y*nw+x)*3]=r/n;im[(y*nw+x)*3+1]=g/n;im[(y*nw+x)*3+2]=b/n;}}
    lv.push({w:nw,h:nh2,img:im,hole:ho});}
  let seed=12345;const rand=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
  let prev=null,nn0=null;
  for(let L=lv.length-1;L>=0;L--){const Lv=lv[L];
    if(!prev){const kn=new Uint8Array(Lv.w*Lv.h);for(let i=0;i<kn.length;i++)kn[i]=Lv.hole[i]?0:1;orPushPull(Lv.img,kn,Lv.w,Lv.h);}
    else{const pw=prev.w,ph=prev.h;for(let y=0;y<Lv.h;y++)for(let x=0;x<Lv.w;x++){const i=y*Lv.w+x;if(!Lv.hole[i])continue;const fx=Math.min(pw-1,x/2),fy=Math.min(ph-1,y/2),ix=Math.floor(fx),iy=Math.floor(fy),jx=Math.min(pw-1,ix+1),jy=Math.min(ph-1,iy+1),ax=fx-ix,ay=fy-iy;
      for(let c=0;c<3;c++){const v=(prev.img[(iy*pw+ix)*3+c]*(1-ax)+prev.img[(iy*pw+jx)*3+c]*ax)*(1-ay)+(prev.img[(jy*pw+ix)*3+c]*(1-ax)+prev.img[(jy*pw+jx)*3+c]*ax)*ay;Lv.img[i*3+c]=v;}}}
    const nn={v:new Int32Array(Lv.w*Lv.h),has:false};if(L===0)nn0=nn;
    const P=Lv.w<80?1:2,ok=orPatchMatch(Lv.img,Lv.hole,Lv.w,Lv.h,P,L===0?5:8,nn,rand,L<=1);
    prev=Lv;}
  // back to full resolution, only inside the hole, with a soft edge
  const f=lv[0],fo=mkCanvas(w,h),fx=cctx(fo),fid=fx.createImageData(w,h);
  for(let i=0;i<w*h;i++){fid.data[i*4]=f.img[i*3];fid.data[i*4+1]=f.img[i*3+1];fid.data[i*4+2]=f.img[i*3+2];fid.data[i*4+3]=255;}fx.putImageData(fid,0,0);
  const up=mkCanvas(cw,ch),ux=cctx(up);ux.imageSmoothingQuality='high';ux.drawImage(fo,0,0,cw,ch);
  const mk=mkCanvas(w,h),mx=cctx(mk),mid=mx.createImageData(w,h);for(let i=0;i<w*h;i++)mid.data[i*4+3]=lv[0].hole[i]?255:0;mx.putImageData(mid,0,0);
  const mu=mkCanvas(cw,ch),mux=cctx(mu);mux.imageSmoothingQuality='high';mux.drawImage(mk,0,0,cw,ch);
  const orig=cctx(crop).getImageData(0,0,cw,ch),od=orig.data,ud=cctx(up).getImageData(0,0,cw,ch).data,md=cctx(mu).getImageData(0,0,cw,ch).data;
  const base=new Uint8ClampedArray(od),sxx=w/cw,syy=h/ch;
  for(let i=0;i<cw*ch;i++){let a=Math.max(0,Math.min(1,(md[i*4+3]/255-0.25)/0.5));if(holeA[((i/cw|0)+cy0)*W+(i%cw)+cx0])a=1;
    if(a>0){let r=ud[i*4],g=ud[i*4+1],b=ud[i*4+2];
      if(s<1&&nn0){const x=i%cw,y=(i/cw)|0,lx=Math.min(w-1,Math.floor(x*sxx)),ly=Math.min(h-1,Math.floor(y*syy)),c=ly*w+lx,q=nn0.v[c];
        if(lv[0].hole[c]&&q){const qx=q%w,qy=(q/w)|0,X=Math.round((qx+0.5)/sxx+(x-(lx+0.5)/sxx)),Y=Math.round((qy+0.5)/syy+(y-(ly+0.5)/syy));
          if(X>=0&&Y>=0&&X<cw&&Y<ch){const k=(Y*cw+X)*4;r=base[k]*0.85+r*0.15;g=base[k+1]*0.85+g*0.15;b=base[k+2]*0.85+b*0.15;}}}
      od[i*4]=od[i*4]*(1-a)+r*a;od[i*4+1]=od[i*4+1]*(1-a)+g*a;od[i*4+2]=od[i*4+2]*(1-a)+b*a;od[i*4+3]=Math.max(od[i*4+3],a*255);}}
  cctx(cv).putImageData(orig,cx0,cy0);return true;
}
function orFill(){
  const l=doc.layers.find(x=>OR&&x.id===OR.lid);if(!OR||!l||!OR.any){toast('Paint over what you want to remove first, or tap Select people');return;}
  toast('Removing and rebuilding the background... please wait');
  setTimeout(()=>{try{
    const W=OR.W,H=OR.H,d=cctx(OR.hc).getImageData(0,0,W,H).data,hole=new Uint8Array(W*H);for(let i=0;i<W*H;i++)hole[i]=d[i*4+3]>127?1:0;
    const ok=orInpaint(l.canvas,hole,S.orm.grow);
    if(!ok){toast('That area is too big to rebuild. Paint a smaller part.');return;}
    touch(l);commit('Remove object');OR=null;redraw();renderOpts();toast('Done. Undo (Ctrl+Z) if you do not like it.');
  }catch(e){console.error(e);toast('Could not fill that area');}},40);
}
ACT.removeObject=()=>{if(!orLayer())return;setTool('objremove');};
ACT.orPeople=()=>{const l=orLayer();if(!l)return;orInit(l);toast('Looking for people...');setTimeout(async()=>{try{const r=await brPerson(l.canvas);if(r){orAddAlpha(l,r.alpha);toast('Selected '+(r.faces>1?r.faces+' people':'a person')+'. Paint more with the brush or tap Remove.');}else toast('No person found. Paint over it with the brush.');}catch(e){console.error(e);toast('Could not find people');}},30);};
ACT.orSubject=()=>{const l=orLayer();if(!l)return;orInit(l);toast('Finding the main subject...');setTimeout(()=>{try{const r=cut_removeBackground(l.canvas,{subject:'center'});orAddAlpha(l,r.alpha);toast('Selected. Tap Remove, or paint more.');}catch(e){toast('Could not find a subject');}},30);};
ACT.orFill=orFill;
ACT.orUndo=()=>{if(!OR||!OR.stack.length){toast('Nothing to undo');return;}cctx(OR.hc).putImageData(OR.stack.pop(),0,0);orTint(doc.layers.find(x=>x.id===OR.lid));};
ACT.orClear=()=>{if(!OR)return;orPush();cctx(OR.hc).clearRect(0,0,OR.W,OR.H);orTint(doc.layers.find(x=>x.id===OR.lid));};
ACT.orCancel=()=>{OR=null;setTool('move');redraw();};
TOOLS.objremove={
  opts:()=>'<button class="primary" data-act="orPeople" title="Find the people in the picture">Select people</button><button data-act="orSubject" title="Find the main object">Select subject</button>'+SIZE_OPT()+rng('Grow','o-orgrow',0,40,S.orm.grow)
    +'<button data-act="orUndo">Undo</button><button data-act="orClear">Clear</button><button class="primary" data-act="orFill">Remove</button><button data-act="orCancel">Cancel</button>',
  down(p){const l=orLayer();if(!l)return;orInit(l);drag={k:'x',tool:'objremove',l,pts:[toLocal(l,p)],dpts:[p]};},
  move(p){const d=drag;if(!d||d.tool!=='objremove')return;d.pts.push(toLocal(d.l,p));d.dpts.push(p);redraw();},
  over(o,z){if(OR&&OR.tint){const l=doc.layers.find(x=>x.id===OR.lid);if(l&&OR.tintL[0]===l.x&&OR.tintL[1]===l.y&&OR.tintL[2]===l.r&&OR.tintL[3]===l.s)o.drawImage(OR.tint,0,0);}
    const d=drag;if(d&&d.tool==='objremove')overStroke(o,z,'rgba(255,50,70,.55)');},
  up(d){const l=d.l;orInit(l);orPush();const x=cctx(OR.hc),r=Math.max(1,S.aux.size/2/l.s);x.save();x.strokeStyle='#fff';x.fillStyle='#fff';x.lineWidth=r*2;x.lineCap=x.lineJoin='round';x.beginPath();d.pts.forEach((q,i)=>i?x.lineTo(q.x,q.y):x.moveTo(q.x,q.y));if(d.pts.length===1)x.lineTo(d.pts[0].x+0.01,d.pts[0].y);x.stroke();x.restore();orTint(l);},
  leave(){}
};
BRUSHY.objremove='aux';CURSORS.objremove='crosshair';
Object.assign(ICONS,{objremove:'<circle cx="9" cy="9" r="4"/><path d="M3 20c0-3 2.5-5 6-5s6 2 6 5"/><path d="M15 5l6 6M21 5l-6 6"/>'});
{const g=TOOLGROUPS.find(x=>x.id==='wand');if(g)g.v.splice(3,0,V('objremove','Remove Object','','objremove'));}
$('#opts').addEventListener('input',e=>{if(e.target.id==='o-orgrow')S.orm.grow=+e.target.value;});
