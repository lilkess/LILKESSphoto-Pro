/* ===== Select menu and Image menu, Photoshop style ===== */

/* ---------- selection helpers ---------- */
function selAlphaArr(sel){
  const d=cctx(sel.c).getImageData(0,0,doc.w,doc.h).data,a=new Uint8Array(doc.w*doc.h);
  for(let i=0;i<a.length;i++)a[i]=d[i*4+3];return a;
}
function alphaToCanvas(a){
  const c=mkCanvas(doc.w,doc.h),x=cctx(c),id=x.createImageData(doc.w,doc.h),d=id.data;
  for(let i=0;i<a.length;i++){const v=a[i];if(v){d[i*4]=d[i*4+1]=d[i*4+2]=255;d[i*4+3]=v;}}
  x.putImageData(id,0,0);return c;
}
/* put an alpha array in as the selection (used for live previews; does not touch the "reselect" memory) */
function previewSel(a){S.sel=selScan(alphaToCanvas(a));redraw();}
function flatData(){const c=flatCanvas(1,null);return cctx(c).getImageData(0,0,doc.w,doc.h).data;}
/* a dialog that previews on the selection. compute(origAlphaOrNull, root) returns an alpha array. */
function selDialog(title,body,compute,o){
  if(!needDoc())return;
  o=o||{};
  if(o.needSel&&!S.sel){toast('Make a selection first');return;}
  const orig=S.sel,oa=orig?selAlphaArr(orig):null;let done=false;
  modalOpen(title,body,[{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
    const r=run($('#mbody'));if(!r)return false;done=true;modalCancel=null;if(orig)S.lastSel=orig;
    if(o.after)o.after(r);
  }}],root=>{
    modalCancel=()=>{if(!done){S.sel=orig;redraw();}};
    eBind(root,()=>run(root));run(root);
    if(o.mount)o.mount(root,()=>run(root));
  },{side:true});
  function run(root){
    let a;try{a=compute(oa,root);}catch(err){console.error(err);return null;}
    if(!a)return null;
    let any=false;for(let i=0;i<a.length;i+=7){if(a[i]){any=true;break;}}
    if(!any){let s=0;for(let i=0;i<a.length;i++)s|=a[i];if(!s){S.sel=null;redraw();return a;}}
    previewSel(a);return a;
  }
}
/* signed distance to the selection edge, only in the area near the selection: negative inside, positive outside */
function selSigned(a,pad){
  const W=doc.w,H=doc.h;let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(a[y*W+x]>=128){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
  if(x1<0)return null;
  x0=Math.max(0,x0-pad);y0=Math.max(0,y0-pad);x1=Math.min(W-1,x1+pad);y1=Math.min(H-1,y1+pad);
  const w=x1-x0+1,h=y1-y0+1,A=new Float32Array(w*h),B=new Float32Array(w*h),INF=1e20;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const ins=a[(y+y0)*W+x+x0]>=128,i=y*w+x;A[i]=ins?0:INF;B[i]=ins?INF:0;}
  edt2(A,w,h);edt2(B,w,h);
  const s=new Float32Array(w*h);
  for(let i=0;i<w*h;i++)s[i]=A[i]===0?-(Math.sqrt(B[i])-0.5):Math.sqrt(A[i])-0.5;
  return {s,x0,y0,w,h};
}
function morphBySigned(a,lo,hi){ // keep pixels whose signed distance is within [lo,hi]
  const sd=selSigned(a,Math.ceil(Math.max(Math.abs(lo),Math.abs(hi)))+3),out=new Uint8Array(a.length);if(!sd)return out;
  for(let y=0;y<sd.h;y++)for(let x=0;x<sd.w;x++){
    const s=sd.s[y*sd.w+x],v=clamp(s-lo+0.5,0,1)*clamp(hi-s+0.5,0,1);
    if(v>0)out[(y+sd.y0)*doc.w+x+sd.x0]=Math.round(v*255);
  }
  return out;
}
const needSelAct=f=>()=>{if(!needDoc())return;if(!S.sel){toast('Make a selection first');return;}f();};
function applySelAlpha(a){const o=S.sel;S.sel=selScan(alphaToCanvas(a));if(o)S.lastSel=o;redraw();}

/* ---------- Modify: Border, Expand, Contract ---------- */
ACT.selBorder=needSelAct(()=>askNumber('Border selection','Width (px)',10,1,200,v=>applySelAlpha(morphBySigned(selAlphaArr(S.sel),-v/2,v/2))));
ACT.selExpand=needSelAct(()=>askNumber('Expand selection','Expand by (px)',10,1,500,v=>applySelAlpha(morphBySigned(selAlphaArr(S.sel),-1e6,v))));
ACT.selContract=needSelAct(()=>askNumber('Contract selection','Contract by (px)',10,1,500,v=>applySelAlpha(morphBySigned(selAlphaArr(S.sel),-1e6,-v))));

/* ---------- Grow and Similar (by colour) ---------- */
function selColorSet(sel,data){
  const W=doc.w,H=doc.h,pts=[];let n=0;
  const a=selAlphaArr(sel);for(let i=0;i<a.length;i++)if(a[i]>=128)n++;
  const step=Math.max(1,Math.floor(n/400));let k=0;
  for(let i=0;i<a.length;i++)if(a[i]>=128){if((k++%step)===0)pts.push([data[i*4],data[i*4+1],data[i*4+2]]);}
  // cluster into at most 24 representative colours
  const q=new Map();pts.forEach(p=>{const key=(p[0]>>4)+','+(p[1]>>4)+','+(p[2]>>4);const e=q.get(key);if(e){e.n++;e.r+=p[0];e.g+=p[1];e.b+=p[2];}else q.set(key,{n:1,r:p[0],g:p[1],b:p[2]});});
  return Array.from(q.values()).sort((x,y)=>y.n-x.n).slice(0,24).map(e=>[e.r/e.n,e.g/e.n,e.b/e.n]);void W;void H;
}
function selSimilarCore(contiguous){
  if(!S.sel){toast('Make a selection first');return;}
  const W=doc.w,H=doc.h,data=flatData(),cols=selColorSet(S.sel,data),tol=(S.wand&&S.wand.tol!=null?S.wand.tol:32)*1.7+6,a=selAlphaArr(S.sel);
  const near=i=>{const r=data[i*4],g=data[i*4+1],b=data[i*4+2];for(const c of cols){const d=Math.hypot(r-c[0],g-c[1],b-c[2]);if(d<=tol)return true;}return false;};
  const out=Uint8Array.from(a);
  if(!contiguous){for(let i=0;i<out.length;i++)if(!out[i]&&near(i))out[i]=255;}
  else{
    const q=[];for(let i=0;i<a.length;i++)if(a[i]>=128)q.push(i);
    let h=0;
    while(h<q.length){
      const i=q[h++],x=i%W,y=(i/W)|0;
      for(const j of [x>0?i-1:-1,x<W-1?i+1:-1,y>0?i-W:-1,y<H-1?i+W:-1]){if(j<0||out[j])continue;if(near(j)){out[j]=255;q.push(j);}}
    }
  }
  applySelAlpha(out);
}
ACT.selGrowColor=()=>{if(needDoc())selSimilarCore(true);};
ACT.selSimilar=()=>{if(needDoc())selSimilarCore(false);};

/* ---------- Color Range ---------- */
const CR_RANGES=[['sampled','Sampled Colors'],['reds','Reds'],['yellows','Yellows'],['greens','Greens'],['cyans','Cyans'],['blues','Blues'],['magentas','Magentas'],['highlights','Highlights'],['midtones','Midtones'],['shadows','Shadows'],['skin','Skin Tones']];
const CR_HUE={reds:0,yellows:60,greens:120,cyans:180,blues:240,magentas:300};
function openColorRange(){
  if(!needDoc())return;
  const data=flatData(),W=doc.w,H=doc.h;
  const px=(x,y)=>{x=clamp(Math.round(x),0,W-1);y=clamp(Math.round(y),0,H-1);let r=0,g=0,b=0,n=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=clamp(x+dx,0,W-1),yy=clamp(y+dy,0,H-1),o=(yy*W+xx)*4;r+=data[o];g+=data[o+1];b+=data[o+2];n++;}return [r/n,g/n,b/n];};
  let samples=[px(W/2,H/2)],stageHook=null;
  const sm=t=>t*t*(3-2*t);
  selDialog('Color Range','<div class="saform"><label class="fld erow">Select<select id="cr-r">'+CR_RANGES.map(r=>'<option value="'+r[0]+'">'+r[1]+'</option>').join('')+'</select></label>'
    +eRng('cr-f','Fuzziness',0,200,40,1,'')+'<label class="row"><input type="checkbox" id="cr-i"> Invert</label><div class="muted" id="cr-h" style="margin-top:6px">Click the picture to pick a colour. Shift-click adds more colours.</div></div>',
    (oa,root)=>{
      const mode=$('#cr-r',root).value,fz=eNum('cr-f'),inv=$('#cr-i',root).checked,out=new Uint8Array(W*H);
      const T=Math.max(1,fz/200*441*0.55);
      $('#cr-h',root).style.display=mode==='sampled'?'':'none';
      for(let i=0;i<W*H;i++){
        const o=i*4,r=data[o],g=data[o+1],b=data[o+2],al=data[o+3];
        if(!al){continue;}
        let v=0;
        if(mode==='sampled'){let d=1e9;for(const s of samples){const dd=Math.hypot(r-s[0],g-s[1],b-s[2]);if(dd<d)d=dd;}v=clamp((T-d)/(0.4*T),0,1);if(fz===0)v=d<2?1:0;}
        else{
          const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(0.299*r+0.587*g+0.114*b);
          if(mode==='highlights')v=clamp((l-(190-fz*0.3))/30,0,1);
          else if(mode==='shadows')v=clamp(((65+fz*0.3)-l)/30,0,1);
          else if(mode==='midtones')v=clamp(1-Math.abs(l-128)/(40+fz*0.4),0,1);
          else{
            let h=0;const dd=mx-mn;
            if(dd>0){if(mx===r)h=((g-b)/dd+6)%6;else if(mx===g)h=(b-r)/dd+2;else h=(r-g)/dd+4;h*=60;}
            const sat=mx?dd/mx:0;
            if(mode==='skin'){const dh=Math.min(Math.abs(h-22),360-Math.abs(h-22));v=sat>0.15&&sat<0.75&&mx>70?clamp(1-dh/(18+fz*0.2),0,1):0;}
            else{const dh=Math.min(Math.abs(h-CR_HUE[mode]),360-Math.abs(h-CR_HUE[mode]));v=sat>0.12?clamp(1-dh/(30+fz*0.25),0,1)*clamp(sat/0.3,0,1):0;}
          }
        }
        v=sm(v);if(inv)v=1-v;
        out[i]=Math.round(v*255*(al/255));
      }
      if(oa)for(let i=0;i<out.length;i++)out[i]=Math.min(out[i],oa[i]);
      return out;
    },{mount:(root,rerun)=>{
      const v=document.getElementById('view'),stage=document.getElementById('stage');
      stageHook=e=>{
        const r=v.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)return;
        e.stopPropagation();e.preventDefault();
        const p=toDoc(e),c=px(p.x,p.y);
        if(e.shiftKey)samples.push(c);else samples=[c];
        $('#cr-r',root).value='sampled';rerun();
      };
      stage.addEventListener('pointerdown',stageHook,true);
      const old=modalCancel,off=()=>stage.removeEventListener('pointerdown',stageHook,true);
      modalCancel=()=>{off();if(old)old();};
      // also drop the hook after OK
      const okBtn=$$('#mfoot button').find(b=>b.textContent==='OK');if(okBtn)okBtn.addEventListener('click',off);
    }});
}
ACT.colorRange=openColorRange;

/* ---------- Select Sky (basic) ---------- */
ACT.selSky=()=>{
  if(!needDoc())return;
  const W=doc.w,H=doc.h,d=flatData(),sky=new Uint8Array(W*H),q=[];
  const cand=i=>{const r=d[i*4],g=d[i*4+1],b=d[i*4+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=0.299*r+0.587*g+0.114*b;return d[i*4+3]>0&&((b>=r+8&&b>=g-8)||(l>185&&mx-mn<40)||(l>150&&b>=r&&b>=g&&mx-mn<60));};
  for(let x=0;x<W;x++){for(let y=0;y<Math.min(6,H);y++){const i=y*W+x;if(cand(i)&&!sky[i]){sky[i]=1;q.push(i);break;}}}
  let h=0;
  while(h<q.length){
    const i=q[h++],x=i%W,y=(i/W)|0;
    for(const j of [x>0?i-1:-1,x<W-1?i+1:-1,y>0?i-W:-1,y<H-1?i+W:-1]){
      if(j<0||sky[j]||!cand(j))continue;
      const dd=Math.abs(d[i*4]-d[j*4])+Math.abs(d[i*4+1]-d[j*4+1])+Math.abs(d[i*4+2]-d[j*4+2]);
      if(dd<54){sky[j]=1;q.push(j);}
    }
  }
  if(q.length<W*H*0.01){toast('No sky found. Try the Color Range with Blues, or use the Lasso.');return;}
  const out=new Uint8Array(W*H);for(let i=0;i<out.length;i++)out[i]=sky[i]?255:0;
  const c=alphaToCanvas(out),id=cctx(c).getImageData(0,0,W,H),dd=id.data;boxBlur(dd,W,H,2,2);for(let i=3;i<dd.length;i+=4)dd[i]=dd[i]>110?255:0;
  cctx(c).putImageData(id,0,0);setSelection(c,'new');toast('Sky selected (basic detection)');
};

/* ---------- Select and Mask ---------- */
function openSelectMask(){
  if(!needDoc())return;
  if(!S.sel){toast('Make a selection first');return;}
  selDialog('Select and Mask','<div class="muted" style="margin-bottom:6px">Clean up the edge of the selection.</div>'
    +eRng('sm-s','Smooth',0,40,0,1,'')+eRng('sm-f','Feather',0,150,0,0.5,' px')+eRng('sm-c','Contrast',0,100,0,1,'%')+eRng('sm-e','Shift Edge',-100,100,0,1,'%')
    +'<label class="fld erow">Output To<select id="sm-o"><option value="sel">Selection</option><option value="mask">Layer Mask</option><option value="new">New Layer with Layer Mask</option></select></label>',
    (oa,root)=>{
      const W=doc.w,H=doc.h,sm=eNum('sm-s'),fe=eNum('sm-f'),ct=eNum('sm-c')/100,sh=eNum('sm-e')/100;
      let c=alphaToCanvas(oa),id=cctx(c).getImageData(0,0,W,H),d=id.data;
      if(sm>0){boxBlur(d,W,H,Math.max(1,Math.round(sm)),2);for(let i=3;i<d.length;i+=4)d[i]=d[i]>127?255:0;}
      if(sh!==0){ // grow or shrink a little by blurring then moving the threshold
        const r=Math.max(1,Math.round(Math.abs(sh)*12)),tmp=new Uint8ClampedArray(d);boxBlur(tmp,W,H,r,1);
        const thr=sh>0?30:225;for(let i=3;i<d.length;i+=4)d[i]=tmp[i]>thr?255:0;
      }
      if(fe>0)boxBlur(d,W,H,Math.max(1,Math.round(fe*0.85)),3);
      if(ct>0){const g=1+ct*14;for(let i=3;i<d.length;i+=4)d[i]=clamp((d[i]-127.5)*g+127.5,0,255);}
      const out=new Uint8Array(W*H);for(let i=0;i<out.length;i++)out[i]=d[i*4+3];
      return out;
    },{needSel:true,after:()=>{
      const mode=$('#sm-o')&&$('#sm-o').value;
      if(mode==='sel'||!mode||!S.sel)return;
      const l=active();if(!l||l.type==='adjust')return;
      const target=mode==='new'?dupLayer(l,0):l;
      const sa=selAlphaCanvasLocal(target),m=mkCanvas(target.canvas.width,target.canvas.height);cctx(m).drawImage(sa,0,0);
      if(target.mask){const x=cctx(m);x.globalCompositeOperation='destination-in';x.drawImage(target.mask,0,0);}
      target.mask=m;if(mode==='new')target.name=l.name+' (masked)';touchMask(target);touch(target);selClearNow();commit('Select and Mask');
    }});
}
ACT.selMask=openSelectMask;

/* ---------- Transform Selection ---------- */
ACT.selTransform=()=>{
  selDialog('Transform Selection',eRng('ts-w','Width',10,400,100,1,'%')+eRng('ts-h','Height',10,400,100,1,'%')+eRng('ts-r','Rotate',-180,180,0,0.5,'°')+eRng('ts-x','Move across',-500,500,0,1,' px')+eRng('ts-y','Move down',-500,500,0,1,' px')+'<label class="row"><input type="checkbox" id="ts-l" checked> Keep proportions</label>',
    (oa,root)=>{
      let kw=eNum('ts-w'),kh=eNum('ts-h');
      if($('#ts-l',root).checked){const ev=root._ev&&root._ev.target&&root._ev.target.id;if(ev==='ts-h')kw=kh;else kh=kw;$('#ts-w',root).value=kw;$('#ts-h',root).value=kh;$('#ts-w_v',root).textContent=kw+'%';$('#ts-h_v',root).textContent=kh+'%';}
      const b=S.sel.bbox,cx=b.x+b.w/2,cy=b.y+b.h/2,c=mkCanvas(doc.w,doc.h),x=cctx(c);
      x.translate(cx+eNum('ts-x'),cy+eNum('ts-y'));x.rotate(eNum('ts-r')*Math.PI/180);x.scale(kw/100,kh/100);x.drawImage(S.selSrc||alphaToCanvas(oa),-cx,-cy);
      const d=x.getImageData(0,0,doc.w,doc.h).data,out=new Uint8Array(doc.w*doc.h);for(let i=0;i<out.length;i++)out[i]=d[i*4+3];return out;
    },{needSel:true,mount:root=>{root.addEventListener('input',e=>{root._ev=e;},true);}});
};

/* ---------- Save Selection / Load Selection ---------- */
ACT.saveSel=()=>{
  if(!needDoc())return;if(!S.sel){toast('Make a selection first');return;}
  const L=exa('alpha');
  modalOpen('Save Selection','<div class="saform"><label class="fld erow">Channel<select id="ss-c"><option value="-1">New</option>'+L.map((a,i)=>'<option value="'+i+'">'+esc(a.name)+'</option>').join('')+'</select></label><label class="fld erow">Name<input type="text" id="ss-n" value="Alpha '+(L.length+1)+'"></label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const c=S.sel.c,t=mkCanvas(32,32),x=cctx(t);x.fillStyle='#000';x.fillRect(0,0,32,32);const k=Math.min(32/c.width,32/c.height);
      const w=mkCanvas(c.width,c.height),wx=cctx(w);wx.fillStyle='#fff';wx.fillRect(0,0,c.width,c.height);wx.globalCompositeOperation='destination-in';wx.drawImage(c,0,0);
      x.drawImage(w,0,0,c.width*k,c.height*k);
      const idx=+$('#ss-c').value,e={name:$('#ss-n').value.trim()||'Alpha',url:c.toDataURL(),thumb:t.toDataURL()};
      if(idx>=0)L[idx]=e;else L.push(e);
      commit('Save selection');if(PANELS.channels&&PANELS.channels.render)PANELS.channels.render();toast('Selection saved');
    }}],root=>{const s=$('#ss-c');s.onchange=()=>{const i=+s.value;if(i>=0)$('#ss-n').value=L[i].name;};$('#ss-n').select();});
};
ACT.loadSel=()=>{
  if(!needDoc())return;const L=exa('alpha');
  if(!L.length){toast('No saved selections yet. Use Select > Save Selection first.');return;}
  modalOpen('Load Selection','<div class="saform"><label class="fld erow">Channel<select id="ls-c">'+L.map((a,i)=>'<option value="'+i+'">'+esc(a.name)+'</option>').join('')+'</select></label><label class="row"><input type="checkbox" id="ls-i"> Invert</label>'
    +'<div class="h" style="margin-top:8px">Operation</div><div class="col"><label class="row"><input type="radio" name="ls-o" value="new" checked> New Selection</label><label class="row"><input type="radio" name="ls-o" value="add"> Add to Selection</label><label class="row"><input type="radio" name="ls-o" value="sub"> Subtract from Selection</label><label class="row"><input type="radio" name="ls-o" value="int"> Intersect with Selection</label></div></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const a=L[+$('#ls-c').value],op=$('input[name=ls-o]:checked').value,inv=$('#ls-i').checked;
      const im=new Image();im.onload=()=>{
        const c=mkCanvas(doc.w,doc.h),x=cctx(c);x.drawImage(im,0,0,doc.w,doc.h);
        if(inv){const id=x.getImageData(0,0,doc.w,doc.h),d=id.data;for(let i=3;i<d.length;i+=4)d[i]=255-d[i];x.putImageData(id,0,0);}
        setSelection(c,op);
      };im.src=a.url;
    }}]);
};

/* ---------- Find Layers ---------- */
ACT.findLayers=()=>{
  if(!needDoc())return;
  modalOpen('Find Layers','<input type="search" id="fl-q" placeholder="Layer name" style="width:100%"><div id="fl-l" class="selist"></div>',[{label:'Close'}],root=>{
    const q=$('#fl-q',root),list=$('#fl-l',root);
    const paint=()=>{const w=q.value.toLowerCase();list.innerHTML=doc.layers.slice().reverse().filter(l=>!w||l.name.toLowerCase().indexOf(w)>=0).map(l=>'<button class="seit" data-id="'+l.id+'"><span>'+esc(l.name)+'</span><kbd>'+l.type+'</kbd></button>').join('')||'<div class="muted" style="padding:10px">No layers match</div>';};
    q.addEventListener('input',paint);
    list.addEventListener('click',e=>{const b=e.target.closest('.seit');if(b){selectLayer(+b.dataset.id);closeModal();}});
    paint();q.focus();
  });
};

/* ---------- the Select menu ---------- */
(function(){
  const M=MENUS.find(m=>m.label==='Select');
  M.items=[
    mi('All','Ctrl+A','selAll'),mi('Deselect','Ctrl+D','selNone'),mi('Reselect','Ctrl+Shift+D','reselect'),mi('Inverse','Ctrl+Shift+I','selInv'),SEP,
    mi('Find Layers...','Ctrl+Alt+Shift+F','findLayers'),SEP,
    mi('Color Range...','','colorRange'),mi('Subject','','selSubject'),mi('Sky','','selSky'),SEP,
    mi('Select and Mask...','Ctrl+Alt+R','selMask',{dis:()=>!doc||!S.sel}),SEP,
    sub('Modify',[mi('Border...','','selBorder'),mi('Smooth...','','selSmooth'),mi('Expand...','','selExpand'),mi('Contract...','','selContract'),mi('Feather...','Shift+F6','selFeather')]),
    mi('Grow','','selGrowColor'),mi('Similar','','selSimilar'),mi('Transform Selection','','selTransform',{dis:()=>!doc||!S.sel}),
    dynCheck(mi('Edit in Quick Mask Mode','Q','quickMask'),()=>S.qm),SEP,
    mi('Load Selection...','','loadSel'),mi('Save Selection...','','saveSel'),SEP,
    mi('Layer pixels','','selLayer'),mi('Make selection from path','','pathSel'),mi('Make work path from selection','','selToPath')
  ];
  function dynCheck(it,fn){it.check=fn;return it;}
})();

/* ---------- more adjustments ---------- */
const hsl2=(r,g,b)=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,d=mx-mn;let h=0,s=0;if(d){s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===r)h=((g-b)/d+(g<b?6:0));else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h*=60;}return [h,s,l];};
const hslRgb=(h,s,l)=>{h=((h%360)+360)%360;const c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs((h/60)%2-1)),m=l-c/2;let r=0,g=0,b=0;if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}return [(r+m)*255,(g+m)*255,(b+m)*255];};
defFx('photof','adjust','Photo Filter',[P('h','Filter colour (hue)',0,360,30),P('d','Density',0,100,25),P('l','Preserve luminosity (1 = on)',0,1,1)],(img,p)=>{
  const d=cp(img),f=hslRgb(p.h,0.9,0.5),fl=(0.299*f[0]+0.587*f[1]+0.114*f[2])||1,k=p.d/100;
  for(let i=0;i<d.length;i+=4){
    const r=d[i],g=d[i+1],b=d[i+2],l0=0.299*r+0.587*g+0.114*b;
    let tr=r*f[0]/fl,tg=g*f[1]/fl,tb=b*f[2]/fl;
    let nr=r+(tr-r)*k,ng=g+(tg-g)*k,nb=b+(tb-b)*k;
    if(p.l>=0.5){const l1=0.299*nr+0.587*ng+0.114*nb||1,s=l0/l1;nr*=s;ng*=s;nb*=s;}
    d[i]=nr;d[i+1]=ng;d[i+2]=nb;
  }
  return mkImg(d,img.width,img.height);
});
defFx('repl','adjust','Replace Color',[P('f','From hue',0,360,0),P('z','Fuzziness',1,100,40),P('h','Hue shift',-180,180,0),P('s','Saturation',-100,100,0),P('l','Lightness',-100,100,0)],(img,p)=>{
  const d=cp(img),sp=Math.max(5,p.z*1.8);
  for(let i=0;i<d.length;i+=4){
    const q=hsl2(d[i],d[i+1],d[i+2]);if(q[1]<0.06)continue;
    const dh=Math.min(Math.abs(q[0]-p.f),360-Math.abs(q[0]-p.f)),w0=clamp(1-dh/sp,0,1),w=w0*w0*(3-2*w0)*clamp(q[1]/0.2,0,1);
    if(w<=0)continue;
    const h=q[0]+p.h*w,s=clamp(q[1]*(1+p.s/100*w),0,1),l=clamp(q[2]+p.l/100*w*(p.l>0?1-q[2]:q[2]),0,1),o=hslRgb(h,s,l);
    d[i]=o[0];d[i+1]=o[1];d[i+2]=o[2];
  }
  return mkImg(d,img.width,img.height);
});
defFx('gmap','adjust','Gradient Map',[P('r','Reverse (1 = on)',0,1,0)],(img,p)=>{
  const d=cp(img),g=S.grad&&S.grad.g?S.grad.g:null;
  let lut;
  try{lut=fxr_gradLUT(g?gFlatten(g):[{p:0,c:'#000000'},{p:1,c:'#ffffff'}],p.r>=0.5);}catch(e){lut=fxr_gradLUT([{p:0,c:'#000000'},{p:1,c:'#ffffff'}],p.r>=0.5);}
  for(let i=0;i<d.length;i+=4){
    const l=(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])/255,k=Math.min(511,Math.round(l*511))*4,a=lut[k+3]/255;
    d[i]=d[i]+(lut[k]-d[i])*a;d[i+1]=d[i+1]+(lut[k+1]-d[i+1])*a;d[i+2]=d[i+2]+(lut[k+2]-d[i+2])*a;
  }
  return mkImg(d,img.width,img.height);
});
defFx('equalize','adjust','Equalize',[],(img)=>{
  const d=cp(img),h=new Float64Array(256);let n=0;
  for(let i=0;i<d.length;i+=4){if(d[i+3]<10)continue;h[Math.round(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])]++;n++;}
  if(!n)return mkImg(d,img.width,img.height);
  const cdf=new Float64Array(256);let c=0;for(let i=0;i<256;i++){c+=h[i];cdf[i]=c/n*255;}
  for(let i=0;i<d.length;i+=4){const l=Math.round(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]),t=cdf[l],k=l>0?t/l:1;d[i]=Math.min(255,d[i]*k+(l===0?t:0));d[i+1]=Math.min(255,d[i+1]*k+(l===0?t:0));d[i+2]=Math.min(255,d[i+2]*k+(l===0?t:0));}
  return mkImg(d,img.width,img.height);
},{immediate:true});
defFx('chmix','adjust','Channel Mixer',[P('rr','Red: Red %',-200,200,100),P('rg','Red: Green %',-200,200,0),P('rb','Red: Blue %',-200,200,0),P('gr','Green: Red %',-200,200,0),P('gg','Green: Green %',-200,200,100),P('gb','Green: Blue %',-200,200,0),P('br','Blue: Red %',-200,200,0),P('bg','Blue: Green %',-200,200,0),P('bb','Blue: Blue %',-200,200,100),P('m','Monochrome (1 = on)',0,1,0)],(img,p)=>{
  const d=cp(img);
  for(let i=0;i<d.length;i+=4){
    const r=d[i],g=d[i+1],b=d[i+2];
    let nr=(r*p.rr+g*p.rg+b*p.rb)/100,ng=(r*p.gr+g*p.gg+b*p.gb)/100,nb=(r*p.br+g*p.bg+b*p.bb)/100;
    if(p.m>=0.5){nr=ng=nb=nr;}
    d[i]=nr;d[i+1]=ng;d[i+2]=nb;
  }
  return mkImg(d,img.width,img.height);
});

/* ---------- Image menu: Mode ---------- */
let modeLayer=()=>doc&&doc.layers.find(l=>l.type==='adjust'&&l.adj&&l.adj.id==='desat'&&l.modeTag);
ACT.modeGray=()=>{
  if(!needDoc())return;if(modeLayer()){toast('Already in Grayscale');return;}
  ACT.adjLayer('desat');const l=active();if(l){l.name='Grayscale (mode)';l.modeTag=true;l.locked=false;}
  doc.layers.push(doc.layers.splice(doc.layers.indexOf(l),1)[0]);doc.active=l.id;commit('Mode: Grayscale');refreshLayers();toast('Grayscale: an adjustment layer on top turns everything gray. Switch to RGB Color to remove it.');
};
ACT.modeRGB=()=>{
  if(!needDoc())return;const l=modeLayer();if(!l){toast('Already in RGB Color');return;}
  doc.layers.splice(doc.layers.indexOf(l),1);doc.active=doc.layers.length?doc.layers[doc.layers.length-1].id:null;commit('Mode: RGB Color');refreshLayers();redraw();
};

/* ---------- Reveal All ---------- */
ACT.revealAll=()=>{
  if(!needDoc())return;
  let x0=0,y0=0,x1=doc.w,y1=doc.h;
  for(const l of doc.layers){
    if(l.type==='adjust'||!l.canvas)continue;
    const w=l.canvas.width*l.s/2,h=l.canvas.height*l.s/2,c=Math.cos(l.r),s=Math.sin(l.r);
    for(const q of [[-w,-h],[w,-h],[w,h],[-w,h]]){const X=l.x+q[0]*c-q[1]*s,Y=l.y+q[0]*s+q[1]*c;x0=Math.min(x0,X);y0=Math.min(y0,Y);x1=Math.max(x1,X);y1=Math.max(y1,Y);}
  }
  if(x0>=-0.5&&y0>=-0.5&&x1<=doc.w+0.5&&y1<=doc.h+0.5){toast('Everything is already inside the canvas');return;}
  growDocTo(x0,y0,x1,y1);commit('Reveal All');fitView();redraw();
};

/* ---------- Arbitrary rotation ---------- */
ACT.rotArbitrary=()=>{
  if(!needDoc())return;
  if(((doc.extra&&doc.extra.boards)||[]).length){toast('Remove the artboards first. Rotating the whole canvas with artboards is not supported.');return;}
  askNumber('Rotate Canvas','Angle (degrees, positive = clockwise)',15,-359,359,v=>{
    const t=v*Math.PI/180,c=Math.cos(t),s=Math.sin(t),W=doc.w,H=doc.h,nw=Math.ceil(Math.abs(W*c)+Math.abs(H*s)),nh=Math.ceil(Math.abs(W*s)+Math.abs(H*c));
    for(const l of doc.layers){const px=l.x-W/2,py=l.y-H/2;l.x=nw/2+px*c-py*s;l.y=nh/2+px*s+py*c;l.r+=t;l._mc=null;l._fc=null;}
    doc.w=nw;doc.h=nh;doc.guides=[];S.sel=null;resizeStage();commit('Rotate canvas');fitView();redraw();
  });
};

/* ---------- Trim ---------- */
ACT.trimDialog=()=>{
  if(!needDoc())return;
  modalOpen('Trim','<div class="saform"><div class="h">Based On</div><div class="col"><label class="row"><input type="radio" name="tr-b" value="alpha" checked> Transparent Pixels</label><label class="row"><input type="radio" name="tr-b" value="tl"> Top Left Pixel Color</label><label class="row"><input type="radio" name="tr-b" value="br"> Bottom Right Pixel Color</label></div>'
    +'<div class="h" style="margin-top:8px">Trim Away</div><div class="row"><label><input type="checkbox" id="tr-t" checked> Top</label> <label><input type="checkbox" id="tr-b2" checked> Bottom</label> <label><input type="checkbox" id="tr-l" checked> Left</label> <label><input type="checkbox" id="tr-r" checked> Right</label></div></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const W=doc.w,H=doc.h,d=flatData(),mode=$('input[name=tr-b]:checked').value;
      const ref=mode==='tl'?[d[0],d[1],d[2],d[3]]:mode==='br'?[d[(W*H-1)*4],d[(W*H-1)*4+1],d[(W*H-1)*4+2],d[(W*H-1)*4+3]]:null;
      const diff=i=>mode==='alpha'?d[i*4+3]>0:(Math.abs(d[i*4]-ref[0])+Math.abs(d[i*4+1]-ref[1])+Math.abs(d[i*4+2]-ref[2])+Math.abs(d[i*4+3]-ref[3]))>6;
      let x0=W,y0=H,x1=-1,y1=-1;
      for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(diff(y*W+x)){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
      if(x1<0){toast('Nothing to trim');return;}
      if(!$('#tr-l').checked)x0=0;if(!$('#tr-r').checked)x1=W-1;if(!$('#tr-t').checked)y0=0;if(!$('#tr-b2').checked)y1=H-1;
      if(x0===0&&y0===0&&x1===W-1&&y1===H-1){toast('Nothing to trim');return;}
      applyCrop({x:x0,y:y0,w:x1-x0+1,h:y1-y0+1});
    }}]);
};

/* ---------- Duplicate ---------- */
ACT.duplicateDoc=()=>{
  if(!needDoc())return;
  modalOpen('Duplicate Image','<div class="saform"><label class="fld erow">As<input type="text" id="dd-n" value="'+esc(doc.name)+' copy"></label><label class="row"><input type="checkbox" id="dd-m"> Duplicate merged layers only</label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const name=$('#dd-n').value.trim()||doc.name+' copy',merged=$('#dd-m').checked,w=doc.w,h=doc.h,ppi=doc.ppi||72;
      const s=snapshot('Duplicate'),flat=merged?flatCanvas(1,null):null;
      startDoc(name,w,h,ppi);
      if(merged){const l=addLayer({name:'Merged',w,h});cctx(l.canvas).drawImage(flat,0,0);touch(l);}
      else restore(s);
      finishDoc();
    }}],()=>$('#dd-n').select());
};

/* ---------- Apply Image ---------- */
ACT.applyImage=()=>{
  if(!needDoc())return;
  const l0=active();if(!l0||l0.type==='adjust'){toast('Select a photo or paint layer first');return;}
  modalOpen('Apply Image','<div class="saform"><label class="fld erow">Source<select id="ai-s"><option value="merged">Merged (everything)</option>'+doc.layers.filter(l=>l.type!=='adjust').slice().reverse().map(l=>'<option value="'+l.id+'">'+esc(l.name)+'</option>').join('')+'</select></label>'
    +'<label class="row"><input type="checkbox" id="ai-i"> Invert</label><div class="h" style="margin-top:8px">Blending</div><label class="fld erow">Mode'+blendSel('ai-b','multiply')+'</label>'+eRng('ai-o','Opacity',1,100,100,1,'%')+'<label class="row"><input type="checkbox" id="ai-t"> Preserve Transparency</label></div>',
    [{label:'Cancel'},{label:'OK',primary:true,cb:()=>{
      const sv=$('#ai-s').value,src=sv==='merged'?flatCanvas(1,null):flatLayer(doc.layers.find(l=>l.id===+sv)||l0);
      let pic=cloneCanvas(src);
      if($('#ai-i').checked){const x=cctx(pic),id=x.getImageData(0,0,pic.width,pic.height),d=id.data;for(let i=0;i<d.length;i+=4){d[i]=255-d[i];d[i+1]=255-d[i+1];d[i+2]=255-d[i+2];}x.putImageData(id,0,0);}
      const l=paintTarget('Applied image');if(!l)return;
      paintDoc(l,pic,{op:eNum('ai-o')/100,blend:$('#ai-b').value,keepAlpha:$('#ai-t').checked});commit('Apply Image');
    }}]);
};

/* ---------- the Image menu ---------- */
(function(){
  const M=MENUS.find(m=>m.label==='Image');
  const chk=(it,fn)=>{it.check=fn;return it;};
  M.items=[
    sub('Mode',[chk(mi('RGB Color','','modeRGB'),()=>doc&&!modeLayer()),chk(mi('Grayscale','','modeGray'),()=>!!(doc&&modeLayer())),SEP,chk(mi('8 Bits/Channel','',()=>{}),()=>true)]),
    sub('Adjustments',[fxi('bc'),fxi('levels','Ctrl+L'),fxi('curves','Ctrl+M'),fxi('exposure'),SEP,fxi('vibrance'),fxi('huesat','Ctrl+U'),fxi('colbal','Ctrl+B'),fxi('bw','Ctrl+Alt+Shift+B'),fxi('photof'),fxi('chmix'),SEP,fxi('invert','Ctrl+I'),fxi('poster'),fxi('thresh'),fxi('gmap'),SEP,fxi('shadhi'),fxi('temp'),SEP,fxi('desat','Ctrl+Shift+U'),fxi('repl'),fxi('equalize')],{dis:()=>!doc}),
    SEP,
    fxi('autotone','Ctrl+Shift+L'),fxi('autocon','Ctrl+Alt+Shift+L'),fxi('autocol','Ctrl+Shift+B'),SEP,
    mi('Image Size...','Ctrl+Alt+I','imageSize'),mi('Canvas Size...','Ctrl+Alt+C','canvasSize'),
    sub('Image Rotation',[mi('180°','','rot180'),mi('90° Clockwise','','rotCW'),mi('90° Counter Clockwise','','rotCCW'),mi('Arbitrary...','','rotArbitrary'),SEP,mi('Flip Canvas Horizontal','','flipCH'),mi('Flip Canvas Vertical','','flipCV')],{dis:()=>!doc}),
    mi('Crop','','cropSel'),mi('Trim...','','trimDialog'),mi('Reveal All','','revealAll'),SEP,
    mi('Duplicate...','','duplicateDoc'),mi('Apply Image...','','applyImage')
  ];
  Object.keys(SHORT).forEach(k=>{if(/^(Ctrl\+Alt\+R|Ctrl\+Alt\+Shift\+F|Shift\+F6|Q)$/.test(k)&&SHORT[k]&&SHORT[k].fn&&k!=='Q')delete SHORT[k];});
  const walk=its=>its.forEach(it=>{if(it.items){const g=Object.getOwnPropertyDescriptor(it,'items');if(!(g&&g.get))walk(it.items);}else if(it.key&&it.key!=='Q'){const k=it.key.replace(/^Ctrl\+Shift\+Alt\+/,'Ctrl+Alt+Shift+');SHORT[k]=it;}});
  walk(MENUS.find(m=>m.label==='Select').items);walk(M.items);
  if(typeof applyKeyOverrides==='function')applyKeyOverrides();
})();
