/* ===== PLUGINS: install small JavaScript add-ons that add menu commands and filters ===== */
const PLUG_KEY='lk_plugins';
const PLUG_BUILTIN=[];
let PLUGS=[];const PLUG_ITEMS=[],PLUG_FILTERS=[];
const plSave=()=>{try{localStorage.setItem(PLUG_KEY,JSON.stringify(PLUGS.map(p=>({id:p.id,name:p.name,version:p.version,author:p.author,desc:p.desc,code:p.code,enabled:p.enabled}))));}catch(e){toast('Could not store the plugin list on this device');}};
const plLoad=()=>{try{return JSON.parse(localStorage.getItem(PLUG_KEY)||'[]');}catch(e){return [];}};
function plMeta(code){const g=k=>((code.match(new RegExp('@'+k+'\\s+(.+)'))||[])[1]||'').trim();return {name:g('name'),version:g('version'),author:g('author'),desc:g('description')};}
function plApi(P){
  const need=()=>{if(!doc){toast('Open a design first');return false;}return true;};
  const A={
    version:'1.0',
    toast:m=>toast(String(m)),
    get doc(){return doc;},
    layer:()=>doc?active():null,
    canvas:()=>{const l=doc?active():null;return l&&l.canvas||null;},
    getPixels:()=>{const l=need()&&active();if(!l||!l.canvas)return null;ensureRaster(l);return cctx(l.canvas).getImageData(0,0,l.canvas.width,l.canvas.height);},
    putPixels:(img,label)=>{const l=active();if(!l)return;cctx(l.canvas).putImageData(img,0,0);touch(l);commit(label||P.name);redraw();},
    newLayer:(canvas,name)=>{if(!need())return null;const l=addLayer({name:name||P.name,type:'image',w:canvas.width,h:canvas.height,above:true});cctx(l.canvas).drawImage(canvas,0,0);commit(name||P.name);refreshLayers();redraw();return l;},
    newDocument:(name,w,h,bg)=>newBlank(name||'Plugin design',w||1080,h||1080,72,bg||'#ffffff'),
    flatten:()=>doc?flatCanvas(1,null):null,
    commit:l=>{if(doc){commit(l||P.name);redraw();}},
    redraw:()=>redraw(),
    ask:(title,label,def)=>new Promise(res=>askText(title,label,def==null?'':String(def),v=>res(v))),
    modal:(title,html,buttons,onMount)=>modalOpen(title,html,buttons||[{label:'Close'}],onMount),
    closeModal:()=>closeModal(),
    mkCanvas:(w,h)=>mkCanvas(w,h),
    addMenuItem:(label,fn)=>{PLUG_ITEMS.push({pid:P.id,label:String(label),fn});},
    addFilter:(def)=>{if(!def||!def.name||typeof def.apply!=='function')throw new Error('addFilter needs {name, apply}');PLUG_FILTERS.push({pid:P.id,def});},
    register:o=>{if(o){P.name=o.name||P.name;P.version=o.version||P.version;P.author=o.author||P.author;P.desc=o.description||P.desc;}},
    save:(k,v)=>{try{localStorage.setItem('lkpd_'+P.id+'_'+k,JSON.stringify(v));}catch(e){}},
    load:(k,d)=>{try{const v=localStorage.getItem('lkpd_'+P.id+'_'+k);return v==null?d:JSON.parse(v);}catch(e){return d;}}
  };
  return A;
}
function plRun(P){
  PLUG_ITEMS.splice(0,PLUG_ITEMS.length,...PLUG_ITEMS.filter(i=>i.pid!==P.id));
  PLUG_FILTERS.splice(0,PLUG_FILTERS.length,...PLUG_FILTERS.filter(i=>i.pid!==P.id));
  if(!P.enabled)return true;
  try{new Function('LK',P.code)(plApi(P));P.err=null;return true;}
  catch(e){P.err=String(e&&e.message||e);console.error('Plugin '+P.name,e);return false;}
}
function plFilterDialog(def){
  if(!doc){toast('Open a design first');return;}
  const ps=def.params||[],vals={};ps.forEach(p=>vals[p.id]=p.value==null?p.min||0:p.value);
  const body=(ps.length?ps.map(p=>'<label class="sl"><span>'+esc(p.label||p.id)+'</span><input type="range" data-pp="'+esc(p.id)+'" min="'+(p.min==null?0:p.min)+'" max="'+(p.max==null?100:p.max)+'" step="'+(p.step||1)+'" value="'+vals[p.id]+'"><output>'+vals[p.id]+'</output></label>').join(''):'<p class="muted">This filter has no settings.</p>');
  modalOpen(def.name,body,[{label:'Cancel'},{label:'Apply',primary:true,cb:()=>{
    const l=active();if(!l||l.locked){toast('Select an unlocked layer');return;}ensureRaster(l);
    try{const img=cctx(l.canvas).getImageData(0,0,l.canvas.width,l.canvas.height),out=def.apply(img,vals,{w:l.canvas.width,h:l.canvas.height})||img;cctx(l.canvas).putImageData(out,0,0);touch(l);commit(def.name);redraw();}
    catch(e){console.error(e);toast('The plugin filter failed: '+(e.message||e));}}}],
    root=>{root.addEventListener('input',e=>{const t=e.target;if(t.dataset.pp){vals[t.dataset.pp]=+t.value;const o=t.parentElement.querySelector('output');if(o)o.textContent=t.value;}});});
}
/* ---- install ---- */
function plInstall(code,srcName){
  const m=plMeta(code),P={id:'pl'+Date.now().toString(36)+Math.random().toString(36).slice(2,5),name:m.name||(srcName||'Plugin').replace(/\.[^.]+$/,''),version:m.version||'1.0',author:m.author||'',desc:m.desc||'',code,enabled:true};
  const ex=PLUGS.findIndex(p=>p.name===P.name);
  if(ex>=0){P.id=PLUGS[ex].id;PLUGS[ex]=P;}else PLUGS.push(P);
  const ok=plRun(P);plSave();return ok;
}
function plConfirmTrust(cb){
  modalOpen('Install plugin','<p>Plugins are small programs. They can read and change every design you open in this software.</p><p><b>Only install plugins from people you trust.</b></p>',[{label:'Cancel'},{label:'I trust it, install',primary:true,cb}]);
}
const PLUG_SAMPLES=[
 {name:'Invert colours',code:`// @name Invert colours
// @version 1.0
// @author LILKESSphoto
// @description Adds Plugins > Filters > Invert colours
LK.addFilter({name:'Invert colours',params:[{id:'amount',label:'Amount',min:0,max:100,value:100}],apply(img,v){const d=img.data,k=v.amount/100;for(let i=0;i<d.length;i+=4){d[i]+=(255-2*d[i])*k;d[i+1]+=(255-2*d[i+1])*k;d[i+2]+=(255-2*d[i+2])*k;}return img;}});`},
 {name:'Soft vignette',code:`// @name Soft vignette
// @version 1.0
// @author LILKESSphoto
// @description Darkens the corners of the active layer
LK.addFilter({name:'Soft vignette',params:[{id:'strength',label:'Strength',min:0,max:100,value:50},{id:'size',label:'Size',min:10,max:100,value:70}],apply(img,v,c){const w=c.w,h=c.h,d=img.data,cx=w/2,cy=h/2,R=Math.hypot(cx,cy)*v.size/100;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const t=Math.max(0,Math.hypot(x-cx,y-cy)/R-0.5)*2,k=1-Math.min(1,t*t)*v.strength/100,i=(y*w+x)*4;d[i]*=k;d[i+1]*=k;d[i+2]*=k;}return img;}});`},
 {name:'Sepia toner',code:`// @name Sepia toner
// @version 1.0
// @author LILKESSphoto
// @description Warm vintage tone
LK.addFilter({name:'Sepia toner',params:[{id:'amount',label:'Amount',min:0,max:100,value:100}],apply(img,v){const d=img.data,k=v.amount/100;for(let i=0;i<d.length;i+=4){const r=d[i],g=d[i+1],b=d[i+2],nr=0.393*r+0.769*g+0.189*b,ng=0.349*r+0.686*g+0.168*b,nb=0.272*r+0.534*g+0.131*b;d[i]=r+(Math.min(255,nr)-r)*k;d[i+1]=g+(Math.min(255,ng)-g)*k;d[i+2]=b+(Math.min(255,nb)-b)*k;}return img;}});`},
 {name:'Add watermark text',code:`// @name Add watermark text
// @version 1.0
// @author LILKESSphoto
// @description Adds Plugins > Add watermark text
LK.addMenuItem('Add watermark text...',async()=>{if(!LK.doc){LK.toast('Open a design first');return;}const t=await LK.ask('Watermark','Text to stamp on the design','© My Name');if(!t)return;const d=LK.doc,c=LK.mkCanvas(d.w,d.h),x=c.getContext('2d');x.font='bold '+Math.round(d.w/22)+'px sans-serif';x.fillStyle='rgba(255,255,255,.55)';x.strokeStyle='rgba(0,0,0,.35)';x.lineWidth=2;x.textAlign='right';x.textBaseline='bottom';x.strokeText(t,d.w-24,d.h-20);x.fillText(t,d.w-24,d.h-20);LK.newLayer(c,'Watermark');});`}
];
const PLUG_TEMPLATE=`// @name My plugin
// @version 1.0
// @author Your name
// @description What it does

// 1) A command in the Plugins menu
LK.addMenuItem('Say hello', () => LK.toast('Hello from my plugin!'));

// 2) A filter with sliders (runs on the active layer)
LK.addFilter({
  name: 'Brighten',
  params: [{ id: 'amount', label: 'Amount', min: -100, max: 100, value: 20 }],
  apply(img, v) {
    const d = img.data;
    for (let i = 0; i < d.length; i += 4) {
      d[i] += v.amount; d[i + 1] += v.amount; d[i + 2] += v.amount;
    }
    return img;
  }
});

// Other things you can use:
//  LK.doc, LK.layer(), LK.canvas(), LK.getPixels(), LK.putPixels(imageData)
//  LK.newLayer(canvas,name), LK.newDocument(name,w,h,bg), LK.flatten()
//  LK.ask(title,label,default) -> Promise,  LK.modal(title,html,buttons,onMount)
//  LK.save(key,value), LK.load(key,default)   (remembered between sessions)
`;
/* ---- manager window ---- */
function openPlugins(){
  const draw=root=>{
    const bi=PLUG_BUILTIN.map(p=>'<div class="plrow"><div class="plinfo"><b>'+esc(p.name)+'</b> <span class="muted">v'+esc(p.version)+' built in</span><div class="muted">'+esc(p.desc)+'</div></div><button data-pb="'+p.open+'">Open</button></div>').join('');
    const rows=bi+(PLUGS.length?PLUGS.map(p=>'<div class="plrow" data-id="'+p.id+'"><label class="pltg"><input type="checkbox" data-pt="'+p.id+'"'+(p.enabled?' checked':'')+'></label><div class="plinfo"><b>'+esc(p.name)+'</b> <span class="muted">v'+esc(p.version||'1.0')+(p.author?' by '+esc(p.author):'')+'</span><div class="muted">'+esc(p.desc||'')+'</div>'+(p.err?'<div class="plerr">Error: '+esc(p.err)+'</div>':'')+'</div><button data-pd="'+p.id+'">Remove</button></div>').join(''):'<p class="muted" style="padding:6px">No other plugins installed yet. Add one below, or try a sample.</p>');
    root.querySelector('#pl-list').innerHTML=rows;
  };
  modalOpen('Plugins','<div class="pl"><div id="pl-list" class="pllist"></div><div class="h">Add a plugin</div><div class="row"><button class="primary" id="pl-file">Install from file...</button><button id="pl-url">From web address...</button><button id="pl-paste">Paste code...</button></div><div class="h">Samples</div><div class="row" id="pl-samples">'+PLUG_SAMPLES.map((s,i)=>'<button data-ps="'+i+'">'+esc(s.name)+'</button>').join('')+'</div><div class="h">Make your own</div><div class="row"><button id="pl-guide">Plugin guide</button><button id="pl-tpl">Download starter plugin</button></div><input type="file" id="pl-input" accept=".js,.lkplugin,text/javascript" hidden></div>',[{label:'Close'}],root=>{
    draw(root);
    root.addEventListener('change',e=>{const t=e.target;if(t.dataset.pt){const P=PLUGS.find(p=>p.id===t.dataset.pt);if(P){P.enabled=t.checked;plRun(P);plSave();draw(root);}}});
    root.addEventListener('click',e=>{
      const pb=e.target.closest('[data-pb]');if(pb){closeModal();setTimeout(()=>ACT[pb.dataset.pb](),30);return;}
      const d=e.target.closest('[data-pd]');if(d){PLUGS=PLUGS.filter(p=>p.id!==d.dataset.pd);PLUG_ITEMS.splice(0,PLUG_ITEMS.length,...PLUG_ITEMS.filter(i=>i.pid!==d.dataset.pd));PLUG_FILTERS.splice(0,PLUG_FILTERS.length,...PLUG_FILTERS.filter(i=>i.pid!==d.dataset.pd));plSave();draw(root);return;}
      const s=e.target.closest('[data-ps]');if(s){const S0=PLUG_SAMPLES[+s.dataset.ps];plInstall(S0.code,S0.name);draw(root);toast(S0.name+' installed. Find it in the Plugins menu.');return;}
    });
    root.querySelector('#pl-file').onclick=()=>root.querySelector('#pl-input').click();
    root.querySelector('#pl-input').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const code=await f.text();plConfirmTrust(()=>{const ok=plInstall(code,f.name);toast(ok?'Plugin installed. Find it in the Plugins menu.':'Installed, but it reported an error');setTimeout(openPlugins,50);});};
    root.querySelector('#pl-url').onclick=()=>askText('Install from web address','Web address of the plugin (.js file)','https://',u=>{if(!u||!/^https?:/i.test(u))return;fetch(u).then(r=>{if(!r.ok)throw new Error('http '+r.status);return r.text();}).then(code=>plConfirmTrust(()=>{const ok=plInstall(code,u.split('/').pop());toast(ok?'Plugin installed':'Installed, but it reported an error');setTimeout(openPlugins,50);})).catch(()=>toast('Could not download that plugin'));});
    root.querySelector('#pl-paste').onclick=()=>askText('Paste plugin code','Plugin code','',code=>{if(!code)return;plConfirmTrust(()=>{const ok=plInstall(code,'Pasted plugin');toast(ok?'Plugin installed':'Installed, but it reported an error');setTimeout(openPlugins,50);});},true);
    root.querySelector('#pl-tpl').onclick=()=>saveBlob(new Blob([PLUG_TEMPLATE],{type:'text/javascript'}),'my-plugin.js');
    root.querySelector('#pl-guide').onclick=()=>plGuide();
  },{wide:true});
}
function plGuide(){modalOpen('Plugin guide','<p>A plugin is one <b>.js</b> file. It gets an object called <code>LK</code>. Start from the starter plugin and change it.</p><pre class="plcode">'+esc(PLUG_TEMPLATE)+'</pre><p class="muted">Plugins run inside the software with full access, so share and install only code you trust. Plugins are stored on this device and load every time the software starts.</p>',[{label:'Back',cb:()=>setTimeout(openPlugins,30)},{label:'Close'}],null,{wide:true});}
ACT.plugins=openPlugins;
/* ---- the Plugins menu ---- */
{
  const menu={label:'Plugins',get items(){
    const out=[al('Plugin gallery...','','plugGallery'),al('Manage plugins...','','plugins')];
    if(typeof plgMenuItems==='function'){const pm=plgMenuItems();if(pm.length){out.push(SEP);pm.forEach(x=>out.push(x));}}
    if(PLUG_FILTERS.length){out.push(SEP);out.push(sub('Filters',PLUG_FILTERS.map(f=>al(f.def.name+(f.def.params&&f.def.params.length?'...':''),'',()=>plFilterDialog(f.def)))));}
    if(PLUG_ITEMS.length){out.push(SEP);PLUG_ITEMS.forEach(it=>out.push(al(it.label,'',()=>{try{const r=it.fn();if(r&&r.catch)r.catch(e=>toast('Plugin error: '+(e.message||e)));}catch(e){toast('Plugin error: '+(e.message||e));}})));}
    
    return out;}};
  const hi=MENUS.findIndex(m=>m.label==='Help');MENUS.splice(hi<0?MENUS.length:hi,0,menu);
  const nav=document.getElementById('menus'),kb=document.getElementById('kess-store');
  nav.innerHTML=MENUS.map((m,i)=>'<button class="mn" data-m="'+i+'">'+m.label+'</button>').join('');if(kb)nav.appendChild(kb);
}
/* ---- load saved plugins at start ---- */
PLUGS=plLoad().map(p=>Object.assign({},p));PLUGS.forEach(p=>plRun(p));
