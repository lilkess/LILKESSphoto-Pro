/* ===== My Templates: save any design as a reusable template ===== */
TPL_CATS.push('My Templates');
{const _lp=listProjects;listProjects=async function(){const a=await _lp();return a===null?null:a.filter(p=>!String(p.id).startsWith('tpl_'));};}
async function listUserTemplates(){
  try{const db=await idbOpen(),a=await idbReq(db.transaction('meta').objectStore('meta').getAll());db.close();return a.filter(p=>String(p.id).startsWith('tpl_')).sort((x,y)=>y.updated-x.updated);}
  catch(err){return null;}
}
async function saveAsTemplate(name){
  flush();
  const oldId=doc.projId,oldName=doc.name,oldMod=doc.modified;
  doc.projId='tpl_'+Date.now();doc.name=name;
  try{await saveProject();}finally{doc.projId=oldId;doc.name=oldName;doc.modified=oldMod;}
}
ACT.saveTemplate=function(){
  if(!doc){toast('Open a design first');return;}
  modalOpen('Save as template','<div class="saform"><label class="opt" style="display:block">Template name<input type="text" id="st-n" value="'+esc(doc.name||'My template')+'" style="width:100%;margin-top:4px"></label><p class="muted" style="margin-top:8px">Everything stays editable: text, shapes, gradients, photo frames and layers. Find it later on the Welcome screen under <b>My Templates</b>.</p></div>',
    [{label:'Cancel'},{label:'Save template',primary:true,cb:()=>{const n=($('#st-n').value||'').trim()||'My template';saveAsTemplate(n).then(()=>toast('Saved to My Templates')).catch(()=>toast('Could not save here. Save as PSD instead.'));}}]);
};
async function openUserTemplate(id){
  await loadProject(id);
  if(doc&&String(doc.projId)===String(id)){doc.projId=null;doc.modified=true;renderTabs();}
  hideWelcome();
}
async function delUserTemplate(id){await deleteProject(id);}
{
  const _tp=tplPaint;
  tplPaint=function(){
    if(tplCat!=='My Templates')return _tp();
    const grid=$('#w-tpl');grid.innerHTML='<p class="muted">Loading...</p>';
    listUserTemplates().then(list=>{
      if(tplCat!=='My Templates')return;
      if(list===null){grid.innerHTML='<p class="muted">Saving is not available in this browser mode.</p>';return;}
      if(!list.length){grid.innerHTML='<p class="muted">Nothing here yet. Open any template or flyer, edit it, then use File &gt; Save as template.</p>';return;}
      grid.innerHTML='';
      list.filter(t=>!tplQ||t.name.toLowerCase().includes(tplQ)).forEach(t=>{
        const b=document.createElement('div');b.className='tcard';b.tabIndex=0;b.setAttribute('role','button');
        b.innerHTML='<div class="tph"><img alt="" src="'+t.thumb+'" style="width:100%;height:100%;object-fit:contain"></div><b>'+esc(t.name)+'</b><small>'+t.w+' x '+t.h+' px</small><button class="tdel" title="Delete this template" aria-label="Delete template">&times;</button>';
        b.addEventListener('click',e=>{if(e.target.closest('.tdel')){e.stopPropagation();if(confirm('Delete template "'+t.name+'"?'))delUserTemplate(t.id).then(()=>tplPaint());return;}openUserTemplate(t.id);});
        grid.appendChild(b);
      });
    });
  };
  const F=MENUS.find(m=>m.label==='File');
  if(F){const i=F.items.findIndex(x=>x&&x.label==='Save to this device');F.items.splice(i+1,0,mi('Save as template...','','saveTemplate'));}
}
