
/* ===== toolbox ===== */
const ICONS={
  move:'<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>',
  marquee:'<rect x="4" y="4" width="16" height="16" stroke-dasharray="3 3"/>',
  ellipse:'<ellipse cx="12" cy="12" rx="8.5" ry="7" stroke-dasharray="3 3"/>',
  lasso:'<path d="M6 10c0-4 5-6 9-4s4 6-1 8-8 0-8-4z"/><path d="M8 15c-1 2 0 4 2 5"/>',
  poly:'<path d="M5 8l9-4 5 6-3 8-10-2z" stroke-dasharray="3 2"/>',
  wand:'<path d="M5 19L16 8"/><path d="M15 4v3M15 11v3M11 7.5h3M18 7.5h3M17 5l-1 1M17 10l-1-1"/>',
  crop:'<path d="M7 3v14h14M3 7h14v14"/>',
  pick:'<path d="M20 4a2.5 2.5 0 0 0-3.5 0l-3 3-1-1-2 2 1 1-7 7v3h3l7-7 1 1 2-2-1-1 3-3a2.5 2.5 0 0 0 0-3.5z"/>',
  smooth:'<path d="M12 3c4 5 6 8 6 11a6 6 0 0 1-12 0c0-3 2-6 6-11z"/><path d="M9 14a3 3 0 0 0 3 3"/>',
  clone:'<rect x="8" y="3" width="8" height="5" rx="1"/><path d="M10 8l-2 6h8l-2-6"/><path d="M6 14h12v3H6zM8 17v3M16 17v3"/>',
  blur:'<path d="M12 4c3 4 5 6.5 5 9a5 5 0 0 1-10 0c0-2.500 2-5 5-9z" stroke-dasharray="2 2"/>',
  sharpen:'<path d="M12 4l7 14H5z"/>',
  smudge:'<path d="M5 17c3-1 4-4 7-4 2 0 2 2 4 2s3-2 3-4"/><path d="M5 20h14"/>',
  lighten:'<circle cx="12" cy="12" r="4"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.500 5.500l2 2M16.500 16.500l2 2M5.500 18.500l2-2M16.500 7.500l2-2"/>',
  darken:'<path d="M20 14.500A8 8 0 1 1 9.500 4a6.500 6.500 0 0 0 10.500 10.500z"/>',
  brush:'<path d="M18.500 3.500l2 2-9.500 9.500-3.200-1.200-1.200-3.200z"/><path d="M8 14.500c-3 0-4 2-4 4 0 .8-.8 1.600-1.500 2 3 .8 7-.2 7-4"/>',
  eraser:'<path d="M5 15l9-9 5 5-9 9H7z"/><path d="M11 20h9"/>',
  mageraser:'<path d="M5 15l9-9 5 5-9 9H7z"/><path d="M17 3v2M16 4h2" />',
  gradient:'<rect x="3" y="5" width="18" height="14" rx="1"/><path d="M8 5v14M13 5v14M18 5v14" opacity=".45"/>',
  fill:'<path d="M5 12l7-7 8 8-7 7z"/><path d="M19 15c1.500 2 2 3 2 4a2 2 0 0 1-4 0c0-1 .5-2 2-4z"/>',
  text:'<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  rect:'<rect x="4" y="6" width="16" height="12"/>',
  round:'<rect x="4" y="6" width="16" height="12" rx="4"/>',
  circle:'<circle cx="12" cy="12" r="8"/>',
  triangle:'<path d="M12 4l9 16H3z"/>',
  star:'<path d="M12 3l2.600 6 6.400.5-4.900 4.200 1.600 6.300L12 16.700 6.300 20l1.600-6.300L3 9.500 9.400 9z"/>',
  line:'<path d="M5 19L19 5"/>',
  hand:'<path d="M8 12V5.500a1.500 1.500 0 0 1 3 0V11M11 11V4a1.500 1.500 0 0 1 3 0v7M14 11V5.500a1.500 1.500 0 0 1 3 0V14c0 4-2 7-6 7-3 0-5-2-6-4l-2-4a1.500 1.500 0 0 1 2.500-1.500L8 14"/>',
  zoom:'<circle cx="10.500" cy="10.500" r="6.500"/><path d="M15.500 15.500L21 21M10.500 8v5M8 10.500h5"/>'
};
const TOOLGROUPS=[
  {id:'move',v:[{t:'move',n:'Move',k:'V',i:'move'}]},
  {id:'marquee',v:[{t:'marquee',kind:'rect',n:'Rectangular Marquee',k:'M',i:'marquee'},{t:'marquee',kind:'ellipse',n:'Elliptical Marquee',k:'M',i:'ellipse'}]},
  {id:'lasso',v:[{t:'lasso',kind:'free',n:'Lasso',k:'L',i:'lasso'},{t:'lasso',kind:'poly',n:'Polygonal Lasso',k:'L',i:'poly'}]},
  {id:'wand',v:[{t:'wand',n:'Magic Wand',k:'W',i:'wand'}]},
  {id:'crop',v:[{t:'crop',n:'Crop',k:'C',i:'crop'}]},
  {id:'pick',v:[{t:'pick',n:'Eyedropper',k:'I',i:'pick'}]},
  {id:'retouch',v:[{t:'retouch',mode:'smooth',n:'Skin Smoothing Brush',k:'J',i:'smooth'},{t:'retouch',mode:'clone',n:'Clone Stamp',k:'S',i:'clone'},{t:'retouch',mode:'blur',n:'Blur Brush',k:'R',i:'blur'},{t:'retouch',mode:'sharpen',n:'Sharpen Brush',k:'R',i:'sharpen'},{t:'retouch',mode:'smudge',n:'Smudge',k:'R',i:'smudge'},{t:'retouch',mode:'lighten',n:'Dodge (lighten)',k:'O',i:'lighten'},{t:'retouch',mode:'darken',n:'Burn (darken)',k:'O',i:'darken'}]},
  {id:'brush',v:[{t:'brush',n:'Brush',k:'B',i:'brush'}]},
  {id:'eraser',v:[{t:'eraser',n:'Eraser',k:'E',i:'eraser'},{t:'fill',mode:'erase',n:'Magic Eraser',k:'E',i:'mageraser'}]},
  {id:'fill',v:[{t:'gradient',n:'Gradient',k:'G',i:'gradient'},{t:'fill',mode:'fill',n:'Paint Bucket',k:'G',i:'fill'}]},
  {id:'text',v:[{t:'text',n:'Type',k:'T',i:'text'}]},
  {id:'shape',v:[{t:'shape',kind:'rect',n:'Rectangle',k:'U',i:'rect'},{t:'shape',kind:'round',n:'Rounded Rectangle',k:'U',i:'round'},{t:'shape',kind:'ellipse',n:'Ellipse',k:'U',i:'circle'},{t:'shape',kind:'triangle',n:'Triangle',k:'U',i:'triangle'},{t:'shape',kind:'star',n:'Star',k:'U',i:'star'},{t:'shape',kind:'line',n:'Line',k:'U',i:'line'}]},
  {id:'hand',v:[{t:'hand',n:'Hand',k:'H',i:'hand'}]},
  {id:'zoom',v:[{t:'zoom',n:'Zoom',k:'Z',i:'zoom'}]}
];
const grpCur={};TOOLGROUPS.forEach(g=>{grpCur[g.id]=0;});
const CURSORS={move:'default',marquee:'crosshair',lasso:'crosshair',wand:'crosshair',crop:'crosshair',brush:'crosshair',eraser:'crosshair',retouch:'crosshair',fill:'crosshair',gradient:'crosshair',pick:'crosshair',text:'text',shape:'crosshair',hand:'grab',zoom:'zoom-in'};
const svgI=n=>'<svg viewBox="0 0 24 24">'+ICONS[n]+'</svg>';
function renderToolbox(){
  $('#toolbtns').innerHTML=TOOLGROUPS.map(g=>{
    const v=g.v[grpCur[g.id]];
    return '<div class="tgrp" data-g="'+g.id+'"><button class="tbtn'+(S.toolBtn===g.id?' on':'')+'" data-g="'+g.id+'" title="'+v.n+' ('+v.k+')" aria-label="'+v.n+'">'+svgI(v.i)+'</button>'+(g.v.length>1?'<span class="tri" data-more="'+g.id+'" title="More tools"></span>':'')+'</div>';
  }).join('');
}
function pickTool(gid,idx){
  const g=TOOLGROUPS.find(x=>x.id===gid),v=g.v[idx];grpCur[gid]=idx;
  if(v.t==='marquee')S.marq.kind=v.kind;
  if(v.t==='lasso')S.lasso.kind=v.kind;
  if(v.t==='retouch')S.retouch.mode=v.mode;
  if(v.t==='fill')S.fill.mode=v.mode;
  if(v.t==='shape')S.shape.kind=v.kind;
  S.tv=v;
  setTool(v.t,gid);
}
function setTool(t,gid){
  if(doc)flush();
  if(drag&&drag.k==='lasso')drag=null;
  toolSwitch(S.tool,t);
  S.tool=t;if(t!=='crop')S.crop=null;
  if(!gid){const g=TOOLGROUPS.find(x=>x.v.some(q=>q.t===t));gid=g?g.id:t;if(g){const i=g.v.findIndex(q=>q.t===t);if(i>=0&&t!=='fill'&&t!=='retouch'&&t!=='marquee'&&t!=='lasso'&&t!=='shape')grpCur[g.id]=i;}}
  S.toolBtn=gid;
  renderToolbox();vp.style.cursor=CURSORS[t]||'crosshair';renderOpts();if(doc)redraw();
}
let flyTimer=0;
function openFlyout(gid,anchor){
  const g=TOOLGROUPS.find(x=>x.id===gid);if(!g||g.v.length<2)return;
  closeMenus();
  const m=document.createElement('div');m.className='menu flyout';m.id='flyout';
  m.innerHTML=g.v.map((v,i)=>'<button data-i="'+i+'"><span class="mi">'+svgI(v.i)+'</span>'+v.n+'<kbd>'+v.k+'</kbd></button>').join('');
  document.body.appendChild(m);
  const r=anchor.getBoundingClientRect();
  m.style.left=Math.min(innerWidth-m.offsetWidth-8,r.right+4)+'px';m.style.top=Math.min(innerHeight-m.offsetHeight-8,Math.max(8,r.top))+'px';
  if(isMobile()){m.style.left=Math.max(8,Math.min(innerWidth-m.offsetWidth-8,r.left))+'px';m.style.top=Math.max(8,r.top-m.offsetHeight-6)+'px';}
  m.addEventListener('click',e=>{const b=e.target.closest('[data-i]');if(b){pickTool(gid,+b.dataset.i);closeMenus();}});
}
$('#toolbtns').addEventListener('click',e=>{
  const more=e.target.closest('[data-more]');if(more){openFlyout(more.dataset.more,more.parentNode);return;}
  const b=e.target.closest('.tbtn');if(b)pickTool(b.dataset.g,grpCur[b.dataset.g]);
});
$('#toolbtns').addEventListener('contextmenu',e=>{const b=e.target.closest('.tbtn');if(b){e.preventDefault();openFlyout(b.dataset.g,b.parentNode);}});
$('#toolbtns').addEventListener('pointerdown',e=>{
  const b=e.target.closest('.tbtn');if(!b)return;
  clearTimeout(flyTimer);flyTimer=setTimeout(()=>{flyTimer=0;if(e.pointerType!=='mouse')openFlyout(b.dataset.g,b.parentNode);},550);
});
['pointerup','pointercancel','pointermove'].forEach(ev=>$('#toolbtns').addEventListener(ev,()=>clearTimeout(flyTimer)));
function selectToolByKey(k){
  const gs=TOOLGROUPS.filter(g=>g.v.some(v=>v.k===k));if(!gs.length)return false;
  /* the same key again cycles through the tools that share it */
  const flat=[];gs.forEach(g=>g.v.forEach((v,i)=>{if(v.k===k)flat.push({g:g.id,i});}));
  let idx=flat.findIndex(f=>f.g===S.toolBtn&&f.i===grpCur[f.g]);
  idx=(idx+1)%flat.length;if(idx<0)idx=0;
  pickTool(flat[idx].g,flat[idx].i);return true;
}
function setSwatches(){
  $('#fgc').value=S.fg;$('#bgc').value=S.bg;
  const cf=$('#cp-fg');
  if(cf){cf.value=S.fg;$('#cp-bg').value=S.bg;const c=hexRgb(S.fg);['r','g','b'].forEach((k,i)=>{const el=$('#cp-'+k);el.value=c[i];el.nextElementSibling.textContent=c[i];});$('#cp-hex').value=S.fg;}
}
$('#fgc').addEventListener('input',e=>{S.fg=e.target.value;setSwatches();});
$('#bgc').addEventListener('input',e=>{S.bg=e.target.value;setSwatches();});
$('#swap').addEventListener('click',()=>{const t=S.fg;S.fg=S.bg;S.bg=t;setSwatches();});
$('#resetsw').addEventListener('click',()=>{S.fg='#000000';S.bg='#ffffff';setSwatches();});

/* ===== options bar ===== */
const rng=(label,id,min,max,val,step)=>'<label class="opt">'+label+'<input type="range" id="'+id+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+val+'"><output>'+(Math.round(val*100)/100)+'</output></label>';
const sel=(id,opts,v)=>'<select id="'+id+'">'+opts.map(o=>'<option value="'+o[0]+'"'+(String(o[0])===String(v)?' selected':'')+'>'+o[1]+'</option>').join('')+'</select>';
const selModeBtns=()=>'<span class="opt seg" role="group" aria-label="Selection mode">'+[['new','New'],['add','Add'],['sub','Subtract'],['int','Intersect']].map(m=>'<button data-selmode="'+m[0]+'" class="'+(S.selMode===m[0]?'on':'')+'">'+m[1]+'</button>').join('')+'</span>';
function renderOpts(){
  const t=S.tool;let h='';
  const gname=(TOOLGROUPS.find(g=>g.id===S.toolBtn)||{v:[{n:''}]}).v[grpCur[S.toolBtn]||0].n;
  h+='<span class="opt toolname">'+esc(gname)+'</span><span class="vsep"></span>';
  if(t==='move')h+='<label class="opt"><input type="checkbox" id="o-auto"'+(S.auto?' checked':'')+'> Auto-select layer</label><span class="vsep"></span><span class="opt"><button data-act="alignL" title="Align left">&#8676;</button><button data-act="alignHC" title="Align centre horizontally">&#8596;</button><button data-act="alignR" title="Align right">&#8677;</button><button data-act="alignT" title="Align top">&#8673;</button><button data-act="alignVC" title="Align centre vertically">&#8597;</button><button data-act="alignB" title="Align bottom">&#8675;</button></span>';
  else if(t==='marquee')h+=selModeBtns()+'<button data-act="selNone">Deselect</button><button data-act="selInv">Inverse</button><button data-act="selFeather">Feather</button><button data-act="cropSel">Crop to selection</button>';
  else if(t==='lasso')h+=selModeBtns()+'<span class="opt muted">'+(S.lasso.kind==='poly'?'Tap each corner. Double-tap or tap the first point to close.':'Draw around the area.')+'</span>';
  else if(t==='wand')h+=selModeBtns()+rng('Tolerance','o-wtol',0,160,S.wand.tol)+'<label class="opt"><input type="checkbox" id="o-wcon"'+(S.wand.contig?' checked':'')+'> Contiguous</label><button data-act="selInv">Inverse</button>';
  else if(t==='crop')h+='<label class="opt">Shape '+sel('o-aspect',[[0,'Free'],[1,'Square 1:1'],[0.8,'Portrait 4:5'],[1.25,'Landscape 5:4'],[1.7778,'Wide 16:9'],[0.5625,'Story 9:16'],[0.7071,'A4 portrait'],[0.6667,'Passport 2:3']],S.aspect)+'</label><button class="primary" data-act="cropApply">Apply crop</button><button data-act="cropReset">Reset</button>';
  else if(t==='brush')h+=rng('Size','o-bsize',1,2500,S.brush.size)+rng('Hardness','o-bhard',0,100,S.brush.hard*100)+rng('Opacity','o-bflow',1,100,S.brush.flow*100);
  else if(t==='eraser')h+=rng('Size','o-esize',1,2500,S.eraser.size)+rng('Hardness','o-ehard',0,100,S.eraser.hard*100)+rng('Opacity','o-eflow',1,100,S.eraser.flow*100);
  else if(t==='retouch'){
    h+=rng('Size','o-rsize',8,400,S.retouch.size)+rng('Strength','o-rstr',5,100,S.retouch.strength*100);
    if(S.retouch.mode==='sponge')h+='<label class="opt">Mode '+sel('o-sponge',[['desat','Desaturate'],['sat','Saturate']],S.retouch.sponge)+'</label>';
    if(S.retouch.mode==='clone')h+='<button data-act="setSrc">'+(S.srcPt?'Change source':'Set source')+'</button><span class="opt muted">Tap Set source, tap a clean spot, then paint over the blemish.</span>';
  }
  else if(t==='fill'){
    if(S.fill.mode==='erase')h+='<span class="opt muted">Tap a plain area to erase it.</span>';
    h+=rng('Tolerance','o-ftol',0,160,S.fill.tol)+'<label class="opt"><input type="checkbox" id="o-fcon"'+(S.fill.contig!==false?' checked':'')+'> Contiguous</label>';
  }
  else if(t==='gradient')h+=gradOptsHtml();
  else if(t==='pick')h+='<span class="opt muted">Tap or drag over the picture to pick a colour.</span>';
  else if(t==='text')h+='<span class="opt muted">Tap the canvas to add text. Style it in the Properties panel.</span>';
  else if(t==='shape')h+='<label class="opt">Fill <input type="color" id="o-sfill" value="'+S.shape.fill+'"></label><label class="opt">Outline <input type="color" id="o-sstroke" value="'+S.shape.stroke+'"></label>'+rng('Outline size','o-ssw',0,40,S.shape.sw)+shapeExtraOpts();
  else if(t==='hand')h+='<span class="opt muted">Drag to move the canvas. Pinch or Ctrl + scroll to zoom.</span>';
  else if(TOOLS[t]&&TOOLS[t].opts)h+=TOOLS[t].opts();
  else if(t==='zoom')h+='<span class="opt muted">Tap to zoom in. Hold Alt and tap to zoom out.</span><button data-act="zfit">Fit on screen</button><button data-act="z100">100%</button>';
  $('#opts').innerHTML=h;
}
$('#opts').addEventListener('input',e=>{
  const t=e.target,id=t.id,v=t.type==='checkbox'?t.checked:t.value;
  if(t.type==='range'&&t.nextElementSibling)t.nextElementSibling.textContent=v;
  switch(id){
    case 'o-auto':S.auto=v;break;
    case 'o-wtol':S.wand.tol=+v;break;case 'o-wcon':S.wand.contig=v;break;
    case 'o-bsize':S.brush.size=+v;break;case 'o-bhard':S.brush.hard=v/100;break;case 'o-bflow':S.brush.flow=v/100;break;
    case 'o-esize':S.eraser.size=+v;break;case 'o-ehard':S.eraser.hard=v/100;break;case 'o-eflow':S.eraser.flow=v/100;break;
    case 'o-rsize':S.retouch.size=+v;break;case 'o-rstr':S.retouch.strength=v/100;break;
    case 'o-ftol':S.fill.tol=+v;break;case 'o-fcon':S.fill.contig=v;break;
    case 'o-gkind':S.grad.kind=v;break;case 'o-gmode':S.grad.mode=v;break;
    case 'o-sfill':S.shape.fill=v;break;case 'o-sstroke':S.shape.stroke=v;break;case 'o-ssw':S.shape.sw=+v;break;
    case 'o-aspect':S.aspect=+v;S.crop=null;if(doc)redraw();break;
  }
});
$('#opts').addEventListener('click',e=>{
  const b=e.target.closest('[data-selmode]');
  if(b){S.selMode=b.dataset.selmode;$$('[data-selmode]').forEach(x=>x.classList.toggle('on',x===b));}
});

/* ===== document tabs and status bar ===== */
function renderTabs(){
  const bar=$('#tabs');
  bar.hidden=!docs.length;
  bar.innerHTML=docs.map((e,i)=>'<div class="dtab'+(i===cur?' on':'')+'" data-i="'+i+'" title="'+esc(e.doc.name)+'"><span class="dn">'+esc(e.doc.name)+(e.doc.modified?' <i class="dot" aria-label="unsaved"></i>':'')+'</span><button class="dx" data-x="'+i+'" aria-label="Close '+esc(e.doc.name)+'">&#10005;</button></div>').join('')+'<button class="dplus" data-act="new" title="New design" aria-label="New design">+</button>';
  document.title=doc?(doc.name+(doc.modified?' *':'')+' - LILKESSphoto Pro'):'LILKESSphoto Pro';
}
$('#tabs').addEventListener('click',e=>{
  const x=e.target.closest('[data-x]');if(x){e.stopPropagation();closeDoc(+x.dataset.x);return;}
  const t=e.target.closest('.dtab');if(t)switchDoc(+t.dataset.i);
});
$('#tabs').addEventListener('auxclick',e=>{const t=e.target.closest('.dtab');if(t&&e.button===1)closeDoc(+t.dataset.i);});
function updateStatus(){
  $('#sdoc').textContent=doc?(doc.w+' × '+doc.h+' px'+(doc.ppi?'  ·  '+doc.ppi+' ppi':'')):'';
}
function updateCursorInfo(p){
  const s=$('#scur');if(!s)return;
  s.textContent=(p.x>=0&&p.y>=0&&p.x<=doc.w&&p.y<=doc.h)?Math.round(p.x)+', '+Math.round(p.y)+' px':'';
}
$('#zoomin').addEventListener('change',e=>{
  if(!doc)return;const v=parseFloat(String(e.target.value).replace('%',''));
  if(v>0){const r=vp.getBoundingClientRect();zoomAt(v/100,r.width/2,r.height/2);}else applyView();
});
$('#zoomin').addEventListener('keydown',e=>{if(e.key==='Enter')e.target.blur();e.stopPropagation();});

/* ===== panels: tabs ===== */
const DOCK_A=['color','swatches','adjust','filters'],DOCK_B=['layers','history','props'];
const isMobile=()=>matchMedia('(max-width:860px)').matches;
S.tabA='color';S.tabB='layers';
function setTab(t,toggle,silent){
  const pn=$('#docks');
  if(toggle&&isMobile()&&S.tab===t&&pn.classList.contains('open')){pn.classList.remove('open');return;}
  S.tab=t;if(DOCK_A.includes(t))S.tabA=t;else S.tabB=t;
  $$('.dtabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab===S.tabA||b.dataset.tab===S.tabB));
  $$('#mtabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
  $$('.tab').forEach(s=>{const id=s.id.slice(4);s.classList.toggle('on',id===S.tabA||id===S.tabB);s.classList.toggle('cur',id===t);});
  $('#dockA').classList.toggle('cur',DOCK_A.includes(t));$('#dockB').classList.toggle('cur',DOCK_B.includes(t));
  if(isMobile()&&!silent)pn.classList.add('open');
  if(t==='filters')renderFilters();
  if(t==='props')renderProps();
  if(t==='history')renderHistory();
  if(t==='adjust')renderAdjMsg();
  setFoot();
  if(isMobile())setTimeout(()=>{if(doc&&S.autoFit)fitView();},30);
}
$('#docks').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b){flush();setTab(b.dataset.tab,true);}});
$('#mtabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b){flush();setTab(b.dataset.tab,true);}});

/* ===== colour and swatches panels ===== */
$('#tab-color').innerHTML='<div class="cpbig"><label>Foreground<input type="color" id="cp-fg" value="#000000"></label><label>Background<input type="color" id="cp-bg" value="#ffffff"></label></div>'
 +['r','g','b'].map(k=>'<label class="sl"><span>'+k.toUpperCase()+'</span><input type="range" id="cp-'+k+'" min="0" max="255" value="0"><output>0</output></label>').join('')
 +'<div class="row"><label>Hex <input type="text" id="cp-hex" value="#000000" maxlength="7" style="width:92px"></label></div>';
$('#tab-color').addEventListener('input',e=>{
  const id=e.target.id;
  if(id==='cp-fg'){S.fg=e.target.value;}else if(id==='cp-bg'){S.bg=e.target.value;}
  else if(/^cp-[rgb]$/.test(id)){const c=hexRgb(S.fg),i='rgb'.indexOf(id[3]);c[i]=+e.target.value;S.fg=rgbHex(c[0],c[1],c[2]);}
  else return;
  if(id!=='cp-hex'){const keep=id;setSwatches();void keep;}
});
$('#cp-hex').addEventListener('change',e=>{const v=e.target.value.trim();if(/^#?[0-9a-f]{6}$/i.test(v)){S.fg=(v[0]==='#'?v:'#'+v).toLowerCase();}setSwatches();});
const SWATCHES=['#000000','#ffffff','#808080','#c0c0c0','#404040','#e53935','#fb8c00','#fdd835','#43a047','#00897b','#039be5','#3949ab','#8e24aa','#d81b60','#6d4c41','#f2b134','#0f4231','#06150f','#ffcdd2','#ffe0b2','#fff9c4','#c8e6c9','#b2dfdb','#b3e5fc','#c5cae9','#e1bee7','#f8bbd0','#d7ccc8','#ffccbc','#d1c4e9','#ffd54f','#7cb342'];
$('#tab-swatches').innerHTML='<div class="row"><span class="muted">Tap sets</span><span class="seg"><button data-swt="fg" class="on">Foreground</button><button data-swt="bg">Background</button></span></div><div class="swgrid">'+SWATCHES.map(c=>'<button class="sw" data-c="'+c+'" style="background:'+c+'" title="'+c+'" aria-label="Colour '+c+'"></button>').join('')+'</div>';
let swTarget='fg';
$('#tab-swatches').addEventListener('click',e=>{
  const t=e.target.closest('[data-swt]');if(t){swTarget=t.dataset.swt;$$('[data-swt]').forEach(x=>x.classList.toggle('on',x===t));return;}
  const s=e.target.closest('.sw');if(s){if(swTarget==='fg')S.fg=s.dataset.c;else S.bg=s.dataset.c;setSwatches();}
});
$('#tab-swatches').addEventListener('contextmenu',e=>{const s=e.target.closest('.sw');if(s){e.preventDefault();S.bg=s.dataset.c;setSwatches();}});

/* ===== adjustments panel ===== */
const ADJ_UI=[
  ['Light',[['exposure','Exposure',-100,100],['brightness','Brightness',-100,100],['contrast','Contrast',-100,100],['highlights','Highlights',-100,100],['shadows','Shadows',-100,100]]],
  ['Colour',[['saturation','Saturation',-100,100],['warmth','Warmth',-100,100],['gray','Black & white',0,100],['sepia','Sepia',0,100]]],
  ['Detail and retouch',[['smooth','Skin smooth',0,100],['sharpen','Sharpen',0,100],['blur','Blur',0,20]]],
  ['Effects',[['vignette','Vignette',0,100],['fade','Fade',0,100],['grain','Grain',0,100]]],
  ['Strength',[['mix','Intensity',0,100]]]
];
$('#tab-adjust').innerHTML='<p class="muted" id="adjmsg" hidden>Select an unlocked layer to adjust it.</p><div class="quick"><button data-act="autoFix">Auto fix</button><button data-act="quickSkin">Smooth skin</button></div>'
 +ADJ_UI.map(g=>'<div class="h">'+g[0]+'</div>'+g[1].map(s=>'<label class="sl"><span>'+s[1]+'</span><input type="range" id="a-'+s[0]+'" data-k="'+s[0]+'" min="'+s[2]+'" max="'+s[3]+'" value="'+ADJ0[s[0]]+'"><output>'+ADJ0[s[0]]+'</output></label>').join('')).join('')
 +'<div class="adjfoot" id="adjfoot" hidden><button data-act="adjReset">Reset</button><button class="primary" data-act="adjApply">Apply</button></div>';
$('#tab-adjust').addEventListener('input',e=>{
  const k=e.target.dataset.k;if(!k)return;
  if(!doc||!active()){toast('Select a layer first');syncAdj();return;}
  adj.p[k]=+e.target.value;e.target.nextElementSibling.textContent=e.target.value;adjChanged();
});
function syncAdj(){
  $$('#tab-adjust input[data-k]').forEach(i=>{i.value=adj.p[i.dataset.k];i.nextElementSibling.textContent=i.value;});
}
function renderAdjMsg(){const m=$('#adjmsg');if(m)m.hidden=!!(doc&&active()&&!active().locked);}
function setFoot(){const f=$('#adjfoot');if(f)f.hidden=!(sess&&sess.kind==='adjust'&&sess.dirty);}

/* ===== looks (filter presets) ===== */
function renderFilters(){
  const box=$('#tab-filters'),l=doc&&active();
  if(!l||l.locked){box.innerHTML='<p class="muted">Select an unlocked photo or paint layer to see look previews.</p>';return;}
  const sc2=l.canvas,k=Math.min(1,110/Math.max(sc2.width,sc2.height)),c=mkCanvas(sc2.width*k,sc2.height*k);
  cctx(c).drawImage(sc2,0,0,c.width,c.height);
  const src=cctx(c).getImageData(0,0,c.width,c.height);
  box.innerHTML='<p class="muted" style="margin:0 0 10px">Tap a look to preview it. Fine-tune it in Adjustments, then press Apply.</p><div class="fgrid"></div>';
  const grid=$('.fgrid',box);
  for(const pr of PRESETS){
    const b=document.createElement('button');b.className='fcard';
    const cv=mkCanvas(src.width,src.height);cctx(cv).putImageData(processAdjust(src,presetParams(pr,src)),0,0);
    b.appendChild(cv);b.insertAdjacentHTML('beforeend','<span>'+esc(pr.n)+'</span>');
    b.addEventListener('click',()=>{flush();applyPreset(pr);setTab('adjust');});grid.appendChild(b);
  }
}

/* ===== layers panel ===== */
const BLENDS=[['source-over','Normal'],['darken','Darken'],['multiply','Multiply'],['color-burn','Colour burn'],['lighten','Lighten'],['screen','Screen'],['color-dodge','Colour dodge'],['overlay','Overlay'],['soft-light','Soft light'],['hard-light','Hard light'],['difference','Difference'],['exclusion','Exclusion'],['hue','Hue'],['saturation','Saturation'],['color','Colour'],['luminosity','Luminosity']];
const EYE='<svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const EYEOFF='<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10 6a9 9 0 0 1 12 6c-.6 1-1.4 2-2.4 3M6.500 7.500C4 9 2.600 11 2 12c1.200 2.200 4.200 6 10 6 1.500 0 2.800-.3 4-.8"/></svg>';
const LOCK='<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const UNLOCK='<svg viewBox="0 0 24 24" style="opacity:.28"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.500-2"/></svg>';
$('#tab-layers').innerHTML='<div class="sl"><span>Opacity</span><input type="range" id="l-opacity" min="0" max="100" value="100"><output id="l-opv">100</output></div>'
 +'<div class="row"><select id="l-blend" aria-label="Blend mode">'+BLENDS.map(b=>'<option value="'+b[0]+'">'+b[1]+'</option>').join('')+'</select></div><div id="layerlist"></div>'
 +'<div class="lbar" role="toolbar" aria-label="Layer actions"><button data-act="lstyle" title="Layer style (shadow, glow, outline)">fx</button><button data-act="maskReveal" title="Add layer mask">Mask</button><button data-act="lnewFill" title="New colour fill layer">Fill</button><button data-act="lnew" title="New layer">New</button><button data-act="ldup" title="Duplicate layer">Copy</button><button data-act="lup" title="Move up" aria-label="Move up">&#8593;</button><button data-act="ldown" title="Move down" aria-label="Move down">&#8595;</button><button data-act="ldel" title="Delete layer">Delete</button></div>';
ACT.lup=ACT.lfwd;ACT.ldown=ACT.lbwd;
function thumb(c,mask){
  const o=mkCanvas(36,36),x=cctx(o);
  if(mask){x.fillStyle='#000';x.fillRect(0,0,36,36);}
  const k=Math.min(36/c.width,36/c.height),w=c.width*k,h=c.height*k;
  if(mask){const t=mkCanvas(c.width,c.height),tx=cctx(t);tx.fillStyle='#fff';tx.fillRect(0,0,t.width,t.height);tx.globalCompositeOperation='destination-in';tx.drawImage(c,0,0);x.drawImage(t,(36-w)/2,(36-h)/2,w,h);}
  else x.drawImage(c,(36-w)/2,(36-h)/2,w,h);
  return o;
}
function refreshLayers(){
  const box=$('#layerlist');if(!box)return;box.innerHTML='';
  if(!doc){$('#l-opacity').value=100;$('#l-opv').textContent='100';return;}
  for(const l of [...doc.layers].reverse()){
    const row=document.createElement('div');row.className='lrow'+(l.id===doc.active?' on':'');row.dataset.id=l.id;
    row.innerHTML='<button class="eye" data-a="vis" title="Show or hide" aria-label="Show or hide layer">'+(l.visible?EYE:EYEOFF)+'</button>'
      +'<div class="th'+(l.id===doc.active&&!l.editMask?' sel':'')+'" data-a="pix"></div>'
      +(l.mask?'<div class="th mk'+(l.id===doc.active&&l.editMask?' sel':'')+'" data-a="mask" title="Layer mask"></div>':'')
      +'<span class="nm">'+esc(l.name)+(hasFx(l.fx)?' <em class="fxb">fx</em>':'')+'</span>'
      +'<button class="eye" data-a="lock" title="Lock or unlock" aria-label="Lock layer">'+(l.locked?LOCK:UNLOCK)+'</button>';
    row.querySelector('[data-a=pix]').appendChild(thumb(l.canvas,false));
    if(l.mask)row.querySelector('[data-a=mask]').appendChild(thumb(l.mask,true));
    box.appendChild(row);
  }
  const a=active();
  $('#l-opacity').value=Math.round((a?a.opacity:1)*100);$('#l-opv').textContent=$('#l-opacity').value;
  $('#l-blend').value=a?a.blend:'source-over';
}
$('#layerlist').addEventListener('click',e=>{
  const row=e.target.closest('.lrow');if(!row)return;
  const id=+row.dataset.id,l=doc.layers.find(x=>x.id===id),a=e.target.closest('[data-a]');
  if(a&&a.dataset.a==='vis'){flush();l.visible=!l.visible;commit('Visibility');redraw();return;}
  if(a&&a.dataset.a==='lock'){flush();l.locked=!l.locked;commit(l.locked?'Lock layer':'Unlock layer');return;}
  if(e.target.tagName==='INPUT')return;
  if(a&&a.dataset.a==='mask'){selectLayer(id);l.editMask=true;refreshLayers();toast('Editing the layer mask. Paint black to hide, white to reveal.');return;}
  if(a&&a.dataset.a==='pix'){selectLayer(id);l.editMask=false;refreshLayers();return;}
  selectLayer(id);
});
$('#layerlist').addEventListener('dblclick',e=>{
  const nm=e.target.closest('.nm');if(!nm)return;
  const row=nm.closest('.lrow'),l=doc.layers.find(x=>x.id===+row.dataset.id);
  const inp=document.createElement('input');inp.type='text';inp.value=l.name;nm.replaceWith(inp);inp.focus();inp.select();
  const done=()=>{l.name=inp.value.trim()||l.name;commit('Rename layer');};
  inp.addEventListener('blur',done,{once:true});inp.addEventListener('keydown',k=>{k.stopPropagation();if(k.key==='Enter')inp.blur();});
});
$('#tab-layers').addEventListener('input',e=>{
  const a=active();if(!a)return;
  if(e.target.id==='l-opacity'){a.opacity=e.target.value/100;$('#l-opv').textContent=e.target.value;pend=true;redraw();}
  if(e.target.id==='l-blend'){a.blend=e.target.value;pend=true;redraw();}
});
$('#tab-layers').addEventListener('change',()=>{if(pend){pend=false;commit('Layer settings');}});
function selectLayer(id){
  flush();doc.active=id;refreshLayers();renderProps();renderAdjMsg();if(S.tab==='filters')renderFilters();redraw();
}
function refreshAll(){refreshLayers();renderProps();renderAdjMsg();if(S.tab==='filters')renderFilters();if(S.tab==='history')renderHistory();setSwatches();updateUndo();updateStatus();renderOpts();}

/* ===== history panel ===== */
function renderHistory(){
  const box=$('#tab-history');
  if(!doc){box.innerHTML='<p class="muted">No document open.</p>';return;}
  box.innerHTML='<div class="hlist">'+hist.map((h,i)=>'<button class="hrow'+(i===hi?' on':'')+(i>hi?' future':'')+'" data-i="'+i+'">'+esc(h.label||'Edit')+'</button>').join('')+'</div>';
  const on=$('.hrow.on',box);if(on)on.scrollIntoView({block:'nearest'});
}
$('#tab-history').addEventListener('click',e=>{const b=e.target.closest('.hrow');if(b)jumpTo(+b.dataset.i);});

/* ===== properties panel ===== */
const TMAP={'p-text':'text','p-font':'font','p-size':'size','p-lh':'lh','p-bold':'bold','p-italic':'italic','p-caps':'caps','p-color':'color','p-tstroke':'stroke','p-tsw':'sw','p-tshadow':'shadow','p-tshcolor':'shadowColor'};
const SMAP={'p-kind':'kind','p-sfill':'fill','p-snofill':'nofill','p-sstroke':'stroke','p-ssw':'sw','p-sradius':'radius','p-wid':'w','p-hei':'h'};
const psl=(label,id,min,max,val,step)=>'<label class="sl"><span>'+label+'</span><input type="range" id="'+id+'" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+val+'"><output>'+val+'</output></label>';
function renderProps(){
  const box=$('#tab-props');if(!box)return;const l=doc&&active();
  if(!doc){box.innerHTML='<p class="muted">No document open.</p>';return;}
  if(!l){box.innerHTML='<div class="h">Document</div><p>'+doc.w+' × '+doc.h+' px</p><p class="muted">Select a layer to see its properties.</p>';return;}
  let h='';
  if(l.type==='text'){
    const p=l.props;
    h+='<div class="h">Text</div><textarea id="p-text" rows="3">'+esc(p.text)+'</textarea>'
     +'<div class="row"><select id="p-font" aria-label="Font">'+fontOptionsHtml(p.font)+'</select><button class="fbtn" data-fontpick="p-font" title="Browse fonts">Aa</button><input type="color" id="p-color" value="'+p.color+'" title="Text colour"></div>'
     +psl('Size','p-size',8,800,Math.round(p.size))+psl('Line gap','p-lh',0.8,2.2,p.lh,0.05)
     +'<div class="row"><label><input type="checkbox" id="p-bold"'+(p.bold?' checked':'')+'> Bold</label><label><input type="checkbox" id="p-italic"'+(p.italic?' checked':'')+'> Italic</label><label><input type="checkbox" id="p-caps"'+(p.caps?' checked':'')+'> CAPS</label></div>'
     +'<div class="seg"><button data-align="left"'+(p.align==='left'?' class="on"':'')+'>Left</button><button data-align="center"'+(p.align==='center'?' class="on"':'')+'>Centre</button><button data-align="right"'+(p.align==='right'?' class="on"':'')+'>Right</button></div>'
     +'<div class="h">Outline and shadow</div><div class="row"><input type="color" id="p-tstroke" value="'+p.stroke+'" title="Outline colour"><span class="muted">Outline</span></div>'+psl('Outline','p-tsw',0,40,p.sw)
     +'<div class="row"><input type="color" id="p-tshcolor" value="'+p.shadowColor+'" title="Shadow colour"><span class="muted">Shadow</span></div>'+psl('Shadow','p-tshadow',0,60,p.shadow);
  }else if(l.type==='shape'){
    const p=l.props;
    if(l.ph)h+='<div class="h">Photo frame</div><div class="row"><button class="primary" data-act="phAdd">Add or replace photo</button></div><p class="muted" style="margin-top:4px">Your picture is placed inside this frame. Move or resize the frame to change the crop. Delete the frame to remove it.</p>';
    h+='<div class="h">Shape</div><div class="row"><select id="p-kind" aria-label="Shape">'+Object.keys(KIND_NAMES).map(k=>'<option value="'+k+'"'+(p.kind===k?' selected':'')+'>'+KIND_NAMES[k]+'</option>').join('')+'</select></div>'
     +'<div class="row"><input type="color" id="p-sfill" value="'+(p.fill||'#f2b134')+'" title="Fill colour"><label><input type="checkbox" id="p-snofill"'+(p.nofill?' checked':'')+'> No fill</label></div>'
     +'<div class="row"><input type="color" id="p-sstroke" value="'+p.stroke+'" title="Outline colour"><span class="muted">Outline</span></div>'+psl('Outline','p-ssw',0,60,Math.round(p.sw))
     +psl('Width','p-wid',4,4000,Math.round(p.w))+psl('Height','p-hei',4,4000,Math.round(p.h))+(p.kind==='round'?psl('Corners','p-sradius',0,500,Math.round(p.radius)):'');
  }else h+='<p class="muted" style="margin-top:0">'+(l.type==='image'?'Photo layer.':'Paint layer.')+' Use Adjustments, Looks and the Filter menu to edit the picture.</p>';
  h+='<div class="h">Mask and style</div><div class="row"><button data-act="'+(l.mask?'maskDel':'maskReveal')+'">'+(l.mask?'Delete mask':'Add mask')+'</button>'+(l.mask?'<button data-act="maskInvert">Invert mask</button><button data-act="maskApply">Apply mask</button>':'')+'<button data-act="lstyle">Layer style...</button></div>';
  h+='<div class="h">Position and size</div><div class="num"><span>X</span><input type="number" id="p-x" value="'+Math.round(l.x)+'"><span>Y</span><input type="number" id="p-y" value="'+Math.round(l.y)+'"><span>Size %</span><input type="number" id="p-scale" value="'+Math.round(l.s*100)+'"><span>Angle</span><input type="number" id="p-rot" value="'+Math.round(l.r*180/Math.PI)+'"></div>'
   +'<div class="row" style="margin-top:10px"><button data-act="rot90">Rotate 90&deg;</button><button data-act="lflipH">Flip &harr;</button><button data-act="lflipV">Flip &varr;</button><button data-act="fitLayer">Fit</button><button data-act="fillLayer">Fill</button></div>';
  box.innerHTML=h;
}
$('#tab-props').addEventListener('input',e=>{
  const l=active();if(!l)return;
  const t=e.target,id=t.id,v=t.type==='checkbox'?t.checked:(t.type==='number'||t.type==='range')?+t.value:t.value;
  if(t.type==='range'&&t.nextElementSibling&&t.nextElementSibling.tagName==='OUTPUT')t.nextElementSibling.textContent=t.value;
  if(id==='p-x'){l.x=v;pend=true;redraw();return;}
  if(id==='p-y'){l.y=v;pend=true;redraw();return;}
  if(id==='p-scale'){l.s=clamp(v/100,0.01,60);pend=true;redraw();return;}
  if(id==='p-rot'){l.r=v*Math.PI/180;pend=true;redraw();return;}
  if(l.type==='text'&&TMAP[id]){l.props[TMAP[id]]=v;renderText(l);pend=true;}
  else if(l.type==='shape'&&SMAP[id]){l.props[SMAP[id]]=v;if(id==='p-kind'){l.name=KIND_NAMES[v];if(v==='round')renderProps();}renderShape(l);pend=true;}
});
$('#tab-props').addEventListener('change',()=>{if(pend){pend=false;commit('Properties');}});
$('#tab-props').addEventListener('click',e=>{
  const b=e.target.closest('[data-align]');if(!b)return;
  const l=active();if(!l||l.type!=='text')return;
  flush();l.props.align=b.dataset.align;renderText(l);commit('Type');renderProps();
});
