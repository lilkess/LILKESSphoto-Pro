(()=>{
'use strict';
/* ===== helpers ===== */
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const hexRgb=h=>{h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return [n>>16&255,n>>8&255,n&255];};
const rgbHex=(r,g,b)=>'#'+[r,g,b].map(v=>clamp(Math.round(v),0,255).toString(16).padStart(2,'0')).join('');
const rgbaStr=(h,a)=>{const c=hexRgb(h);return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';};
const lumHex=h=>{const c=hexRgb(h);return 0.299*c[0]+0.587*c[1]+0.114*c[2];};
const FONTS=['Montserrat','Anton','Bebas Neue','Oswald','Playfair Display','Pacifico','Lobster','Dancing Script','Permanent Marker','Roboto Slab','Arial','Georgia','Impact','Verdana','Courier New'];

function mkCanvas(w,h){const c=document.createElement('canvas');c.width=Math.max(1,Math.round(w));c.height=Math.max(1,Math.round(h));return c;}
function cctx(c){return c.getContext('2d',{willReadFrequently:true});}
function cloneCanvas(c){const n=mkCanvas(c.width,c.height);cctx(n).drawImage(c,0,0);return n;}

/* ===== state ===== */
let doc=null,hist=[],hi=-1,dirty=false,pend=false,guides={x:null,y:null};
const docs=[];let cur=-1,docSeq=0;
const S={tool:'move',toolBtn:'move',fg:'#000000',bg:'#ffffff',zoom:1,px:0,py:0,autoFit:true,sel:null,lastSel:null,crop:null,tab:'layers',auto:true,aspect:0,selMode:'new',
  brush:{size:40,hard:0.6,flow:1},eraser:{size:60,hard:0.8,flow:1},
  retouch:{mode:'smooth',size:70,strength:0.5},fill:{mode:'fill',tol:32},grad:{kind:'linear',mode:'fgbg'},
  shape:{kind:'rect',fill:'#f2b134',stroke:'#111111',sw:0},marq:{kind:'rect'},lasso:{kind:'free'},wand:{tol:32,contig:true},
  srcPt:null,settingSrc:false,rulers:true,grid:false,snap:true,showGuides:true,clip:null,dragGuide:null};
const view=$('#view'),over=$('#over'),vctx=view.getContext('2d'),octx=over.getContext('2d'),vp=$('#vp'),stage=$('#stage');
let toastTimer=0;
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2800);}

/* ===== layers ===== */
const active=()=>doc&&doc.layers.find(l=>l.id===doc.active)||null;
function touch(l){l.ver++;redraw();}
function touchMask(l){l.mver++;redraw();}
function addLayer(o={}){
  const w=o.w||doc.w,h=o.h||doc.h;
  const l={id:doc.nextId++,name:o.name||('Layer '+doc.nextId),type:o.type||'raster',visible:true,locked:!!o.locked,opacity:1,blend:'source-over',
    x:o.x!=null?o.x:doc.w/2,y:o.y!=null?o.y:doc.h/2,s:1,r:0,canvas:mkCanvas(w,h),ver:0,props:o.props||null,mask:null,mver:0,editMask:false,fx:null,pvv:0};
  if(o.fill){const c=cctx(l.canvas);c.fillStyle=o.fill;c.fillRect(0,0,w,h);}
  let idx=doc.layers.length;
  if(o.above){const a=active();if(a)idx=doc.layers.indexOf(a)+1;}
  doc.layers.splice(idx,0,l);
  if(o.select!==false)doc.active=l.id;
  return l;
}
const clone=o=>o?JSON.parse(JSON.stringify(o)):null;
const pxLocked=l=>!!(l&&(l.locked||(l.lk&&l.lk.i)));
const posLocked=l=>!!(l&&(l.locked||(l.lk&&l.lk.p)));
function meta(l){return {lk:clone(l.lk),id:l.id,name:l.name,type:l.type,visible:l.visible,locked:l.locked,opacity:l.opacity,blend:l.blend,x:l.x,y:l.y,s:l.s,r:l.r,props:clone(l.props),fx:clone(l.fx),editMask:!!l.editMask,pvv:0,clip:!!l.clip,fillOp:l.fillOp==null?1:l.fillOp,smart:!!l.smart,sf:clone(l.sf),orig:l.orig||null,so:l.so||null,adj:clone(l.adj),group:l.group||0,bd:l.bd||null,ph:!!l.ph};}

/* ===== documents, tabs and history ===== */
function snapshot(label){
  const prev=hist[hi];
  const layers=doc.layers.map(l=>{
    const pv=prev&&prev.layers.find(q=>q.id===l.id);
    let cv,mk=null;
    if(pv&&pv.ver===l.ver&&pv.canvas.width===l.canvas.width&&pv.canvas.height===l.canvas.height)cv=pv.canvas;else cv=cloneCanvas(l.canvas);
    if(l.mask){mk=(pv&&pv.mask&&pv.mver===l.mver&&pv.mask.width===l.mask.width&&pv.mask.height===l.mask.height)?pv.mask:cloneCanvas(l.mask);}
    return Object.assign(meta(l),{ver:l.ver,mver:l.mver,canvas:cv,mask:mk});
  });
  return {label:label||'Edit',w:doc.w,h:doc.h,active:doc.active,nextId:doc.nextId,layers,paths:clone(doc.paths||[]),ap:doc.ap==null?-1:doc.ap,extra:clone(doc.extra||null)};
}
function commit(label){
  if(!doc)return;
  hist.length=hi+1;hist.push(snapshot(label));hi=hist.length-1;
  while(hist.length>(S.histMax||50)){hist.shift();hi--;}
  if(hist.length>1)doc.modified=true;
  refreshLayers();updateUndo();renderTabs();
  if(S.tab==='filters')renderFilters();
  if(S.tab==='history')renderHistory();
}
function restore(s){
  doc.w=s.w;doc.h=s.h;doc.active=s.active;doc.nextId=s.nextId;doc.paths=clone(s.paths||[]);doc.ap=s.ap==null?-1:s.ap;doc.extra=clone(s.extra||null);
  doc.layers=s.layers.map(q=>Object.assign(meta(q),{canvas:cloneCanvas(q.canvas),ver:q.ver,mver:q.mver||0,mask:q.mask?cloneCanvas(q.mask):null,pvv:0}));
  resizeStage();refreshAll();redraw();
}
function jumpTo(n){flush();if(n<0||n>=hist.length)return;hi=n;restore(hist[hi]);doc.modified=true;updateUndo();renderTabs();if(S.tab==='history')renderHistory();}
function undo(){flush();if(hi>0){hi--;restore(hist[hi]);doc.modified=true;renderTabs();}updateUndo();if(S.tab==='history')renderHistory();}
function redo(){flush();if(hi<hist.length-1){hi++;restore(hist[hi]);doc.modified=true;renderTabs();}updateUndo();if(S.tab==='history')renderHistory();}
function updateUndo(){$('#undo').disabled=!doc||hi<=0;$('#redo').disabled=!doc||hi>=hist.length-1;}
function flush(){if(sess){if(sess.kind==='filter')sessCancelQuiet();else sessFinish();}if(pend){pend=false;commit();}}

function saveCur(){
  if(cur<0||!docs[cur])return;
  Object.assign(docs[cur],{doc,hist,hi,zoom:S.zoom,px:S.px,py:S.py,autoFit:S.autoFit,sel:S.sel,lastSel:S.lastSel});
}
function loadEntry(i){
  const e=docs[i];cur=i;doc=e.doc;hist=e.hist;hi=e.hi;S.zoom=e.zoom;S.px=e.px;S.py=e.py;S.autoFit=e.autoFit;S.sel=e.sel;S.lastSel=e.lastSel;S.crop=null;
}
function startDoc(name,w,h,ppi){
  saveCur();
  const d={id:++docSeq,name:name||'Untitled-'+docSeq,w:Math.round(w),h:Math.round(h),ppi:ppi||72,layers:[],active:null,nextId:1,guides:[],modified:false,projId:null};
  doc=d;hist=[];hi=-1;S.sel=null;S.lastSel=null;S.crop=null;guides={x:null,y:null};sessCancelQuiet();
  docs.push({doc,hist,hi,zoom:1,px:0,py:0,autoFit:true,sel:null,lastSel:null});cur=docs.length-1;
}
function finishDoc(){
  const top=doc.layers[doc.layers.length-1];
  if(top)doc.active=top.id;
  commit('New');doc.modified=false;resizeStage();S.autoFit=true;hideWelcome();fitView();refreshAll();renderTabs();redraw();
}
function switchDoc(i){
  if(i===cur||!docs[i])return;
  flush();saveCur();loadEntry(i);resizeStage();hideWelcome();refreshAll();applyView();renderTabs();redraw();
}
function closeDoc(i,force){
  const e=docs[i];if(!e)return;
  if(!force&&e.doc.modified){askSaveBeforeClose(i);return;}
  if(i===cur){flush();}
  docs.splice(i,1);
  if(!docs.length){doc=null;hist=[];hi=-1;cur=-1;S.sel=null;renderTabs();refreshAll();showWelcome();return;}
  const n=Math.min(i,docs.length-1);
  if(i===cur||cur>=docs.length){cur=-1;loadEntry(n);resizeStage();refreshAll();applyView();}
  else if(i<cur)cur--;
  renderTabs();redraw();
}
function resizeStage(){
  if(!doc)return;
  view.width=over.width=doc.w;view.height=over.height=doc.h;
  stage.style.width=doc.w+'px';stage.style.height=doc.h+'px';
  vctx.imageSmoothingQuality='high';
}

/* ===== geometry ===== */
function toLocal(l,p){
  const dx=p.x-l.x,dy=p.y-l.y,c=Math.cos(-l.r),s=Math.sin(-l.r);
  return {x:(dx*c-dy*s)/l.s+l.canvas.width/2,y:(dx*s+dy*c)/l.s+l.canvas.height/2};
}
function fromLocal(l,q){
  const dx=(q.x-l.canvas.width/2)*l.s,dy=(q.y-l.canvas.height/2)*l.s,c=Math.cos(l.r),s=Math.sin(l.r);
  return {x:l.x+dx*c-dy*s,y:l.y+dx*s+dy*c};
}
function docToLocalM(l){
  const c=Math.cos(-l.r),s=Math.sin(-l.r),k=1/l.s,hw=l.canvas.width/2,hh=l.canvas.height/2;
  return [c*k,s*k,-s*k,c*k,(-l.x*c+l.y*s)*k+hw,(-l.x*s-l.y*c)*k+hh];
}
function layerCorners(l){
  const hw=l.canvas.width/2*l.s,hh=l.canvas.height/2*l.s,c=Math.cos(l.r),s=Math.sin(l.r);
  return [[-hw,-hh],[hw,-hh],[hw,hh],[-hw,hh]].map(([x,y])=>({x:l.x+x*c-y*s,y:l.y+x*s+y*c}));
}
function rotHandle(l){
  const hh=l.canvas.height/2*l.s+40/S.zoom,c=Math.cos(l.r),s=Math.sin(l.r);
  return {x:l.x+hh*s,y:l.y-hh*c};
}
function handleAt(p){
  const l=active();if(!l||!l.visible||S.tool!=='move')return null;
  const tol=24/S.zoom;
  for(const c of layerCorners(l))if(Math.hypot(p.x-c.x,p.y-c.y)<tol)return 'scale';
  const r=rotHandle(l);if(Math.hypot(p.x-r.x,p.y-r.y)<tol)return 'rotate';
  return null;
}
function pointInLayer(l,p){
  const q=toLocal(l,p);
  if(q.x<0||q.y<0||q.x>=l.canvas.width||q.y>=l.canvas.height)return false;
  if(l.type==='text'||l.type==='shape')return true;
  return cctx(l.canvas).getImageData(Math.floor(q.x),Math.floor(q.y),1,1).data[3]>8;
}
function findLayerAt(p){
  for(let i=doc.layers.length-1;i>=0;i--){const l=doc.layers[i];if(l.visible&&!l.locked&&l.opacity>0&&pointInLayer(l,p))return l;}
  return null;
}

/* ===== compositing: masks and layer styles ===== */
function hasFx(f){return !!(f&&fxr_hasAny(f));}
function layerSource(l){
  const src=l.pv||l.canvas;
  if(!l.mask)return src;
  const key=l.ver+':'+l.mver+':'+l.pvv;
  if(!l._mc||l._mc.key!==key){
    const n=mkCanvas(src.width,src.height),x=n.getContext('2d');
    x.drawImage(src,0,0);x.globalCompositeOperation='destination-in';x.drawImage(l.mask,0,0,src.width,src.height);
    l._mc={key,canvas:n};
  }
  return l._mc.canvas;
}
function patternTile(id){return typeof PATTERN_TILE==='function'?PATTERN_TILE(id):null;}
/* layer styles: rendered on a work canvas that covers the layer plus the effect reach, clipped to the document */
let FX_SCALE=1;
function fxCanvas(l,src){
  const key=[l.ver,l.mver,l.pvv,l.x,l.y,l.s,l.r,doc.w,doc.h,l.fillOp,JSON.stringify(l.fx)].join('|');
  if(l._fc&&l._fc.key===key)return l._fc;
  const pad=Math.ceil(fxr_pad(l.fx)*FX_SCALE)+2,cs=layerCorners(l),X=cs.map(c=>c.x),Y=cs.map(c=>c.y);
  const bx=Math.max(0,Math.floor(Math.min(...X)-pad)),by=Math.max(0,Math.floor(Math.min(...Y)-pad));
  const bw=Math.min(doc.w,Math.ceil(Math.max(...X)+pad))-bx,bh=Math.min(doc.h,Math.ceil(Math.max(...Y)+pad))-by;
  if(bw<1||bh<1){l._fc={key,canvas:mkCanvas(1,1),bx:0,by:0};return l._fc;}
  const lay=mkCanvas(bw,bh),lx=lay.getContext('2d');
  lx.translate(l.x-bx,l.y-by);lx.rotate(l.r);lx.scale(l.s,l.s);lx.drawImage(src,-l.canvas.width/2,-l.canvas.height/2,l.canvas.width,l.canvas.height);
  const out=fxr_render(lay,l.fx,{fillOpacity:l.fillOp==null?1:l.fillOp,patternFn:patternTile,scale:FX_SCALE});
  l._fc={key,canvas:out,bx,by};
  return l._fc;
}
function drawLayerEx(ctx,l,o){
  const src=layerSource(l),alpha=o&&o.alpha!=null?o.alpha:l.opacity,blend=o&&o.blend?o.blend:l.blend;
  if(!(o&&o.nofx)&&hasFx(l.fx)){
    const fc=fxCanvas(l,src);
    ctx.save();ctx.globalAlpha=alpha;ctx.globalCompositeOperation=blend;ctx.drawImage(fc.canvas,fc.bx,fc.by);ctx.restore();return;
  }
  ctx.save();ctx.globalAlpha=alpha*(l.fillOp==null?1:l.fillOp);ctx.globalCompositeOperation=blend;
  ctx.translate(l.x,l.y);ctx.rotate(l.r);ctx.scale(l.s,l.s);
  ctx.drawImage(src,-l.canvas.width/2,-l.canvas.height/2,l.canvas.width,l.canvas.height);ctx.restore();
}
function drawLayer(ctx,l){drawLayerEx(ctx,l,null);}
/* a base layer and the layers clipped to it (Photoshop clipping mask) are drawn together */
function groupKey(g){return g.map(l=>[l.id,l.ver,l.mver,l.pvv,l.x,l.y,l.s,l.r,l.opacity,l.blend,l.visible,l.fillOp,l.fx?JSON.stringify(l.fx):'',l.adj?JSON.stringify(l.adj):''].join(',')).join(';')+'|'+doc.w+'x'+doc.h;}
function drawGroup(ctx,g){
  const base=g[0],key=groupKey(g);
  if(!base._gc||base._gc.key!==key){
    const W=doc.w,H=doc.h,tmp=mkCanvas(W,H),tx=tmp.getContext('2d');
    drawLayerEx(tx,base,{alpha:1,blend:'source-over',nofx:true});
    const alphaSrc=mkCanvas(W,H);alphaSrc.getContext('2d').drawImage(tmp,0,0);
    for(let i=1;i<g.length;i++){
      const m=g[i];if(!m.visible)continue;
      const mc=mkCanvas(W,H),mx=mc.getContext('2d');
      if(m.type==='adjust')applyAdjustLayer(mx,tmp,m);else drawLayerEx(mx,m,{alpha:m.opacity,blend:'source-over'});
      if(m.type==='adjust'){mx.globalCompositeOperation='destination-in';mx.drawImage(alphaSrc,0,0);tx.save();tx.globalAlpha=1;tx.drawImage(mc,0,0);tx.restore();continue;}
      mx.globalCompositeOperation='destination-in';mx.drawImage(alphaSrc,0,0);
      tx.save();tx.globalCompositeOperation=m.blend;tx.drawImage(mc,0,0);tx.restore();
    }
    let out=tmp;
    if(hasFx(base.fx))out=fxr_render(tmp,base.fx,{fillOpacity:base.fillOp==null?1:base.fillOp,patternFn:patternTile,scale:FX_SCALE});
    base._gc={key,canvas:out};
  }
  ctx.save();ctx.globalAlpha=base.opacity;ctx.globalCompositeOperation=base.blend;ctx.drawImage(base._gc.canvas,0,0);ctx.restore();
}
function composeList(ctx,list){
  for(let i=0;i<list.length;i++){
    const l=list[i];
    if(l.type==='adjust'&&!l.clip){if(l.visible)drawAdjustOnto(ctx,l);continue;}
    let j=i+1;while(j<list.length&&list[j].clip)j++;
    if(!l.visible){i=j-1;continue;}
    if(j===i+1){drawLayer(ctx,l);continue;}
    drawGroup(ctx,list.slice(i,j));i=j-1;
  }
}
function compose(ctx,scale){
  ctx.save();ctx.scale(scale||1,scale||1);
  drawBoardsBg(ctx);
  composeList(ctx,doc.layers);
  ctx.restore();
}
function render(){dirty=false;if(!doc)return;vctx.clearRect(0,0,doc.w,doc.h);compose(vctx,1);drawOver();}
function redraw(){if(!dirty){dirty=true;requestAnimationFrame(()=>{if(dirty)render();});}}

/* ===== selection (raster mask) ===== */
function selNew(){const c=mkCanvas(doc.w,doc.h);return {c,ctx:c.getContext('2d')};}
function selScan(c){
  const W=c.width,H=c.height,id=cctx(c).getImageData(0,0,W,H),d=id.data;
  let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++){const row=y*W*4;for(let x=0;x<W;x++){if(d[row+x*4+3]>127){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}}}
  if(x1<0)return null;
  const e=mkCanvas(W,H),ex=cctx(e),ed=ex.createImageData(W,H),o=ed.data;
  const A=(x,y)=>(x<0||y<0||x>=W||y>=H)?0:d[(y*W+x)*4+3]>127?1:0;
  for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
    if(!A(x,y))continue;
    if(!A(x-1,y)||!A(x+1,y)||!A(x,y-1)||!A(x,y+1)){
      const i=(y*W+x)*4,v=(((x>>2)+(y>>2))&1)?255:0;o[i]=v;o[i+1]=v;o[i+2]=v;o[i+3]=255;
    }
  }
  ex.putImageData(ed,0,0);
  return {c,edge:e,bbox:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}};
}
function setSelection(newMask,mode){
  mode=mode||S.selMode;
  if(!S.sel||mode==='new'){
    const s=selScan(newMask);if(s)S.lastSel=S.sel||S.lastSel;S.sel=s;
  }else{
    const m=S.sel.c,x=m.getContext('2d'),tmp=cloneCanvas(m),tx=tmp.getContext('2d');
    if(mode==='add'){tx.globalCompositeOperation='source-over';tx.drawImage(newMask,0,0);}
    else if(mode==='sub'){tx.globalCompositeOperation='destination-out';tx.drawImage(newMask,0,0);}
    else if(mode==='int'){tx.globalCompositeOperation='destination-in';tx.drawImage(newMask,0,0);}
    S.lastSel=S.sel;S.sel=selScan(tmp);
  }
  redraw();
}
function selFromPathFn(fn,mode){const n=selNew();n.ctx.fillStyle='#fff';fn(n.ctx);setSelection(n.c,mode);}
function selAll(){const n=selNew();n.ctx.fillStyle='#fff';n.ctx.fillRect(0,0,doc.w,doc.h);setSelection(n.c,'new');}
function selClearNow(){if(S.sel)S.lastSel=S.sel;S.sel=null;redraw();}
function selInverse(){
  const n=selNew();n.ctx.fillStyle='#fff';n.ctx.fillRect(0,0,doc.w,doc.h);
  if(S.sel){n.ctx.globalCompositeOperation='destination-out';n.ctx.drawImage(S.sel.c,0,0);}
  S.sel=null;setSelection(n.c,'new');
}
function selAlphaCanvasLocal(l){
  if(!S.sel)return null;
  const c=mkCanvas(l.canvas.width,l.canvas.height),x=cctx(c);
  x.setTransform.apply(x,docToLocalM(l));x.drawImage(S.sel.c,0,0);
  return c;
}
function selAlphaLocal(l,w,h){
  const c=selAlphaCanvasLocal(l);if(!c)return null;
  let src=c;
  if(w&&h&&(w!==c.width||h!==c.height)){src=mkCanvas(w,h);cctx(src).drawImage(c,0,0,w,h);}
  const d=cctx(src).getImageData(0,0,src.width,src.height).data,a=new Uint8Array(src.width*src.height);
  for(let i=0;i<a.length;i++)a[i]=d[i*4+3];
  return a;
}
function mixSel(base,out,sel){
  if(!sel)return out;
  const b=base.data,o=out.data;
  for(let i=0,k=0;i<o.length;i+=4,k++){
    const a=sel[k];
    if(a===255)continue;
    if(a===0){o[i]=b[i];o[i+1]=b[i+1];o[i+2]=b[i+2];o[i+3]=b[i+3];continue;}
    const t=a/255;
    o[i]=b[i]+(o[i]-b[i])*t;o[i+1]=b[i+1]+(o[i+1]-b[i+1])*t;o[i+2]=b[i+2]+(o[i+2]-b[i+2])*t;o[i+3]=b[i+3]+(o[i+3]-b[i+3])*t;
  }
  return out;
}

/* ===== overlay ===== */
let hover=null,drag=null;
function drawOver(){
  const o=octx,z=S.zoom;o.clearRect(0,0,doc.w,doc.h);
  if(S.grid){
    let step=S.gridStep||100;while(step*z<28)step*=2;
    o.save();o.lineWidth=1/z;const sub=Math.round(S.gridSub||1);
    if(sub>1&&step*z/sub>=6){o.strokeStyle=S.gridCol||'#78a0ff';o.globalAlpha=.16;o.beginPath();for(let x=step/sub;x<doc.w;x+=step/sub){o.moveTo(x,0);o.lineTo(x,doc.h);}for(let y=step/sub;y<doc.h;y+=step/sub){o.moveTo(0,y);o.lineTo(doc.w,y);}o.stroke();}
    o.globalAlpha=.4;o.strokeStyle=S.gridCol||'#78a0ff';o.beginPath();
    for(let x=step;x<doc.w;x+=step){o.moveTo(x,0);o.lineTo(x,doc.h);}
    for(let y=step;y<doc.h;y+=step){o.moveTo(0,y);o.lineTo(doc.w,y);}
    o.stroke();o.restore();
  }
  if(S.showGuides&&doc.guides){
    o.save();o.strokeStyle=S.guideCol||'#19c2d8';o.lineWidth=1/z;o.beginPath();
    for(const g of doc.guides){if(g.o==='v'){o.moveTo(g.p,0);o.lineTo(g.p,doc.h);}else{o.moveTo(0,g.p);o.lineTo(doc.w,g.p);}}
    o.stroke();o.restore();
  }
  if(S.dragGuide){
    const g=S.dragGuide;o.save();o.strokeStyle=S.guideCol||'#19c2d8';o.lineWidth=1/z;o.beginPath();
    if(g.o==='v'){o.moveTo(g.p,0);o.lineTo(g.p,doc.h);}else{o.moveTo(0,g.p);o.lineTo(doc.w,g.p);}
    o.stroke();o.restore();
  }
  if(guides.x!=null||guides.y!=null){
    o.save();o.strokeStyle='#ff4fa3';o.lineWidth=1/z;o.beginPath();
    if(guides.x!=null){o.moveTo(guides.x,0);o.lineTo(guides.x,doc.h);}
    if(guides.y!=null){o.moveTo(0,guides.y);o.lineTo(doc.w,guides.y);}
    o.stroke();o.restore();
  }
  if(S.sel)o.drawImage(S.sel.edge,0,0);
  if(drag&&(drag.k==='marquee'||drag.k==='lasso')){
    o.save();o.lineWidth=1/z;o.setLineDash([5/z,5/z]);o.strokeStyle='#fff';
    if(drag.k==='marquee'){
      const a=drag.p0,b=drag.p1,x=Math.min(a.x,b.x),y=Math.min(a.y,b.y),w=Math.abs(b.x-a.x),h=Math.abs(b.y-a.y);
      if(S.marq.kind==='ellipse'){o.beginPath();o.ellipse(x+w/2,y+h/2,w/2,h/2,0,0,7);o.stroke();}else o.strokeRect(x,y,w,h);
    }else if(drag.pts&&drag.pts.length){
      o.beginPath();drag.pts.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));
      if(drag.cursor)o.lineTo(drag.cursor.x,drag.cursor.y);o.stroke();
    }
    o.restore();
  }
  if(S.tool==='crop'&&S.crop){
    const c=S.crop;o.save();o.fillStyle='rgba(0,0,0,.58)';
    o.beginPath();o.rect(0,0,doc.w,doc.h);o.rect(c.x,c.y,c.w,c.h);o.fill('evenodd');
    o.strokeStyle='#fff';o.lineWidth=1.5/z;o.strokeRect(c.x,c.y,c.w,c.h);
    o.lineWidth=.8/z;o.globalAlpha=.5;o.beginPath();
    for(let i=1;i<3;i++){o.moveTo(c.x+c.w*i/3,c.y);o.lineTo(c.x+c.w*i/3,c.y+c.h);o.moveTo(c.x,c.y+c.h*i/3);o.lineTo(c.x+c.w,c.y+c.h*i/3);}
    o.stroke();o.restore();
  }
  if(drag&&drag.k==='shape'){
    const a=drag.p0,b=drag.p1;o.save();o.strokeStyle='#f2b134';o.lineWidth=1.5/z;o.setLineDash([6/z,4/z]);
    o.strokeRect(Math.min(a.x,b.x),Math.min(a.y,b.y),Math.abs(b.x-a.x),Math.abs(b.y-a.y));o.restore();
  }
  if(drag&&drag.k==='gradient'){
    const a=drag.p0,b=drag.p1;o.save();o.strokeStyle='#f2b134';o.fillStyle='#f2b134';o.lineWidth=2/z;
    o.beginPath();o.moveTo(a.x,a.y);o.lineTo(b.x,b.y);o.stroke();
    o.beginPath();o.arc(a.x,a.y,5/z,0,7);o.fill();o.beginPath();o.arc(b.x,b.y,5/z,0,7);o.fill();o.restore();
  }
  const l=active();
  if(S.tool==='move'&&l&&l.visible&&!S.xfOwn&&!(drag&&drag.k==='paint')){
    const c=layerCorners(l),rh=rotHandle(l);
    o.save();o.strokeStyle='#4b9eff';o.lineWidth=1.5/z;o.beginPath();
    c.forEach((q,i)=>i?o.lineTo(q.x,q.y):o.moveTo(q.x,q.y));o.closePath();o.stroke();
    const tm={x:(c[0].x+c[1].x)/2,y:(c[0].y+c[1].y)/2};
    o.beginPath();o.moveTo(tm.x,tm.y);o.lineTo(rh.x,rh.y);o.stroke();
    o.fillStyle='#4b9eff';o.beginPath();o.arc(rh.x,rh.y,9/z,0,7);o.fill();
    o.fillStyle='#fff';const hs=14/z;
    c.forEach(q=>{o.fillRect(q.x-hs/2,q.y-hs/2,hs,hs);o.strokeRect(q.x-hs/2,q.y-hs/2,hs,hs);});
    o.restore();
  }
  if(S.tool==='retouch'&&S.retouch.mode==='clone'&&S.srcPt&&l&&S.srcPt.id===l.id){
    const q=fromLocal(l,S.srcPt);o.save();o.strokeStyle='#46c28a';o.lineWidth=2/z;
    o.beginPath();o.moveTo(q.x-12/z,q.y);o.lineTo(q.x+12/z,q.y);o.moveTo(q.x,q.y-12/z);o.lineTo(q.x,q.y+12/z);o.stroke();
    o.beginPath();o.arc(q.x,q.y,8/z,0,7);o.stroke();o.restore();
  }
  if(hover&&brushLike(S.tool)){
    const sz=brushSizeOf(S.tool)/2;
    o.save();o.lineWidth=1/z;o.strokeStyle='#fff';o.beginPath();o.arc(hover.x,hover.y,sz,0,7);o.stroke();
    o.strokeStyle='#000';o.globalAlpha=.6;o.beginPath();o.arc(hover.x,hover.y,sz+1/z,0,7);o.stroke();o.restore();
  }
  drawToolOver(o,z);
}

/* ===== view, rulers ===== */
function applyView(){
  if(!doc)return;
  stage.style.transform='translate('+S.px+'px,'+S.py+'px) rotate('+(S.rot||0)+'rad) scale('+S.zoom+')';document.body.classList.toggle('rotated',!!S.rot);
  const zi=$('#zoomin');if(zi&&document.activeElement!==zi)zi.value=Math.round(S.zoom*100)+'%';
  drawRulers();updateStatus();redraw();
}
function fitView(){
  if(!doc)return;const r=vp.getBoundingClientRect(),m=22;
  if(r.width<10)return;
  S.zoom=clamp(Math.min((r.width-m*2)/doc.w,(r.height-m*2)/doc.h),0.02,4);
  S.px=(r.width-doc.w*S.zoom)/2;S.py=(r.height-doc.h*S.zoom)/2;applyView();
}
function zoomAt(z,cx,cy){
  z=clamp(z,0.02,32);const k=z/S.zoom;S.px=cx-(cx-S.px)*k;S.py=cy-(cy-S.py)*k;S.zoom=z;S.autoFit=false;applyView();
}
function toDoc(e){const r=vp.getBoundingClientRect();return viewToDoc(e.clientX-r.left,e.clientY-r.top);}
new ResizeObserver(()=>{if(doc&&S.autoFit)fitView();else drawRulers();}).observe(vp);

function rulerSteps(z){
  const t=[1,2,5,10,20,50,100,200,500,1000,2000,5000,10000];
  for(const s of t)if(s*z>=60)return s;
  return 20000;
}
function drawRuler(cv,horiz){
  const dpr=window.devicePixelRatio||1,r=cv.getBoundingClientRect();
  if(r.width<2||r.height<2)return;
  const W=Math.round(r.width*dpr),H=Math.round(r.height*dpr);
  if(cv.width!==W||cv.height!==H){cv.width=W;cv.height=H;}
  const x=cv.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);
  const cs=getComputedStyle(document.documentElement);
  x.fillStyle=cs.getPropertyValue('--ruler').trim()||'#3a3a3a';x.fillRect(0,0,r.width,r.height);
  if(!doc)return;
  const step=rulerSteps(S.zoom),off=horiz?S.px:S.py,len=horiz?r.width:r.height;
  x.strokeStyle='#8a8a8a';x.fillStyle='#b5b5b5';x.font='10px system-ui,sans-serif';x.lineWidth=1;x.beginPath();
  const a=Math.floor((-off/S.zoom)/step)*step,b=(len-off)/S.zoom;
  for(let v=a;v<=b;v+=step){
    const p=Math.round(off+v*S.zoom)+0.5;
    if(horiz){x.moveTo(p,r.height);x.lineTo(p,0);}else{x.moveTo(r.width,p);x.lineTo(0,p);}
    for(let k=1;k<10;k++){
      const q=Math.round(off+(v+step*k/10)*S.zoom)+0.5,h=k===5?r.height*0.45:r.height*0.22;
      if(step*S.zoom/10<4)continue;
      if(horiz){x.moveTo(q,r.height);x.lineTo(q,r.height-h);}else{x.moveTo(r.width,q);x.lineTo(r.width-h,q);}
    }
  }
  x.stroke();
  for(let v=a;v<=b;v+=step){
    const p=off+v*S.zoom;
    if(horiz)x.fillText(String(v),p+3,10);
    else{x.save();x.translate(10,p+3);x.rotate(-Math.PI/2);x.textAlign='right';x.fillText(String(v),0,0);x.restore();}
  }
  x.strokeStyle='#222';x.beginPath();
  if(horiz){x.moveTo(0,r.height-.5);x.lineTo(r.width,r.height-.5);}else{x.moveTo(r.width-.5,0);x.lineTo(r.width-.5,r.height);}
  x.stroke();
}
function drawRulers(){if(!S.rulers)return;drawRuler($('#rulerH'),true);drawRuler($('#rulerV'),false);}

/* ===== pixel helpers ===== */
function blurH(s,t,w,h,r){
  const n=2*r+1;
  for(let y=0;y<h;y++){const o=y*w*4;
    for(let c=0;c<4;c++){let acc=0;
      for(let i=-r;i<=r;i++)acc+=s[o+Math.min(w-1,Math.max(0,i))*4+c];
      for(let x=0;x<w;x++){t[o+x*4+c]=acc/n;acc+=s[o+Math.min(w-1,x+r+1)*4+c]-s[o+Math.max(0,x-r)*4+c];}
    }}
}
function blurV(s,t,w,h,r){
  const n=2*r+1,st=w*4;
  for(let x=0;x<w;x++){
    for(let c=0;c<4;c++){const o=x*4+c;let acc=0;
      for(let i=-r;i<=r;i++)acc+=s[o+Math.min(h-1,Math.max(0,i))*st];
      for(let y=0;y<h;y++){t[o+y*st]=acc/n;acc+=s[o+Math.min(h-1,y+r+1)*st]-s[o+Math.max(0,y-r)*st];}
    }}
}
function boxBlur(d,w,h,r,it){
  if(r<1)return d;const t=new Uint8ClampedArray(d.length);
  for(let k=0;k<(it||1);k++){blurH(d,t,w,h,r);blurV(t,d,w,h,r);}
  return d;
}
