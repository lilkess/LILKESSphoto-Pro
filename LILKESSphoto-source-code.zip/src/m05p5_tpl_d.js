/* ===== Templates: Social ===== */
TEMPLATES.push(
{name:'Thank you',cat:'Social',tags:'thank you thanks gratitude customers post',w:1080,h:1080,build(){
  tGrad('#fce7f3','#fbcfe8',160);
  tShape('ellipse',.5,.5,.86,.86,'#ffffff',{name:'Circle'}).opacity=.6;
  tCustom('heart',.5,.2,.1,.1,'#e11d48',{name:'Heart'});
  tText('Thank',0.5,0.37,{font:'Great Vibes',size:230,bold:false,color:'#be123c'});
  tText('YOU',0.5,0.56,{font:'Gloock',size:250,bold:false,color:'#881337'});
  tText('for being part of our journey',0.5,0.73,{font:'Instrument Serif',size:66,bold:false,italic:true,color:'#9f1239'});
  tText('— YOUR BRAND —',0.5,0.86,{font:'Outfit',size:40,color:'#be123c'});
}},
{name:'Big announcement',cat:'Social',tags:'announcement news update big post',w:1080,h:1080,build(){
  tSolid('#2563eb');
  tShape('rect',.5,.5,1.3,.4,'#1d4ed8',{name:'Band'}).r=-.2;
  tShape('round',.5,.18,.46,.08,'#fde047',{name:'Tag',p:{radius:40}});
  tText('ANNOUNCEMENT',0.5,0.18,{font:'Outfit',size:44,color:'#1e3a8a'});
  tText('BIG NEWS\nIS HERE!',0.5,0.47,{font:'Big Shoulders Display',size:290,color:'#ffffff',lh:.9});
  tText('We have something exciting to share with you.\nStay tuned for the details.',0.5,0.78,{font:'Outfit',size:44,bold:false,color:'#dbeafe',lh:1.45});
  tText('@yourbrand',0.5,0.92,{font:'Outfit',size:44,color:'#fde047'});
}},
{name:'YouTube thumbnail',cat:'Social',tags:'youtube thumbnail video cover',w:1280,h:720,build(){
  tGrad('#7c3aed','#2563eb',120);
  tCustom('burst',.78,.5,.7,.7,'#fde047',{name:'Burst'}).opacity=.9;
  tText('I TRIED IT\nFOR 30 DAYS',0.34,0.42,{font:'Big Shoulders Display',size:150,color:'#ffffff',stroke:'#000000',sw:12,lh:.95,shadow:14,shadowColor:'#000000'});
  tShape('rect',.34,.82,.46,.1,'#ef4444',{name:'Label'});
  tText('SHOCKING RESULTS',0.34,0.82,{font:'Outfit',size:54,color:'#ffffff'});
  tText('WOW!',0.8,0.62,{font:'Erica One',size:150,bold:false,color:'#7c3aed',stroke:'#ffffff',sw:8});
}},
{name:'Facebook cover',cat:'Social',tags:'facebook cover banner header page',w:1640,h:624,build(){
  tGrad('#0f172a','#1e3a8a',100);
  tShape('ellipse',.85,.5,.5,.5,'#3b82f6',{name:'Glow'}).opacity=.3;
  tShape('ellipse',.92,.5,.3,.3,'#60a5fa',{name:'Glow 2'}).opacity=.3;
  tText('YOUR BRAND NAME',0.32,0.38,{font:'Big Shoulders Display',size:140,color:'#ffffff',align:'center'});
  tText('Quality products  •  Fast delivery  •  Great service',0.32,0.68,{font:'Outfit',size:34,bold:false,color:'#bfdbfe'});
  tShape('round',.32,.84,.2,.07,'#fbbf24',{name:'Button',p:{radius:30}});
  tText('SHOP NOW',0.32,0.84,{font:'Outfit',size:34,color:'#0f172a'});
}},
{name:'Podcast cover',cat:'Social',tags:'podcast cover art audio show',w:1080,h:1080,build(){
  tGrad('#fb7185','#f97316',140);
  tShape('ellipse',.5,.5,.9,.9,null,{name:'Ring',p:{stroke:'#ffffff',sw:6,nofill:true}}).opacity=.6;
  tShape('ellipse',.5,.5,.7,.7,null,{name:'Ring 2',p:{stroke:'#ffffff',sw:4,nofill:true}}).opacity=.4;
  tText('THE',0.5,0.27,{font:'Outfit',size:70,color:'#ffffff'});
  tText('REAL\nTALK',0.5,0.5,{font:'Erica One',size:230,bold:false,color:'#ffffff',lh:.95,shadow:20,shadowColor:'#9a340066'});
  tText('PODCAST',0.5,0.74,{font:'Big Shoulders Display',size:130,color:'#431407'});
  tText('Hosted by Your Name',0.5,0.88,{font:'Instrument Serif',size:60,bold:false,italic:true,color:'#ffffff'});
}},
{name:'Q&A story',cat:'Social',tags:'question answer ask me story instagram',w:1080,h:1920,build(){
  tGrad('#0ea5e9','#6366f1',160);
  tDots(14,'#ffffff',9,[0,0,1,1],.05,.15,.15);
  tText('ASK ME',0.5,0.2,{font:'Big Shoulders Display',size:330,color:'#ffffff'});
  tText('ANYTHING',0.5,0.32,{font:'Big Shoulders Display',size:260,color:'#fde047'});
  tShape('round',.5,.55,.82,.2,'#ffffff',{name:'Question box',p:{radius:50}});
  tText('Type your question here...',0.5,0.55,{font:'Outfit',size:56,bold:false,color:'#64748b'});
  tText('I\'ll answer your questions all day today!',0.5,0.72,{font:'Instrument Serif',size:74,bold:false,italic:true,color:'#ffffff'});
  tText('@yourname',0.5,0.9,{font:'Outfit',size:58,color:'#fde047'});
}},
{name:'Motivation Monday',cat:'Social',tags:'motivation monday inspire quote story positive',w:1080,h:1920,build(){
  tGrad('#111827','#1f2937',180);
  tShape('ellipse',.5,.3,1,1,'#f59e0b',{name:'Sun'}).opacity=.25;
  tShape('ellipse',.5,.3,.55,.55,'#f59e0b',{name:'Sun core'}).opacity=.6;
  tText('MOTIVATION',0.5,0.14,{font:'Outfit',size:70,color:'#fbbf24'});
  tText('MONDAY',0.5,0.25,{font:'Big Shoulders Display',size:330,color:'#ffffff'});
  tRule(.5,.37,.4,'#fbbf24',5);
  tText('"Start where you are.\nUse what you have.\nDo what you can."',0.5,0.55,{font:'Gloock',size:92,bold:false,color:'#ffffff',lh:1.3});
  tText('— ARTHUR ASHE',0.5,0.72,{font:'Outfit',size:46,color:'#fbbf24'});
  tText('Share this with someone who needs it',0.5,0.9,{font:'Instrument Serif',size:60,bold:false,italic:true,color:'#d1d5db'});
}},
{name:'Event ticket promo',cat:'Social',tags:'ticket event promo post conference webinar',w:1080,h:1350,build(){
  tGrad('#134e4a','#042f2e',170);
  tCustom('ticket',.5,.42,.9,.5,'#fef3c7',{name:'Ticket'});
  tText('ADMIT ONE',0.5,0.27,{font:'Outfit',size:44,color:'#134e4a'});
  tText('TECH SUMMIT\n2026',0.5,0.42,{font:'Big Shoulders Display',size:150,color:'#134e4a',lh:.9});
  tText('KEYNOTES • WORKSHOPS • NETWORKING',0.5,0.55,{font:'Outfit',size:34,color:'#0f766e'});
  tText('REGISTER FREE',0.5,0.76,{font:'Erica One',size:110,bold:false,color:'#fef3c7'});
  tText('12 – 13 MARCH  •  CONFERENCE CENTRE, ACCRA\nwww.techsummit.com',0.5,0.86,{font:'Outfit',size:40,bold:false,color:'#99f6e4',lh:1.5});
}}
);
