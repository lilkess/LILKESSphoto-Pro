/* ===== Upscaler (built-in plugin): enlarge pictures up to 6x with edge-aware detail rebuilding. Original code, offline. ===== */
const UP_MODES={
 'Standard':{sh:45,dn:25,fc:10,rc:0,gr:8,fa:0,shock:0.2,desc:'Balanced, for most photos'},
 'High Fidelity':{sh:25,dn:5,fc:0,rc:0,gr:5,fa:0,shock:0,desc:'Already sharp, big pictures; keeps everything as it is'},
 'Low Res':{sh:55,dn:45,fc:55,rc:25,gr:10,fa:0,shock:0.3,desc:'Small or heavily compressed files'},
 'Art and CG':{sh:55,dn:30,fc:35,rc:0,gr:0,fa:0,shock:0.8,desc:'Drawings, logos, game art: crisp clean edges'},
 'Text and Shapes':{sh:70,dn:35,fc:45,rc:0,gr:0,fa:0,shock:1,desc:'Scans, documents and graphics'},
 'Recover':{sh:65,dn:35,fc:30,rc:70,gr:10,fa:0,shock:0.3,desc:'Old, soft or slightly out-of-focus photos'},
 'Portrait':{sh:40,dn:30,fc:20,rc:15,gr:10,fa:60,shock:0.1,desc:'Faces: smooth skin, crisp eyes and hair'}
};
const UPS={src:null,P:null};
function upBicubic(src,w,h){
  let c=src;
  while(c.width<w*0.999||c.height<h*0.999){const nw=Math.min(w,Math.round(c.width*2)),nh=Math.min(h,Math.round(c.height*2)),t=mkCanvas(nw,nh),x=cctx(t);x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(c,0,0,nw,nh);c=t;}
  if(c.width!==w||c.height!==h){const t=mkCanvas(w,h),x=cctx(t);x.imageSmoothingQuality='high';x.drawImage(c,0,0,w,h);c=t;}
  return c;
}
function upPipeline(srcCv,f,P){
  const sw=srcCv.width,sh=srcCv.height,W=Math.max(1,Math.round(sw*f)),H=Math.max(1,Math.round(sh*f));
  // 1. clean the small picture first (compression blocks and noise are much cheaper to remove before enlarging)
  const sd=cctx(srcCv).getImageData(0,0,sw,sh),d=sd.data,n=sw*sh;
  if(P.fc>0||P.dn>0){
    const r=new Float32Array(n),g=new Float32Array(n),b=new Float32Array(n);
    for(let i=0,j=0;i<n;i++,j+=4){r[i]=d[j];g[i]=d[j+1];b[i]=d[j+2];}
    const k=P.dn/100,c=P.fc/100,rad=Math.max(1,Math.round(Math.max(sw,sh)/900)+(c>0.4?1:0));
    const br=psBlur(r,sw,sh,rad),bg=psBlur(g,sw,sh,rad),bb=psBlur(b,sw,sh,rad);
    for(let y=0,i=0;y<sh;y++)for(let x=0;x<sw;x++,i++){
      const Y=0.299*r[i]+0.587*g[i]+0.114*b[i],Yb=0.299*br[i]+0.587*bg[i]+0.114*bb[i],df=Math.abs(Y-Yb);
      let a=k*Math.exp(-(df*df)/(14*14)); // only flat or noisy areas, never real edges
      const bx=(x&7)<=0||(x&7)===7||(y&7)<=0||(y&7)===7;if(bx)a=Math.max(a,c*0.8*Math.exp(-(df*df)/(22*22)));else a=Math.max(a,c*0.3*Math.exp(-(df*df)/(10*10)));
      a=Math.min(1,a);
      // colour smoothing (blocky chroma is the worst part of a squashed JPEG)
      const cs=Math.min(1,c*1.1),R2=r[i]+(br[i]-r[i])*a,G2=g[i]+(bg[i]-g[i])*a,B2=b[i]+(bb[i]-b[i])*a,Y2=0.299*R2+0.587*G2+0.114*B2;
      const mr=Yb+(br[i]-Yb),j=i*4;d[j]=R2+((Y2+(br[i]-Yb))-R2)*cs*0;d[j]=R2;d[j+1]=G2;d[j+2]=B2;
      if(cs>0){const Cr=(R2-Y2),Cg=(G2-Y2),Cb=(B2-Y2),Yq=Y2,sr=(br[i]-Yb),sg=(bg[i]-Yb),sb=(bb[i]-Yb);d[j]=Yq+Cr+(sr-Cr)*cs*0.7;d[j+1]=Yq+Cg+(sg-Cg)*cs*0.7;d[j+2]=Yq+Cb+(sb-Cb)*cs*0.7;}
    }
    const t=mkCanvas(sw,sh);cctx(t).putImageData(sd,0,0);srcCv=t;
  }
  // 2. enlarge
  const big=upBicubic(srcCv,W,H),bx=cctx(big),id=bx.getImageData(0,0,W,H),o=id.data,N=W*H;
  // 3. rebuild edges on the brightness channel only (keeps colours clean, and it is 3x faster)
  const L=new Float32Array(N),A=new Uint8ClampedArray(N);
  for(let i=0,j=0;i<N;i++,j+=4){L[i]=0.299*o[j]+0.587*o[j+1]+0.114*o[j+2];A[i]=o[j+3];}
  const dL=new Float32Array(N),fs=Math.max(1,f);
  const pass=(rad,amt,edgeOnly)=>{
    if(amt<=0)return;const bl=psBlur(L,W,H,rad),gm=new Float32Array(N);
    for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){const i=y*W+x,gx=bl[i+1]-bl[i-1],gy=bl[i+W]-bl[i-W];gm[i]=Math.hypot(gx,gy);}
    for(let i=0;i<N;i++){const det=L[i]-bl[i],m=edgeOnly?Math.min(1,gm[i]/10):0.35+0.65*Math.min(1,gm[i]/10);dL[i]+=det*amt*m;}
  };
  const s=P.sh/100,rc=P.rc/100;
  pass(Math.max(1,Math.round(fs*0.55)),s*1.5,true);
  if(rc>0){pass(Math.max(1,Math.round(fs*1.2)),rc*1.3,true);pass(Math.max(1,Math.round(fs*2.4)),rc*0.8,true);}
  // shock filter: pulls soft edges toward the nearby dark or bright side so lines get thin and crisp
  let Lc=L;
  if(P.shock>0){
    const bl=psBlur(L,W,H,Math.max(1,Math.round(fs*0.7))),mn=new Float32Array(N),mx=new Float32Array(N),rr=Math.max(1,Math.round(fs*0.8));
    const tmpMin=new Float32Array(N),tmpMax=new Float32Array(N);
    for(let y=0;y<H;y++){const o2=y*W;for(let x=0;x<W;x++){let a=255,b2=0;for(let k=-rr;k<=rr;k++){const v=L[o2+Math.min(W-1,Math.max(0,x+k))];if(v<a)a=v;if(v>b2)b2=v;}tmpMin[o2+x]=a;tmpMax[o2+x]=b2;}}
    for(let x=0;x<W;x++)for(let y=0;y<H;y++){let a=255,b2=0;for(let k=-rr;k<=rr;k++){const yy=Math.min(H-1,Math.max(0,y+k))*W+x;if(tmpMin[yy]<a)a=tmpMin[yy];if(tmpMax[yy]>b2)b2=tmpMax[yy];}mn[y*W+x]=a;mx[y*W+x]=b2;}
    for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){const i=y*W+x,gm=Math.hypot(bl[i+1]-bl[i-1],bl[i+W]-bl[i-W]),w2=Math.min(1,gm/18)*P.shock;if(w2<=0.02)continue;
      const lap=bl[i-1]+bl[i+1]+bl[i-W]+bl[i+W]-4*bl[i],target=lap>0?mn[i]:mx[i];dL[i]+=(target-L[i])*w2*0.55*Math.min(1,Math.abs(lap)/6);}
  }
  // clamp against halos: result must stay inside the local range
  {const rr=Math.max(1,Math.round(fs*0.5));let mn=new Float32Array(N),mx=new Float32Array(N);
    const tmpMin=new Float32Array(N),tmpMax=new Float32Array(N);
    for(let y=0;y<H;y++){const o2=y*W;for(let x=0;x<W;x++){let a=255,b2=0;for(let k=-rr;k<=rr;k++){const v=L[o2+Math.min(W-1,Math.max(0,x+k))];if(v<a)a=v;if(v>b2)b2=v;}tmpMin[o2+x]=a;tmpMax[o2+x]=b2;}}
    for(let x=0;x<W;x++)for(let y=0;y<H;y++){let a=255,b2=0;for(let k=-rr;k<=rr;k++){const yy=Math.min(H-1,Math.max(0,y+k))*W+x;if(tmpMin[yy]<a)a=tmpMin[yy];if(tmpMax[yy]>b2)b2=tmpMax[yy];}mn[y*W+x]=a;mx[y*W+x]=b2;}
    const over=1+0.06*(1+P.rc/100);
    for(let i=0;i<N;i++){const t=L[i]+dL[i],lo=mn[i]-(mx[i]-mn[i])*(over-1),hi=mx[i]+(mx[i]-mn[i])*(over-1);dL[i]=(t<lo?lo:t>hi?hi:t)-L[i];}}
  // 4. face recovery: smooth skin, keep eyes and hair
  let skin=null;
  if(P.fa>0){skin=new Float32Array(N);const k=P.fa/100,bR=new Float32Array(N),bG=new Float32Array(N),bB=new Float32Array(N);
    for(let i=0,j=0;i<N;i++,j+=4){bR[i]=o[j];bG[i]=o[j+1];bB[i]=o[j+2];}
    const rad=Math.max(1,Math.round(Math.max(W,H)*0.003)),r2=psBlur(bR,W,H,rad),g2=psBlur(bG,W,H,rad),b2=psBlur(bB,W,H,rad);
    for(let i=0,j=0;i<N;i++,j+=4){const Y=L[i],cb=128-0.1687*o[j]-0.3313*o[j+1]+0.5*o[j+2],cr=128+0.5*o[j]-0.4187*o[j+1]-0.0813*o[j+2],
      sk=Math.max(0,1-Math.max(Math.abs(cb-102)/26,Math.abs(cr-150)/26,Y<35?1:0)),Yb=0.299*r2[i]+0.587*g2[i]+0.114*b2[i],df=Math.abs(Y-Yb),a=Math.min(1,k*sk*Math.exp(-(df*df)/(16*16))*1.1);
      if(a>0){o[j]+=(r2[i]-o[j])*a;o[j+1]+=(g2[i]-o[j+1])*a;o[j+2]+=(b2[i]-o[j+2])*a;dL[i]*=1-a*0.8;}}}
  // 5. write back, add a little fine grain so it does not look like plastic
  const gk=P.gr/100*9;
  for(let y=0,i=0,j=0;y<H;y++)for(let x=0;x<W;x++,i++,j+=4){const dl=dL[i],nz=gk?(fxHash(x,y,5)-0.5)*gk*Math.min(1,Math.abs(L[i]-128)<110?1:0.4):0,v=dl+nz;
    o[j]=psClamp(o[j]+v);o[j+1]=psClamp(o[j+1]+v);o[j+2]=psClamp(o[j+2]+v);o[j+3]=A[i];}
  bx.putImageData(id,0,0);return big;
}
function upSource(kind){
  if(kind==='layer'){const l=active();if(!l||!l.canvas)return null;ensureRaster(l);const c=mkCanvas(l.canvas.width,l.canvas.height);cctx(c).drawImage(l.canvas,0,0);return c;}
  return flatCanvas(1,null);
}
function openUpscaler(){
  if(!doc){toast('Open a picture first');return;}
  const MAXMP=36;let kind='image',mode='Standard',f=2;const P=Object.assign({},UP_MODES[mode]);
  modalOpen('Upscaler','<div class="ps"><div class="psv"><canvas id="up-cv"></canvas><div class="row psb"><button id="up-hold">Hold: normal resize</button><span class="muted" id="up-pv"></span></div><p class="muted">The preview shows the centre of the picture at full size.</p></div><div class="psc">'
   +'<label class="opt">Upscale <select id="up-src"><option value="image">Whole picture</option><option value="layer">Selected layer only</option></select></label>'
   +'<div class="h">Size</div><div class="pschips" id="up-f">'+[1.5,2,3,4,6].map(v=>'<button class="chip'+(v===2?' on':'')+'" data-f="'+v+'">'+v+'x</button>').join('')+'</div><p class="muted" id="up-info"></p>'
   +'<label class="opt">Preset <select id="up-mode">'+Object.keys(UP_MODES).map(k=>'<option>'+k+'</option>').join('')+'</select></label><p class="muted" id="up-desc"></p>'
   +[['sh','Sharpen'],['dn','Remove noise'],['fc','Fix compression'],['rc','Recover detail'],['gr','Add fine grain'],['fa','Face recovery']].map(a=>'<label class="sl"><span>'+a[1]+'</span><input type="range" data-up="'+a[0]+'" min="0" max="100" value="0"><output>0</output></label>').join('')
   +'<label class="opt">Result <select id="up-out"><option value="doc">Open as new picture</option><option value="png">Download PNG</option><option value="jpg">Download JPG</option></select></label></div></div>',
   [{label:'Cancel'},{label:'Upscale',primary:true,cb:()=>{if(UPS.go)UPS.go();return false;}}],root=>{
    const cv=root.querySelector('#up-cv'),cx=cv.getContext('2d');let tm=0,pvBig=null,pvSimple=null,src=upSource(kind);
    const q=id=>root.querySelector(id);
    const fit=()=>{let ff=f;const mp=src.width*src.height*ff*ff/1e6;if(mp>MAXMP)ff=Math.sqrt(MAXMP*1e6/(src.width*src.height));return ff;};
    const info=()=>{const ff=fit(),w=Math.round(src.width*ff),h=Math.round(src.height*ff);q('#up-info').textContent=src.width+' x '+src.height+'  ->  '+w+' x '+h+' ('+(w*h/1e6).toFixed(1)+' MP)'+(ff<f?'  - limited to '+MAXMP+' MP':'');};
    const syncUI=()=>{root.querySelectorAll('[data-up]').forEach(i=>{i.value=P[i.dataset.up];i.nextElementSibling.textContent=i.value;});q('#up-desc').textContent=UP_MODES[mode].desc+'. This is classical edge-aware enlarging, not a neural network. Added detail is estimated, not real, and the original stays untouched (the result opens as a new picture).';};
    const preview=()=>{const ff=fit(),cw=Math.max(8,Math.min(src.width,Math.ceil(460/ff)+12)),ch=Math.max(8,Math.min(src.height,Math.ceil(340/ff)+12)),sx=Math.max(0,Math.round(src.width/2-cw/2)),sy=Math.max(0,Math.round(src.height/2-ch/2)),crop=mkCanvas(cw,ch);
      cctx(crop).drawImage(src,sx,sy,cw,ch,0,0,cw,ch);const w=Math.round(cw*ff),h=Math.round(ch*ff);
      try{pvBig=upPipeline(crop,ff,P);}catch(e){console.error(e);return;}pvSimple=upBicubic(crop,w,h);cv.width=w;cv.height=h;cx.drawImage(pvBig,0,0);q('#up-pv').textContent='';};
    const later=()=>{clearTimeout(tm);tm=setTimeout(preview,120);};
    const setMode=m=>{mode=m;Object.keys(P).forEach(k=>delete P[k]);Object.assign(P,UP_MODES[m]);syncUI();later();};
    root.addEventListener('input',e=>{const t=e.target;if(t.dataset.up){P[t.dataset.up]=+t.value;t.nextElementSibling.textContent=t.value;later();}});
    q('#up-mode').onchange=e=>setMode(e.target.value);
    q('#up-src').onchange=e=>{kind=e.target.value;src=upSource(kind);if(!src){toast('Select a layer first');return;}info();later();};
    q('#up-f').addEventListener('click',e=>{const b=e.target.closest('[data-f]');if(!b)return;f=+b.dataset.f;root.querySelectorAll('#up-f .chip').forEach(c=>c.classList.toggle('on',c===b));info();later();});
    const hb=q('#up-hold');hb.addEventListener('pointerdown',()=>{if(pvSimple)cx.drawImage(pvSimple,0,0);});['pointerup','pointerleave','pointercancel'].forEach(ev=>hb.addEventListener(ev,()=>{if(pvBig)cx.drawImage(pvBig,0,0);}));
    UPS.go=go;function go(){
      const ff=fit(),out=q('#up-out').value,s2=src;toast('Upscaling '+Math.round(s2.width*ff)+' x '+Math.round(s2.height*ff)+'... please wait');closeModal();
      setTimeout(async()=>{try{
        const big=upPipeline(s2,ff,P),base=fileBase?fileBase(doc.name||'image'):'image';
        if(out==='doc'){const ppi=doc.ppi||72;newBlank(base+' '+(Math.round(ff*10)/10)+'x',big.width,big.height,ppi,'transparent');const l=active();cctx(l.canvas).drawImage(big,0,0);touch(l);commit('Upscaled');redraw();toast('Done. Opened as a new picture');}
        else{const blob=await new Promise(r=>big.toBlob(r,out==='png'?'image/png':'image/jpeg',0.95));await saveBlob(blob,base+'-'+(Math.round(ff*10)/10)+'x.'+out);toast('Done');}
      }catch(e){console.error(e);toast('Could not upscale this one (too large for this device?)');}},40);
    }
    syncUI();info();preview();
  },{wide:true});
}
ACT.upscaler=openUpscaler;
{const pm=MENUS.find(m=>m.label==='Plugins');if(pm){const d=Object.getOwnPropertyDescriptor(pm,'items'),g=d.get;Object.defineProperty(pm,'items',{get(){const a=g.call(pm);const i=a.findIndex(x=>x.label==='Mockup Batch...');a.splice(i>=0?i:1,0,al('Upscaler (enlarge up to 6x)...','','upscaler'));return a;}});}}
PLUG_BUILTIN.push({name:'Upscaler',version:'1.0',desc:'Enlarge pictures up to 6x with edge-aware detail rebuilding, noise and compression cleanup, and models for photos, art, text and portraits. Works on this device, no internet.',open:'upscaler'});
