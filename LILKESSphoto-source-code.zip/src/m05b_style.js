
/* ===== patterns (procedural tiles, used by Pattern Overlay, Pattern Stamp and Fill with pattern) ===== */
const PATTERNS=[
  ['dots','Dots'],['stripes','Stripes'],['diag','Diagonal lines'],['checker','Checkerboard'],['grid','Grid'],['hatch','Cross hatch'],
  ['waves','Waves'],['bricks','Bricks'],['zigzag','Zigzag'],['plaid','Plaid'],['stars','Stars'],['hearts','Hearts'],['noise','Paper grain'],['hex','Hexagons'],['circles','Circles'],['carbon','Carbon fibre']
];
const patCache={};
function PATTERN_TILE(id){
  if(patCache[id])return patCache[id];
  const n=64,c=mkCanvas(n,n),x=c.getContext('2d');
  x.strokeStyle='#000';x.fillStyle='#000';x.lineWidth=4;
  switch(id){
    case 'dots':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.fillStyle='#222';[[16,16],[48,48]].forEach(p=>{x.beginPath();x.arc(p[0],p[1],8,0,7);x.fill();});break;
    case 'stripes':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.fillStyle='#222';x.fillRect(0,0,n,16);x.fillRect(0,32,n,16);break;
    case 'diag':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#222';x.lineWidth=6;for(let i=-n;i<2*n;i+=16){x.beginPath();x.moveTo(i,n);x.lineTo(i+n,0);x.stroke();}break;
    case 'checker':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.fillStyle='#222';x.fillRect(0,0,32,32);x.fillRect(32,32,32,32);break;
    case 'grid':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#222';x.lineWidth=3;x.strokeRect(0,0,n,n);break;
    case 'hatch':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#333';x.lineWidth=2;for(let i=-n;i<2*n;i+=8){x.beginPath();x.moveTo(i,n);x.lineTo(i+n,0);x.moveTo(i,0);x.lineTo(i+n,n);x.stroke();}break;
    case 'waves':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#222';x.lineWidth=4;for(let y=8;y<n+16;y+=16){x.beginPath();for(let i=0;i<=n;i+=2)x.lineTo(i,y+Math.sin(i/n*Math.PI*2)*5);x.stroke();}break;
    case 'bricks':x.fillStyle='#b5523b';x.fillRect(0,0,n,n);x.strokeStyle='#e9dcc9';x.lineWidth=3;for(let r=0;r<4;r++){const y=r*16;x.beginPath();x.moveTo(0,y);x.lineTo(n,y);x.stroke();const o=r%2?0:16;for(let i=o;i<=n+32;i+=32){x.beginPath();x.moveTo(i,y);x.lineTo(i,y+16);x.stroke();}}break;
    case 'zigzag':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#222';x.lineWidth=4;for(let y=8;y<n+16;y+=16){x.beginPath();for(let i=0;i<=n;i+=8)x.lineTo(i,y+(i/8%2?6:-6));x.stroke();}break;
    case 'plaid':x.fillStyle='#d94b4b';x.fillRect(0,0,n,n);x.fillStyle='rgba(20,20,60,.55)';x.fillRect(0,8,n,16);x.fillRect(8,0,16,n);x.fillStyle='rgba(255,255,255,.5)';x.fillRect(0,40,n,3);x.fillRect(40,0,3,n);break;
    case 'stars':x.fillStyle='#14213d';x.fillRect(0,0,n,n);x.fillStyle='#fcd34d';[[16,16,9],[48,48,9]].forEach(p=>{x.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,k=i%2?0.42:1;x.lineTo(p[0]+Math.cos(a)*k*p[2],p[1]+Math.sin(a)*k*p[2]);}x.closePath();x.fill();});break;
    case 'hearts':x.fillStyle='#ffe4ec';x.fillRect(0,0,n,n);x.fillStyle='#e0457b';[[16,18],[48,50]].forEach(p=>{x.beginPath();x.moveTo(p[0],p[1]+8);x.bezierCurveTo(p[0]-14,p[1]-2,p[0]-8,p[1]-14,p[0],p[1]-5);x.bezierCurveTo(p[0]+8,p[1]-14,p[0]+14,p[1]-2,p[0],p[1]+8);x.fill();});break;
    case 'noise':{x.fillStyle='#e9e4d8';x.fillRect(0,0,n,n);const id=x.getImageData(0,0,n,n),d=id.data;let sd=7;for(let i=0;i<d.length;i+=4){sd=(sd*1103515245+12345)&0x7fffffff;const v=(sd%40)-20;d[i]+=v;d[i+1]+=v;d[i+2]+=v;}x.putImageData(id,0,0);break;}
    case 'hex':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#222';x.lineWidth=3;for(let r=-1;r<4;r++)for(let q=-1;q<3;q++){const cx=q*37.6+(r%2?18.8:0),cy=r*21.7;x.beginPath();for(let i=0;i<6;i++){const a=Math.PI/6+i*Math.PI/3;x.lineTo(cx+Math.cos(a)*21.7,cy+Math.sin(a)*21.7);}x.closePath();x.stroke();}break;
    case 'circles':x.fillStyle='#fff';x.fillRect(0,0,n,n);x.strokeStyle='#222';x.lineWidth=3;x.beginPath();x.arc(32,32,26,0,7);x.stroke();x.beginPath();x.arc(32,32,13,0,7);x.stroke();break;
    case 'carbon':x.fillStyle='#16181c';x.fillRect(0,0,n,n);x.fillStyle='#2b2f36';for(let i=0;i<n;i+=16)for(let j=0;j<n;j+=16)if(((i+j)/16)%2===0){x.fillRect(i,j,15,7);x.fillRect(i,j+8,15,7);}else{x.fillRect(i,j,7,15);x.fillRect(i+8,j,7,15);}break;
    default:x.fillStyle='#fff';x.fillRect(0,0,n,n);
  }
  patCache[id]=c;return c;
}
function patternCanvas(id,w,h,scale){
  const t=PATTERN_TILE(id),c=mkCanvas(w,h),x=c.getContext('2d'),k=(scale||100)/100;
  const p=x.createPattern(t,'repeat');p.setTransform&&p.setTransform(new DOMMatrix().scale(k));
  x.fillStyle=p;x.fillRect(0,0,w,h);return c;
}

/* ===== Layer Style dialog (Blending Options, Bevel, Stroke, shadows, glows, satin, overlays) ===== */
const BLEND_OPTS=[['source-over','Normal'],['multiply','Multiply'],['screen','Screen'],['overlay','Overlay'],['soft-light','Soft light'],['hard-light','Hard light'],['color-dodge','Colour dodge'],['color-burn','Colour burn'],['darken','Darken'],['lighten','Lighten'],['difference','Difference'],['exclusion','Exclusion'],['hue','Hue'],['saturation','Saturation'],['color','Colour'],['luminosity','Luminosity']];
const R_=(k,label,min,max,step)=>({t:'r',k,label,min,max,step:step||1});
const C_=(k,label)=>({t:'c',k,label});
const SEL_=(k,label,opts)=>({t:'s',k,label,opts});
const CK_=(k,label)=>({t:'k',k,label});
const LS_SECS=[
  {k:'bevel',n:'Bevel & Emboss',c:[SEL_('style','Style',[['inner','Inner bevel'],['outer','Outer bevel'],['emboss','Emboss'],['pillow','Pillow emboss']]),SEL_('technique','Technique',[['smooth','Smooth'],['chisel','Chisel hard']]),R_('depth','Depth',1,500),SEL_('dir','Direction',[['up','Up'],['down','Down']]),R_('size','Size',0,100),R_('soften','Soften',0,16),R_('angle','Angle',-180,180),R_('altitude','Altitude',0,90),C_('hiColor','Highlight colour'),SEL_('hiBlend','Highlight mode',BLEND_OPTS),R_('hiOp','Highlight opacity',0,1,0.01),C_('shColor','Shadow colour'),SEL_('shBlend','Shadow mode',BLEND_OPTS),R_('shOp','Shadow opacity',0,1,0.01)]},
  {k:'stroke',n:'Stroke',c:[R_('w','Size',1,120),SEL_('pos','Position',[['outside','Outside'],['inside','Inside'],['center','Center']]),SEL_('blend','Blend mode',BLEND_OPTS),R_('op','Opacity',0,1,0.01),C_('color','Colour')]},
  {k:'ishadow',n:'Inner Shadow',c:[SEL_('blend','Blend mode',BLEND_OPTS),C_('color','Colour'),R_('op','Opacity',0,1,0.01),R_('angle','Angle',-180,180),R_('dist','Distance',0,150),R_('choke','Choke',0,100),R_('size','Size',0,150),R_('noise','Noise',0,100)]},
  {k:'iglow',n:'Inner Glow',c:[SEL_('blend','Blend mode',BLEND_OPTS),C_('color','Colour'),R_('op','Opacity',0,1,0.01),SEL_('source','Source',[['edge','Edge'],['center','Center']]),R_('choke','Choke',0,100),R_('size','Size',0,150),R_('noise','Noise',0,100)]},
  {k:'satin',n:'Satin',c:[SEL_('blend','Blend mode',BLEND_OPTS),C_('color','Colour'),R_('op','Opacity',0,1,0.01),R_('angle','Angle',-180,180),R_('dist','Distance',0,150),R_('size','Size',0,150),CK_('invert','Invert')]},
  {k:'overlay',n:'Color Overlay',c:[SEL_('blend','Blend mode',BLEND_OPTS),C_('color','Colour'),R_('op','Opacity',0,1,0.01)]},
  {k:'grad',n:'Gradient Overlay',c:[SEL_('blend','Blend mode',BLEND_OPTS),R_('op','Opacity',0,1,0.01),{t:'g',k:'stops',label:'Gradient'},SEL_('style','Style',[['linear','Linear'],['radial','Radial'],['angle','Angle'],['reflected','Reflected'],['diamond','Diamond']]),R_('angle','Angle',-180,180),R_('scale','Scale',10,300),CK_('reverse','Reverse')]},
  {k:'pat',n:'Pattern Overlay',c:[SEL_('blend','Blend mode',BLEND_OPTS),R_('op','Opacity',0,1,0.01),{t:'p',k:'id',label:'Pattern'},R_('scale','Scale',10,500)]},
  {k:'glow',n:'Outer Glow',c:[SEL_('blend','Blend mode',BLEND_OPTS),R_('op','Opacity',0,1,0.01),C_('color','Colour'),R_('spread','Spread',0,100),R_('size','Size',0,150),R_('noise','Noise',0,100)]},
  {k:'shadow',n:'Drop Shadow',c:[SEL_('blend','Blend mode',BLEND_OPTS),C_('color','Colour'),R_('op','Opacity',0,1,0.01),R_('angle','Angle',-180,180),R_('dist','Distance',0,150),R_('spread','Spread',0,100),R_('size','Size',0,150),R_('noise','Noise',0,100),CK_('knock','Layer knocks out drop shadow')]}
];
function lsNormalize(f){
  for(const sec of LS_SECS){
    const cur=f[sec.k]||{},d=fxr_defaults(sec.k)||{};
    if(sec.k==='shadow'&&cur.dx!==undefined&&cur.dist===undefined){cur.dist=Math.round(Math.hypot(cur.dx,cur.dy));cur.angle=Math.round(Math.atan2(cur.dy,-cur.dx)*180/Math.PI);delete cur.dx;delete cur.dy;}
    if((sec.k==='shadow'||sec.k==='glow')&&cur.blur!==undefined&&cur.size===undefined){cur.size=cur.blur;delete cur.blur;}
    f[sec.k]=Object.assign({},d,cur,{on:!!cur.on});
  }
  return f;
}
function gradCss(stops,rev){
  const st=[...stops].sort((a,b)=>a.p-b.p);if(rev)st.reverse();
  return 'linear-gradient(90deg,'+st.map(s=>s.c+' '+Math.round((rev?1-s.p:s.p)*100)+'%').join(',')+')';
}
function openLayerStyle(startSec){
  const l=active();if(!l){toast('Select a layer first');return;}
  const backup={fx:clone(l.fx),op:l.opacity,fill:l.fillOp,blend:l.blend};
  const f=lsNormalize(clone(l.fx)||{});l.fx=f;
  let sel=startSec||S.lsSel||'blend';S.lsSel=sel;
  const secOf=k=>LS_SECS.find(s=>s.k===k);
  const order=['blend'].concat(LS_SECS.map(s=>s.k));
  const nav=()=>order.map(k=>{
    if(k==='blend')return '<div role="button" tabindex="0" class="lsn'+(sel==='blend'?' on':'')+'" data-s="blend"><span class="lsn-sp"></span>Blending Options</div>';
    const sc=secOf(k);return '<div role="button" tabindex="0" class="lsn'+(sel===k?' on':'')+'" data-s="'+k+'"><input type="checkbox" data-on="'+k+'"'+(f[k].on?' checked':'')+' aria-label="'+sc.n+' on or off"> '+sc.n+'</div>';
  }).join('');
  const ctl=(sk,c)=>{
    const v=f[sk][c.k],id='ls-'+sk+'-'+c.k;
    if(c.t==='r')return '<label class="sl"><span>'+c.label+'</span><input type="range" data-s="'+sk+'" data-k="'+c.k+'" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'" value="'+v+'"><output>'+(+v).toFixed(c.step<1?2:0).replace(/\.00$/,'')+'</output></label>';
    if(c.t==='c')return '<label class="sl"><span>'+c.label+'</span><input type="color" data-s="'+sk+'" data-k="'+c.k+'" value="'+v+'"><output></output></label>';
    if(c.t==='s')return '<label class="sl"><span>'+c.label+'</span><select data-s="'+sk+'" data-k="'+c.k+'" class="lsw">'+c.opts.map(o=>'<option value="'+o[0]+'"'+(o[0]===v?' selected':'')+'>'+o[1]+'</option>').join('')+'</select><output></output></label>';
    if(c.t==='k')return '<label class="row"><input type="checkbox" data-s="'+sk+'" data-k="'+c.k+'"'+(v?' checked':'')+'> '+c.label+'</label>';
    if(c.t==='g')return '<div class="gedit" data-s="'+sk+'"><div class="gbarwrap"><div class="gbar" data-gopen="1" title="Click to edit the gradient" style="background:'+gradCss(v,f[sk].reverse)+'"></div></div><div class="row"><button data-gopen="1">Edit gradient...</button><button data-gpre="1">Presets</button></div></div>';
    if(c.t==='p')return '<div class="pgrid" data-s="'+sk+'">'+PATTERNS.map(p=>'<button class="ptile'+(p[0]===v?' on':'')+'" data-pid="'+p[0]+'" title="'+p[1]+'"></button>').join('')+'</div>';
    return '';
  };
  const pane=()=>{
    if(sel==='blend'){
      return '<div class="h">Blending Options</div>'
       +'<label class="sl"><span>Blend mode</span><select id="ls-blend" class="lsw">'+BLEND_OPTS.map(o=>'<option value="'+o[0]+'"'+(o[0]===l.blend?' selected':'')+'>'+o[1]+'</option>').join('')+'</select><output></output></label>'
       +'<label class="sl"><span>Opacity</span><input type="range" id="ls-op" min="0" max="100" value="'+Math.round(l.opacity*100)+'"><output>'+Math.round(l.opacity*100)+'</output></label>'
       +'<div class="h">Advanced</div>'
       +'<label class="sl"><span>Fill opacity</span><input type="range" id="ls-fill" min="0" max="100" value="'+Math.round((l.fillOp==null?1:l.fillOp)*100)+'"><output>'+Math.round((l.fillOp==null?1:l.fillOp)*100)+'</output></label>'
       +'<p class="muted">Fill opacity fades the layer itself but keeps its effects (strokes, glows, shadows) fully visible. It is how you make glass and outline-only text.</p>';
    }
    const sc=secOf(sel);
    return '<div class="h">'+sc.n+'</div><label class="row"><input type="checkbox" data-on="'+sel+'"'+(f[sel].on?' checked':'')+'> <b>Enable '+sc.n+'</b></label>'+sc.c.map(c=>ctl(sel,c)).join('')
      +'<div class="row"><button data-lsreset="'+sel+'">Reset to default</button></div>';
  };
  const body='<div class="ls"><nav class="ls-nav" id="ls-nav">'+nav()+'</nav><div class="ls-pane" id="ls-pane">'+pane()+'</div></div>';
  const redrawPane=()=>{$('#ls-nav').innerHTML=nav();$('#ls-pane').innerHTML=pane();paintPatterns();};
  const paintPatterns=()=>{$$('.ptile').forEach(b=>{b.style.backgroundImage='url('+PATTERN_TILE(b.dataset.pid).toDataURL()+')';});};
  const live=()=>{l.fxv=(l.fxv||0)+1;redraw();refreshLayers();};
  modalOpen('Layer Style - '+l.name,body,[
    {label:'Cancel'},
    {label:'OK',primary:true,cb:()=>{modalCancel=null;if(!hasFx(l.fx))l.fx=null;touch(l);commit('Layer style');renderProps();}}
  ],root=>{
    modalCancel=()=>{l.fx=backup.fx;l.opacity=backup.op;l.fillOp=backup.fill;l.blend=backup.blend;l._fc=null;redraw();refreshLayers();};
    paintPatterns();
    const setOn=(k,v)=>{f[k].on=v;live();};
    root.onclick=e=>{
      const gd=e.target.closest('[data-gdel]'),ga=e.target.closest('[data-gadd]'),pt=e.target.closest('[data-pid]'),rs=e.target.closest('[data-lsreset]');
      const go=e.target.closest('[data-gopen]'),gp=e.target.closest('[data-gpre]');
      if(go||gp){openGradEditor(fxToGrad(f.grad),g=>{const o=gradToFx(g);f.grad.stops=o.stops;f.grad.model=g;f.grad.on=true;redrawPane();live();});return;}
      if(pt){f.pat.id=pt.dataset.pid;f.pat.on=true;redrawPane();live();return;}
      if(rs){const k=rs.dataset.lsreset;f[k]=Object.assign({},fxr_defaults(k),{on:f[k].on});redrawPane();live();return;}
      const on=e.target.closest('[data-on]');
      if(on&&e.target.tagName==='INPUT'){setOn(on.dataset.on,e.target.checked);if(sel!==on.dataset.on){sel=on.dataset.on;S.lsSel=sel;}redrawPane();return;}
      const nb=e.target.closest('.lsn');
      if(nb&&nb.dataset.s!==sel){sel=nb.dataset.s;S.lsSel=sel;redrawPane();}
    };
    root.oninput=e=>{
      const t=e.target,s=t.dataset.s,k=t.dataset.k;
      if(t.id==='ls-op'){l.opacity=t.value/100;t.nextElementSibling.textContent=t.value;live();return;}
      if(t.id==='ls-fill'){l.fillOp=t.value/100;t.nextElementSibling.textContent=t.value;live();return;}
      if(t.id==='ls-blend'){l.blend=t.value;live();return;}
      if(t.dataset.gs!==undefined){
        const st=f.grad.stops[+t.dataset.gs];
        if(t.dataset.gk==='c')st.c=t.value;else st.p=t.value/100;
        $('.gbar',root).style.background=gradCss(f.grad.stops,f.grad.reverse);f.grad.on=true;live();return;
      }
      if(!s)return;
      f[s][k]=t.type==='checkbox'?t.checked:t.type==='range'?+t.value:t.value;
      if(t.type==='range'&&t.nextElementSibling)t.nextElementSibling.textContent=(+t.value).toFixed((+t.step)<1?2:0).replace(/\.00$/,'');
      if(!f[s].on&&!(s==='grad'&&k==='reverse')){f[s].on=true;const cb=$('input[data-on="'+s+'"]',root);if(cb)cb.checked=true;const nv=$('.lsn[data-s="'+s+'"] input',root);if(nv)nv.checked=true;}
      if(s==='grad'&&k==='reverse')$('.gbar',root).style.background=gradCss(f.grad.stops,f.grad.reverse);
      live();
    };
    root.onchange=root.oninput;
  },{wide:true,side:true});
}
