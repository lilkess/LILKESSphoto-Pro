/* ===== Background Remover: auto cut-out + paint Keep / Remove strokes that re-run GrabCut on just that area ===== */
S.bgr={mode:'keep',shift:0,feather:1,red:true,subject:'auto'};
let BR=null;
/* labels for cut__grabcut: 0 hard bg, 1 hard fg, 2 probable bg, 3 probable fg */
function brLayer(){const l=active();if(!l||!isPixelLayer(l)||l.type==='adjust'){toast('Select a photo layer first');return null;}if(l.locked){toast('This layer is locked');return null;}return l;}
function brInit(l){
  if(BR&&BR.lid===l.id&&BR.cv===l.canvas.width+'x'+l.canvas.height)return BR;
  if(BR)brRestore();
  ensureRaster(l);
  const W=l.canvas.width,H=l.canvas.height;
  BR={lid:l.id,cv:W+'x'+H,W,H,raw:null,pr:null,sk:null,sd:null,stack:[],origMask:l.mask||null,origEdit:l.editMask,busy:false,tint:null,hist:0};
  return BR;
}
function brRestore(){const l=doc&&doc.layers.find(x=>BR&&x.id===BR.lid);if(l){l.mask=BR.origMask;l.editMask=BR.origEdit;l.mver++;touch(l);}BR=null;}
function brPrep(){if(!BR.pr){const l=doc.layers.find(x=>x.id===BR.lid);BR.pr=cut__prepare(l.canvas,0,0,BR.W,BR.H,640);BR.sk=new Uint8Array(BR.pr.w*BR.pr.h);BR.sd=new Uint8Array(BR.pr.w*BR.pr.h);}return BR.pr;}
function brPush(){BR.stack.push({raw:BR.raw?new Uint8ClampedArray(BR.raw):null,sk:BR.sk?new Uint8Array(BR.sk):null,sd:BR.sd?new Uint8Array(BR.sd):null});if(BR.stack.length>10)BR.stack.shift();}

/* ---- find people: face (browser FaceDetector if it exists, else skin-colour blobs), then grow head, hair and body with GrabCut ---- */
async function brPerson(canvas){
  const W=canvas.width,H=canvas.height,pr=cut__prepare(canvas,0,0,W,H,640),w=pr.w,h=pr.h,N=w*h;
  const sc=cut__resize(canvas,w,h),d=cctx(sc).getImageData(0,0,w,h).data;
  let faces=[];
  if(typeof window.FaceDetector==='function'){try{const fd=new window.FaceDetector({fastMode:true,maxDetectedFaces:6}),res=await fd.detect(sc);faces=res.map(f=>({x:f.boundingBox.x,y:f.boundingBox.y,w:f.boundingBox.width,h:f.boundingBox.height})).filter(f=>f.w>w*0.04);}catch(e){faces=[];}}
  if(!faces.length){
    const sk=new Uint8Array(N);
    for(let i=0;i<N;i++){const r=d[i*4],g=d[i*4+1],b=d[i*4+2],Y=0.299*r+0.587*g+0.114*b,cb=128-0.168736*r-0.331264*g+0.5*b,cr=128+0.5*r-0.418688*g-0.081312*b;
      sk[i]=((Y>40&&cb>=77&&cb<=130&&cr>=133&&cr<=178&&r>b)||(Y>18&&Y<=90&&cr>=130&&cr<=170&&cb>=88&&cb<=125&&r>=g&&g>=b*0.9))?1:0;}
    const k2=cut__dilate(cut__erode(sk,w,h,1),w,h,1),cc=cut__components(k2,w,h,true),bb=[];
    for(let k=0;k<=cc.n;k++)bb.push({x0:1e9,y0:1e9,x1:-1,y1:-1});
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=cc.id[y*w+x];if(k){const q=bb[k];if(x<q.x0)q.x0=x;if(x>q.x1)q.x1=x;if(y<q.y0)q.y0=y;if(y>q.y1)q.y1=y;}}
    let c=[];for(let k=1;k<=cc.n;k++){const q=bb[k],bw=q.x1-q.x0+1,bh=q.y1-q.y0+1,a=cc.area[k];
      if(a>=0.004*N&&bh/bw>0.6&&bh/bw<2.1&&a/(bw*bh)>0.45&&q.y0<h*0.75)c.push({x:q.x0,y:q.y0,w:bw,h:Math.min(bh,Math.round(bw*1.3)),a});}
    c.sort((u,v)=>v.a-u.a);if(c.length)faces=c.filter(f=>f.a>=c[0].a*0.5).slice(0,4);
  }
  if(!faces.length)return null;
  const lbl=new Uint8Array(N).fill(2),bw0=Math.max(2,Math.round(Math.min(w,h)*0.012));
  const ell=(cx,cy,rx,ry,v)=>{for(let y=Math.max(0,Math.floor(cy-ry));y<=Math.min(h-1,Math.ceil(cy+ry));y++)for(let x=Math.max(0,Math.floor(cx-rx));x<=Math.min(w-1,Math.ceil(cx+rx));x++){if(((x-cx)/rx)**2+((y-cy)/ry)**2<=1&&(v===1||lbl[y*w+x]!==1))lbl[y*w+x]=v;}};
  const trap=(ytop,wtop,ybot,wbot,cx,v)=>{for(let y=Math.max(0,Math.round(ytop));y<h&&y<=ybot;y++){const t=(y-ytop)/Math.max(1,ybot-ytop),hw=(wtop+(wbot-wtop)*Math.min(1,t))/2;for(let x=Math.max(0,Math.round(cx-hw));x<=Math.min(w-1,Math.round(cx+hw));x++)if(v===1||lbl[y*w+x]!==1)lbl[y*w+x]=v;}};
  for(const f of faces){const cx=f.x+f.w/2,chin=f.y+f.h;
    ell(cx,f.y+f.h*0.3,f.w*0.9,f.h*0.95,3);          // hair and head
    trap(chin-f.h*0.1,f.w*2.0,h-1,f.w*3.6,cx,3);       // shoulders and body
    ell(cx,f.y+f.h*0.55,f.w*0.28,f.h*0.3,1);          // face core
    trap(chin+f.h*0.1,f.w*0.5,Math.min(h-1,chin+f.h*1.1),f.w*0.9,cx,1); // neck and chest core
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(lbl[i]===2){const r=d[i*4],g=d[i*4+1],b=d[i*4+2],cr=128+0.5*r-0.418688*g-0.081312*b,cb=128-0.168736*r-0.331264*g+0.5*b;if(cr>=133&&cr<=175&&cb>=77&&cb<=128&&Math.hypot(x-cx,y-f.y)<f.w*3.2)lbl[i]=3;}}} // arms and hands
  for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(Math.min(x,y,w-1-x,h-1-y)<bw0&&!(y>h-1-bw0&&lbl[y*w+x]===1))lbl[y*w+x]=0;
  const m=cut__runGC(pr.lab,w,h,lbl,null,{});
  // keep only the pieces that touch the head/body cores
  const cc=cut__components(m,w,h,true),good=new Set();for(let i=0;i<N;i++)if(lbl[i]===1&&m[i])good.add(cc.id[i]);
  for(let i=0;i<N;i++)if(m[i]&&!good.has(cc.id[i]))m[i]=0;
  let cnt=0;for(let i=0;i<N;i++)cnt+=m[i];if(cnt<0.01*N)return null;
  return {alpha:cut__finalize(m,w,h,pr.full,W,H,{feather:1}),faces:faces.length};
}
async function brDetect(canvas,kind){
  if(kind==='person'||kind==='auto'){try{const r=await brPerson(canvas);if(r)return {alpha:r.alpha,how:'person',n:r.faces};}catch(e){console.error(e);}}
  const r=cut_removeBackground(canvas,{subject:kind==='object'?'center':'auto'});return {alpha:r.alpha,how:'object',fallback:kind==='person'};
}
function brAuto(){
  const l=brLayer();if(!l)return;brInit(l);toast(S.bgr.subject==='person'?'Looking for people...':'Finding the subject...');
  setTimeout(async()=>{try{brPush();const r=await brDetect(l.canvas,S.bgr.subject);BR.raw=r.alpha;brPrep();BR.sk.fill(0);BR.sd.fill(0);brShow();
    toast(r.how==='person'?'Found '+(r.n>1?r.n+' people':'a person')+'. Paint green where it missed, red where background is left.':(r.fallback?'No person found, so I used general detection. ':'')+'Done. Paint green where it missed the subject, red where background is left.');}
    catch(e){console.error(e);toast('Could not find a subject. Paint over it with the green brush.');}},40);
}
function brDisc(m,w,h,cx,cy,r){const R=Math.ceil(r);for(let y=Math.max(0,Math.floor(cy-R));y<=Math.min(h-1,cy+R);y++)for(let x=Math.max(0,Math.floor(cx-R));x<=Math.min(w-1,cx+R);x++)if((x-cx)**2+(y-cy)**2<=r*r)m[y*w+x]=1;}
function brStroke(l,pts,keep,radiusLocal){
  brInit(l);const pr=brPrep(),w=pr.w,h=pr.h,N=w*h,sx=w/BR.W,sy=h/BR.H,rr=Math.max(1.5,radiusLocal*sx);
  brPush();
  const seed=new Uint8Array(N);
  for(let i=0;i<pts.length;i++){const a=pts[i];if(i){const b=pts[i-1],d=Math.hypot(a.x-b.x,a.y-b.y)*sx,n=Math.max(1,Math.ceil(d/(rr*0.5)));for(let k=1;k<=n;k++)brDisc(seed,w,h,(b.x+(a.x-b.x)*k/n)*sx,(b.y+(a.y-b.y)*k/n)*sy,rr);}else brDisc(seed,w,h,a.x*sx,a.y*sy,rr);}
  const tgt=keep?BR.sk:BR.sd,oth=keep?BR.sd:BR.sk;
  for(let i=0;i<N;i++)if(seed[i]){tgt[i]=1;oth[i]=0;}
  // prior
  const lbl=new Uint8Array(N),prior=new Uint8Array(N);
  if(BR.raw){const up=cut__resize(cut_alphaToCanvas(BR.raw,BR.W,BR.H),w,h),d=cctx(up).getImageData(0,0,w,h).data;for(let i=0;i<N;i++)prior[i]=d[i*4+3]>127?1:0;}
  const dist=cut__dist(seed,w,h),zone=Math.max(rr*3.2,14);
  if(BR.raw){for(let i=0;i<N;i++)lbl[i]=prior[i]?3:2;
    for(let i=0;i<N;i++){if(dist[i]<=zone){if(keep&&!prior[i])lbl[i]=3;if(!keep&&prior[i])lbl[i]=2;}}}
  else{ // no auto result yet: the area around the green stroke is the guess, everything else is background
    let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(let i=0;i<N;i++)if(BR.sk[i]){const x=i%w,y=(i/w)|0;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
    if(x1<0){x0=y0=0;x1=w;y1=h;}
    const mg=Math.max(24,Math.round(Math.max(x1-x0,y1-y0)*0.9));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++)lbl[y*w+x]=(x>=x0-mg&&x<=x1+mg&&y>=y0-mg&&y<=y1+mg)?3:0;}
  for(let i=0;i<N;i++){if(BR.sk[i])lbl[i]=1;else if(BR.sd[i])lbl[i]=0;}
  const init=BR.raw?null:cut__autoInit(pr.lab,w,h,'auto');
  let tb=null;if(init&&init.flat){tb=new Float32Array(N);for(let i=0;i<N;i++)tb[i]=init.T[i]>3?Math.min(6,(init.T[i]-3)*3):0;}
  const m=cut__runGC(pr.lab,w,h,lbl,tb,{});
  // keep the green strokes' connected blob only when starting from nothing
  if(!BR.raw){const cc=cut__components(m,w,h,true),good=new Set();for(let i=0;i<N;i++)if(BR.sk[i]&&m[i])good.add(cc.id[i]);for(let i=0;i<N;i++)if(m[i]&&!good.has(cc.id[i]))m[i]=0;}
  const fin=cut__finalize(m,w,h,pr.full,BR.W,BR.H,{feather:1});
  if(!BR.raw){BR.raw=fin;}
  else{ // only change pixels near the stroke; leave the rest of the earlier result exactly as it was
    const zn=new Uint8Array(N);for(let i=0;i<N;i++)zn[i]=dist[i]<=zone*1.6?255:0;
    const zs=cut__upsample(cut__box(Float32Array.from(zn),w,h,2),w,h,BR.W,BR.H),raw=BR.raw;
    for(let i=0;i<raw.length;i++){const k=zs[i]/255;if(k>0)raw[i]=raw[i]*(1-k)+fin[i]*k;}}
  brShow();
}
/* edge refinement (shift = grow / shrink, feather = soften) then show as the layer mask */
function brEdge(){
  const {W,H}=BR,N=W*H;let a=BR.raw;const sh=Math.round(S.bgr.shift),fe=Math.round(S.bgr.feather);
  let out=a;
  if(sh!==0){const m=new Uint8Array(N);for(let i=0;i<N;i++)m[i]=a[i]>127?1:0;const mm=sh>0?cut__dilate(m,W,H,sh):cut__erode(m,W,H,-sh);out=new Uint8ClampedArray(N);for(let i=0;i<N;i++)out[i]=mm[i]?Math.max(a[i],mm[i]&&!m[i]?255:a[i]):0;if(sh>0)for(let i=0;i<N;i++)if(mm[i])out[i]=255;}
  if(fe>0&&(sh!==0||fe>1)){const f=Float32Array.from(out),b=cut__box(f,W,H,fe);out=new Uint8ClampedArray(N);for(let i=0;i<N;i++)out[i]=b[i];}
  return out;
}
let brT=0;
function brShow(){clearTimeout(brT);brT=setTimeout(()=>{if(!BR||!BR.raw)return;const l=doc.layers.find(x=>x.id===BR.lid);if(!l)return;
  BR.out=brEdge();const m=cut_alphaToCanvas(BR.out,BR.W,BR.H);
  if(BR.origMask){const x=cctx(m);x.globalCompositeOperation='destination-in';x.drawImage(BR.origMask,0,0,m.width,m.height);}
  l.mask=m;l.editMask=false;l.mver++;touch(l);
  // red tint of what was removed
  const t=mkCanvas(BR.W,BR.H),tx=cctx(t),id=tx.createImageData(BR.W,BR.H),d=id.data,o=BR.out;for(let i=0;i<o.length;i++){d[i*4]=255;d[i*4+1]=40;d[i*4+2]=60;d[i*4+3]=(255-o[i])*0.45;}tx.putImageData(id,0,0);BR.tint=layerToDocCanvas(l,t);BR.tintL=[l.x,l.y,l.r,l.s];
  redraw();},30);}
function brFinish(kind){
  if(!BR||!BR.raw){toast('Remove the background first: tap Auto or paint over the subject');return;}
  const l=doc.layers.find(x=>x.id===BR.lid);if(!l)return;
  const out=BR.out||brEdge(),m=cut_alphaToCanvas(out,BR.W,BR.H);
  if(BR.origMask){const x=cctx(m);x.globalCompositeOperation='destination-in';x.drawImage(BR.origMask,0,0,m.width,m.height);}
  l.mask=m;l.editMask=false;l.mver++;
  if(kind==='cut'){const x=l.canvas.getContext('2d');x.save();x.globalCompositeOperation='destination-in';x.drawImage(m,0,0,l.canvas.width,l.canvas.height);x.restore();l.mask=null;}
  touch(l);BR=null;commit(kind==='cut'?'Remove background (cut out)':'Remove background');refreshLayers();renderOpts();redraw();
  toast(kind==='cut'?'Background removed. The picture is now a transparent cut-out.':'Background hidden with a layer mask. Paint the mask white or black to touch up.');
}
ACT.brAuto=brAuto;ACT.brSubAuto=()=>{S.bgr.subject='auto';renderOpts();};ACT.brSubPerson=()=>{S.bgr.subject='person';renderOpts();};ACT.brSubObject=()=>{S.bgr.subject='object';renderOpts();};
ACT.brKeep=()=>{S.bgr.mode='keep';renderOpts();};ACT.brDrop=()=>{S.bgr.mode='drop';renderOpts();};
ACT.brUndo=()=>{if(!BR||!BR.stack.length){toast('Nothing to undo');return;}const s=BR.stack.pop();BR.raw=s.raw;BR.sk=s.sk;BR.sd=s.sd;if(BR.raw)brShow();else{const l=doc.layers.find(x=>x.id===BR.lid);l.mask=BR.origMask;l.mver++;touch(l);BR.tint=null;redraw();}};
ACT.brReset=()=>{if(!BR)return;brRestore();redraw();renderOpts();toast('Reset');};
ACT.brApply=()=>brFinish('mask');ACT.brCut=()=>brFinish('cut');
ACT.brCancel=()=>{brRestore();setTool('move');redraw();};
ACT.brRed=()=>{S.bgr.red=!S.bgr.red;renderOpts();redraw();};
TOOLS.bgremove={
  opts:()=>'<span class="seg brseg"><button data-act="brKeep" class="'+(S.bgr.mode==='keep'?'on':'')+'" title="Paint over the subject">&#10010; Keep</button><button data-act="brDrop" class="'+(S.bgr.mode==='drop'?'on':'')+'" title="Paint over background left behind">&#8722; Remove</button></span>'
    +'<span class="seg brseg"><button data-act="brSubAuto" class="'+(S.bgr.subject==='auto'?'on':'')+'" title="People first, then any main object">Auto</button><button data-act="brSubPerson" class="'+(S.bgr.subject==='person'?'on':'')+'" title="Look for people (face, hair, body)">People</button><button data-act="brSubObject" class="'+(S.bgr.subject==='object'?'on':'')+'" title="Main object in the middle">Object</button></span><button class="primary" data-act="brAuto">Detect</button>'+SIZE_OPT()
    +rng('Edge','o-brshift',-20,20,S.bgr.shift)+rng('Soft','o-brfeather',0,20,S.bgr.feather)
    +'<label class="opt"><input type="checkbox" id="o-brred"'+(S.bgr.red?' checked':'')+'> Red view</label>'
    +'<button data-act="brUndo">Undo</button><button data-act="brReset">Reset</button><button class="primary" data-act="brApply">Apply</button><button data-act="brCut">Cut out</button><button data-act="brCancel">Cancel</button>',
  down(p,e){const l=brLayer();if(!l)return;brInit(l);const keep=(S.bgr.mode==='keep')!==!!(e&&e.altKey);drag={k:'x',tool:'bgremove',l,keep,pts:[toLocal(l,p)],dpts:[p]};},
  move(p){const d=drag;if(!d||d.tool!=='bgremove')return;d.pts.push(toLocal(d.l,p));d.dpts.push(p);redraw();},
  over(o,z){
    if(BR&&BR.tint&&S.bgr.red){const l=doc.layers.find(x=>x.id===BR.lid);if(l&&BR.tintL[0]===l.x&&BR.tintL[1]===l.y&&BR.tintL[2]===l.r&&BR.tintL[3]===l.s)o.drawImage(BR.tint,0,0);}
    const d=drag;if(d&&d.tool==='bgremove')overStroke(o,z,d.keep?'rgba(40,220,90,.55)':'rgba(255,50,70,.55)');},
  up(d){const keep=d.keep,l=d.l,pts=d.pts,rad=S.aux.size/2/l.s;toast(keep?'Keeping that area...':'Removing that area...');
    setTimeout(()=>{try{brStroke(l,pts,keep,rad);}catch(e){console.error(e);toast('Could not refine that area');}},30);},
  leave(){if(BR&&BR.raw)brFinish('mask');else if(BR)brRestore();}
};
BRUSHY.bgremove='aux';
Object.assign(ICONS,{bgremove:'<rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="3 2"/><circle cx="12" cy="9" r="3"/><path d="M6 19c0-3 3-5 6-5s6 2 6 5"/>'});
{const g=TOOLGROUPS.find(x=>x.id==='wand');if(g)g.v.splice(2,0,V('bgremove','Remove Background','W','bgremove'));}
CURSORS.bgremove='crosshair';
$('#opts').addEventListener('input',e=>{const t=e.target;if(t.id==='o-brshift'){S.bgr.shift=+t.value;brShow();}else if(t.id==='o-brfeather'){S.bgr.feather=+t.value;brShow();}else if(t.id==='o-brred'){S.bgr.red=t.checked;redraw();}});
/* the old menu command and Quick action now open this tool and run Auto */
ACT.removeBg=()=>{const l=brLayer();if(!l)return;setTool('bgremove');brAuto();};
ACT.removeBgPro=ACT.removeBg;
