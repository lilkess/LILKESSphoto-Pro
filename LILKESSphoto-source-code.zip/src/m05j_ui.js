/* ===== Photoshop-style Color panel, Window menu with check marks, panel tab menu,
   layer context menu (long-press / right-click), Photoshop keyboard shortcuts ===== */

/* ---------- Color panel ---------- */
const CMODELS={
  RGB:{ch:[['R',0,255],['G',0,255],['B',0,255]],get:c=>c,set:v=>v},
  HSB:{ch:[['H',0,360],['S',0,100],['B',0,100]],get:c=>cpRgb2hsv(c[0],c[1],c[2]),set:v=>cpHsv2rgb(v[0],v[1],v[2])},
  CMYK:{ch:[['C',0,100],['M',0,100],['Y',0,100],['K',0,100]],get:c=>cpRgb2cmyk(c[0],c[1],c[2]),set:v=>cpCmyk2rgb(v[0],v[1],v[2],v[3])},
  Lab:{ch:[['L',0,100],['a',-128,127],['b',-128,127]],get:c=>cpRgb2lab(c[0],c[1],c[2]),set:v=>cpLab2rgb(v[0],v[1],v[2])},
  Grayscale:{ch:[['K',0,100]],get:c=>[(1-(0.299*c[0]+0.587*c[1]+0.114*c[2])/255)*100],set:v=>{const g=255*(1-v[0]/100);return [g,g,g];}}
};
S.cmodel='RGB';S.ctarget='fg';
(function(){
  const host=$('#tab-color');
  host.innerHTML='<div class="pcwrap"><div class="pctop"><div class="pcsw" id="pc-sw"><button id="pc-bg" title="Background color" aria-label="Background color"></button><button id="pc-fg" title="Foreground color" aria-label="Foreground color"></button>'
    +'<button class="pcmini" id="pc-def" title="Default colors (D)" aria-label="Default colors">&#9635;</button><button class="pcmini sw2" id="pc-swap" title="Switch colors (X)" aria-label="Switch colors">&#8646;</button></div>'
    +'<div class="pcsl" id="pc-sl"></div></div>'
    +'<div class="pcramp"><canvas id="pc-ramp" width="320" height="44"></canvas></div>'
    +'<div class="pcfoot"><label>Model <select id="pc-model">'+Object.keys(CMODELS).map(k=>'<option>'+k+'</option>').join('')+'</select></label><label>Hex <input type="text" id="cp-hex" maxlength="7" value="#000000" style="width:84px"></label></div></div>';
  const cur=()=>hexRgb(S.ctarget==='bg'?S.bg:S.fg);
  const M=()=>CMODELS[S.cmodel];
  function trackCss(i,vals){
    const m=M(),[,mn,mx]=m.ch[i],n=S.cmodel==='HSB'&&i===0?13:S.cmodel==='Lab'?9:5,st=[];
    for(let k=0;k<=n;k++){const v=vals.slice();v[i]=mn+(mx-mn)*k/n;const c=m.set(v);st.push(rgbHex(c[0],c[1],c[2])+' '+Math.round(k/n*100)+'%');}
    return 'linear-gradient(90deg,'+st.join(',')+')';
  }
  function build(){
    const m=M(),vals=m.get(cur());
    $('#pc-sl').innerHTML=m.ch.map((c,i)=>'<div class="pcs"><span>'+c[0]+'</span><input type="range" data-ci="'+i+'" min="'+c[1]+'" max="'+c[2]+'" step="1" value="'+Math.round(vals[i])+'" style="--tr:'+trackCss(i,vals)+'" aria-label="'+c[0]+'"><input type="number" class="pcn" data-cn="'+i+'" min="'+c[1]+'" max="'+c[2]+'" value="'+Math.round(vals[i])+'"></div>').join('');
  }
  function paintSw(){
    $('#pc-fg').style.background=S.fg;$('#pc-bg').style.background=S.bg;
    $('#pc-fg').classList.toggle('on',S.ctarget==='fg');$('#pc-bg').classList.toggle('on',S.ctarget==='bg');
  }
  function syncVals(skip){
    const m=M(),vals=m.get(cur());
    $$('#pc-sl input[data-ci]').forEach(r=>{const i=+r.dataset.ci;r.style.setProperty('--tr',trackCss(i,vals));if(skip!==r)r.value=Math.round(vals[i]);});
    $$('#pc-sl input[data-cn]').forEach(r=>{const i=+r.dataset.cn;if(document.activeElement!==r)r.value=Math.round(vals[i]);});
    const h=$('#cp-hex');if(document.activeElement!==h)h.value=S.ctarget==='bg'?S.bg:S.fg;
  }
  const _ss=setSwatches;
  setSwatches=function(){_ss();paintSw();syncVals();};
  function apply(vals,skip){
    const c=M().set(vals),hex=rgbHex(c[0],c[1],c[2]);
    if(S.ctarget==='bg')S.bg=hex;else S.fg=hex;
    $('#fgc').value=S.fg;$('#bgc').value=S.bg;paintSw();syncVals(skip);
  }
  host.addEventListener('input',e=>{
    const t=e.target;
    if(t.dataset&&(t.dataset.ci!==undefined||t.dataset.cn!==undefined)){
      const vals=[...$$('#pc-sl input[data-ci]')].map(r=>+r.value);
      if(t.dataset.cn!==undefined){if(t.value==='')return;const i=+t.dataset.cn;vals[i]=cpClamp(+t.value,+t.min,+t.max);}
      apply(vals,t.dataset.ci!==undefined?t:null);
      if(t.dataset.cn!==undefined)$$('#pc-sl input[data-ci]').forEach((r,i)=>{r.value=Math.round(vals[i]);});
    }
  });
  $('#pc-model').addEventListener('change',e=>{S.cmodel=e.target.value;build();});
  $('#cp-hex').addEventListener('change',e=>{const v=e.target.value.trim();if(/^#?[0-9a-f]{6}$/i.test(v)){const h=(v[0]==='#'?v:'#'+v).toLowerCase();if(S.ctarget==='bg')S.bg=h;else S.fg=h;}setSwatches();});
  $('#pc-fg').addEventListener('click',()=>{if(S.ctarget==='fg')openColorPicker(S.fg,'Foreground color',h=>{S.fg=h;setSwatches();});else{S.ctarget='fg';build();setSwatches();}});
  $('#pc-bg').addEventListener('click',()=>{if(S.ctarget==='bg')openColorPicker(S.bg,'Background color',h=>{S.bg=h;setSwatches();});else{S.ctarget='bg';build();setSwatches();}});
  $('#pc-def').addEventListener('click',()=>{S.fg='#000000';S.bg='#ffffff';setSwatches();});
  $('#pc-swap').addEventListener('click',()=>{const t=S.fg;S.fg=S.bg;S.bg=t;setSwatches();});
  // colour ramp (spectrum on top, black to white underneath)
  const rc=$('#pc-ramp'),rx=rc.getContext('2d');
  (function drawRamp(){
    const w=rc.width,h=rc.height,top=30;
    for(let x=0;x<w;x++){const c=cpHsv2rgb(x/(w-1)*360,100,100);rx.fillStyle=rgbHex(c[0],c[1],c[2]);rx.fillRect(x,0,1,top);const g=x/(w-1)*255;rx.fillStyle=rgbHex(g,g,g);rx.fillRect(x,top,1,h-top);}
  })();
  function pickRamp(e){
    const r=rc.getBoundingClientRect(),x=cpClamp(Math.floor((e.clientX-r.left)/r.width*rc.width),0,rc.width-1),y=cpClamp(Math.floor((e.clientY-r.top)/r.height*rc.height),0,rc.height-1);
    const d=rx.getImageData(x,y,1,1).data,hex=rgbHex(d[0],d[1],d[2]);
    if(e.altKey||S.ctarget==='bg')S.bg=hex;else S.fg=hex;setSwatches();
  }
  rc.addEventListener('pointerdown',e=>{e.preventDefault();rc.setPointerCapture(e.pointerId);pickRamp(e);const mv=ev=>pickRamp(ev),up=()=>{rc.removeEventListener('pointermove',mv);rc.removeEventListener('pointerup',up);};rc.addEventListener('pointermove',mv);rc.addEventListener('pointerup',up);});
  build();paintSw();
})();

/* ---------- Window menu: check marks, click again to close a panel ---------- */
const dockOf=id=>PANELS[id]&&(PANELS[id].dock==='A'?DOCK_A:DOCK_B);
const panelOpen=id=>{const a=dockOf(id);return !!a&&a.includes(id);};
function closePanel(id){
  const a=dockOf(id);if(!a||!a.includes(id))return;
  if(a.length<=1){toast('A panel group needs at least one panel');return;}
  a.splice(a.indexOf(id),1);
  const nx=a[Math.max(0,Math.min(a.length-1,0))];
  if(S.tabA===id)S.tabA=a===DOCK_A?nx:S.tabA;if(S.tabB===id)S.tabB=a===DOCK_B?nx:S.tabB;
  buildDockTabs();setTab(a===DOCK_A?S.tabA:S.tabB,false,true);
}
function movePanel(id){
  const p=PANELS[id];if(!p)return;const from=dockOf(id),toD=p.dock==='A'?'B':'A',to=toD==='A'?DOCK_A:DOCK_B;
  if(from.includes(id)){if(from.length<=1){toast('A panel group needs at least one panel');return;}from.splice(from.indexOf(id),1);}
  if(S.tabA===id)S.tabA=DOCK_A.find(x=>x!==id)||S.tabA;if(S.tabB===id)S.tabB=DOCK_B.find(x=>x!==id)||S.tabB;
  p.dock=toD;to.push(id);
  const sec=$('#tab-'+id),body=$('#dock'+toD+' .dbody');if(sec&&body)body.appendChild(sec);
  buildDockTabs();setTab(id,false);
}
function resetWorkspace(){
  PANEL_ORDER.forEach(id=>{const p=PANELS[id];const want=DEFAULT_OPEN.A.includes(id)?'A':DEFAULT_OPEN.B.includes(id)?'B':p.dock;if(p.dock!==want){p.dock=want;const sec=$('#tab-'+id),body=$('#dock'+want+' .dbody');if(sec&&body)body.appendChild(sec);}});
  DOCK_A.length=0;DOCK_A.push(...DEFAULT_OPEN.A);DOCK_B.length=0;DOCK_B.push(...DEFAULT_OPEN.B);
  S.tabA='color';S.tabB='layers';buildDockTabs();setTab('layers',false,true);toast('Workspace reset to Essentials');
}
ACT.resetWorkspace=resetWorkspace;
(function(){
  const M=MENUS.find(m=>m.label==='Window');
  const byName={};PANEL_ORDER.forEach(id=>{byName[PANELS[id].name]=id;});
  const fix=items=>items.forEach(it=>{
    if(it.items){fix(it.items);return;}
    const id=byName[it.label];
    if(id){it.check=()=>panelOpen(id);it.fn=()=>{if(panelOpen(id)&&S[(PANELS[id].dock==='A'?'tabA':'tabB')]===id&&!isMobile())closePanel(id);else openPanel(id);};}
  });
  fix(M.items);
  const hideIdx=M.items.findIndex(it=>it.label==='Hide or show panels');
  M.items.splice(hideIdx>=0?hideIdx:M.items.length,0,al('Reset workspace (Essentials)','',()=>resetWorkspace()),al('Panel groups: move this panel to the other side','',()=>movePanel(S.tab)));
  // F-key and other panel shortcuts need to be registered again because the Window menu was rebuilt
  const walk=its=>its.forEach(it=>{if(it.items)walk(it.items);else if(it.key){SHORT[it.key.replace(/^Ctrl\+Shift\+Alt\+/,'Ctrl+Alt+Shift+')]=it;}});
  walk(M.items);
})();
// right-click or long-press on a panel tab
(function(){
  const showTab=(btn,x,y)=>{
    const id=btn.dataset.tab,p=PANELS[id];if(!p)return;
    showCtx(x,y,[{label:'Close panel',fn:()=>closePanel(id)},{label:'Move to the '+(p.dock==='A'?'bottom':'top')+' panel group',fn:()=>movePanel(id)},{sep:true},{label:'Reset workspace',fn:resetWorkspace}]);
  };
  $('#docks').addEventListener('contextmenu',e=>{const b=e.target.closest('.dtabs button[data-tab]');if(!b)return;e.preventDefault();showTab(b,e.clientX,e.clientY);});
  let tm=0,sx=0,sy=0,tb=null;
  $('#docks').addEventListener('pointerdown',e=>{const b=e.target.closest('.dtabs button[data-tab]');if(!b||e.pointerType==='mouse')return;tb=b;sx=e.clientX;sy=e.clientY;clearTimeout(tm);tm=setTimeout(()=>{if(tb){showTab(tb,sx,sy);tb=null;}},550);});
  document.addEventListener('pointermove',e=>{if(tb&&Math.hypot(e.clientX-sx,e.clientY-sy)>8){clearTimeout(tm);tb=null;}});
  document.addEventListener('pointerup',()=>{clearTimeout(tm);tb=null;});
})();

/* ---------- context menu helper ---------- */
function showCtx(x,y,items){
  closeMenus();
  const w=document.createElement('div');w.className='menu ctxm';w.setAttribute('role','menu');
  buildItems(items,w);document.body.appendChild(w);
  const r=w.getBoundingClientRect();
  w.style.left=Math.max(4,Math.min(x,innerWidth-r.width-6))+'px';w.style.top=Math.max(4,Math.min(y,innerHeight-r.height-6))+'px';
  const off=e=>{if(!e.target.closest||!e.target.closest('.ctxm')){closeMenus();document.removeEventListener('pointerdown',off,true);}};
  setTimeout(()=>document.addEventListener('pointerdown',off,true),0);
  return w;
}

/* ---------- layer context menu: right-click on a computer, long-press on a phone ---------- */
(function(){
  const box=$('#layerlist');
  const L=()=>doc&&doc.layers;
  const run=(l,name,arg)=>()=>{selectLayer(l.id);if(typeof name==='function')name();else ACT[name](arg);};
  function layerItems(l){
    const isTxt=l.type==='text',isShape=l.type==='shape',isAdj=l.type==='adjust';
    const items=[
      {label:'Blending Options...',fn:run(l,'lsOpen','blend')},
      {label:'Layer Style...',fn:run(l,'lstyle')},{sep:true},
      {label:'Duplicate Layer',fn:run(l,'ldup')},{label:'Delete Layer',fn:run(l,'ldel')},{sep:true},
      {label:'Copy Layer Style',fn:run(l,'lcopyfx'),dis:()=>!hasFx(l.fx)},{label:'Paste Layer Style',fn:run(l,'lpastefx')},{label:'Clear Layer Style',fn:run(l,'lclearfx'),dis:()=>!hasFx(l.fx)},{sep:true}
    ];
    if(isTxt||isShape||l.smart)items.push({label:'Rasterize Layer',fn:run(l,'rasterize')});
    if(!isAdj&&!l.smart)items.push({label:'Convert to Smart Object',fn:run(l,'toSmart')});
    if(l.smart)items.push({label:'Edit Contents',fn:run(l,'smartEdit')});
    if(isTxt)items.push({label:'Convert to Shape',fn:run(l,'textToShape')});
    items.push({label:l.clip?'Release Clipping Mask':'Create Clipping Mask',fn:run(l,'clipToggle')});
    items.push({label:l.mask?'Delete Layer Mask':'Add Layer Mask',fn:run(l,l.mask?'maskDel':'maskReveal')});
    items.push({label:'Select Pixels',fn:run(l,'selLayer')},{sep:true},
      {label:'Merge Down',fn:run(l,'lmerge')},{label:'Merge Visible',fn:run(l,'mergeVisible')},{label:'Flatten Image',fn:run(l,'flatten')},{sep:true},
      {label:l.locked?'Unlock Layer':'Lock Layer',fn:run(l,'lockToggle')},{label:l.visible?'Hide Layer':'Show Layer',fn:run(l,'visToggle')},{sep:true},
      {label:'Bring to Front',fn:run(l,'lfront')},{label:'Bring Forward',fn:run(l,'lfwd')},{label:'Send Backward',fn:run(l,'lbwd')},{label:'Send to Back',fn:run(l,'lback')});
    return items;
  }
  function boardItems(i){
    const b=bl()[i],pick=fn=>()=>{S.bsel=i;refreshLayers();fn();};
    return [
      {label:'Rename Artboard',fn:()=>{const nm=box.querySelector('.brow[data-bi="'+i+'"] .nm');if(nm)nm.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));}},
      {label:'Zoom to Artboard',fn:pick(()=>ACT.boardFit())},{label:'Add Artboard',fn:pick(()=>ACT.boardAdd())},
      {label:'Duplicate Artboard',fn:pick(()=>ACT.boardDup())},{sep:true},
      {label:'Export Artboard as PNG',fn:pick(()=>ACT.boardExport())},{label:'Export All Artboards',fn:()=>ACT.boardExportAll()},{sep:true},
      {label:'Delete Artboard',fn:pick(()=>ACT.boardDel())}
    ];
  }
  function openFor(target,x,y){
    if(!doc)return false;
    const brow=target.closest('.brow'),row=target.closest('.lrow');
    if(brow){showCtx(x,y,boardItems(+brow.dataset.bi));return true;}
    if(row){const l=L().find(q=>q.id===+row.dataset.id);if(!l)return false;selectLayer(l.id);showCtx(x,y,layerItems(l));return true;}
    return false;
  }
  box.addEventListener('contextmenu',e=>{e.preventDefault();openFor(e.target,e.clientX,e.clientY);});
  let tm=0,sx=0,sy=0,tg=null;
  box.addEventListener('pointerdown',e=>{
    if(e.pointerType==='mouse')return;tg=e.target;sx=e.clientX;sy=e.clientY;clearTimeout(tm);
    tm=setTimeout(()=>{
      if(!tg)return;const t=tg;tg=null;
      if(box.querySelector('.lrow.dragging'))return;
      document.dispatchEvent(new Event('pointercancel'));
      if(openFor(t,sx,sy)&&navigator.vibrate)try{navigator.vibrate(18);}catch(err){}
    },560);
  });
  document.addEventListener('pointermove',e=>{if(tg&&Math.hypot(e.clientX-sx,e.clientY-sy)>9){clearTimeout(tm);tg=null;}});
  document.addEventListener('pointerup',()=>{clearTimeout(tm);tg=null;});
  document.addEventListener('pointercancel',()=>{clearTimeout(tm);tg=null;});
  // Alt+click on the eye shows only that layer (click again to bring the others back)
  let solo=null;
  box.addEventListener('click',e=>{
    const eye=e.target.closest('.lrow [data-a=vis]');
    if(eye&&e.altKey&&doc){
      e.stopPropagation();e.preventDefault();flush();
      const id=+eye.closest('.lrow').dataset.id;
      if(solo&&solo.id===id){doc.layers.forEach(l=>{if(solo.v[l.id]!==undefined)l.visible=solo.v[l.id];});solo=null;}
      else{solo={id,v:{}};doc.layers.forEach(l=>{solo.v[l.id]=l.visible;l.visible=l.id===id;});}
      commit('Show only one layer');redraw();return;
    }
    // Ctrl+click on a layer loads its pixels as a selection
    const row=e.target.closest('.lrow');
    if(row&&(e.ctrlKey||e.metaKey)&&doc&&!e.target.closest('button')){
      e.stopPropagation();e.preventDefault();selectLayer(+row.dataset.id);ACT.selLayer();
    }
  },true);
  // double-click anywhere on a layer row except the name opens Layer Style
  box.addEventListener('dblclick',e=>{
    const row=e.target.closest('.lrow');if(!row||e.target.closest('.nm,button,input'))return;
    selectLayer(+row.dataset.id);ACT.lsOpen('blend');
  });
})();

/* ---------- Photoshop keyboard shortcuts (Windows) ---------- */
(function(){
  const add=(k,label,fn,dis)=>{if(!SHORT[k])SHORT[k]={label,fn,dis};};
  add('Ctrl+Alt+Z','Step backward',()=>ACT.undo());
  add('Ctrl+Y','Redo',()=>ACT.redo());
  add('Alt+Delete','Fill with foreground colour',()=>ACT.fillFg());
  add('Ctrl+Delete','Fill with background colour',()=>ACT.fillBg());
  add('Ctrl+Alt+Shift+N','New layer (no dialog)',()=>ACT.lnew());
  add('Ctrl+Alt+Shift+E','Stamp visible layers',()=>{
    flush();const src=flatDoc(),l=addLayer({name:'Stamp visible',select:true});
    cctx(l.canvas).drawImage(src,0,0);const i=doc.layers.indexOf(l);doc.layers.push(doc.layers.splice(i,1)[0]);doc.active=l.id;touch(l);commit('Stamp visible');
  });
  add('Ctrl+Alt+D','Feather selection',()=>ACT.selFeather());
  add('Ctrl+Alt+F','Open last filter again',()=>ACT.lastFilter());
  add('Ctrl+Alt+0','Actual pixels (100%)',()=>ACT.z100());
  add('Ctrl+H','Show or hide guides, grid and extras',()=>ACT.guidesToggle());
  add('Shift+Tab','Hide or show panels (keep tools)',()=>togglePanels());
  add('F5','Brush settings panel',()=>openPanel('brushset'));
  add('F6','Color panel',()=>openPanel('color'));
  add('F8','Info panel',()=>openPanel('info'));
  add('Alt+F9','Actions panel',()=>openPanel('actions'));
  add('Ctrl+Alt+Shift+W','Export as...',()=>ACT.exportAs());
  add('Ctrl+Alt+Shift+S','Export as... (Save for web)',()=>ACT.exportAs());
  add('Ctrl+Shift+Alt+Z','Step forward',()=>ACT.redo());
  add('Ctrl+Alt+A','Select all layers (selects the top layer)',()=>{if(doc&&doc.layers.length)selectLayer(doc.layers[doc.layers.length-1].id);});
  add('Ctrl+Shift+T','Transform again (free transform)',()=>ACT.transform());
  add('F12','Revert to the first history state',()=>{if(doc)jumpTo(0);});
  // keys without Ctrl, handled before the main handler
  let dBuf=null,dT=0;
  document.addEventListener('keydown',e=>{
    if(!doc||cpOpen||geOpen)return;
    const tg=e.target,typing=tg.tagName==='TEXTAREA'||tg.tagName==='SELECT'||(tg.tagName==='INPUT'&&/text|number|search/.test(tg.type));
    if(typing||!$('#modal').hidden||!$('#welcome').hidden||document.body.classList.contains('fx-open'))return;
    const mod=e.ctrlKey||e.metaKey,code=e.code,a=active(),handled=()=>{e.preventDefault();e.stopImmediatePropagation();};
    if(mod)return;
    // Alt+[ and Alt+] pick the layer below / above, Alt+. and Alt+, pick the top / bottom layer
    if(e.altKey&&!e.shiftKey&&(code==='BracketLeft'||code==='BracketRight'||code==='Period'||code==='Comma')){
      const ls=doc.layers;if(!ls.length)return;let i=a?ls.indexOf(a):ls.length-1;
      if(code==='BracketLeft')i=Math.max(0,i-1);else if(code==='BracketRight')i=Math.min(ls.length-1,i+1);else if(code==='Period')i=ls.length-1;else i=0;
      selectLayer(ls[i].id);handled();return;
    }
    // Shift+[ and Shift+] change brush hardness
    if(e.shiftKey&&!e.altKey&&(code==='BracketLeft'||code==='BracketRight')&&brushLike(S.tool)){
      const o=brushObj(S.tool);if(o){o.hard=clamp(Math.round((o.hard+(code==='BracketRight'?0.25:-0.25))*100)/100,0,1);renderOpts();redraw();handled();return;}
    }
    // Shift and + or - cycle through the layer blend modes
    if(e.shiftKey&&!e.altKey&&(code==='Equal'||code==='Minus')&&a&&!brushLike(S.tool)){
      const ids=BLEND_OPTS.map(o=>o[0]);let i=ids.indexOf(a.blend);if(i<0)i=0;
      i=(i+(code==='Equal'?1:-1)+ids.length)%ids.length;a.blend=ids[i];commit('Blend mode');refreshLayers();toast(BLEND_OPTS[i][1]);handled();return;
    }
    // slash locks transparent pixels
    if(e.key==='/'&&a){a.lk=Object.assign({t:false,i:false,p:false},a.lk);a.lk.t=!a.lk.t;commit(a.lk.t?'Lock transparent pixels':'Unlock transparent pixels');refreshLayers();handled();return;}
    // number keys: opacity of the layer (or of the brush); Shift+number: fill
    if(/^Digit\d$/.test(code)&&!e.altKey){
      const d=+code.slice(5),now=Date.now();
      let val=d===0?100:d*10;
      if(dBuf!==null&&now-dT<650&&!e.shiftKey){val=dBuf*10+d;if(val===0)val=100;}
      dBuf=e.shiftKey?null:d;dT=now;val=cpClamp(val,1,100);
      if(brushLike(S.tool)&&!e.shiftKey){const o=brushObj(S.tool);if(o){o.flow=val/100;renderOpts();toast('Opacity '+val+'%');handled();return;}}
      if(a){if(e.shiftKey){a.fillOp=val/100;toast('Fill '+val+'%');}else{a.opacity=val/100;toast('Opacity '+val+'%');}commit(e.shiftKey?'Fill':'Opacity');refreshLayers();redraw();handled();return;}
    }
  },true);
  // rebuild the lookup so the Help sheet and the menus show every key
  const walk=its=>its.forEach(it=>{if(it.items)walk(it.items);else if(it.key){const k=it.key.replace(/^Ctrl\+Shift\+Alt\+/,'Ctrl+Alt+Shift+');if(!SHORT[k])SHORT[k]=it;}});
  MENUS.forEach(m=>walk(m.items));
})();

/* ---------- Help sheet: every shortcut ---------- */
openHelp=function(){
  const tools=TOOLGROUPS.map(g=>g.v.map(v=>[v.k,v.n]));
  const seen=new Set(),trow=[];tools.flat().forEach(r=>{const k=r[0]+'|'+r[1];if(!seen.has(k)){seen.add(k);trow.push(r);}});
  const keys=Object.entries(SHORT).filter(([k,v])=>!(k==='Ctrl+='||k==='Ctrl+Shift++'));
  const rows=keys.map(([k,v])=>[k.replace(/\+/g,' + ').replace('Ctrl','Ctrl'),v.label]);
  const extra=[['X','Swap foreground and background'],['D','Default colours'],['[ and ]','Brush smaller / bigger'],['Shift + [ or ]','Brush harder / softer'],['0 - 9','Opacity of the layer or brush (10% - 100%)'],['Shift + 0 - 9','Fill of the layer'],['Shift + + or -','Next / previous blend mode'],['Alt + [ or ]','Select layer below / above'],['/','Lock transparent pixels'],['Alt + click the eye','Show only this layer'],['Ctrl + click a layer','Load its pixels as a selection'],['Space (hold)','Hand tool'],['Arrow keys','Nudge with the Move tool (Shift = 10 px)'],['Q','Quick mask'],['F','Screen mode'],['Enter / Esc','Apply / cancel crop and transform']];
  const sec=(t,r)=>'<div class="h">'+t+'</div><div class="keys">'+r.map(x=>'<span><kbd>'+esc(x[0])+'</kbd></span><span>'+esc(x[1])+'</span>').join('')+'</div>';
  modalOpen('Keyboard shortcuts (Photoshop style)',sec('Tools (press the key again to cycle the group)',trow)+sec('While you work',extra)+sec('Menus and panels',rows)+'<p class="muted" style="margin-top:14px">On a Mac use Cmd instead of Ctrl. Phone: pinch to zoom, two fingers to pan, long-press a layer for its menu.</p>',[{label:'Close',primary:true}],null,{wide:true});
};
